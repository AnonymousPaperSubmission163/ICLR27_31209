"""Original-only goals, alternative support routes, and bounded truth maintenance."""
import re
import time
from contextlib import contextmanager
from itertools import product

from route_planned_rag.method.store import Store as V3Store
from route_planned_rag.method.schema import Requirement, signature as digest
from route_planned_rag.indexed.schema import norm
from route_planned_rag.prototype.schemas import Atom
from route_planned_rag.prototype.logic import substitute, unify, key, opposite, ground
from .schema import AcquisitionPlan, AcquisitionRule, TEMPLATES


class EvidenceStore(V3Store):
    def __init__(self, question, program, path, max_bindings=512, spec_version=1, limits=None):
        self.spec_version = spec_version
        self.acquisition = AcquisitionPlan()
        self.use_derived = True
        self.derivations = {}
        self.reverse_dependencies = {}
        self.closure_records = []
        self.closure_signature = None
        self.limits = dict(max_auxiliary=12, max_rules=8, max_depth=3, max_routes=128,
                           max_derived=1024, max_supports=4096, max_rule_matches=20000,
                           rule_cpu_seconds=2.)
        self.limits.update(limits or {})
        self.routes_truncated = False
        super().__init__(question, program, path, max_bindings)

    @property
    def catalog(self):
        return self.plan.needs + self.acquisition.auxiliary

    def pattern(self, i):
        n = self.catalog[i]
        return Atom(predicate='r' + digest([norm(n.r), n.scope]),
                    arguments=[self.term(n.s), self.term(n.o, n.kind)], negated=n.negated)

    def row_atom(self, row):
        n = self.catalog[row['node']]
        return Atom(predicate=self.pattern(row['node']).predicate,
                    arguments=[self.term(row['s']), self.term(row['o'], n.kind)], negated=row['negated'])

    def observe(self, evidence):
        originals = dict(self.evidence)
        for e in evidence:
            eid = e['evidence_id']
            if eid in originals and originals[eid]['original_text'] != e['original_text']:
                raise ValueError('original evidence changed')
            # Re-retrieval cannot resurrect an explicitly withdrawn source.
            if eid not in originals:
                originals[eid] = e
        self.evidence = {eid: e for eid, e in originals.items() if not e.get('withdrawn')}
        super().observe([])
        self.evidence = originals
        self.sync()

    def propose(self, reading, call_id):
        blocked = [r for r in reading.rows if self.evidence.get(r.evidence_id, {}).get('withdrawn')]
        for row in blocked:
            self.rejected.append(dict(row.model_dump(), status='invalid', reason='source_withdrawn'))
        reading = reading.model_copy(update={'rows': [r for r in reading.rows if r not in blocked]})
        # The unchanged v3 admission code sees every acquisition slot. Goals and
        # comparisons always use the original RequirementSpec outside this call.
        original, auxiliary = self.plan, self.acquisition.auxiliary
        self.plan = original.model_copy(update={'needs': self.catalog})
        self.acquisition.auxiliary = []
        try:
            ids = super().propose(reading, call_id)
        finally:
            self.plan = original
            self.acquisition.auxiliary = auxiliary
        for fid in ids:
            self.rows[fid].update(origin='observed', spec_version=self.spec_version)
        self.closure_signature = None
        self.sync()
        return ids

    @contextmanager
    def visibility(self, derived):
        previous = self.use_derived
        self.use_derived = derived
        try:
            yield self
        finally:
            self.use_derived = previous

    def match(self, pattern, binding=None, statuses=('accepted',)):
        hits = super().match(pattern, binding, statuses)
        if not self.use_derived:
            hits = [h for h in hits if all(self.rows[f].get('origin') != 'program_derived' for f in h['facts'])]
        return hits

    def _join_nodes(self, nodes, statuses=('accepted',), partial=False):
        rows = [dict(binding=b, facts=[], missing=[]) for b in self.initial()]
        for node in nodes:
            next_rows = {}
            for row in rows:
                for hit in self.match(self.pattern(node), row['binding'], statuses):
                    item = dict(binding=hit['binding'], facts=sorted(set(row['facts'] + hit['facts'])), missing=row['missing'])
                    sig = digest([item['binding'], item['missing']])
                    old = next_rows.get(sig)
                    if old is None or (len(item['facts']), item['facts']) < (len(old['facts']), old['facts']):
                        next_rows[sig] = item
                if partial:
                    item = dict(row, missing=row['missing'] + [node])
                    next_rows.setdefault(digest([item['binding'], item['missing']]), item)
            rows = list(next_rows.values())
            if len(rows) > self.max_bindings:
                if not partial:
                    raise ValueError('complete_binding_budget_exhausted')
                self.truncated = True
                rows.sort(key=lambda r: (len(r['missing']), -len(r['binding']), digest(r)))
                empty = next((r for r in rows if not r['binding']), None)
                rows = rows[:self.max_bindings]
                if empty and empty not in rows:
                    rows[-1] = empty
        return rows

    def support_routes(self):
        self.routes_truncated = False
        def options(node, seen=(), depth=0):
            result = [(node,)]
            if node in seen or depth >= self.limits['max_depth']:
                return result
            for rule in self.acquisition.rules:
                if rule.head != node or not rule.valid:
                    continue
                for branches in product(*(options(n, seen + (node,), depth + 1) for n in rule.body)):
                    result.append(tuple(dict.fromkeys(n for branch in branches for n in branch)))
                    if len(result) >= self.limits['max_routes']:
                        self.routes_truncated = True
                        return result
            return result
        result = []
        for branches in product(*(options(i) for i in range(len(self.plan.needs)))):
            result.append(tuple(dict.fromkeys(n for branch in branches for n in branch)))
            if len(result) >= self.limits['max_routes']:
                self.routes_truncated = True
                break
        return list(dict.fromkeys(result))

    def joins(self, statuses=('accepted',), partial=False):
        self.lookups += 1
        self.truncated = False
        # Auxiliary obligations are alternatives for particular original needs.
        # Terminal enumeration always joins exactly the original conjunction.
        routes = self.support_routes() if partial else [tuple(range(len(self.plan.needs)))]
        result = {}
        for route in routes:
            for row in self._join_nodes(route, statuses, partial):
                sig = digest([row['binding'], row['missing']])
                previous = result.get(sig)
                if previous is None or (len(row['facts']), row['facts']) < (len(previous['facts']), previous['facts']):
                    result[sig] = row
        rows = list(result.values())
        if len(rows) > self.max_bindings:
            if not partial:
                raise ValueError('complete_binding_budget_exhausted')
            self.truncated = True
            rows.sort(key=lambda r: (len(r['missing']), -len(r['binding']), digest(r)))
            rows = rows[:self.max_bindings]
        return rows

    def add_support(self, proposal):
        if len(self.acquisition.rules) >= self.limits['max_rules']:
            raise ValueError('rule_instance_budget_exhausted')
        if proposal.requirement_id >= len(self.catalog):
            raise ValueError('unknown support target')
        head = self.catalog[proposal.requirement_id]
        template = proposal.template
        if template not in TEMPLATES:
            raise ValueError('undeclared rule template')
        if template != 'explicit_source_rule':
            if head.negated or head.kind != 'place' or not re.fullmatch(r'(?:is )?(?:located|situated|based|headquartered)(?: in(?: (?:the )?(?:city|state|country)(?: of)?)?)?', head.r, re.I):
                raise ValueError('geographic template requires a positive physical-location relation')
            if proposal.conditions or proposal.source_evidence_id or proposal.source_quote:
                raise ValueError('built-in template body is constructed by the program')
            t = TEMPLATES[template]
            level = re.search(r'\bin (?:the )?(city|state|country)(?: of)?$', head.r, re.I)
            if level and level.group(1).lower() != t['container_type']:
                raise ValueError('geographic template changes the required administrative level')
            var = '?aux_' + digest([self.spec_version, len(self.acquisition.rules), proposal.model_dump()])[:10]
            verb = re.search(r'located|situated|based|headquartered', head.r, re.I).group().lower()
            first_relation = verb + ' in '
            body = [Requirement(s=head.s, r=first_relation + t['bridge_type'], o=var, kind='place', subject_kind=head.subject_kind, scope=head.scope, span=head.span),
                    Requirement(s=var, r=t['bridge_type'] + ' in ' + t['container_type'], o=head.o, kind='place', subject_kind='place', scope=head.scope, span=head.span)]
            origin = 'declared_scoped_geographic_template'
        else:
            evidence = self.evidence.get(proposal.source_evidence_id)
            quote = proposal.source_quote or ''
            if not evidence or evidence.get('withdrawn') or not quote or quote not in evidence['original_text']:
                raise ValueError('explicit rule lacks an active exact original span')
            if not re.search(r'\b(?:all|each|every|if|whenever)\b', quote, re.I):
                raise ValueError('source does not explicitly state a conditional/universal rule')
            body = proposal.conditions
            if not body:
                raise ValueError('source rule has no premises')
            if (head.negated or any(n.negated for n in body)) and not re.search(r'\b(?:not|no|never|without|except|excluding)\b', quote, re.I):
                raise ValueError('negative rule literal lacks explicit source negation')
            head_variables = {v for v in (head.s, head.o) if v.startswith('?')}
            local_variables = sorted({v for n in body for v in (n.s, n.o) if v.startswith('?')} - head_variables)
            renamed = {v: '?aux_' + digest([self.spec_version, len(self.acquisition.rules), v])[:10] for v in local_variables}
            body = [n.model_copy(update={'s': renamed.get(n.s, n.s), 'o': renamed.get(n.o, n.o)}) for n in body]
            origin = 'source_rule_extraction_conditional_on_translation'
        if len(self.acquisition.auxiliary) + len(body) > self.limits['max_auxiliary']:
            raise ValueError('auxiliary_budget_exhausted')
        head_vars = {v for v in (head.s, head.o) if v.startswith('?')}
        body_vars = {v for n in body for v in (n.s, n.o) if v.startswith('?')}
        if not head_vars <= body_vars:
            raise ValueError('rule head variable has no premise binding')
        text = self.question + ' ' + ' '.join(e['original_text'] + ' ' + e['source_metadata']['title'] for e in self.evidence.values() if not e.get('withdrawn'))
        types = {}
        for n in [head, *body]:
            if n.scope != head.scope:
                raise ValueError('rule scope mismatch')
            for value, kind in [(n.s, n.subject_kind), (n.o, n.kind)]:
                if value.startswith('?'):
                    if not re.fullmatch(r'\?[a-z][a-z0-9_]{0,25}', value):
                        raise ValueError('invalid rule variable/function term')
                    if value in types and types[value] not in ('entity', kind) and kind != 'entity':
                        raise ValueError('incompatible rule variable types')
                    if kind != 'entity':
                        types[value] = kind
                elif value not in ('true', 'false') and norm(value) not in norm(text):
                    raise ValueError('unsupported rule constant')
        # Require a connected support graph, not an unrelated factual conjunction.
        connected = set((head.s, head.o))
        for _ in body:
            for n in body:
                if connected & {n.s, n.o}:
                    connected.update((n.s, n.o))
        if any(not {n.s, n.o} <= connected for n in body):
            raise ValueError('disconnected auxiliary support')
        start = len(self.catalog)
        rid = 'R' + digest([self.spec_version, proposal.requirement_id, template, body])
        if any(r.head == proposal.requirement_id and r.template == template for r in self.acquisition.rules):
            raise ValueError('duplicate support template for requirement')
        self.acquisition.auxiliary.extend(body)
        rule = AcquisitionRule(id=rid, head=proposal.requirement_id, body=list(range(start, start + len(body))), template=template,
                               spec_version=self.spec_version, origin=origin, source_evidence_id=proposal.source_evidence_id,
                               source_quote=proposal.source_quote, reason=proposal.rationale)
        self.acquisition.rules.append(rule)
        self.closure_signature = None
        return rule

    def _ground_matches(self, nodes, operations, deadline):
        rows = [dict(binding={}, facts=[])]
        for node in nodes:
            following = []
            pattern = self.pattern(node)
            for row in rows:
                target = substitute(pattern, row['binding'])
                for fid, fact in list(self.rows.items()):
                    operations[0] += 1
                    if operations[0] > self.limits['max_rule_matches'] or time.process_time() > deadline:
                        raise ValueError('rule_work_budget_exhausted')
                    if fact['status'] != 'accepted':
                        continue
                    binding = unify(target, self.row_atom(fact), row['binding'])
                    if binding is not None:
                        following.append(dict(binding=binding, facts=sorted(set(row['facts'] + [fid]))))
            rows = following
            if len(rows) > self.max_bindings:
                raise ValueError('rule_binding_budget_exhausted')
        return rows

    def _has_ancestor(self, fid, ancestor, visited=None):
        if fid == ancestor:
            return True
        visited = set() if visited is None else visited
        if fid in visited:
            return False
        visited.add(fid)
        return any(self._has_ancestor(p, ancestor, visited) for d in self.derivations.values()
                   if d['valid'] and d['conclusion'] == fid for p in d['premise_ids'])

    def recompute(self):
        signature = digest([self.spec_version, self.alias_version, self.acquisition, [(f, r['status'], r.get('base_status')) for f, r in self.rows.items() if r.get('origin') != 'program_derived']])
        if signature == self.closure_signature:
            return None
        started = time.process_time()
        deadline = started + self.limits['rule_cpu_seconds']
        operations = [0]
        previous_valid = {s for s, d in self.derivations.items() if d.get('valid')}
        for d in self.derivations.values():
            d['valid'] = False
        for r in self.rows.values():
            if r.get('origin') == 'program_derived':
                r.update(status='invalid', base_status='invalid', depth=None)
        self.detect_conflicts()
        error = None
        try:
            for depth in range(1, self.limits['max_depth'] + 1):
                additions = []
                for rule in self.acquisition.rules:
                    if not rule.valid:
                        continue
                    for match in self._ground_matches(rule.body, operations, deadline):
                        if any(self.rows[f].get('depth', 0) is None or self.rows[f].get('depth', 0) >= depth for f in match['facts']):
                            continue
                        atom = substitute(self.pattern(rule.head), match['binding'])
                        if not ground(atom):
                            raise ValueError('non_ground_rule_conclusion')
                        fid = 'D' + digest([self.spec_version, atom])
                        if fid in match['facts']:
                            continue
                        sid = 'S' + digest([rule.id, match['facts'], self.alias_version])
                        additions.append((fid, sid, atom, rule, match['facts']))
                for fid, sid, atom, rule, premise_ids in additions:
                    if any(self._has_ancestor(p, fid) for p in premise_ids):
                        continue  # No cyclic support, even when another grounded path exists.
                    if sum(r.get('origin') == 'program_derived' for r in self.rows.values()) >= self.limits['max_derived'] and fid not in self.rows:
                        raise ValueError('derived_item_budget_exhausted')
                    if len(self.derivations) >= self.limits['max_supports'] and sid not in self.derivations:
                        raise ValueError('derivation_support_budget_exhausted')
                    n = self.catalog[rule.head]
                    self.rows.setdefault(fid, dict(id=fid, node=rule.head, s=self.names[atom.arguments[0].name], o=self.names[atom.arguments[1].name],
                                                   negated=atom.negated, scope=n.scope, evidence_id=None, quote=None,
                                                   origin='program_derived', spec_version=self.spec_version, extraction_call=None))
                    r = self.rows[fid]
                    r.update(status='accepted', base_status='accepted', reason='bounded_source_supported_rule', depth=min(r.get('depth') or depth, depth))
                    actual_depth = 1 + max(self.rows[p].get('depth', 0) for p in premise_ids)
                    self.derivations[sid] = dict(support_id=sid, conclusion=fid, premise_ids=premise_ids, rule_ids=[rule.id],
                                                spec_version=self.spec_version, alias_version=self.alias_version, depth=actual_depth, valid=True)
                self.detect_conflicts()
                self._invalidate_unsupported()
        except ValueError as exc:
            error = str(exc)
            # Never use a partial closure to certify exact answer cardinality.
            for d in self.derivations.values():
                d['valid'] = False
            for r in self.rows.values():
                if r.get('origin') == 'program_derived':
                    r.update(status='invalid', base_status='invalid')
        self._invalidate_unsupported()
        self.reverse_dependencies = {}
        for sid, d in self.derivations.items():
            for fid in d['premise_ids']:
                self.reverse_dependencies.setdefault(fid, []).append(sid)
        self.version += 1
        self.sync()
        self.closure_signature = signature
        valid = {s for s, d in self.derivations.items() if d['valid']}
        record = dict(cpu_seconds=time.process_time() - started, operations=operations[0], error=error,
                      valid_supports=len(valid), new_supports=sorted(valid - previous_valid), invalidated_supports=sorted(previous_valid - valid),
                      derived_items=sum(r.get('origin') == 'program_derived' and r['status'] == 'accepted' for r in self.rows.values()))
        self.closure_records.append(record)
        return record

    def _invalidate_unsupported(self):
        for _ in range(len(self.derivations) + 1):
            changed = False
            active_rules = {r.id for r in self.acquisition.rules if r.valid}
            for d in self.derivations.values():
                if d['valid'] and (not set(d['rule_ids']) <= active_rules or any(self.rows[f]['status'] != 'accepted' for f in d['premise_ids'])):
                    d['valid'] = False
                    changed = True
            supported = {d['conclusion'] for d in self.derivations.values() if d['valid']}
            for fid, r in self.rows.items():
                if r.get('origin') == 'program_derived' and fid not in supported and r['status'] != 'invalid':
                    r.update(status='invalid', base_status='invalid')
                    changed = True
            if not changed:
                return

    def set_status(self, ids, status, reason):
        if status == 'invalid':
            for fid in ids:
                self.rows[fid].update(status='invalid', base_status='invalid', reason=reason)
            self.version += 1
            self.sync()
        else:
            super().set_status(ids, status, reason)
        self.closure_signature = None
        # Immediate invalidation prevents consumers from observing stale facts
        # between an explicit withdrawal and the next controller iteration.
        self._invalidate_unsupported()
        self.sync()

    def withdraw_evidence(self, evidence_id, reason='source_withdrawn'):
        self.evidence[evidence_id]['withdrawn'] = reason
        ids = [f for f, r in self.rows.items() if r.get('evidence_id') == evidence_id]
        self.set_status(ids, 'invalid', reason)
        self.aliases = {k: v for k, v in self.aliases.items() if v['evidence_id'] != evidence_id}
        self.alias_version += 1
        for rule in self.acquisition.rules:
            if rule.source_evidence_id == evidence_id:
                rule.valid = False
        self.recompute()

    def leaf_facts(self, ids):
        leaves, seen = set(), set()
        def visit(fid):
            if fid in seen:
                return
            seen.add(fid)
            row = self.rows[fid]
            if row['status'] != 'accepted':
                raise ValueError('invalid fact used in answer')
            if row.get('origin') != 'program_derived':
                leaves.add(fid)
            else:
                supports = [d for d in self.derivations.values() if d['conclusion'] == fid and d['valid']]
                if not supports:
                    raise ValueError('derived fact lacks valid grounded support')
                support = min(supports, key=lambda d: (d['depth'], len(d['premise_ids']), d['support_id']))
                for premise in support['premise_ids']:
                    visit(premise)
        for fid in ids:
            visit(fid)
        return sorted(leaves)

    def rule_sources(self, ids):
        sources, visited = {}, set()
        def visit(fid):
            if fid in visited:
                return
            visited.add(fid)
            for support in self.derivations.values():
                if support['conclusion'] != fid or not support['valid']:
                    continue
                for rid in support['rule_ids']:
                    rule = next(r for r in self.acquisition.rules if r.id == rid)
                    if rule.source_evidence_id:
                        sources[rid] = dict(rule_id=rid, evidence_id=rule.source_evidence_id, quote=rule.source_quote,
                                            origin=rule.origin)
                for premise in support['premise_ids']:
                    visit(premise)
        for fid in ids:
            visit(fid)
        return list(sources.values())

    def snapshot(self):
        return dict(super().snapshot(), spec_version=self.spec_version,
                    requirement_spec=self.plan.model_dump(), acquisition_plan=self.acquisition.model_dump(),
                    derivations=self.derivations, reverse_dependencies=self.reverse_dependencies,
                    closure_records=self.closure_records, use_derived=self.use_derived)
