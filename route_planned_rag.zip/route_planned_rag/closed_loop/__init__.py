"""Bounded evidence-driven closed loop for our own method."""
VERSION = "method-closed-loop-v1.2"
