"""The v3 source reader, extended to at most 24 independent acquisition slots."""
from pydantic import Field
from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.logic_control.core import Row
from route_planned_rag.method.reader import slot_schema, SLOT_PROMPT, original_sentences


class AcquisitionRow(Row):
    node: int = Field(ge=0, le=23)


class AcquisitionReading(Strict):
    rows: list[AcquisitionRow] = Field(default_factory=list, max_length=576)
    complete: list[int] = Field(default_factory=list, max_length=24)
    missing: list[str] = Field(default_factory=list, max_length=24)


def slots_to_reading(value, evidence):
    _, sentences = original_sentences(evidence)
    sources = {e['evidence_id']: e['original_text'] for e in evidence}
    rows, unknown, missing = [], [], []
    for name, slot in value.model_dump().items():
        node = int(name[1:])
        for source_row in slot['rows']:
            row = dict(source_row)
            spans = [sentences[sid] for sid in row.pop('sentence_ids')]
            if any(s['evidence_id'] != row['evidence_id'] for s in spans):
                raise ValueError('sentence belongs to another source')
            quote = sources[row['evidence_id']][min(s['start'] for s in spans):max(s['end'] for s in spans)]
            uncertain = row.pop('uncertain', False)
            row.update(node=node, s=row.pop('subject'), o=row.pop('value'), quote=quote)
            if uncertain:
                unknown.append(dict(row, status='unknown', reason='reader_uncertain'))
            else:
                rows.append(row)
        if not slot['rows']:
            missing.append(name + ': ' + slot['check'])
    return AcquisitionReading(rows=rows, missing=missing), unknown
