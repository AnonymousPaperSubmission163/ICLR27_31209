"""Separate question semantics, acquisition rules, and source-grounded state."""
import re
from typing import Literal

from pydantic import Field
from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.method.schema import Program, Requirement, compile_question, signature


TEMPLATES = {
    "city_state": {"meaning": "An entity located in a city in a state is located in that state.", "bridge_type": "city", "container_type": "state"},
    "city_country": {"meaning": "An entity located in a city in a country is located in that country.", "bridge_type": "city", "container_type": "country"},
    "state_country": {"meaning": "An entity located in a state in a country is located in that country.", "bridge_type": "state", "container_type": "country"},
    "explicit_source_rule": {"meaning": "A conditional/universal rule explicitly stated in an observed original. Translation remains a model proposal; no unsourced general axioms."},
}


class SupportProposal(Strict):
    requirement_id: int = Field(ge=0, le=23)
    template: Literal["city_state", "city_country", "state_country", "explicit_source_rule"]
    rationale: str = Field(max_length=400)
    # Used only for an explicit source rule. Built-in templates construct their own body.
    conditions: list[Requirement] = Field(default_factory=list, max_length=3)
    source_evidence_id: str | None = None
    source_quote: str | None = None


class Expansion(Strict):
    explanation: str = Field(max_length=400)
    supports: list[SupportProposal] = Field(default_factory=list, max_length=4)


class AcquisitionRule(Strict):
    id: str
    head: int
    body: list[int]
    template: str
    spec_version: int
    origin: str
    source_evidence_id: str | None = None
    source_quote: str | None = None
    valid: bool = True
    reason: str


class AcquisitionPlan(Strict):
    auxiliary: list[Requirement] = Field(default_factory=list, max_length=12)
    rules: list[AcquisitionRule] = Field(default_factory=list, max_length=8)
    rejected: list[dict] = Field(default_factory=list)


class Edit(Strict):
    node: int | None = Field(default=None, ge=0, le=11)
    original_question_span: str
    replacement: Requirement
    reason: str = Field(max_length=400)
    preservation_explanation: str = Field(max_length=400)


class SpecReview(Strict):
    decision: Literal["keep", "repair"]
    explanation: str = Field(max_length=500)
    preserved_nodes: list[int] = Field(default_factory=list, max_length=12)
    edits: list[Edit] = Field(default_factory=list, max_length=12)
    revalidate: str = Field(max_length=500)


def apply_review(question, old, review):
    """No deletion operation. Every old clause is retained or explicitly replaced.

    Structural/lexical checks are enforceable; semantic preservation still depends
    on the reviewer and is not presented as a theorem.
    """
    if review.decision == "keep":
        if review.edits:
            raise ValueError("keep review contains edits")
        return compile_question(question, old)[0], []
    if not review.edits:
        raise ValueError("repair has no edits")
    edited = [e.node for e in review.edits if e.node is not None]
    if len(edited) != len(set(edited)) or set(edited) & set(review.preserved_nodes):
        raise ValueError("overlapping repair coverage")
    if set(edited) | set(review.preserved_nodes) != set(range(len(old.needs))):
        raise ValueError("repair must account for every original requirement")
    needs = [n.model_copy(deep=True) for n in old.needs]
    differences = []
    for edit in review.edits:
        if not edit.original_question_span.strip() or edit.original_question_span not in question:
            raise ValueError("repair span is not original question text")
        if not edit.reason.strip() or not edit.preservation_explanation.strip():
            raise ValueError("repair lacks semantic preservation explanation")
        before = needs[edit.node].model_dump() if edit.node is not None else None
        if edit.node is None:
            needs.append(edit.replacement)
        else:
            needs[edit.node] = edit.replacement
        differences.append(dict(old=before, new=edit.replacement.model_dump(), **edit.model_dump(exclude={"replacement"})))
    # Goal, cardinality and explicit alternatives cannot be weakened by this API.
    candidate = Program(**dict(old.model_dump(), needs=[n.model_dump() for n in needs], unrepresented=[]))
    candidate, _ = compile_question(question, candidate)
    if candidate.goal != old.goal or candidate.choices != old.choices:
        raise ValueError("repair changed goal/cardinality/finite choices")
    return candidate, differences


EXPANSION_PROMPT = '''Propose auxiliary acquisition supports for unmet question requirements.
The original question is immutable. A support offers an alternative way to establish ONE existing requirement; it never adds a new mandatory question condition. Never supply answer facts or remembered place names.
Available built-in templates: city_state, city_country, state_country. Use ONLY for a positive physical location relation (located/based/headquartered/situated in), with a place-valued object. The engine constructs the two typed geographic premises with a fresh bridge variable. Choose the geographic level requested by the condition; do not change its meaning. For these templates output conditions:[], source_evidence_id:null, source_quote:null.
Built-in templates are already declared rules; they do NOT require the question to mention the intermediate city, and they do NOT require an explicit universal rule in a passage. They create requests to acquire the missing facts. An unknown country binding is precisely a reason to consider a city_country support. The intermediate city remains a variable, not a remembered answer. For example, an unmet (named station, located in, ?country) can activate city_country: acquire (station, located in city, ?city) AND (?city, city in country, ?country). Likewise an unmet (?school, located in, named state) can activate city_state. Select a template only if its geographic level and the head's physical-location meaning agree.
The only other template is explicit_source_rule: an observed original explicitly states a universal/conditional rule (all/each/every/if/whenever). Supply the exact original source span and 1–3 typed relation conditions sharing variables with the target. Preserve its scope and negation. A statement about one named entity is not a universal rule. No arbitrary relation transitivity or unsourced commonsense rules. All constants must occur in the question or observed originals. New variables must be fresh.
Only propose for eligible_unmet_ids. The request includes known bindings and gaps, not answer labels. If no sound available template applies, return supports:[] with an explanation. Do not force expansion.'''


REVIEW_PROMPT = '''Compare the original QUESTION with its structured requirements. Review semantics, entity binding, restrictions, negation, time and types. Retrieval difficulty does not authorize simplifying the question.
Return keep or repair. For a repair, give local edits with the exact original_question_span, replacement requirement, reason and preservation_explanation. node:null adds an omitted requirement; an integer replaces that node. List all unchanged nodes in preserved_nodes. Every old node must be accounted for; no deletion operation exists. Keep goal, answer cardinality and finite alternatives unchanged. Preserve all necessary restrictions, even if evidence may be unavailable. Describe which facts/bindings/derivations require revalidation. Do not answer the question or fill variables with remembered answers. A structurally valid proposal is not a proof of semantic equivalence.'''

REVIEW_PROMPT += '''
Check nested location descriptions carefully: an asked filming/birth/event place and a country restricting that place need not be the same entity. For “where did an event happen in the country where someone was born”, preserve the requested event place, the person's birth-country relation, and the event-place-to-country restriction with distinct variables where appropriate. The current goal variable can retain its identifier while the requirements correct its meaning. Never assume that sharing a word such as “where” means sharing the same entity. Likewise, person/parent/spouse attributes must attach to the correct participant, not the named anchor merely because it is easier to retrieve.'''
