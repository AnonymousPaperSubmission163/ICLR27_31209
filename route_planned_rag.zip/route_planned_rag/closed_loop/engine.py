"""Acquire → admit → derive/retract → replan → validate, with bounded repair."""
import json
import time
from pathlib import Path

from route_planned_rag.method.engine import DEFAULTS as V3_DEFAULTS
from route_planned_rag.method.schema import contract, signature as digest
from route_planned_rag.prototype.logic import substitute, ground, unify
from route_planned_rag.prototype.prover import write_json
from .schema import Expansion, SpecReview, apply_review, EXPANSION_PROMPT, REVIEW_PROMPT
from .store import EvidenceStore
from .planner import plan
from .acquisition_io import AcquisitionIO
from .reader import AcquisitionReading, SLOT_PROMPT


DEFAULTS = dict(V3_DEFAULTS, planner_use_derived=True, global_read_priority=False,
                enable_expansion=True, enable_review=True, max_expansion_calls=2,
                max_review_calls=2, max_auxiliary=12, max_rules=8, max_depth=3,
                stall_steps=3, max_routes=128, max_derived=1024, max_supports=4096,
                max_rule_matches=20000, rule_cpu_seconds=2.)


def validate_candidate(store, candidate):
    """Explicit final conjunction, finite-domain and active-provenance check.

    candidates() supplies the unchanged v3 cardinality/date/numeric semantics.
    This is a program validation record, never a Prover9 certificate.
    """
    if any(store.rows[f]['status'] != 'accepted' for f in candidate['facts']):
        return None
    checked = []
    for i in range(len(store.plan.needs)):
        target = substitute(store.pattern(i), candidate['binding'])
        if not ground(target):
            return None
        support = [f for f in candidate['facts'] if unify(target, store.row_atom(store.rows[f]), {}) is not None]
        if not support:
            return None
        checked.append(dict(requirement_id=i, target=target.model_dump(), fact_ids=support))
    for variable, choices in store.plan.choices.items():
        if candidate['binding'].get(variable[1:]) not in [store.term(c) for c in choices]:
            return None
    leaves = store.leaf_facts(candidate['facts']) if hasattr(store, 'leaf_facts') else candidate['facts']
    return dict(constraint_id='C' + digest([store.plan_hash, candidate['binding'], candidate['facts'], store.alias_version]),
                status='constraint_valid', valid=True, spec_version=getattr(store, 'spec_version', 1),
                checked_requirements=checked, fact_ids=candidate['facts'], leaf_fact_ids=leaves,
                computation=candidate['computation'], semantics='conditional on question and source translation')


class ClosedLoopEngine(AcquisitionIO):
    def __init__(self, question, program, client, retriever, directory, config=None, initial_review=None):
        self.question, self.program = question, program
        self.coverage = contract(question, program)
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        if (self.directory / 'checkpoint.json').exists():
            raise ValueError('partial episode already exists: retain it and start a fresh run; budgets cannot reset on resume')
        self.config = dict(DEFAULTS, **(config or {}))
        self.client, self.retriever = client, retriever
        version = 2 if initial_review and initial_review.get('changed') else 1
        self.store = self.new_store(program, version)
        self.started = time.perf_counter()
        self.state = dict(plan_hash=digest(program), spec_version=version, retrieval_calls=0, reader_calls=0,
                          step=0, reads={}, queries=[], retrieval_attempts={}, query_usage=[], events=[],
                          last_candidate=None, reader_errors=[], run_seconds=0., expansion_calls=0,
                          expansion_states=[], review_calls=1 if initial_review else 0, stall_review_done=False,
                          stall_steps=0, added_auxiliary=0, added_rules=0, revisions=[], validation_records=[])
        if initial_review:
            self.state['revisions'].append(initial_review)
        self.event('initialized', initial_review=initial_review)

    def new_store(self, program, version):
        limits = {k: self.config[k] for k in ('max_auxiliary', 'max_rules', 'max_depth', 'max_routes', 'max_derived', 'max_supports', 'max_rule_matches', 'rule_cpu_seconds')}
        return EvidenceStore(self.question, program, self.directory / f'spec_{version}/relations.sqlite', self.config['max_bindings'], version, limits)

    def save(self):
        self.store.sync()
        write_json(self.directory / 'checkpoint.json', self.state)
        write_json(self.directory / 'events.json', self.state['events'])
        write_json(self.directory / 'requirement_spec.json', dict(version=self.state['spec_version'], **self.program.model_dump()))
        write_json(self.directory / 'acquisition_plan.json', self.store.acquisition.model_dump())
        write_json(self.directory / 'evidence_state.json', self.store.snapshot())

    def event(self, kind, **data):
        event = dict(index=len(self.state['events']), step=self.state['step'], kind=kind, spec_version=self.state['spec_version'], **data)
        path = self.directory / 'states' / f"{event['index']:04d}.json"
        write_json(path, dict(self.store.snapshot(), budget={k: self.state[k] for k in ('retrieval_calls', 'reader_calls', 'step', 'expansion_calls', 'review_calls')},
                             charged_tokens=getattr(self.client, 'charged', None)))
        event['snapshot'] = str(path.relative_to(self.directory))
        self.state['events'].append(event)
        self.save()

    def read_signature(self, request, eid):
        # Unchanged obligations retain attempt identity across a spec revision.
        return digest([request['target'], eid])

    def terminal(self):
        closure = self.store.recompute()
        if closure is not None:
            self.event('closure_updated', **closure)
        if self.store.closure_records and self.store.closure_records[-1]['error']:
            raise ValueError(self.store.closure_records[-1]['error'])
        with self.store.visibility(True):
            candidates = self.store.candidates()
        unique = {}
        for c in sorted(candidates, key=lambda c: (len(c['facts']), digest(c))):
            unique.setdefault(c['term'].name, c)
        answers = []
        for c in unique.values():
            record = validate_candidate(self.store, c)
            if record:
                self.state['validation_records'].append(record)
                answers.append(dict(value=c['value'], fact_ids=c['facts'], leaf_fact_ids=record['leaf_fact_ids'],
                                    constraint_id=record['constraint_id'], computation=c['computation']))
        if self.program.goal.count is not None and len(answers) != self.program.goal.count:
            return []
        return answers

    def choose(self):
        with self.store.visibility(False):
            direct_candidates, direct = plan(self)
        with self.store.visibility(True):
            derived_candidates, derived = plan(self)
        def identity(action):
            return {k: action.get(k) for k in ('mode', 'target', 'query', 'source_ids')} if action else None
        changed = identity(direct) != identity(derived)
        candidates, action = (derived_candidates, derived) if self.config['planner_use_derived'] else (direct_candidates, direct)
        self.event('planner_feedback', direct_next=direct, derived_next=derived, action_changed=changed,
                   planner_use_derived=self.config['planner_use_derived'], diagnostic_only=True)
        self.event('support_plan', candidates=candidates, selected=action,
                   enumeration_truncated=self.store.truncated, routes_truncated=self.store.routes_truncated)
        return candidates, action

    def expand(self, candidates):
        if not self.config['enable_expansion'] or self.state['expansion_calls'] >= self.config['max_expansion_calls']:
            return False
        supported = {r.head for r in self.store.acquisition.rules if r.valid}
        # Expansion uses the same direct-only reference support in E-T and E-O.
        # Hypothetical omissions from every alternative are not all actual gaps.
        with self.store.visibility(False):
            reference, _ = plan(self)
        best = next((c for c in reference if c['ready']), reference[0] if reference else None)
        eligible = sorted({m['node'] for m in best['missing']} - supported) if best else []
        if not eligible or self.state['added_auxiliary'] >= self.config['max_auxiliary'] or self.state['added_rules'] >= self.config['max_rules']:
            return False
        signature = digest([self.state['spec_version'], [(f, r['status']) for f, r in self.store.rows.items() if r.get('origin') != 'program_derived']])
        if signature in self.state['expansion_states']:
            return False
        # E-T and E-O get identical direct-only known-state inputs.
        with self.store.visibility(False):
            bindings = [{k: self.store.names[v.name] for k, v in r['binding'].items()} for r in self.store.joins(partial=True)[:12]]
        payload = dict(question=self.question, requirement_spec=self.program.model_dump(),
                       catalog=[dict(id=i, **n.model_dump()) for i, n in enumerate(self.store.catalog)],
                       eligible_unmet_ids=eligible, known_bindings=bindings,
                       explicit_rule_sources=[dict(evidence_id=eid, title=e['source_metadata']['title'], original_text=e['original_text']) for eid, e in self.store.evidence.items() if not e.get('withdrawn') and any(w in e['original_text'].lower().split() for w in ('if', 'all', 'each', 'every', 'whenever'))][:4])
        if hasattr(self.client, 'preflight'):
            self.client.preflight(EXPANSION_PROMPT, payload, 2000)
        self.state['expansion_calls'] += 1
        self.state['expansion_states'].append(signature)
        self.event('expansion_started', eligible=eligible)
        added = []
        try:
            proposal = self.client.ask('plan_expansion', Expansion, EXPANSION_PROMPT, payload, maximum=2000)
            for support in proposal.supports:
                try:
                    if support.requirement_id not in eligible:
                        raise ValueError('expansion target is not eligible/unmet')
                    self.store.limits['max_auxiliary'] = len(self.store.acquisition.auxiliary) + self.config['max_auxiliary'] - self.state['added_auxiliary']
                    self.store.limits['max_rules'] = len(self.store.acquisition.rules) + self.config['max_rules'] - self.state['added_rules']
                    rule = self.store.add_support(support)
                    added.append(rule.model_dump())
                    self.state['added_auxiliary'] += len(rule.body)
                    self.state['added_rules'] += 1
                except ValueError as exc:
                    self.store.acquisition.rejected.append(dict(proposal=support.model_dump(), error=str(exc)))
            self.event('plan_expanded', proposal=proposal.model_dump(), added=added)
        except (ValueError, RuntimeError) as exc:
            self.event('expansion_failed', error=repr(exc))
            if 'token_budget_exhausted' in str(exc):
                raise
        return bool(added)

    def revise(self, trigger):
        if not self.config['enable_review'] or self.state['review_calls'] >= self.config['max_review_calls']:
            return False
        if trigger != 'initial' and self.state['stall_review_done']:
            return False
        payload = dict(question=self.question, requirement_spec=self.program.model_dump(), structural_errors=[], trigger=trigger,
                       restriction='The trigger authorizes review only; preserve the original question regardless of retrieval failure.')
        if hasattr(self.client, 'preflight'):
            self.client.preflight(REVIEW_PROMPT, payload, 2000)
        self.state['review_calls'] += 1
        if trigger != 'initial':
            self.state['stall_review_done'] = True
        self.event('spec_review_started', trigger=trigger)
        try:
            review = self.client.ask('spec_review', SpecReview, REVIEW_PROMPT, payload, maximum=2000)
            revised, differences = apply_review(self.question, self.program, review)
            if revised == self.program:
                self.event('spec_review_kept', proposal=review.model_dump())
                return False
            self.install_revision(revised, review, differences, trigger)
            return True
        except (ValueError, RuntimeError) as exc:
            self.event('spec_review_rejected', error=repr(exc))
            if 'token_budget_exhausted' in str(exc):
                raise
            return False

    def install_revision(self, revised, review, differences, trigger):
        old = self.store
        before = {k: self.state[k] for k in ('retrieval_calls', 'reader_calls', 'step', 'expansion_calls', 'review_calls')}
        version = self.state['spec_version'] + 1
        new = self.new_store(revised, version)
        new.observe([e for e in old.evidence.values() if not e.get('withdrawn')])
        remap = {i: j for i, n in enumerate(self.program.needs) for j, m in enumerate(revised.needs) if n == m}
        retained, invalidated = [], []
        for fid, row in old.rows.items():
            if row.get('origin') == 'program_derived' or row['node'] not in remap:
                invalidated.append(fid)
                continue
            data = {k: row[k] for k in ('s', 'o', 'evidence_id', 'quote', 'negated', 'scope')}
            data['node'] = remap[row['node']]
            ids = new.propose(AcquisitionReading(rows=[data]), row.get('extraction_call'))
            for new_id in ids:
                if row.get('base_status', row['status']) != 'accepted':
                    new.set_status([new_id], row.get('base_status', row['status']), 'preserved previous admission status')
                retained.append(dict(old_fact_id=fid, new_fact_id=new_id, validation='rerun original source/type/scope admission; unchanged relation only'))
        for d in old.derivations.values():
            d['valid'] = False
        for row in old.rows.values():
            if row.get('origin') == 'program_derived':
                row.update(status='invalid', base_status='invalid', reason='spec_superseded')
        write_json(self.directory / f'spec_{old.spec_version}/superseded.json', old.snapshot())
        old.close()
        self.store, self.program = new, revised
        self.coverage = contract(self.question, revised)
        self.state.update(spec_version=version, plan_hash=digest(revised), last_candidate=None, stall_steps=0)
        record = dict(trigger=trigger, old_version=version - 1, new_version=version, proposal=review.model_dump(),
                      differences=differences, retained_facts=retained, invalidated_facts=invalidated,
                      invalidated_bindings='all; recomputed from revalidated observations',
                      invalidated_rules='all prior spec rules; global expansion allowance is preserved', budget_before=before,
                      budget_after={k: self.state[k] for k in before})
        self.state['revisions'].append(record)
        self.event('spec_revised', **record)

    def run(self):
        answers, status, error = [], 'unknown', None
        try:
            if self.config['enable_review'] and not self.state['review_calls']:
                self.revise('initial')
            while True:
                assert digest(self.program) == self.state['plan_hash']
                answers = self.terminal()  # Also after the last permitted acquisition.
                if answers:
                    status = 'constraint_valid'
                    break
                if self.state['step'] >= self.config['max_steps']:
                    status = 'step_budget_exhausted'
                    break
                candidates, action = self.choose()
                # Expansion is driven by gaps and current direct bindings. Give
                # initial direct acquisition a chance; then broaden support.
                if (self.state['reader_calls'] > 0 or action is None) and self.expand(candidates):
                    continue
                if action is None or self.state['stall_steps'] >= self.config['stall_steps']:
                    if self.revise('no_executable_action' if action is None else 'sustained_stall'):
                        continue
                if action is None:
                    if self.state['reader_calls'] >= self.config['max_reader_calls']:
                        status = 'reader_budget_exhausted'
                    elif self.state['retrieval_calls'] >= self.config['max_retrievals']:
                        status = 'retrieval_budget_exhausted'
                    elif any(r['status'] == 'conflicted' for r in self.store.rows.values()):
                        status = 'conflicted'
                    else:
                        status = 'unknown_no_executable_action'
                    break
                previous = self.state['last_candidate']
                if previous and previous != action['candidate_id']:
                    self.event('support_switched', old=previous, new=action['candidate_id'])
                self.state['last_candidate'] = action['candidate_id']
                before = digest([(f, r['status']) for f, r in self.store.rows.items()])
                self.state['step'] += 1
                if action['mode'] == 'read':
                    self.read(action)
                    after = digest([(f, r['status']) for f, r in self.store.rows.items()])
                    self.state['stall_steps'] = self.state['stall_steps'] + 1 if before == after else 0
                else:
                    self.retrieve(action)
        except (ValueError, KeyError, RuntimeError, OSError) as exc:
            error = repr(exc)
            status = 'token_budget_exhausted' if 'token_budget_exhausted' in str(exc) else ('rule_budget_exhausted' if 'rule_' in str(exc) or 'derived_item_budget' in str(exc) else 'execution_error')
        self.state['run_seconds'] += time.perf_counter() - self.started
        leaves = sorted({f for a in answers for f in a['leaf_fact_ids']})
        rule_citations = self.store.rule_sources([f for a in answers for f in a['fact_ids']])
        result = dict(question=self.question, status=status, error=error,
                      final_answer='; '.join(dict.fromkeys(a['value'] for a in answers)),
                      answer_source='constraint_readout' if answers else 'abstain', answers=answers,
                      citations=[dict(fact_id=f, evidence_id=self.store.rows[f]['evidence_id'], quote=self.store.rows[f]['quote'], position=self.store.rows[f].get('quote_alignment')) for f in leaves],
                      evidence_ids=sorted({self.store.rows[f]['evidence_id'] for f in leaves} | {c['evidence_id'] for c in rule_citations}),
                      rule_citations=rule_citations,
                      spec_version=self.state['spec_version'], requirement_spec_hash=self.state['plan_hash'],
                      model_calls=len(self.client.calls), input_tokens=sum(c.get('input_tokens', 0) for c in self.client.calls),
                      output_tokens=sum(c.get('output_tokens', 0) for c in self.client.calls), charged_tokens=getattr(self.client, 'charged', None),
                      retrieval_calls=self.state['retrieval_calls'], reader_calls=self.state['reader_calls'],
                      expansion_calls=self.state['expansion_calls'], review_calls=self.state['review_calls'],
                      added_auxiliary=self.state['added_auxiliary'], added_rules=self.state['added_rules'],
                      derived_items=sum(r.get('origin') == 'program_derived' and r['status'] == 'accepted' for r in self.store.rows.values()),
                      derived_feedback_changes=sum(e['kind'] == 'planner_feedback' and e['action_changed'] for e in self.state['events']),
                      semantic_revisions=sum('new_version' in r or r.get('changed', False) for r in self.state['revisions']),
                      rule_cpu_seconds=sum(r['cpu_seconds'] for r in self.store.closure_records),
                      proof_calls=0, query_embedding_usage=self.state['query_usage'], seconds=self.state['run_seconds'],
                      semantic_status='Program-checked conditions under proposed question/source/rule translations; semantic correctness is not certified.',
                      unknown_usage_calls=sum(c.get('status') == 'interrupted_usage_unknown' for c in self.client.calls))
        self.event('finished', status=status, answer=result['final_answer'])
        write_json(self.directory / 'result.json', result)
        write_json(self.directory / 'validations.json', self.state['validation_records'])
        return result
