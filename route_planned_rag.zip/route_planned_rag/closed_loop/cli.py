"""Real-model entry point, shared public corpus, immutable runs and compiler cache."""
import argparse
import copy
import hashlib
import json
import os
import shutil
import time
from pathlib import Path

from route_planned_rag.method.client import Client
from route_planned_rag.method.cli import compile_episode, source_hashes
from route_planned_rag.method.schema import Program, compile_question, question_schema, COMPILE_PROMPT
from route_planned_rag.prototype.prover import write_json
from . import VERSION
from .engine import ClosedLoopEngine, DEFAULTS
from .schema import TEMPLATES, SpecReview, apply_review, REVIEW_PROMPT


VARIANTS = {'E-T': dict(planner_use_derived=False, enable_review=False),
            'E-O': dict(planner_use_derived=True, enable_review=False),
            'R': dict(planner_use_derived=True, enable_review=True)}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class SharedRetriever:
    def __init__(self, corpus_path, encoder, cache, model_identity):
        import numpy as np
        from route_planned_rag.prototype.retrieval import ContextRetriever
        self.encoder = encoder
        cache.mkdir(parents=True, exist_ok=True)
        signature = hashlib.sha256((sha(corpus_path) + json.dumps(model_identity, sort_keys=True)).encode()).hexdigest()
        directory = cache / signature
        self.physical_index_seconds = 0.
        if not (directory / 'COMPLETE.json').exists():
            docs = json.loads(corpus_path.read_text())
            start = time.perf_counter()
            index = ContextRetriever([(d['title'], [d['text']]) for d in docs], encoder)
            for e in index.evidence:
                e['source_metadata']['retrieval_setting'] = 'shared_public_candidate_pool'
            if not index.evidence:
                raise ValueError('empty shared corpus')
            directory.mkdir(parents=True, exist_ok=True)
            write_json(directory / 'evidence.json', index.evidence)
            np.save(directory / 'vectors.npy', index.vectors)
            write_json(directory / 'COMPLETE.json', dict(corpus_sha256=sha(corpus_path), documents=len(docs), chunks=len(index.evidence),
                       index_usage=index.index_usage, model_identity=model_identity, wall_seconds=time.perf_counter() - start))
            self.physical_index_seconds = time.perf_counter() - start
        self.evidence = json.loads((directory / 'evidence.json').read_text())
        self.vectors = np.load(directory / 'vectors.npy', mmap_mode='r')
        self.index_record = json.loads((directory / 'COMPLETE.json').read_text())
        self.cache_path = str(directory)

    def __call__(self, query, k):
        import numpy as np
        vectors, usage = self.encoder.encode([query], is_query=True)
        scores = self.vectors @ vectors[0]
        ids = np.argsort(-scores, kind='stable')[:k]
        return [dict(self.evidence[int(i)], retrieval_score=float(scores[i])) for i in ids], dict(input_tokens=usage.input_tokens, seconds=usage.gpu_seconds)


def recover_initial(question, cache, client, error):
    proposals = sorted(cache.glob('proposal_*.json'))
    before = Program.model_validate(json.loads(proposals[-1].read_text())) if proposals else None
    if before is not None:
        review = client.ask('spec_review', SpecReview, REVIEW_PROMPT,
                            dict(question=question, requirement_spec=before.model_dump(), structural_errors=[error], trigger='initial_compile_invalid'), maximum=2000)
        program, differences = apply_review(question, before, review)
        record = dict(trigger='initial_compile_invalid', old=before.model_dump(), new=program.model_dump(),
                      proposal=review.model_dump(), differences=differences, changed=program != before,
                      no_evidence_yet=True)
    else:
        proposal = client.ask('spec_review', Program, COMPILE_PROMPT + '\nA previous structural compilation failed. Recheck every original condition.',
                              dict(question=question, structural_errors=[error]), maximum=2000, decoding_schema=question_schema(question))
        program, compilation = compile_question(question, proposal)
        record = dict(trigger='initial_compile_unparseable', old=None, new=program.model_dump(), changed=True, compilation=compilation, no_evidence_yet=True)
    return program, record


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path.cwd())
    parser.add_argument('--sample', type=Path, required=True)
    parser.add_argument('--corpus-dir', type=Path, required=True)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--variants', nargs='+', choices=list(VARIANTS), default=['R'])
    parser.add_argument('--debug-only', action='store_true')
    parser.add_argument('--limit', type=int)
    parser.add_argument('--config', type=Path, default=Path('configs/closed_loop.yaml'))
    args = parser.parse_args(argv)
    root = args.root.resolve()
    if Path(args.run_id).name != args.run_id or args.run_id in ('', '.', '..'):
        parser.error('run-id must be a single safe name')
    import yaml
    settings = yaml.safe_load((root / args.config).read_text())
    model_config = yaml.safe_load((root / settings['model_config']).read_text())
    config = dict(DEFAULTS, **settings.get('execution', {}))
    sample_path = root / args.sample
    source = json.loads(sample_path.read_text())
    public = [{k: r[k] for k in ('dataset', 'question_id', 'question')} for r in source if not args.debug_only or r.get('debug')]
    if args.limit is not None:
        if args.limit <= 0:parser.error('limit must be positive')
        public = public[:args.limit]
    if not public or len({(r['dataset'], r['question_id']) for r in public}) != len(public):
        raise ValueError('empty/duplicate input')
    if any(Path(r['question_id']).name != r['question_id'] or r['dataset'] not in ('hotpotqa','twowiki','musique') for r in public):
        raise ValueError('invalid public dataset/question ID')
    variants = list(dict.fromkeys(args.variants))
    out = root / 'runs/closed_loop' / args.run_id
    if out.exists():
        raise ValueError('immutable run exists; use a new run ID, retaining all previous cost records')
    out.mkdir(parents=True)
    sources = source_hashes(root)
    sources.update({str(p.relative_to(root)): sha(p) for p in [root / 'scripts/run_closed_loop.py', root / args.config]})
    protocol = dict(version=VERSION, purpose='own-method implementation validation; not the complete seven-arm selection study',
                    run_kind='real_model', no_gold_online=True, seed=settings['seed'], variants={v: VARIANTS[v] for v in variants},
                    execution=config, token_budget=settings['question_token_budget'], compiler_output_tokens=2400,
                    public_questions=public, sources=sources, models={k:model_config['models'][k] for k in ('actor','retriever')},
                    rules=TEMPLATES, retrieval_setting='shared public candidate pool per dataset',
                    corpora={ds:dict(path=str(root / args.corpus_dir / f'{ds}.json'),sha256=sha(root / args.corpus_dir / f'{ds}.json')) for ds in sorted({r['dataset'] for r in public})},
                    initial_compiler='same cached v3 compiler result per question, including failures; independently charged logical costs',
                    physical_compiler_cost='cache generation once; separate shared compilation ledger',
                    ordering='question order; cyclic variant rotation by question index',
                    interrupted_episode_policy='no in-place restart; preserve and count any rerun separately')
    write_json(out / 'protocol.json', protocol)
    for name in sources:
        destination = out / 'source_code' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / name, destination)
    import torch
    from route_planned_rag.logicgraph.runtime import load_models
    torch.manual_seed(settings['seed'])
    model_config['project']['root'] = str(root)
    start = time.perf_counter()
    actor, _, encoder = load_models(model_config, with_encoder=True, with_scorer=False)
    write_json(out / 'runtime.json', dict(model_load_seconds=time.perf_counter() - start, job_id=os.getenv('SLURM_JOB_ID'),
                                        device=torch.cuda.get_device_name(), torch_version=torch.__version__))
    retrievers = {}
    for ds in sorted({r['dataset'] for r in public}):
        print(json.dumps(dict(event='index_started', dataset=ds)), flush=True)
        retrievers[ds] = SharedRetriever(root / args.corpus_dir / f'{ds}.json', encoder, root / 'artifacts/closed_loop_indices' / ds, model_config['models']['retriever'])
        index = retrievers[ds]
        write_json(out / f'{ds}.index.json', dict(index.index_record, physical_index_seconds=index.physical_index_seconds, cache_path=index.cache_path))
        print(json.dumps(dict(event='index_completed', dataset=ds, documents=index.index_record['documents'], seconds=index.physical_index_seconds)), flush=True)
    results = []
    for qi, row in enumerate(public):
        cache = out / 'compilation_cache' / (row['dataset'] + '_' + row['question_id'])
        compiler = Client(actor, cache, budget=settings['question_token_budget'])
        program, compile_error = None, None
        try:
            program = compile_episode(row['question'], compiler, cache, maximum=2400)
        except (ValueError, RuntimeError) as exc:
            compile_error = repr(exc)
        write_json(cache / 'outcome.json', dict(error=compile_error, program=program.model_dump() if program else None))
        order = variants[qi % len(variants):] + variants[:qi % len(variants)]
        for variant in order:
            directory = out / row['dataset'] / row['question_id'] / variant
            directory.mkdir(parents=True)
            inherited = [dict(c, physical_execution=False, shared_compiler_cache=str(cache.relative_to(out))) for c in copy.deepcopy(compiler.calls)]
            write_json(directory / 'model_calls.json', inherited)
            client = Client(actor, directory, budget=settings['question_token_budget'])
            initial_review, engine = None, None
            arm_program = program.model_copy(deep=True) if program else None
            started = time.perf_counter()
            try:
                if arm_program is None:
                    if variant != 'R':raise ValueError(compile_error)
                    arm_program, initial_review = recover_initial(row['question'], cache, client, compile_error)
                    write_json(directory / 'initial_review.json', initial_review)
                engine = ClosedLoopEngine(row['question'], arm_program, client, retrievers[row['dataset']], directory,
                                          dict(config, **VARIANTS[variant]), initial_review=initial_review)
                result = engine.run()
            except (ValueError, RuntimeError, OSError) as exc:
                result = dict(question=row['question'], final_answer='', status='plan_invalid' if arm_program is None else 'execution_error',
                              error=repr(exc), answer_source='abstain', input_tokens=sum(c.get('input_tokens',0) for c in client.calls),
                              output_tokens=sum(c.get('output_tokens',0) for c in client.calls), model_calls=len(client.calls),
                              retrieval_calls=0, reader_calls=0, proof_calls=0)
            finally:
                if engine is not None:engine.store.close()
            result.update(dataset=row['dataset'], question_id=row['question_id'], variant=variant, run_kind='real_model',
                          relative_directory=str(directory.relative_to(out)), seconds_this_episode=time.perf_counter() - started,
                          logical_compiler_tokens=compiler.charged, logical_compiler_seconds=sum(c['seconds'] for c in compiler.calls),
                          logical_total_tokens=client.charged,
                          physical_episode_tokens=sum(c.get('input_tokens',0)+c.get('output_tokens',0) for c in client.calls if c.get('physical_execution',True)))
            write_json(directory / 'result.json', result)
            results.append(result)
            write_json(out / 'results.json', results)
            print(json.dumps({k:result.get(k) for k in ('dataset','question_id','variant','status','final_answer','logical_total_tokens','added_auxiliary','derived_items','derived_feedback_changes','semantic_revisions','error')}), flush=True)
    (out / 'episodes.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in results))
    write_json(out / 'COMPLETE.json', dict(questions=len(public), episodes=len(results), variants=variants,
               logical_total_tokens=sum(r['logical_total_tokens'] for r in results),
               physical_episode_tokens=sum(r['physical_episode_tokens'] for r in results),
               physical_compiler_tokens=sum(r['logical_compiler_tokens'] for r in results[::len(variants)])))
    return results


if __name__ == '__main__':main()
