"""v3 acquisition operations, with the catalog including legal auxiliary slots.

Copied from method/engine.py with only catalog/reader imports adapted. Retrieval,
admission, costs and retry behavior remain explicit and independently testable.
"""
from .reader import original_sentences, slot_schema, slots_to_reading, SLOT_PROMPT
from route_planned_rag.method.schema import signature as digest, words, STOP

class AcquisitionIO:
    def requests(self, nodes, binding):
        requests = []
        for i in nodes:
            n = self.store.catalog[i]
            requests.append(dict(id="N" + str(i), relation=n.r, condition=n.span,
                                 subject_filter=binding.get(n.s[1:]) if n.s.startswith("?") else n.s,
                                 value_filter=binding.get(n.o[1:]) if n.o.startswith("?") else n.o,
                                 subject_type=n.subject_kind, value_type=n.kind, scope=n.scope,
                                 required_negation=n.negated))
        return requests

    def reading_payload(self, evidence, nodes, binding, retry=False):
        payload = dict(requests=self.requests(nodes, binding), passages=original_sentences(evidence)[0])
        if retry:
            payload["task"] = "Re-read the originals for omitted alternatives or a previous format failure. Keep every condition; do not guess unsupported rows."
            payload["previous_rejections"] = self.store.rejected[-6:]
        return payload

    def read_option(self, request):
        if self.state["reader_calls"] >= self.config["max_reader_calls"]:
            return None
        eligible = []
        wanted = set(words(self.store.catalog[request["node"]].r)) - STOP
        anchor = request["anchor"] or ""
        neighboring_anchors = [t for n in self.store.catalog for t in (n.s, n.o) if not t.startswith("?") and t not in ("true", "false")]
        for eid, evidence in self.store.evidence.items():
            if evidence.get("withdrawn"):
                continue
            signature = self.read_signature(request, eid)
            attempts = self.state["reads"].get(signature, 0)
            if attempts >= self.config["max_attempts"]:
                continue
            title = evidence["source_metadata"]["title"]
            anchor_present = self.store.canonical(anchor) == self.store.canonical(title) or anchor.casefold() in evidence["original_text"].casefold()
            overlap = len(wanted & set(words(evidence["original_text"])))
            neighbor_present = any(a.casefold() in (title + " " + evidence["original_text"]).casefold() for a in neighboring_anchors)
            unbound_signature = self.read_signature(dict(target=self.store.pattern(request["node"]).model_dump()), eid)
            unseen = self.state["reads"].get(unbound_signature, 0) == 0
            # A neighboring anchor can add an unread passage to a multi-slot
            # batch. Once read, only the current anchor justifies a bound reread.
            if not (anchor_present or (neighbor_present and (unseen or not request["binding"])) or (unseen and overlap)):
                continue
            eligible.append((attempts, self.store.canonical(anchor) != self.store.canonical(title), not anchor_present, -overlap, eid))
        if not eligible:
            return None
        eligible.sort()
        ids = [row[-1] for row in eligible[:self.config["reading_top_k"]]]
        return dict(request, key=digest(["read", request["id"], ids]), mode="read", source_ids=ids, cost=self.config["read_cost"])

    def retrieval_option(self, request):
        if self.state["retrieval_calls"] >= self.config["max_retrievals"] or self.state["reader_calls"] >= self.config["max_reader_calls"]:
            return None
        attempt = self.state["retrieval_attempts"].get(request["id"], 0)
        if attempt >= self.config["max_attempts"]:
            return None
        need = self.store.catalog[request["node"]]
        target = request["target"]
        names = [self.store.names[t["name"]] for t in target["arguments"] if t["kind"] == "constant" and self.store.names[t["name"]] not in ("true", "false")]
        base = " ".join(dict.fromkeys([*names, need.r, need.scope or ""])) .strip()
        candidates = [base, self.question + " " + base]
        for query in candidates[attempt:]:
            if query not in self.state["queries"]:
                return dict(request, key=digest(["retrieve", request["id"], query]), mode="retrieve", query=query,
                            cost=self.config["retrieve_cost"] + self.config["read_cost"])
        return None

    def read(self, action):
        evidence = [self.store.evidence[eid] for eid in action["source_ids"]]
        # One reader call fills independent slots for the entire fixed graph.
        # Only the selected slot receives this candidate's binding; other slots
        # stay unbound to avoid excluding alternative entities.
        nodes = list(range(len(self.store.catalog)))
        payload = self.reading_payload(evidence, nodes, {}, retry=any(self.state["reads"].get(self.read_signature(action, eid), 0) for eid in action["source_ids"]))
        selected = self.requests([action["node"]], action["binding"])[0]
        payload["requests"][action["node"]] = selected
        maximum = self.config["reader_output_tokens"]
        if hasattr(self.client, "preflight"):
            self.client.preflight(SLOT_PROMPT, payload, maximum)
        self.state["reader_calls"] += 1
        # The same call reads every slot. Charge every slot/source attempt so
        # switching the selected node cannot buy identical unbound reads again.
        for node in nodes:
            target = action["target"] if node == action["node"] else self.store.pattern(node).model_dump()
            for eid in action["source_ids"]:
                signature = self.read_signature(dict(target=target), eid)
                self.state["reads"][signature] = self.state["reads"].get(signature, 0) + 1
        self.event("reader_started", action=action)
        try:
            raw = self.client.ask("reader", slot_schema(nodes, evidence), SLOT_PROMPT, payload, maximum=maximum)
            reading, unknown = slots_to_reading(raw, evidence)
            self.store.rejected.extend(unknown)
            ids = self.store.propose(reading, self.client.calls[-1]["call_id"])
            self.event("facts_updated", action=action, admitted=ids, missing=reading.missing,
                       source_ids=action["source_ids"], store_version=self.store.version, unknown=unknown)
        except (ValueError, KeyError, IndexError, RuntimeError) as exc:
            self.state["reader_errors"].append(repr(exc))
            self.event("reader_failed", action=action, error=repr(exc))
            if "token_budget_exhausted" in str(exc):
                raise

    def retrieve(self, action):
        # Reserve at least a reader over current originals before spending E5.
        if hasattr(self.client, "preflight"):
            self.client.preflight(SLOT_PROMPT, self.reading_payload([], list(range(len(self.store.catalog))), {}), self.config["reader_output_tokens"])
        self.state["retrieval_calls"] += 1
        self.state["queries"].append(action["query"])
        self.state["retrieval_attempts"][action["id"]] = self.state["retrieval_attempts"].get(action["id"], 0) + 1
        self.event("retrieval_started", action=action)
        evidence, usage = self.retriever(action["query"], self.config["retrieval_top_k"])
        old = set(self.store.evidence)
        self.store.observe(evidence)  # Every returned original is retained, including unread passages.
        self.state["query_usage"].append(usage)
        self.event("retrieval_completed", action=action, source_ids=[e["evidence_id"] for e in evidence],
                   new_source_ids=sorted(set(self.store.evidence) - old), usage=usage)
