"""Route-Planned RAG: auditable budget-aware evidence search."""

__version__ = "0.1.0"

