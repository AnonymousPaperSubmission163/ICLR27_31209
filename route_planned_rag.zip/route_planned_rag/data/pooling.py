from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Iterable

from route_planned_rag.data.adapters import iter_raw_json


def _document_id(dataset: str, title: str, text: str) -> str:
    digest = hashlib.sha256(f"{title}\0{text}".encode("utf-8")).hexdigest()[:24]
    return f"{dataset}:doc:{digest}"


def _join_sentences(sentences: Iterable[str]) -> tuple[str, list[list[int]]]:
    parts = []
    spans = []
    cursor = 0
    for sentence_id, sentence in enumerate(map(str, sentences)):
        if parts:
            cursor += 1
        start = cursor
        parts.append(sentence)
        cursor += len(sentence)
        spans.append([sentence_id, start, cursor])
    return " ".join(parts), spans


def iter_public_documents(dataset: str, row: dict[str, Any]):
    question_id = str(row["id"] if dataset == "musique" else row["_id"])
    if dataset == "musique":
        for ordinal, paragraph in enumerate(row["paragraphs"]):
            title = str(paragraph.get("title", paragraph.get("idx", ordinal)))
            text = str(paragraph["paragraph_text"])
            local_id = str(paragraph.get("idx", ordinal))
            yield question_id, local_id, {
                "title": title,
                "text": text,
                "sentence_char_spans": [],
            }
    elif dataset == "twowiki":
        for title, sentences in row["context"]:
            text, spans = _join_sentences(sentences)
            yield question_id, str(title), {
                "title": str(title),
                "text": text,
                "sentence_char_spans": spans,
            }
    else:
        raise ValueError(f"unsupported pooled dataset {dataset}")


def build_pooled_corpus(
    dataset: str,
    source_paths: Iterable[str | Path],
    documents_path: str | Path,
    mapping_path: str | Path,
) -> dict[str, Any]:
    documents_path = Path(documents_path)
    mapping_path = Path(mapping_path)
    documents_path.parent.mkdir(parents=True, exist_ok=True)
    mapping_path.parent.mkdir(parents=True, exist_ok=True)
    documents_temporary = documents_path.with_suffix(documents_path.suffix + f".tmp-{os.getpid()}")
    mapping_temporary = mapping_path.with_suffix(mapping_path.suffix + f".tmp-{os.getpid()}")
    seen: set[str] = set()
    document_count = mapping_count = duplicate_count = 0
    with documents_temporary.open("w", encoding="utf-8") as documents_handle, mapping_temporary.open("w", encoding="utf-8") as mapping_handle:
        for source_path in source_paths:
            for row in iter_raw_json(source_path):
                for question_id, local_id, document in iter_public_documents(dataset, row):
                    doc_id = _document_id(dataset, document["title"], document["text"])
                    mapping_handle.write(json.dumps({
                        "question_id": question_id,
                        "local_id": local_id,
                        "doc_id": doc_id,
                    }, ensure_ascii=False, sort_keys=True) + "\n")
                    mapping_count += 1
                    if doc_id in seen:
                        duplicate_count += 1
                        continue
                    seen.add(doc_id)
                    documents_handle.write(json.dumps({"doc_id": doc_id, **document}, ensure_ascii=False, sort_keys=True) + "\n")
                    document_count += 1
    documents_temporary.replace(documents_path)
    mapping_temporary.replace(mapping_path)
    return {
        "dataset": dataset,
        "documents_path": str(documents_path),
        "private_question_mapping_path": str(mapping_path),
        "document_count": document_count,
        "mapping_count": mapping_count,
        "duplicate_count": duplicate_count,
        "question_association_in_actor_index": False,
        "gold_flags_in_actor_index": False,
    }

