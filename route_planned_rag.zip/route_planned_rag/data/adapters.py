from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Iterable, Iterator

from route_planned_rag.types import PrivateReference, PublicSample


def _iter_json(path: str | Path) -> Iterator[dict]:
    source = Path(path)
    if source.suffix == ".jsonl":
        with source.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    yield json.loads(line)
    else:
        try:
            import ijson
        except ImportError:
            ijson = None
        if ijson is not None:
            with source.open("rb") as handle:
                first = handle.read(1)
                handle.seek(0)
                if first == b"[":
                    yield from ijson.items(handle, "item")
                    return
        value = json.loads(source.read_text(encoding="utf-8"))
        if isinstance(value, dict):
            for key in ("data", "examples", "instances"):
                if isinstance(value.get(key), list):
                    value = value[key]
                    break
        if not isinstance(value, list):
            raise ValueError(f"unsupported dataset container in {source}")
        yield from value


def iter_raw_json(path: str | Path) -> Iterator[dict]:
    yield from _iter_json(path)


def freeze_question_split(
    question_ids: Iterable[str], *, seed: int, counts: dict[str, int]
) -> dict[str, list[str]]:
    ids = list(question_ids)
    if len(set(ids)) != len(ids):
        raise ValueError("question ids must be unique")
    ranked = sorted(
        ids,
        key=lambda item: hashlib.sha256(f"{seed}:{item}".encode("utf-8")).hexdigest(),
    )
    if sum(counts.values()) > len(ranked):
        raise ValueError("requested split counts exceed available questions")
    result: dict[str, list[str]] = {}
    cursor = 0
    for role, count in counts.items():
        result[role] = ranked[cursor : cursor + count]
        cursor += count
    return result


def normalized_question_key(question: str) -> str:
    return re.sub(r"\W+", " ", question.casefold()).strip()


class MuSiQueAdapter:
    adapter_id = "musique-answerable-public-private-v1"

    def load(self, path: str | Path, split_role: str) -> Iterator[tuple[PublicSample, PrivateReference]]:
        for row in _iter_json(path):
            question_id = str(row.get("id", row.get("question_id")))
            paragraphs = []
            support_ids = []
            for ordinal, paragraph in enumerate(row.get("paragraphs", row.get("context", []))):
                if isinstance(paragraph, dict):
                    paragraph_id = str(paragraph.get("idx", paragraph.get("id", ordinal)))
                    text = str(paragraph.get("paragraph_text", paragraph.get("text", "")))
                    title = str(paragraph.get("title", paragraph_id))
                    is_supporting = bool(paragraph.get("is_supporting", False))
                else:
                    title = str(paragraph[0])
                    text = " ".join(paragraph[1]) if len(paragraph) > 1 and isinstance(paragraph[1], list) else str(paragraph[1])
                    paragraph_id = str(ordinal)
                    is_supporting = False
                doc_id = f"musique:{question_id}:{paragraph_id}"
                paragraphs.append({"doc_id": doc_id, "title": title, "text": text})
                if is_supporting:
                    support_ids.append(doc_id)
            public = PublicSample(
                question_id=question_id,
                question=str(row["question"]),
                split_role=split_role,
                corpus_id=f"musique:{split_role}",
                public_context=tuple(paragraphs),
                metadata={"adapter_id": self.adapter_id},
            )
            answer = row.get("answer", row.get("answers", ""))
            answers = tuple(map(str, answer)) if isinstance(answer, list) else (str(answer),)
            private = PrivateReference(question_id, answers, tuple(support_ids))
            yield public, private


class TwoWikiAdapter:
    adapter_id = "2wiki-public-private-v1"

    def load(self, path: str | Path, split_role: str) -> Iterator[tuple[PublicSample, PrivateReference]]:
        for row in _iter_json(path):
            question_id = str(row.get("_id", row.get("id", row.get("question_id"))))
            documents = []
            for ordinal, context in enumerate(row.get("context", [])):
                if isinstance(context, dict):
                    title = str(context.get("title", ordinal))
                    sentences = list(map(str, context.get("sentences", context.get("text", []))))
                else:
                    title = str(context[0])
                    sentences = list(map(str, context[1]))
                documents.append({
                    "doc_id": f"2wiki:{title}",
                    "title": title,
                    "sentences": sentences,
                    "text": " ".join(sentences),
                })
            supporting_facts = tuple((str(title), int(index)) for title, index in row.get("supporting_facts", []))
            public = PublicSample(
                question_id=question_id,
                question=str(row["question"]),
                split_role=split_role,
                corpus_id=f"2wiki:{split_role}",
                public_context=tuple(documents),
                metadata={"adapter_id": self.adapter_id},
            )
            answer = row.get("answer", "")
            private = PrivateReference(
                question_id=question_id,
                reference_answers=(str(answer),),
                supporting_facts=supporting_facts,
                reasoning_triples=tuple(tuple(map(str, triple)) for triple in row.get("evidences", [])),
            )
            yield public, private


class MultiHopRAGAdapter:
    adapter_id = "multihop-rag-public-private-v1"

    def load(self, path: str | Path, split_role: str) -> Iterator[tuple[PublicSample, PrivateReference]]:
        for row in _iter_json(path):
            question = str(row["query"])
            question_id = str(row.get("query_id") or hashlib.sha256(question.encode("utf-8")).hexdigest()[:24])
            evidence = row.get("evidence_list", [])
            support_ids = tuple(
                str(item.get("url") or item.get("title"))
                for item in evidence
                if isinstance(item, dict) and (item.get("url") or item.get("title"))
            )
            public = PublicSample(
                question_id=question_id,
                question=question,
                split_role=split_role,
                corpus_id="multihop_rag:fixed_corpus",
                metadata={"adapter_id": self.adapter_id, "question_type": row.get("question_type")},
            )
            private = PrivateReference(
                question_id=question_id,
                reference_answers=(str(row["answer"]),),
                support_ids=support_ids,
            )
            yield public, private


class BrowseCompPlusAdapter:
    adapter_id = "browsecomp-plus-decrypted-private-v1"

    def load(self, path: str | Path, split_role: str) -> Iterator[tuple[PublicSample, PrivateReference]]:
        for row in _iter_json(path):
            question_id = str(row["query_id"])
            support_docs = row.get("evidence_docs") or row.get("gold_docs") or []
            support_ids = tuple(
                str(item["docid"] if isinstance(item, dict) else item)
                for item in support_docs
            )
            public = PublicSample(
                question_id=question_id,
                question=str(row["query"]),
                split_role=split_role,
                corpus_id="browsecomp_plus:100k",
                metadata={"adapter_id": self.adapter_id},
            )
            private = PrivateReference(
                question_id=question_id,
                reference_answers=(str(row["answer"]),),
                support_ids=support_ids,
            )
            yield public, private
