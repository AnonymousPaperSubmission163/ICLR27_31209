from __future__ import annotations

import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

from route_planned_rag.data.adapters import iter_raw_json, normalized_question_key


def _rank(items: Iterable[str], seed: int) -> list[str]:
    return sorted(items, key=lambda item: hashlib.sha256(f"{seed}:{item}".encode()).hexdigest())


def _row_id(row: dict, dataset: str) -> str:
    key = "id" if dataset == "musique" else "_id"
    return str(row[key])


def _stratum(row: dict, dataset: str) -> str:
    if dataset == "musique":
        decomposition = row.get("question_decomposition", [])
        return f"hop-{len(decomposition) if decomposition else 'unknown'}"
    return str(row.get("type", "unknown"))


def stratified_ids(rows: list[dict[str, Any]], dataset: str, count: int, seed: int) -> list[str]:
    if count > len(rows):
        raise ValueError(f"requested {count} {dataset} rows but only {len(rows)} exist")
    groups: dict[str, list[str]] = defaultdict(list)
    for row in rows:
        groups[_stratum(row, dataset)].append(_row_id(row, dataset))
    total = len(rows)
    exact = {key: count * len(values) / total for key, values in groups.items()}
    allocations = {key: math.floor(value) for key, value in exact.items()}
    remainder = count - sum(allocations.values())
    for key in sorted(groups, key=lambda item: (-(exact[item] - allocations[item]), item))[:remainder]:
        allocations[key] += 1
    selected = []
    for key in sorted(groups):
        selected.extend(_rank(groups[key], seed)[: allocations[key]])
    return _rank(selected, seed + 1)


def _duplicates_across_roles(rows: Iterable[dict], dataset: str, roles: dict[str, set[str]]) -> list[dict[str, Any]]:
    question_to_roles: dict[str, set[str]] = defaultdict(set)
    for row in rows:
        row_id = _row_id(row, dataset)
        keys = [normalized_question_key(str(row["question"]))]
        for decomposition in row.get("question_decomposition", []):
            if isinstance(decomposition, dict) and decomposition.get("question"):
                keys.append(normalized_question_key(str(decomposition["question"])))
        for key in keys:
            for role, ids in roles.items():
                if row_id in ids:
                    question_to_roles[key].add(role)
    return [
        {"normalized_question": key, "roles": sorted(value)}
        for key, value in sorted(question_to_roles.items())
        if len(value) > 1
    ]


def _question_keys(row: dict[str, Any]) -> set[str]:
    keys = {normalized_question_key(str(row["question"]))}
    for decomposition in row.get("question_decomposition", []):
        if isinstance(decomposition, dict) and decomposition.get("question"):
            keys.add(normalized_question_key(str(decomposition["question"])))
    return keys


def build_frozen_split_manifest(config: dict[str, Any]) -> dict[str, Any]:
    seed = int(config["data"]["seed"])
    result: dict[str, Any] = {
        "schema_version": "1.0",
        "seed": seed,
        "datasets": {},
        "official_dev_is_hidden_test": False,
    }
    for offset, dataset in enumerate(("musique", "twowiki")):
        paths = config["data"]["datasets"][dataset]
        id_key = "id" if dataset == "musique" else "_id"
        def summarize(row: dict[str, Any]) -> dict[str, Any]:
            return {
                id_key: row[id_key],
                "question": row["question"],
                "type": row.get("type"),
                "question_decomposition": row.get("question_decomposition", []),
            }
        train_rows = [summarize(row) for row in iter_raw_json(paths["train_path"])]
        train_ids = _rank((_row_id(row, dataset) for row in train_rows), seed + offset)
        row_by_id = {_row_id(row, dataset): row for row in train_rows}
        train_count = 1000
        internal_count = 200
        if len(train_ids) < train_count + internal_count:
            raise ValueError(f"{dataset} train split is too small")
        full_train = train_ids[:train_count]
        train_keys = set().union(*(_question_keys(row_by_id[row_id]) for row_id in full_train))
        internal_dev = []
        internal_keys: set[str] = set()
        for row_id in train_ids[train_count:]:
            keys = _question_keys(row_by_id[row_id])
            if keys.isdisjoint(train_keys) and keys.isdisjoint(internal_keys):
                internal_dev.append(row_id)
                internal_keys.update(keys)
                if len(internal_dev) == internal_count:
                    break
        if len(internal_dev) < internal_count:
            raise ValueError(f"{dataset} cannot form a leakage-free internal_dev of {internal_count}")
        initial_train = full_train[:200]
        roles = {"full_train": set(full_train), "internal_dev": set(internal_dev)}
        duplicates = _duplicates_across_roles(train_rows, dataset, roles)
        if duplicates:
            raise ValueError(f"{dataset} exact normalized near-duplicates cross train/internal_dev: {len(duplicates)}")
        official_rows = [summarize(row) for row in iter_raw_json(paths["official_dev_path"])]
        official_e2 = stratified_ids(official_rows, dataset, 1000, seed + 100 + offset)
        official_e1 = official_e2[:200]
        e1_set = set(official_e1)
        result["datasets"][dataset] = {
            "train_path": paths["train_path"],
            "official_dev_path": paths["official_dev_path"],
            "initial_train_ids": initial_train,
            "full_train_ids": full_train,
            "internal_dev_ids": internal_dev,
            "e1_official_dev_ids": official_e1,
            "e2_official_dev_ids": official_e2,
            "counts": {
                "initial_train": len(initial_train),
                "full_train": len(full_train),
                "internal_dev": len(internal_dev),
                "e1_official_dev": len(official_e1),
                "e2_official_dev": len(official_e2),
            },
            "strata_e1": dict(Counter(_stratum(row, dataset) for row in official_rows if _row_id(row, dataset) in e1_set)),
            "near_duplicate_audit": {"method": "exact_normalized_question_and_musique_subquestions", "cross_role_count": 0},
        }
    return result


def write_split_manifest(config: dict[str, Any], destination: str | Path) -> dict[str, Any]:
    manifest = build_frozen_split_manifest(config)
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest
