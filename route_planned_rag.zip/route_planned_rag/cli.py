from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from route_planned_rag.accounting import BudgetUsage, GlobalLedger
from route_planned_rag.config import ConfigError, load_config
from route_planned_rag.corpus.retrieval import CachedRetriever, InMemoryBM25Retriever
from route_planned_rag.corpus.build import build_chunks, dense_index_manifest
from route_planned_rag.corpus.external import normalize_external_corpus
from route_planned_rag.data.pooling import build_pooled_corpus
from route_planned_rag.data.splits import write_split_manifest
from route_planned_rag.evaluation.report import build_actual_run_report
from route_planned_rag.experiments.vertical import run_vertical
from route_planned_rag.manifest import base_manifest
from route_planned_rag.models.deterministic import DeterministicActor, HeuristicScorer
from route_planned_rag.models.registry import ModelRegistry, resolve_huggingface_revision
from route_planned_rag.rollouts.collector import collect_continuations
from route_planned_rag.search.controllers import (
    GlobalGreedyController,
    NoRetrievalController,
    Pi0Controller,
    SingleRouteIterativeController,
)
from route_planned_rag.search.engine import EpisodeRunner
from route_planned_rag.search.mcts import MCTSControl
from route_planned_rag.storage import RunWriter
from route_planned_rag.training.checkpoint import load_trained_scorer
from route_planned_rag.training.trainer import train_scorer
from route_planned_rag.types import ObservedPassage, PublicSample


def _registry(config: dict) -> ModelRegistry:
    root = Path(config["project"]["root"])
    registry = ModelRegistry(root / "model_allowlist.json")
    registry.validate_configured_roles(config["models"])
    return registry


def _writer(config: dict, prefix: str, requested_run_id: str | None) -> RunWriter:
    run_id = requested_run_id or RunWriter.timestamped_id(prefix)
    return RunWriter(config["project"]["run_root"], run_id, project_root=config["project"]["root"])


def command_prepare(args, config: dict) -> int:
    registry = _registry(config)
    root = Path(config["project"]["root"])
    paths = [
        Path(config["project"]["artifact_root"]),
        Path(config["project"]["run_root"]),
        Path(config["project"]["cache_root"]),
        root / "data" / "raw",
        root / "indexes",
        root / "models_cache",
    ]
    if args.dry_run:
        print(json.dumps({"status": "dry_run", "paths": list(map(str, paths))}, indent=2))
        return 0
    for path in paths:
        path.mkdir(parents=True, exist_ok=True)
    writer = _writer(config, "prepare", args.run_id)
    manifest = base_manifest(config, "prepare")
    resolved = {}
    if args.resolve_models:
        for role in ("actor", "scorer", "reranker", "retriever"):
            item = config["models"][role]
            registry.require(item["repo_id"], "compiler" if role == "actor" else role)
            resolved[role] = resolve_huggingface_revision(item["repo_id"], item.get("revision"))
    manifest.update({"status": "complete", "resolved_revisions": resolved})
    writer.write_json("manifest.json", manifest)
    writer.write_json("metrics.json", {"status": "not_applicable", "values": {}})
    writer.write_json("resources.json", {"status": "complete", "usage": {}})
    print(writer.run_dir)
    return 0


def command_contract_smoke(args, config: dict) -> int:
    _registry(config)
    writer = _writer(config, "contract-smoke", args.run_id)
    passage = ObservedPassage(
        chunk_id="smoke-chunk-0",
        doc_id="smoke-doc-0",
        text="Paris is the capital of France.",
        char_start=0,
        char_end=31,
        sentence_ids=(0,),
    )
    limits = BudgetUsage(
        actor_requests=100,
        format_repair_requests=10,
        logical_retrieval_calls=1,
        physical_backend_requests=1,
        reasoning_input_tokens=10000,
        reasoning_output_tokens=2000,
        scorer_forward_tokens=10000,
        reader_input_tokens=1000,
        reader_output_tokens=100,
    )
    ledger = GlobalLedger(limits, BudgetUsage(reader_input_tokens=1000, reader_output_tokens=100))
    backend = InMemoryBM25Retriever({"contract-smoke": [passage]})
    retriever = CachedRetriever(backend, ledger)
    runner = EpisodeRunner(
        DeterministicActor(),
        retriever,
        GlobalGreedyController(HeuristicScorer()),
        initial_top_k=1,
        delivered_top_k=1,
    )
    sample = PublicSample("smoke-0", "What is the capital of France?", "internal_dev", "contract-smoke")
    episode = runner.run(sample)
    if episode.completion_status.value != "complete":
        raise RuntimeError(f"contract smoke failed: {episode.stop_reason}")
    writer.write_json("manifest.json", {**base_manifest(config, "contract-smoke"), "status": "complete", "synthetic_contract_only": True})
    for event in episode.events + episode.ledger.events:
        writer.append_event(event)
    writer.append_prediction({"question_id": sample.question_id, "answer": episode.answer.answer, "synthetic_contract_only": True})
    writer.write_json("metrics.json", {"status": "complete", "synthetic_contract_only": True, "values": {"completed": 1}})
    writer.write_json("resources.json", {"status": "complete", "usage": episode.ledger.used.to_dict()})
    print(writer.run_dir)
    return 0


def command_freeze_splits(args, config: dict) -> int:
    _registry(config)
    destination = Path(config["project"]["root"]) / "data" / "manifests" / "frozen_splits_v1.json"
    if destination.exists() and not args.force:
        raise RuntimeError(
            f"split manifest already exists: {destination}; pass --force only for an intentional protocol revision"
        )
    manifest = write_split_manifest(config, destination)
    print(json.dumps({
        "path": str(destination),
        "counts": {name: item["counts"] for name, item in manifest["datasets"].items()},
    }, indent=2, sort_keys=True))
    return 0


def command_build_index(args, config: dict) -> int:
    _registry(config)
    writer = _writer(config, "build-index", args.run_id)
    writer.write_json("manifest.json", {**base_manifest(config, "build-index"), "status": "running"})
    root = Path(config["project"]["root"])
    datasets = ("musique", "twowiki", "multihop_rag", "browsecomp_plus") if args.dataset == "all" else (args.dataset,)
    results = {}
    try:
        for dataset in datasets:
            item = config["data"]["datasets"][dataset]
            corpus_dir = root / "data" / "corpora" / dataset
            private_dir = root / "data" / "private" / dataset
            is_external = dataset in {"multihop_rag", "browsecomp_plus"}
            documents = corpus_dir / ("actor_documents.jsonl" if is_external else "documents.jsonl")
            mapping = private_dir / "question_doc_map.jsonl"
            corpus_manifest_path = corpus_dir / "manifest.json"
            if args.stage in {"corpus", "all"}:
                ready = corpus_manifest_path.exists() and documents.exists() and (is_external or mapping.exists())
                if ready:
                    corpus_manifest = json.loads(corpus_manifest_path.read_text(encoding="utf-8"))
                    corpus_manifest["cache_status"] = "reused"
                else:
                    if is_external:
                        corpus_manifest = normalize_external_corpus(dataset, item["corpus_path"], documents)
                    else:
                        corpus_manifest = build_pooled_corpus(
                            dataset,
                            (item["train_path"], item["official_dev_path"]),
                            documents,
                            mapping,
                        )
                    corpus_manifest_path.write_text(json.dumps(corpus_manifest, indent=2, sort_keys=True) + "\n")
                writer.append_event({"event_type": "pooled_corpus", **corpus_manifest})
                results.setdefault(dataset, {})["corpus"] = corpus_manifest
            if args.stage in {"chunks", "dense", "all"}:
                if not documents.exists():
                    raise RuntimeError(f"build corpus stage before chunks: {documents}")
                actor = config["models"]["actor"]
                index_dir = root / "indexes" / dataset / actor["revision"]
                chunks_path = index_dir / "chunks.jsonl"
                chunk_manifest_path = index_dir / "chunk_manifest.json"
                if chunk_manifest_path.exists() and chunks_path.exists():
                    chunk_manifest = json.loads(chunk_manifest_path.read_text(encoding="utf-8"))
                    chunk_manifest["cache_status"] = "reused"
                else:
                    from transformers import AutoTokenizer

                    tokenizer = AutoTokenizer.from_pretrained(
                        actor["repo_id"],
                        revision=actor["revision"],
                        fix_mistral_regex=bool(actor.get("fix_mistral_regex")),
                        cache_dir=str(root / "cache" / "huggingface"),
                    )
                    chunk_manifest = build_chunks(
                        documents,
                        chunks_path,
                        tokenizer,
                        tokenizer_revision=actor["revision"],
                        chunk_tokens=int(config["retrieval"]["chunk_tokens"]),
                        overlap_tokens=int(config["retrieval"]["overlap_tokens"]),
                    )
                    chunk_manifest_path.parent.mkdir(parents=True, exist_ok=True)
                    chunk_manifest_path.write_text(json.dumps(chunk_manifest, indent=2, sort_keys=True) + "\n")
                dense_contract = dense_index_manifest(config, chunk_manifest)
                (index_dir / "dense_contract.json").write_text(json.dumps(dense_contract, indent=2, sort_keys=True) + "\n")
                writer.append_event({"event_type": "chunks", **chunk_manifest})
                results.setdefault(dataset, {})["chunks"] = chunk_manifest
            if args.stage in {"dense", "all"}:
                import torch

                if not torch.cuda.is_available():
                    raise RuntimeError("dense index construction requires a CUDA allocation")
                from route_planned_rag.models.dense_index import build_embedding_shards
                from route_planned_rag.models.e5 import E5MistralEncoder

                retriever_item = config["models"]["retriever"]
                dense_dir = index_dir / "dense" / dense_contract["index_id"]
                dense_manifest_path = dense_dir / "manifest.json"
                if dense_manifest_path.exists():
                    dense_manifest = json.loads(dense_manifest_path.read_text(encoding="utf-8"))
                    dense_manifest["cache_status"] = "reused"
                else:
                    encoder = E5MistralEncoder(
                        retriever_item["repo_id"],
                        retriever_item["revision"],
                        query_instruction=retriever_item["query_instruction"],
                        max_tokens=int(retriever_item["max_tokens"]),
                        device="cuda",
                        dtype=retriever_item["dtype"],
                        cache_dir=str(root / "cache" / "huggingface"),
                    )
                    dense_manifest = build_embedding_shards(
                        chunks_path,
                        dense_dir,
                        encoder,
                        batch_size=args.batch_size,
                        shard_size=args.shard_size,
                    )
                    dense_manifest = {**dense_contract, **dense_manifest}
                    dense_manifest_path.write_text(json.dumps(dense_manifest, indent=2, sort_keys=True) + "\n")
                writer.append_event({"event_type": "dense_index", "dataset": dataset, **dense_manifest})
                results.setdefault(dataset, {})["dense"] = dense_manifest
        writer.write_json("manifest.json", {**base_manifest(config, "build-index"), "status": "complete", "results": results})
        writer.write_json("metrics.json", {"status": "not_applicable", "values": {}})
        writer.write_json("resources.json", {"status": "complete", "usage": {}})
    except Exception as exc:
        writer.append_event({"event_type": "build_index_failure", "error_type": type(exc).__name__, "message": str(exc)})
        writer.write_json("manifest.json", {**base_manifest(config, "build-index"), "status": "failed", "error": str(exc)})
        raise
    print(writer.run_dir)
    return 0


def _datasets(value: str) -> tuple[str, ...]:
    return ("musique", "twowiki") if value == "all" else (value,)


def command_collect(args, config: dict) -> int:
    _registry(config)
    if not __import__("torch").cuda.is_available():
        raise RuntimeError("continuation collection requires a CUDA allocation")
    default_limit = {
        "initial": int(config["data"]["initial_train_questions"]) // 2,
        "full": int(config["data"]["full_train_questions"]) // 2,
        "internal_dev": int(config["data"]["internal_dev_questions"]) // 2,
    }[args.phase]
    skip_question_ids: set[str] = set()
    if args.resume:
        for event_path in Path(config["project"]["run_root"]).glob("collect-*/events.jsonl"):
            try:
                for line in event_path.read_text(encoding="utf-8").splitlines():
                    event = json.loads(line)
                    if event.get("event_type") == "question_collection_complete" and event.get("phase") == args.phase:
                        skip_question_ids.add(str(event["question_id"]))
            except (OSError, json.JSONDecodeError):
                continue
    writer = _writer(config, f"collect-{args.phase}", args.run_id)
    writer.write_json("manifest.json", {
        **base_manifest(config, "collect"),
        "status": "running",
        "phase": args.phase,
        "resume_requested": args.resume,
    })
    try:
        result = collect_continuations(
            config,
            writer,
            phase=args.phase,
            datasets=_datasets(args.dataset),
            limit=args.limit or default_limit,
            seed=args.seed if args.seed is not None else int(config["data"]["seed"]),
            skip_question_ids=skip_question_ids,
        )
        writer.write_json("metrics.json", result)
        writer.write_json("resources.json", {"status": "complete", "usage": {}})
        writer.write_json("manifest.json", {
            **base_manifest(config, "collect"),
            "status": "complete",
            "phase": args.phase,
            "resume_requested": args.resume,
            "result": result,
        })
    except Exception as exc:
        writer.append_event({"event_type": "collection_failure", "error_type": type(exc).__name__, "message": str(exc)})
        writer.write_json("manifest.json", {**base_manifest(config, "collect"), "status": "failed", "error": str(exc)})
        raise
    print(writer.run_dir)
    return 0


def _latest_labels(config: dict, phase: str) -> Path:
    candidates = []
    for path in Path(config["project"]["run_root"]).glob("collect-*/manifest.json"):
        try:
            manifest = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        label_path = path.parent / "labels.jsonl"
        if manifest.get("status") == "complete" and manifest.get("phase") == phase and label_path.exists():
            candidates.append(label_path)
    if not candidates:
        raise RuntimeError(f"no completed {phase} collection labels found")
    return max(candidates, key=lambda path: path.stat().st_mtime)


def command_train(args, config: dict) -> int:
    _registry(config)
    if not __import__("torch").cuda.is_available():
        raise RuntimeError("scorer training requires a CUDA allocation")
    train_path = Path(args.train_labels) if args.train_labels else _latest_labels(config, args.phase)
    dev_path = Path(args.dev_labels) if args.dev_labels else _latest_labels(config, "internal_dev")
    writer = _writer(config, f"train-{args.target}-seed-{args.seed}", args.run_id)
    output = writer.run_dir / "checkpoint"
    writer.write_json("manifest.json", {**base_manifest(config, "train"), "status": "running", "target": args.target, "seed": args.seed})
    try:
        result = train_scorer(
            config,
            target_kind=args.target,
            seed=args.seed,
            train_path=train_path,
            dev_path=dev_path,
            output_dir=output,
        )
        writer.write_json("metrics.json", {"status": "complete", "values": {"best_dev_loss": result["best_dev_loss"]}})
        writer.write_json("resources.json", {"status": "complete", "elapsed_seconds": result["elapsed_seconds"]})
        writer.write_json("manifest.json", {**base_manifest(config, "train"), "status": "complete", "target": args.target, "seed": args.seed, "checkpoint": str(output), "training": result})
    except Exception as exc:
        writer.append_event({"event_type": "training_failure", "error_type": type(exc).__name__, "message": str(exc)})
        writer.write_json("manifest.json", {**base_manifest(config, "train"), "status": "failed", "error": str(exc)})
        raise
    print(writer.run_dir)
    return 0


def _latest_checkpoint(config: dict, target: str, seed: int) -> Path:
    candidates = []
    for path in Path(config["project"]["run_root"]).glob(f"train-{target}-seed-{seed}*/manifest.json"):
        try:
            manifest = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        checkpoint = path.parent / "checkpoint"
        if manifest.get("status") == "complete" and checkpoint.exists():
            candidates.append(checkpoint)
    if not candidates:
        raise RuntimeError(f"no completed checkpoint for {target}, seed {seed}")
    return max(candidates, key=lambda path: path.stat().st_mtime)


def command_evaluate(args, config: dict) -> int:
    _registry(config)
    if not __import__("torch").cuda.is_available():
        raise RuntimeError("evaluation requires a CUDA allocation")
    method = args.method
    budget = args.call_budget or int(config["search"]["primary_call_budget"])
    if method == "no-retrieval":
        budget = 0
        factory = NoRetrievalController
    elif method == "single-shot":
        budget = 1
        factory = lambda: Pi0Controller("dependency_first")
    elif method == "ircot":
        factory = SingleRouteIterativeController
    elif method in {"planrag", "pi0"}:
        factory = lambda: Pi0Controller("dependency_first")
    elif method == "mcts":
        checkpoint = Path(args.checkpoint) if args.checkpoint else _latest_checkpoint(config, "success", args.seed)
        scorer = load_trained_scorer(config, checkpoint, "success")
        mcts_config = config["search"]["mcts"]
        factory = lambda: MCTSControl(
            scorer,
            exploration=float(args.mcts_exploration),
            max_depth=int(mcts_config["max_depth"]),
            simulations=int(mcts_config["simulations_per_decision"]),
        )
    else:
        target = method.removesuffix("-global")
        checkpoint = Path(args.checkpoint) if args.checkpoint else _latest_checkpoint(config, target, args.seed)
        scorer = load_trained_scorer(config, checkpoint, target)
        factory = lambda: GlobalGreedyController(scorer, float(args.lambda_value))
    role = "e1" if args.experiment in {"E1", "E3"} else "e2"
    if args.dataset == "browsecomp_plus":
        role = "external_main" if budget == 16 else "external_curve"
        default_limit = 830 if budget == 16 else 200
    elif args.dataset == "multihop_rag":
        role = "external_main"
        default_limit = 2556
    else:
        default_limit = int(config["data"]["e1_questions_per_dataset"] if role == "e1" else config["data"]["eval_questions_per_dataset"])
    writer = _writer(config, f"evaluate-{args.experiment}-{method}", args.run_id)
    writer.write_json("manifest.json", {**base_manifest(config, "evaluate"), "status": "running", "experiment": args.experiment, "method": method, "call_budget": budget})
    try:
        result = run_vertical(
            config,
            writer,
            datasets=_datasets(args.dataset),
            role=role,
            limit=args.limit or default_limit,
            call_budget=budget,
            controller_factory=factory,
            retrieval_protocol="pooled-corpus",
        )
        writer.write_json("metrics.json", {"status": "complete", **result})
        writer.write_json("resources.json", {"status": "complete", **result["resources"]})
        writer.write_json("manifest.json", {**base_manifest(config, "evaluate"), "status": "complete", "experiment": args.experiment, "method": method, "call_budget": budget, "evaluated": result["requested"]})
    except Exception as exc:
        writer.append_event({"event_type": "evaluation_failure", "error_type": type(exc).__name__, "message": str(exc)})
        writer.write_json("manifest.json", {**base_manifest(config, "evaluate"), "status": "failed", "error": str(exc)})
        raise
    print(writer.run_dir)
    return 0


def command_report(args, config: dict) -> int:
    _registry(config)
    writer = _writer(config, "report", args.run_id)
    destination = Path(config["project"]["artifact_root"]) / "actual_run_report.json"
    report = build_actual_run_report(config["project"]["run_root"], destination)
    writer.write_json("manifest.json", {**base_manifest(config, "report"), "status": "complete", "report": str(destination)})
    writer.write_json("metrics.json", {"status": "complete", "values": {"complete_runs": report["complete_count"], "failed_runs": report["failed_count"]}})
    writer.write_json("resources.json", {"status": "complete", "usage": {}})
    print(writer.run_dir)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="route-planned-rag")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name in ("prepare", "freeze-splits", "build-index", "collect", "train", "evaluate", "report", "contract-smoke"):
        sub = subparsers.add_parser(name)
        sub.add_argument("--config", default="configs/default.yaml")
        sub.add_argument("--run-id")
        if name == "prepare":
            sub.add_argument("--resolve-models", action="store_true")
            sub.add_argument("--dry-run", action="store_true")
        if name == "freeze-splits":
            sub.add_argument("--force", action="store_true")
        if name == "build-index":
            sub.add_argument("--dataset", choices=("all", "musique", "twowiki", "multihop_rag", "browsecomp_plus"), default="all")
            sub.add_argument("--stage", choices=("all", "corpus", "chunks", "dense"), default="all")
            sub.add_argument("--batch-size", type=int, default=8)
            sub.add_argument("--shard-size", type=int, default=4096)
        if name == "collect":
            sub.add_argument("--phase", choices=("initial", "full", "internal_dev"), required=True)
            sub.add_argument("--resume", action="store_true")
            sub.add_argument("--dataset", choices=("all", "musique", "twowiki"), default="all")
            sub.add_argument("--limit", type=int)
            sub.add_argument("--seed", type=int)
        if name == "train":
            sub.add_argument("--target", choices=("cost", "success", "distance"), required=True)
            sub.add_argument("--seed", type=int, required=True)
            sub.add_argument("--phase", choices=("initial", "full"), default="initial")
            sub.add_argument("--train-labels")
            sub.add_argument("--dev-labels")
        if name == "evaluate":
            sub.add_argument("--experiment", choices=("E1", "E2", "E3", "E4", "E5", "E6"), required=True)
            sub.add_argument("--method", choices=("no-retrieval", "single-shot", "ircot", "planrag", "mcts", "pi0", "distance-global", "success-global", "cost-global"), default="cost-global")
            sub.add_argument("--dataset", choices=("all", "musique", "twowiki", "multihop_rag", "browsecomp_plus"), default="all")
            sub.add_argument("--limit", type=int)
            sub.add_argument("--call-budget", type=int)
            sub.add_argument("--lambda-value", type=float, default=16.0)
            sub.add_argument("--seed", type=int, default=11)
            sub.add_argument("--checkpoint")
            sub.add_argument("--mcts-exploration", type=float, choices=(0.5, 1.0, 2.0), default=1.0)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        config = load_config(args.config)
        if args.command == "prepare":
            return command_prepare(args, config)
        if args.command == "contract-smoke":
            return command_contract_smoke(args, config)
        if args.command == "freeze-splits":
            return command_freeze_splits(args, config)
        if args.command == "build-index":
            return command_build_index(args, config)
        if args.command == "collect":
            return command_collect(args, config)
        if args.command == "train":
            return command_train(args, config)
        if args.command == "evaluate":
            return command_evaluate(args, config)
        if args.command == "report":
            return command_report(args, config)
        raise RuntimeError(f"unknown command: {args.command}")
    except (ConfigError, RuntimeError, ValueError, OSError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
