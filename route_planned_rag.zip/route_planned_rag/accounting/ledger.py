from __future__ import annotations

import dataclasses
from dataclasses import dataclass, fields
from typing import Any


class BudgetExceeded(RuntimeError):
    pass


@dataclass
class BudgetUsage:
    actor_requests: int = 0
    format_repair_requests: int = 0
    logical_retrieval_calls: int = 0
    physical_backend_requests: int = 0
    reasoning_input_tokens: int = 0
    reasoning_output_tokens: int = 0
    unique_evidence_tokens: int = 0
    scorer_forward_tokens: int = 0
    dense_forward_tokens: int = 0
    reranker_forward_tokens: int = 0
    reader_input_tokens: int = 0
    reader_output_tokens: int = 0
    scorer_gpu_seconds: float = 0.0
    dense_gpu_seconds: float = 0.0
    reranker_gpu_seconds: float = 0.0
    actor_gpu_seconds: float = 0.0

    def __add__(self, other: "BudgetUsage") -> "BudgetUsage":
        return BudgetUsage(**{field.name: getattr(self, field.name) + getattr(other, field.name) for field in fields(self)})

    def __sub__(self, other: "BudgetUsage") -> "BudgetUsage":
        return BudgetUsage(**{field.name: getattr(self, field.name) - getattr(other, field.name) for field in fields(self)})

    def to_dict(self) -> dict[str, int | float]:
        return dataclasses.asdict(self)


class GlobalLedger:
    """One append-only, non-refundable ledger for a complete question."""

    def __init__(self, limits: BudgetUsage, final_reader_reserve: BudgetUsage | None = None):
        self.limits = limits
        self.used = BudgetUsage()
        self.final_reader_reserve = final_reader_reserve or BudgetUsage()
        self._reservations: dict[str, BudgetUsage] = {}
        self._completed_requests: set[str] = set()
        self._evidence_intervals: dict[str, list[tuple[int, int]]] = {}
        self.events: list[dict[str, Any]] = []

    @property
    def reserved(self) -> BudgetUsage:
        total = BudgetUsage()
        for usage in self._reservations.values():
            total = total + usage
        return total

    def remaining(self, include_reader_reserve: bool = False) -> BudgetUsage:
        held = self.reserved
        if not include_reader_reserve:
            held = held + self.final_reader_reserve
        return self.limits - self.used - held

    def can_search(self) -> bool:
        return self.remaining().logical_retrieval_calls >= 1

    def reserve(self, request_id: str, maximum: BudgetUsage) -> None:
        if request_id in self._completed_requests:
            return
        if request_id in self._reservations:
            if self._reservations[request_id] != maximum:
                raise ValueError("request reservation changed during resume")
            return
        candidate = self.used + self.reserved + self.final_reader_reserve + maximum
        self._assert_within_limits(candidate)
        self._reservations[request_id] = maximum
        self.events.append({"event_type": "reserve", "request_id": request_id, "reserved_budget": maximum.to_dict()})

    def reconcile(self, request_id: str, actual: BudgetUsage, *, complete: bool = True) -> None:
        if request_id in self._completed_requests:
            return
        maximum = self._reservations.pop(request_id, None)
        if maximum is None:
            raise ValueError(f"request {request_id} has no reservation")
        for field in fields(actual):
            if getattr(actual, field.name) > getattr(maximum, field.name) + 1e-9:
                raise BudgetExceeded(f"actual {field.name} exceeds reservation")
        self._assert_within_limits(self.used + actual)
        self.used = self.used + actual
        if complete:
            self._completed_requests.add(request_id)
        self.events.append({
            "event_type": "reconcile",
            "request_id": request_id,
            "usage_actual": actual.to_dict(),
            "completion_status": "complete" if complete else "incomplete_infrastructure",
        })

    def charge(self, request_id: str, actual: BudgetUsage) -> None:
        if request_id in self._completed_requests:
            return
        self.reserve(request_id, actual)
        self.reconcile(request_id, actual)

    def charge_reader(self, request_id: str, actual: BudgetUsage) -> None:
        if request_id in self._completed_requests:
            return
        prior = self.final_reader_reserve
        self.final_reader_reserve = BudgetUsage()
        try:
            self.reserve(request_id, actual)
            self.reconcile(request_id, actual)
        finally:
            self.final_reader_reserve = BudgetUsage()
        self.events.append({"event_type": "reader_reserve_released", "request_id": request_id, "prior": prior.to_dict()})

    def observe_evidence(self, request_id: str, passages) -> int:
        evidence_request_id = f"{request_id}:delivered-evidence"
        if evidence_request_id in self._completed_requests:
            return 0
        before = sum(end - start for values in self._evidence_intervals.values() for start, end in values)
        candidate_intervals = {doc_id: list(values) for doc_id, values in self._evidence_intervals.items()}
        for passage in passages:
            if passage.token_start is None or passage.token_end is None:
                continue
            values = candidate_intervals.setdefault(passage.doc_id, [])
            values.append((int(passage.token_start), int(passage.token_end)))
            merged = []
            for start, end in sorted(values):
                if not merged or start > merged[-1][1]:
                    merged.append([start, end])
                else:
                    merged[-1][1] = max(merged[-1][1], end)
            candidate_intervals[passage.doc_id] = [tuple(value) for value in merged]
        after = sum(end - start for values in candidate_intervals.values() for start, end in values)
        added = after - before
        self.charge(evidence_request_id, BudgetUsage(unique_evidence_tokens=added))
        self._evidence_intervals = candidate_intervals
        return added

    def snapshot(self) -> dict[str, Any]:
        return {
            "limits": self.limits.to_dict(),
            "used": self.used.to_dict(),
            "reserved": self.reserved.to_dict(),
            "final_reader_reserve": self.final_reader_reserve.to_dict(),
            "completed_request_ids": sorted(self._completed_requests),
        }

    def _assert_within_limits(self, candidate: BudgetUsage) -> None:
        for field in fields(candidate):
            limit = getattr(self.limits, field.name)
            if limit and getattr(candidate, field.name) > limit + 1e-9:
                raise BudgetExceeded(f"budget exceeded for {field.name}")
