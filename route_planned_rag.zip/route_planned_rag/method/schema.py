"""Frozen relational requirements and source-based question coverage checks."""
import re

from pydantic import Field

from route_planned_rag.logic_control.schema import Need, Plan, PLAN_PROMPT, plan_schema
from route_planned_rag.logic_control.compiler import compile_plan, question_operator, requested_count
from route_planned_rag.indexed.schema import parse_date
from route_planned_rag.prototype.logic import digest


def signature(value):
    def serializable(item):
        if hasattr(item, "model_dump"):
            return item.model_dump()
        if isinstance(item, dict):
            return {k: serializable(v) for k, v in item.items()}
        if isinstance(item, (list, tuple)):
            return [serializable(v) for v in item]
        return item
    return digest(serializable(value))


class Requirement(Need):
    negated: bool = False


class Program(Plan):
    needs: list[Requirement] = Field(min_length=1, max_length=12)


def words(text):
    return re.findall(r"[\w]+", text.casefold())


STOP = set("a an the which what who whose where when how did does do is are was were has have had be been being of in at on to for from by with and or as that this these those it its s both name named called please tell me".split())
QUALIFIERS = set("first last latest earliest younger youngest older oldest largest smallest former current independent separate only exactly least most before after during since until never without not except".split())
QUESTION_START = set("Which What Who Whose Where When How Is Are Was Were Do Does Did Has Have Had In At On The A An Both".split())


def normalized(text):
    return " ".join(words(text))


def contains(text, value):
    return (" " + normalized(value) + " ") in (" " + normalized(text) + " ")


def question_schema(question):
    """Constrain names/spans and answer operators before generation, not afterwards."""
    schema = Program.model_json_schema()
    source = plan_schema(question)
    for field in ("s", "o", "span"):
        schema["$defs"]["Requirement"]["properties"][field] = source["$defs"]["Need"]["properties"][field]
    requirement = schema["$defs"]["Requirement"]["properties"]
    # Possessive descriptions denote another required hop, not an entity name.
    # Quoted titles remain legal literal subjects even when they use possessives.
    quoted = {m[1] for m in re.finditer(r'["“]([^"”]+)["”]', question)}
    requirement["s"] = {"anyOf": [dict(enum=[s for s in requirement["s"]["anyOf"][0]["enum"] if not re.search(r"['’]s\s", s) or s in quoted]), requirement["s"]["anyOf"][1]]}
    if not re.search(r"\b(?:not|no|never|without|except|excluding)\b", question, re.I):
        requirement["negated"] = {"enum": [False]}
    schema["properties"]["choices"] = source["properties"]["choices"]
    schema["required"] = ["interpretation", "needs", "goal", "choices", "unrepresented"]
    goal = schema["$defs"]["Goal"]
    op = question_operator(question)
    goal["properties"]["op"] = {"enum": [op]}
    variable = {"type": "string", "pattern": r"^\?[a-z][a-z0-9_]{0,25}$"}
    for field in ("variable", "left", "right"):
        goal["properties"][field] = variable if (field == "variable") == (op == "select") else {"type": "null"}
    goal["required"] = ["op", "variable"] if op == "select" else ["op", "left", "right"]
    count = requested_count(question)
    goal["properties"]["count"] = {"enum": [count]}
    return schema


def contract(question, program):
    """Detect missing lexical clauses, named anchors, dates and explicit qualifiers.

    This is a checkable coverage contract, not a general natural-language
    equivalence theorem. Raw spans remain attached to each executable relation.
    """
    program.checked(question)
    if any(n.negated for n in program.needs) and not re.search(r"\b(?:not|no|never|without|except|excluding)\b", question, re.I):
        raise ValueError("question_contract_incomplete: question contains no negative requirement")
    spans = " ".join(n.span for n in program.needs)
    literals = " ".join(t for n in program.needs for t in (n.s, n.o, n.scope or "") if not t.startswith("?"))
    literals += " " + " ".join(v for values in program.choices.values() for v in values)
    relations = " ".join(n.r for n in program.needs)
    operators = {"greater": "more greater larger", "earlier": "earlier older first", "same": "same"}.get(program.goal.op, "")
    represented = spans + " " + literals + " " + relations + " " + operators
    if program.goal.count == requested_count(question) and program.goal.count is not None:
        represented += " " + re.match(r"^(?:What|Which) (\S+)", question, re.I)[1]
    missing_words = sorted(set(words(question)) - STOP - set(words(represented)))
    # Question operators and requested output nouns are represented by the goal
    # and types. Remaining relation words must be mapped to an exact question span.
    output_terms = {"many", "number", "year", "date", "country", "city", "place", "person", "school", "college", "university", "organization", "company", "film", "movie", "work", "character", "nationality", "category", "categories"}
    missing_words = [w for w in missing_words if w not in output_terms]
    anchors = []
    for match in re.finditer(r'\b[A-Z][\w-]*(?:\s+(?:(?:of|the|and|de|van)\s+)?[A-Z][\w-]*)*', question):
        parts = match.group().split()
        while parts and parts[0] in QUESTION_START:
            parts.pop(0)
        if parts:
            anchor = " ".join(parts)
            # A conjunction of two explicit names may occur in separate needs.
            anchors.extend(re.split(r"\s+and\s+", anchor))
    anchors.extend(m.group(1) for m in re.finditer(r'["“]([^"”]+)["”]', question))
    # Canonical dates preserve the original month/day anchors. A literal such as
    # Europe can also retain the question's inflected adjective European.
    months = "January|February|March|April|May|June|July|August|September|October|November|December"
    source_dates = re.finditer(r"\b(?:" + months + r"),?\s+\d{1,2}(?:st|nd|rd|th)?(?:,|\s)*(?:in\s+)?\d{4}\b", question, re.I)
    literal_dates = [parse_date(n.o) for n in program.needs if n.kind == "date" and not n.o.startswith("?")]
    date_spans = " ".join(m.group() for m in source_dates if parse_date(m.group()) in literal_dates)
    def anchor_present(anchor):
        if contains(literals, anchor) or contains(relations, anchor) or contains(date_spans, anchor):
            return True
        return any(normalized(anchor) == w + suffix for w in words(literals) if len(w) >= 4 for suffix in ("an", "n", "ian", "ese", "ish"))
    missing_anchors = sorted({a for a in anchors if not anchor_present(a)})
    numbers = set(re.findall(r"\b\d+(?:[.,]\d+)*\b", question))
    numeric_text = literals + " " + " ".join(n.r for n in program.needs)
    if program.goal.count is not None:
        numeric_text += " " + str(program.goal.count)
    missing_numbers = sorted(n for n in numbers if not contains(numeric_text, n))
    qualifiers = set(words(question)) & QUALIFIERS
    executed = " ".join(n.r + " " + (n.scope or "") for n in program.needs)
    explicit = set(words(executed))
    if any(n.negated for n in program.needs):
        explicit.update({"not", "never", "without"})
    if program.goal.op == "earlier":
        explicit.update({"older", "earlier", "first"})
    missing_qualifiers = sorted(qualifiers - explicit)
    missing = (["unmapped question words: " + ", ".join(missing_words)] if missing_words else [])
    missing += (["unbound question anchors: " + ", ".join(missing_anchors)] if missing_anchors else [])
    missing += (["unrepresented numbers: " + ", ".join(missing_numbers)] if missing_numbers else [])
    missing += (["unrepresented qualifiers: " + ", ".join(missing_qualifiers)] if missing_qualifiers else [])
    if re.search(r"\b(more|greater|larger)\b", question, re.I) and program.goal.op != "greater":
        missing.append("question comparison must use greater")
    if re.search(r"\b(earlier|older|born first)\b", question, re.I) and program.goal.op != "earlier":
        missing.append("question comparison must use earlier")
    record = dict(question=question, plan_hash=digest(program), coverage=[dict(node=i, span=n.span, subject=n.s, relation=n.r, object=n.o, scope=n.scope, negated=n.negated) for i, n in enumerate(program.needs)],
                  missing=missing, valid=not missing,
                  scope="question-span, literal-anchor, number, qualifier and structural checks; semantic translation remains a model proposal")
    if missing:
        raise ValueError("question_contract_incomplete: " + "; ".join(missing))
    return record


def compile_question(question, proposal):
    value = Program.model_validate(proposal.model_dump())
    operations = []
    retained = []
    for i, n in enumerate(value.needs):
        if n.s == n.o and n.s in value.choices and re.fullmatch(r"(?:is )?(?:one of|among)", n.r, re.I) and not n.negated:
            operations.append(dict(operation="question_domain_already_represented_by_choices", original_node=i, variable=n.s))
            continue
        if re.fullmatch(r"(?:has )?(?:time |temporal )?scope", n.r, re.I) and n.kind == "date" and not n.o.startswith("?"):
            parents = [p for p in value.needs if p is not n and p.s == n.s and p.o.startswith("?")]
            if len(parents) == 1 and parents[0].scope in (None, n.o):
                parents[0].scope = n.o
                operations.append(dict(operation="attach_explicit_temporal_scope", original_node=i, subject=n.s, scope=n.o))
                continue
        retained.append(n)
    value.needs = retained
    program, record = compile_plan(question, value)
    record["raw_proposal"] = proposal.model_dump()
    record["operations"] = operations + record["operations"]
    record["question_contract"] = contract(question, program)
    return program, record


COMPILE_PROMPT = PLAN_PROMPT + '''
METHOD CONTRACT: Every named entity, date, number and restrictive clause in the QUESTION must occur in the executable needs, not only in interpretation. Copy full exact question spans covering each relation and restriction, including intermediate roles. A geographical condition is a separate relation with the location as its literal object. E.g. "Which school in Paris did Nora graduate from?" requires (Nora,graduated from,?school) AND (?school,located in,Paris). Never omit a filter because evidence might be unavailable.
Need also permits negated:true for an explicitly negated requirement; it defaults to false. Preserve first/last/independent/former/current/younger/ordinal qualifications in the relation. Question-defined relationships are requirements, not factual axioms. If a condition cannot be represented, put it in unrepresented; do not output a simplified answerable question.
Output example: {"interpretation":"Find a school shared by both people.","needs":[{"s":"Nora","r":"graduated from","o":"?school","kind":"organization","span":"Nora and Ivo graduate from"},{"s":"Ivo","r":"graduated from","o":"?school","kind":"organization","span":"Nora and Ivo graduate from"}],"goal":{"op":"select","variable":"?school"},"choices":{},"unrepresented":[]}.
Return only the JSON object. Never fill an answer value from memory.

The supplied schema fixes the question's goal operator. A choice question is select, not same or greater: use one candidate variable with its finite choices and the requested filter. Do not add name-equals-each-choice nodes.
An event YEAR restricts the event relation: (Nora,won,?award,scope="2020"), not (?award,has date,2020). Do not change the spelling of any question name even if you remember a more famous similar name.
For "What three categories does income fall into under Luma's tax code?", use ONE multirow need (income,falls into categories under Luma's tax code,?category), with the full question span and goal select ?category count=3. No category1/category2/category3 variables and no named document required for the code. The legal scope must remain in the relation. Finite answer cardinality is not a separate evidence request.
Use a direct boolean guard for a descriptive set: (?character,is one of the seven Luma characters with independent series and their own logos,true). Do not invent a name for the unnamed set, series, logo, measure, or fictional status. Proper names mentioned inside such executable qualified relations count as constraints only when their roles are explicit.
'''
