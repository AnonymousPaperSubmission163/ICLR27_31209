"""Method-diagram controller: index -> proof or read/retrieve -> state feedback."""
import json
import re
import time
from pathlib import Path

from .reader import original_sentences, slot_schema, slots_to_reading, SLOT_PROMPT
from route_planned_rag.prototype.logic import substitute
from route_planned_rag.prototype.prover import Prover, write_json
from .schema import contract, words, STOP
from .schema import signature as digest
from .store import Store
from .planner import plan


DEFAULTS = dict(max_retrievals=8, max_reader_calls=16, max_steps=40, max_attempts=2,
                retrieval_top_k=5, reading_top_k=2, max_bindings=512,
                reader_output_tokens=2000, read_cost=.2, retrieve_cost=1.,
                cost_unit="relative_acquisition_units", prover_timeout=2, max_prover_calls=64)


class Engine:
    def __init__(self, question, program, client, retriever, prover, directory, config=None):
        self.question = question
        self.program = program
        self.coverage = contract(question, program)
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.config = dict(DEFAULTS, **(config or {}))
        self.client, self.retriever, self.prover = client, retriever, prover
        self.store = Store(question, program, self.directory / "relations.sqlite", self.config["max_bindings"])
        self.state_path = self.directory / "checkpoint.json"
        self.state = dict(plan_hash=digest(program), retrieval_calls=0, reader_calls=0, step=0,
                          reads={}, queries=[], retrieval_attempts={}, query_usage=[], events=[], last_candidate=None,
                          reader_errors=[], proof_attempts={}, proofs=[], run_seconds=0.)
        if self.state_path.exists():
            self.state = json.loads(self.state_path.read_text())
            if self.state["plan_hash"] != digest(program):
                raise ValueError("checkpoint graph mismatch")
        # Restore completed prover records/cache so resumed runs retain real costs.
        self.restore_prover()
        self.started = time.perf_counter()
        write_json(self.directory / "question_contract.json", self.coverage)

    def restore_prover(self):
        if not isinstance(self.prover, Prover) or self.prover.records:
            return
        for path in sorted(self.prover.directory.glob("P*/record.json")):
            r = json.loads(path.read_text())
            self.prover.records.append(r)
            if r["result"] not in ("unavailable", "budget_exhausted"):
                self.prover.calls += 1
        # IDs must remain append-only even if a process died before record.json.
        existing = list(self.prover.directory.glob("P*"))
        if len(existing) > len(self.prover.records):
            raise ValueError("incomplete_prover_record: retain interrupted episode and use a new run")

    def save(self):
        self.store.sync()
        write_json(self.state_path, self.state)
        write_json(self.directory / "events.json", self.state["events"])

    def event(self, kind, **data):
        self.state["events"].append(dict(step=self.state["step"], kind=kind, **data))
        self.save()

    def requests(self, nodes, binding):
        requests = []
        for i in nodes:
            n = self.program.needs[i]
            requests.append(dict(id="N" + str(i), relation=n.r, condition=n.span,
                                 subject_filter=binding.get(n.s[1:]) if n.s.startswith("?") else n.s,
                                 value_filter=binding.get(n.o[1:]) if n.o.startswith("?") else n.o,
                                 subject_type=n.subject_kind, value_type=n.kind, scope=n.scope,
                                 required_negation=n.negated))
        return requests

    def reading_payload(self, evidence, nodes, binding, retry=False):
        payload = dict(requests=self.requests(nodes, binding), passages=original_sentences(evidence)[0])
        if retry:
            payload["task"] = "Re-read the originals for omitted alternatives or a previous format failure. Keep every condition; do not guess unsupported rows."
            payload["previous_rejections"] = self.store.rejected[-6:]
        return payload

    def read_signature(self, request, eid):
        return digest([request["target"], eid, self.store.plan_hash])

    def read_option(self, request):
        if self.state["reader_calls"] >= self.config["max_reader_calls"]:
            return None
        eligible = []
        wanted = set(words(self.program.needs[request["node"]].r)) - STOP
        anchor = request["anchor"] or ""
        neighboring_anchors = [t for n in self.program.needs for t in (n.s, n.o) if not t.startswith("?") and t not in ("true", "false")]
        for eid, evidence in self.store.evidence.items():
            signature = self.read_signature(request, eid)
            attempts = self.state["reads"].get(signature, 0)
            if attempts >= self.config["max_attempts"]:
                continue
            title = evidence["source_metadata"]["title"]
            anchor_present = self.store.canonical(anchor) == self.store.canonical(title) or anchor.casefold() in evidence["original_text"].casefold()
            overlap = len(wanted & set(words(evidence["original_text"])))
            neighbor_present = any(a.casefold() in (title + " " + evidence["original_text"]).casefold() for a in neighboring_anchors)
            unbound_signature = self.read_signature(dict(target=self.store.pattern(request["node"]).model_dump()), eid)
            unseen = self.state["reads"].get(unbound_signature, 0) == 0
            # A neighboring anchor can add an unread passage to a multi-slot
            # batch. Once read, only the current anchor justifies a bound reread.
            if not (anchor_present or (neighbor_present and (unseen or not request["binding"])) or (unseen and overlap)):
                continue
            eligible.append((attempts, self.store.canonical(anchor) != self.store.canonical(title), not anchor_present, -overlap, eid))
        if not eligible:
            return None
        eligible.sort()
        ids = [row[-1] for row in eligible[:self.config["reading_top_k"]]]
        return dict(request, key=digest(["read", request["id"], ids]), mode="read", source_ids=ids, cost=self.config["read_cost"])

    def retrieval_option(self, request):
        if self.state["retrieval_calls"] >= self.config["max_retrievals"] or self.state["reader_calls"] >= self.config["max_reader_calls"]:
            return None
        attempt = self.state["retrieval_attempts"].get(request["id"], 0)
        if attempt >= self.config["max_attempts"]:
            return None
        need = self.program.needs[request["node"]]
        target = request["target"]
        names = [self.store.names[t["name"]] for t in target["arguments"] if t["kind"] == "constant" and self.store.names[t["name"]] not in ("true", "false")]
        base = " ".join(dict.fromkeys([*names, need.r, need.scope or ""])) .strip()
        candidates = [base, self.question + " " + base]
        for query in candidates[attempt:]:
            if query not in self.state["queries"]:
                return dict(request, key=digest(["retrieve", request["id"], query]), mode="retrieve", query=query,
                            cost=self.config["retrieve_cost"] + self.config["read_cost"])
        return None

    def read(self, action):
        evidence = [self.store.evidence[eid] for eid in action["source_ids"]]
        # One reader call fills independent slots for the entire fixed graph.
        # Only the selected slot receives this candidate's binding; other slots
        # stay unbound to avoid excluding alternative entities.
        nodes = list(range(len(self.program.needs)))
        payload = self.reading_payload(evidence, nodes, {}, retry=any(self.state["reads"].get(self.read_signature(action, eid), 0) for eid in action["source_ids"]))
        selected = self.requests([action["node"]], action["binding"])[0]
        payload["requests"][action["node"]] = selected
        maximum = self.config["reader_output_tokens"]
        if hasattr(self.client, "preflight"):
            self.client.preflight(SLOT_PROMPT, payload, maximum)
        self.state["reader_calls"] += 1
        # The same call reads every slot. Charge every slot/source attempt so
        # switching the selected node cannot buy identical unbound reads again.
        for node in nodes:
            target = action["target"] if node == action["node"] else self.store.pattern(node).model_dump()
            for eid in action["source_ids"]:
                signature = self.read_signature(dict(target=target), eid)
                self.state["reads"][signature] = self.state["reads"].get(signature, 0) + 1
        self.event("reader_started", action=action)
        try:
            raw = self.client.ask("reader", slot_schema(nodes, evidence), SLOT_PROMPT, payload, maximum=maximum)
            reading, unknown = slots_to_reading(raw, evidence)
            self.store.rejected.extend(unknown)
            ids = self.store.propose(reading, self.client.calls[-1]["call_id"])
            self.event("facts_updated", action=action, admitted=ids, missing=reading.missing,
                       source_ids=action["source_ids"], store_version=self.store.version, unknown=unknown)
        except (ValueError, KeyError, IndexError, RuntimeError) as exc:
            self.state["reader_errors"].append(repr(exc))
            self.event("reader_failed", action=action, error=repr(exc))
            if "token_budget_exhausted" in str(exc):
                raise

    def retrieve(self, action):
        # Reserve at least a reader over current originals before spending E5.
        if hasattr(self.client, "preflight"):
            self.client.preflight(SLOT_PROMPT, self.reading_payload([], list(range(len(self.program.needs))), {}), self.config["reader_output_tokens"])
        self.state["retrieval_calls"] += 1
        self.state["queries"].append(action["query"])
        self.state["retrieval_attempts"][action["id"]] = self.state["retrieval_attempts"].get(action["id"], 0) + 1
        self.event("retrieval_started", action=action)
        evidence, usage = self.retriever(action["query"], self.config["retrieval_top_k"])
        old = set(self.store.evidence)
        self.store.observe(evidence)  # Every returned original is retained, including unread passages.
        self.state["query_usage"].append(usage)
        self.event("retrieval_completed", action=action, source_ids=[e["evidence_id"] for e in evidence],
                   new_source_ids=sorted(set(self.store.evidence) - old), usage=usage)

    def prove(self):
        candidates = self.store.candidates()
        selected = {}
        for candidate in sorted(candidates, key=lambda c: (len(c["facts"]), digest(c))):
            selected.setdefault(candidate["term"].name, candidate)
        answers = []
        for candidate in selected.values():
            signature = digest([candidate["binding"], candidate["facts"], self.store.alias_version, self.store.plan_hash])
            cached = next((p for p in self.state["proofs"] if p["signature"] == signature and p["certificate"].get("valid")), None)
            if cached:
                certificate = cached["certificate"]
            else:
                if self.state["proof_attempts"].get(signature, 0) >= 2:
                    continue
                self.state["proof_attempts"][signature] = self.state["proof_attempts"].get(signature, 0) + 1
                self.event("proof_started", signature=signature, value=candidate["value"], fact_ids=candidate["facts"])
                certificate = self.store.prove(candidate, self.prover)
                record = self.prover.records[-1] if self.prover.records else {}
                self.event("proof_finished", signature=signature, result=record.get("result", "unavailable"), proof_id=record.get("proof_id"))
                if certificate:
                    self.state["proofs"].append(dict(signature=signature, certificate=certificate))
            if certificate:
                answers.append(dict(value=candidate["value"], fact_ids=candidate["facts"], proof_id=certificate["proof_id"], computation=candidate["computation"]))
        if self.program.goal.count is not None and len(answers) != self.program.goal.count:
            return []
        return answers

    def run(self):
        status, error, answers = "unknown", None, []
        try:
            while self.state["step"] < self.config["max_steps"]:
                assert digest(self.program) == self.state["plan_hash"]
                answers = self.prove()
                if answers:
                    status = "proved"
                    break
                candidates, action = plan(self)
                self.event("support_plan", candidates=candidates, selected=action,
                           enumeration_truncated=self.store.truncated, cost_unit=self.config["cost_unit"])
                if action is None:
                    if self.state["reader_calls"] >= self.config["max_reader_calls"]:
                        status = "reader_budget_exhausted"
                    elif self.state["retrieval_calls"] >= self.config["max_retrievals"]:
                        status = "retrieval_budget_exhausted"
                    elif self.store.candidates():
                        status = "proof_unavailable"
                    elif any(r["status"] == "conflicted" for r in self.store.rows.values()):
                        status = "conflicted"
                    else:
                        status = "unknown_no_executable_action"
                    break
                previous = self.state["last_candidate"]
                if previous and previous != action["candidate_id"]:
                    self.event("support_switched", old=previous, new=action["candidate_id"])
                self.state["last_candidate"] = action["candidate_id"]
                self.state["step"] += 1
                if action["mode"] == "read":
                    self.read(action)
                else:
                    self.retrieve(action)
            else:
                status = "step_budget_exhausted"
        except (ValueError, KeyError, RuntimeError, OSError) as exc:
            error = repr(exc)
            status = "token_budget_exhausted" if "token_budget_exhausted" in str(exc) else "execution_error"
        self.state["run_seconds"] += time.perf_counter() - self.started
        facts = sorted({fid for a in answers for fid in a["fact_ids"]})
        sources = sorted({self.store.rows[fid]["evidence_id"] for fid in facts})
        result = dict(question=self.question, status=status, error=error, final_answer="; ".join(dict.fromkeys(a["value"] for a in answers)),
                      answer_source="proved_readout" if answers else "abstain", answers=answers, evidence_ids=sources,
                      citations=[dict(fact_id=fid, evidence_id=self.store.rows[fid]["evidence_id"], quote=self.store.rows[fid]["quote"], position=self.store.rows[fid].get("quote_alignment")) for fid in facts],
                      plan_hash=self.state["plan_hash"], question_contract=self.coverage,
                      retrieval_calls=self.state["retrieval_calls"], reader_calls=self.state["reader_calls"], model_calls=len(self.client.calls),
                      input_tokens=sum(c.get("input_tokens", 0) for c in self.client.calls), output_tokens=sum(c.get("output_tokens", 0) for c in self.client.calls),
                      unknown_usage_calls=sum(c.get("status") == "interrupted_usage_unknown" for c in self.client.calls),
                      proof_calls=self.prover.calls, proof_seconds=sum(p.get("elapsed_seconds", 0) for p in self.prover.records),
                      query_embedding_usage=self.state["query_usage"], seconds=self.state["run_seconds"],
                      semantic_status="proof conditional on question translation and program-checked source-backed premises",
                      independent_review_calls=0, original_passages=len(self.store.evidence))
        self.event("finished", status=status, answer=result["final_answer"])
        write_json(self.directory / "result.json", result)
        write_json(self.directory / "proofs.json", self.store.certificates)
        return result
