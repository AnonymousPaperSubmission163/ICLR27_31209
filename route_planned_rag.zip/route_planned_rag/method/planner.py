"""Bounded support enumeration; unit acquisition costs, shared actions counted once."""
from route_planned_rag.prototype.logic import substitute
from .schema import signature as digest


def plan(engine):
    store = engine.store
    candidates = []
    actions = {}
    for row in store.joins(partial=True):
        missing = {}
        ready = []
        facts = set(row["facts"])
        for node in row["missing"]:
            target = substitute(store.pattern(node), row["binding"])
            # A later join can bind an earlier hypothetical omission. Recheck
            # the now-ground requirement in SQL before scheduling acquisition.
            if all(t.kind == "constant" for t in target.arguments):
                hits = store.match(target)
                if hits:
                    facts.update(hits[0]["facts"])
                    continue
            action_id = digest([target, store.plan_hash])
            if action_id in missing:
                continue
            binding = {k: store.names[v.name] for k, v in row["binding"].items()}
            constants = [store.names[t.name] if t.kind == "constant" else None for t in target.arguments]
            anchor = constants[0] or (constants[1] if constants[1] not in ("true", "false") else None)
            request = dict(id=action_id, node=node, binding=binding, target=target.model_dump(), anchor=anchor)
            choice = None
            if anchor:
                choice = engine.read_option(request) or engine.retrieval_option(request)
            cost = choice["cost"] if choice else engine.config["retrieve_cost"] + engine.config["read_cost"]
            missing[action_id] = dict(id=action_id, node=node, pattern=target.model_dump(), cost=cost, executable=choice is not None)
            if choice:
                ready.append(choice["key"])
                actions[choice["key"]] = choice
        cid = digest([row["binding"], sorted(missing), store.plan_hash])
        candidates.append(dict(id=cid, binding={k: store.names[v.name] for k, v in row["binding"].items()},
                               fact_ids=sorted(facts), missing=list(missing.values()),
                               remaining_cost=sum(a["cost"] for a in missing.values()), ready=sorted(set(ready))))
    # Resolving hypothetical omissions can collapse several rows to the same
    # support. Count that support once when measuring action sharing.
    unique = {}
    for candidate in candidates:
        old = unique.get(candidate["id"])
        if old is None or (len(candidate["fact_ids"]), candidate["fact_ids"]) < (len(old["fact_ids"]), old["fact_ids"]):
            unique[candidate["id"]] = candidate
    candidates = sorted(unique.values(), key=lambda c: (c["remaining_cost"], len(c["missing"]), c["id"]))
    sharing = {a: sum(a in c["ready"] for c in candidates) for a in actions}
    # Existing originals are always considered before purchasing another retrieval.
    readable = {key for key, a in actions.items() if a["mode"] == "read"}
    allowed = readable or set(actions)
    selected = None
    for candidate in candidates:
        choices = [actions[k] for k in candidate["ready"] if k in allowed]
        if choices:
            selected = min(choices, key=lambda a: (-sharing[a["key"]], a["cost"], a["node"], a["key"]))
            selected = dict(selected, candidate_id=candidate["id"], remaining_cost=candidate["remaining_cost"], shared_count=sharing[selected["key"]],
                            selection_reason="retained originals first; minimum distinct remaining acquisition cost; shared action tie break")
            break
    return candidates, selected
