"""Single reproducible entry point for the method diagram."""
import argparse
import hashlib
import json
import os
import shutil
import time
from pathlib import Path

from route_planned_rag.prototype.prover import Prover, write_json
from . import VERSION
from .client import Client
from .schema import Program, compile_question, question_schema, COMPILE_PROMPT
from .engine import Engine, DEFAULTS


def source_hashes(root):
    paths = [*root.glob("route_planned_rag/**/*.py"), root / "scripts/run_method.py"]
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def compile_episode(question, client, directory, maximum=2400):
    directory = Path(directory)
    saved = directory / "program.json"
    if saved.exists():
        value = Program.model_validate(json.loads(saved.read_text()))
        program, _ = compile_question(question, value)
        if program.model_dump() != value.model_dump():
            raise ValueError("resume attempted to change frozen program")
        return program
    error = None
    previous = None
    for attempt in range(2):
        payload = dict(question=question)
        if error:
            payload.update(previous=previous, error=error, instruction="Repair the question representation; preserve every named anchor and qualifying clause. No evidence or answers are available.")
        try:
            proposal = client.ask("compile" if not attempt else "compile_repair", Program, COMPILE_PROMPT, payload, maximum=maximum, decoding_schema=question_schema(question))
            previous = proposal.model_dump()
            write_json(directory / ("proposal_" + str(attempt) + ".json"), previous)
            program, record = compile_question(question, proposal)
            write_json(directory / "compilation.json", record)
            write_json(saved, program.model_dump())
            return program
        except (ValueError, KeyError, RuntimeError) as exc:
            error = repr(exc)
            write_json(directory / ("compile_error_" + str(attempt) + ".json"), dict(error=error, proposal=previous))
            if "token_budget_exhausted" in error:
                break
    raise ValueError("plan_invalid: " + str(error))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--config", type=Path, default=Path("configs/method.yaml"))
    parser.add_argument("--sample", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args(argv)
    if not args.run_id or Path(args.run_id).name != args.run_id:
        parser.error("run-id must be one directory name")
    root = args.root.resolve()
    import yaml
    config_path = args.config if args.config.is_absolute() else root / args.config
    settings = yaml.safe_load(config_path.read_text())
    config = dict(DEFAULTS, **settings["execution"])
    sample_path = args.sample if args.sample.is_absolute() else root / args.sample
    source = json.loads(sample_path.read_text())
    if args.limit is not None and args.limit <= 0:
        parser.error("limit must be positive")
    public = [{k: r[k] for k in ("question_id", "question", "context")} for r in source[:args.limit]]
    if not public or len({r["question_id"] for r in public}) != len(public):
        raise ValueError("empty or duplicate sample")
    if any(Path(r["question_id"]).name != r["question_id"] for r in public):
        raise ValueError("invalid question ID")
    model_config = yaml.safe_load((root / settings["model_config"]).read_text())
    binary = root / settings["prover_executable"]
    if not binary.is_file() or not os.access(binary, os.X_OK):
        raise ValueError("real Prover9 executable required before model loading")
    manifest = dict(version=VERSION, settings=settings, question_ids=[r["question_id"] for r in public],
                    public_sha256=hashlib.sha256(json.dumps(public, sort_keys=True).encode()).hexdigest(),
                    models=model_config["models"], sources=source_hashes(root),
                    prover_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                    run_kind="real_model", no_gold_online=True,
                    retrieval_setting="per_question_distractor_context",
                    graph_policy="fixed after question-contract validation", answer_policy="proved_readout_or_abstain",
                    model_roles=["compile", "compile_repair", "reader"], independent_review=False)
    out = root / "runs/method" / args.run_id
    if out.exists():
        if not args.resume:
            raise ValueError("existing run: use --resume or a fresh run ID")
        if json.loads((out / "protocol.json").read_text()) != manifest:
            raise ValueError("resume requires identical public inputs, source code, settings, models and prover")
    else:
        if args.resume:
            raise ValueError("resume run does not exist")
        out.mkdir(parents=True)
        write_json(out / "protocol.json", manifest)
        for name in manifest["sources"]:
            dst = out / "source_code" / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / name, dst)
    results = []
    pending = []
    for row in public:
        path = out / row["question_id"] / "result.json"
        if path.exists():
            result = json.loads(path.read_text())
            if result["question"] != row["question"]:
                raise ValueError("saved result question mismatch")
            results.append(result)
        else:
            pending.append(row)
    if pending:
        import torch
        from route_planned_rag.logicgraph.runtime import load_models
        from route_planned_rag.prototype.retrieval import ContextRetriever
        model_config["project"]["root"] = str(root)
        torch.manual_seed(settings["seed"])
        started = time.perf_counter()
        actor, _, encoder = load_models(model_config, with_encoder=True, with_scorer=False)
        runtime_path = out / "runtime.json"
        loads = json.loads(runtime_path.read_text()) if runtime_path.exists() else []
        loads.append(dict(job_id=os.getenv("SLURM_JOB_ID"), load_seconds=time.perf_counter() - started))
        write_json(runtime_path, loads)
        for row in pending:
            directory = out / row["question_id"]
            client = Client(actor, directory, budget=settings["question_token_budget"])
            started = time.perf_counter()
            engine = None
            try:
                program = compile_episode(row["question"], client, directory, settings["compiler_output_tokens"])
                retriever = ContextRetriever(row["context"], encoder)
                write_json(directory / "index_usage.json", retriever.index_usage)
                prover = Prover(binary, directory / "prover", timeout=config["prover_timeout"], cap=config["max_prover_calls"])
                engine = Engine(row["question"], program, client, retriever, prover, directory, config)
                result = engine.run()
            except (ValueError, KeyError, RuntimeError, OSError) as exc:
                result = dict(question=row["question"], status="plan_invalid" if "plan_invalid" in str(exc) else "execution_error", error=repr(exc),
                              final_answer="", answer_source="abstain", input_tokens=sum(c.get("input_tokens", 0) for c in client.calls),
                              output_tokens=sum(c.get("output_tokens", 0) for c in client.calls), model_calls=len(client.calls),
                              retrieval_calls=0, reader_calls=0, proof_calls=0)
            finally:
                if engine is not None:
                    engine.store.close()
            result.update(question_id=row["question_id"], seconds_this_invocation=time.perf_counter() - started)
            write_json(directory / "result.json", result)
            results.append(result)
            write_json(out / "results.json", results)
            print(json.dumps({k: result.get(k) for k in ("question_id", "status", "final_answer", "model_calls", "input_tokens", "output_tokens", "retrieval_calls", "proof_calls", "error")}), flush=True)
    by_id = {r["question_id"]: r for r in results}
    results = [by_id[r["question_id"]] for r in public]
    write_json(out / "results.json", results)
    calls = [dict(call, question_id=row["question_id"]) for row in public for call in json.loads((out / row["question_id"] / "model_calls.json").read_text())]
    write_json(out / "actual_model_calls.json", calls)
    write_json(out / "COMPLETE.json", dict(questions=len(results), model_calls=len(calls),
               input_tokens=sum(c.get("input_tokens", 0) for c in calls), output_tokens=sum(c.get("output_tokens", 0) for c in calls),
               unknown_usage_calls=sum(c["status"] == "interrupted_usage_unknown" for c in calls)))
    return results


if __name__ == "__main__":
    main()
