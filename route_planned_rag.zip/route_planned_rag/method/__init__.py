"""Canonical implementation of artifacts/method_diagram, version 1."""

VERSION = "method-diagram-v3"
