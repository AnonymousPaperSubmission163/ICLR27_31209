"""Persistent relational store sharing the tested grounding and scalar semantics."""
import json
import re
import sqlite3
from pathlib import Path

from route_planned_rag.logic_control.core import Store as BaseStore, quantity, lexical, align_quote
from route_planned_rag.indexed.schema import parse_date
from route_planned_rag.prototype.logic import substitute, unify, key
from .schema import signature as digest


class Store(BaseStore):
    def __init__(self, question, program, path, max_bindings=512):
        super().__init__(question, program)
        self.max_bindings = max_bindings
        self.truncated = False
        self.query_cache = {}
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS metadata (id INTEGER PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS evidence (id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS fact (id TEXT PRIMARY KEY, predicate TEXT NOT NULL,
                subject TEXT NOT NULL, object TEXT NOT NULL, negated INTEGER NOT NULL,
                status TEXT NOT NULL, data TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS forward_lookup ON fact(predicate, subject, negated, status);
            CREATE INDEX IF NOT EXISTS reverse_lookup ON fact(predicate, object, negated, status);
        ''')
        old = self.db.execute("SELECT data FROM metadata WHERE id=1").fetchone()
        if old:
            data = json.loads(old[0])
            if data["plan_hash"] != self.plan_hash or data["question"] != question:
                raise ValueError("stored graph/input mismatch")
            for name in ["version", "aliases", "names", "alias_version", "rejected", "certificates"]:
                setattr(self, name, data[name])
            self.rows = {i: json.loads(d) for i, d in self.db.execute("SELECT id,data FROM fact")}
            self.evidence = {i: json.loads(d) for i, d in self.db.execute("SELECT id,data FROM evidence")}

    def pattern(self, i):
        return super().pattern(i).model_copy(update={"negated": self.plan.needs[i].negated})

    def term(self, value, kind="entity"):
        term = super().term(value, kind)
        alias = self.aliases.get(lexical(value))
        if alias and term.kind == "constant":
            source = self.evidence.get(alias["evidence_id"])
            if source:
                title = source["source_metadata"]["title"]
                if self.canonical(title) == self.canonical(value):
                    # The explicit lead establishes identity; use its document
                    # title consistently for display rather than oscillating
                    # between a common name and an expanded biographical name.
                    self.names[term.name] = title
        return term

    def sync(self):
        with self.db:
            for eid, e in self.evidence.items():
                self.db.execute("INSERT OR REPLACE INTO evidence VALUES (?,?)", (eid, json.dumps(e)))
            for rid, row in self.rows.items():
                a = self.row_atom(row)
                self.db.execute("INSERT OR REPLACE INTO fact VALUES (?,?,?,?,?,?,?)", (rid, a.predicate, a.arguments[0].name, a.arguments[1].name, int(a.negated), row["status"], json.dumps(row)))
            data = {n: getattr(self, n) for n in ["question", "plan_hash", "version", "aliases", "names", "alias_version", "rejected", "certificates"]}
            self.db.execute("INSERT OR REPLACE INTO metadata VALUES (1,?)", (json.dumps(data),))
        self.query_cache.clear()

    def observe(self, evidence):
        super().observe(evidence)
        self.sync()

    def propose(self, reading, call_id):
        reading = reading.model_copy(deep=True)
        extensions = {}
        for row in reading.rows:
            source = self.evidence.get(row.evidence_id)
            if not source or lexical(row.s) in lexical(source["source_metadata"]["title"] + " " + row.quote):
                continue
            original = source["original_text"]
            quote, position = align_quote(row.quote, original)
            if not quote:
                continue
            # Keep the earlier explicit full-name antecedent in the citation.
            # This only adds original context; it never aliases people by surname.
            antecedent = re.search(re.escape(row.s), original[:position["start"]], re.I)
            surname = lexical(row.s).split()[-1:]
            if antecedent and surname and re.search(r"\b" + re.escape(surname[0]) + r"\b", lexical(quote)):
                extended = original[:position["end"]]
                extensions[(row.node, row.s, row.o, row.evidence_id)] = dict(selected_quote=quote, reason="retain_explicit_antecedent_from_same_original")
                row.quote = extended
        ids = super().propose(reading, call_id)
        admitted = []
        for rid in ids:
            row = self.rows[rid]
            if row["status"] != "proposed":
                continue  # Re-observation never resurrects rejected/withdrawn facts.
            need = self.plan.needs[row["node"]]
            extension = extensions.get((row["node"], row["s"], row["o"], row["evidence_id"]))
            if extension:
                row["citation_context"] = extension
            if need.kind == "boolean" and row["o"] not in ("true", "false"):
                self.set_status([rid], "rejected", "boolean_value_required")
                continue
            if need.kind == "date" and parse_date(row["o"]) is None:
                self.set_status([rid], "rejected", "date_value_required")
                continue
            if need.kind in ("number", "frequency") and quantity(row["o"], need.kind) is None:
                self.set_status([rid], "rejected", "non_comparable_or_ambiguous_quantity")
                continue
            if need.kind == "number":
                amount = quantity(row["o"])
                if amount and amount["lower"] == amount["upper"]:
                    surface = re.escape(row["o"])
                    guarded = re.search(r"\b(?:at least|at most|more than|less than|over|under|about|around|approximately|roughly|estimated(?: at)?)\s+" + surface + r"\b", row["quote"], re.I)
                    if guarded:
                        self.set_status([rid], "rejected", "source_quantity_qualification_was_dropped")
                        continue
            admitted.append(rid)
        if admitted:
            self.set_status(admitted, "accepted", "program_checked_source_type_scope; conditional_on_reader_translation")
        self.sync()
        return admitted

    def set_status(self, ids, status, reason):
        super().set_status(ids, status, reason)
        self.sync()

    def match(self, pattern, binding=None, statuses=("accepted",)):
        binding = binding or {}
        target = substitute(pattern, binding)
        sql = "SELECT id,data FROM fact WHERE predicate=? AND negated=? AND status IN (" + ",".join("?" for _ in statuses) + ")"
        values = [target.predicate, int(target.negated), *statuses]
        for field, term in zip(("subject", "object"), target.arguments):
            if term.kind == "constant":
                sql += " AND " + field + "=?"
                values.append(term.name)
        hits = []
        for rid, raw in self.db.execute(sql + " ORDER BY id", values):
            row = json.loads(raw)
            result = unify(target, self.row_atom(row), binding)
            if result is not None:
                hits.append(dict(binding=result, facts=[rid], missing=[]))
        return hits

    def joins(self, statuses=("accepted",), partial=False):
        self.lookups += 1
        signature = (self.version, self.alias_version, tuple(statuses), partial)
        if signature in self.query_cache:
            return self.query_cache[signature]
        self.truncated = False
        rows = [dict(binding=b, facts=[], missing=[]) for b in self.initial()]
        for i in range(len(self.plan.needs)):
            next_rows = {}
            for row in rows:
                for hit in self.match(self.pattern(i), row["binding"], statuses):
                    item = dict(binding=hit["binding"], facts=sorted(set(row["facts"] + hit["facts"])), missing=row["missing"])
                    sig = digest([item["binding"], item["missing"]])
                    previous = next_rows.get(sig)
                    if previous is None or (len(item["facts"]), item["facts"]) < (len(previous["facts"]), previous["facts"]):
                        next_rows[sig] = item
                if partial:
                    item = dict(row, missing=row["missing"] + [i])
                    next_rows.setdefault(digest([item["binding"], item["missing"]]), item)
            rows = list(next_rows.values())
            if len(rows) > self.max_bindings:
                self.truncated = True
                if not partial:
                    raise ValueError("complete_binding_budget_exhausted")
                rows.sort(key=lambda r: (len(r["missing"]), -len(r["binding"]), digest(r)))
                # Retain the empty hypothesis so later relations can bind either end.
                empty = next((r for r in rows if not r["binding"]), None)
                rows = rows[:self.max_bindings - 1] + ([empty] if empty else [rows[self.max_bindings - 1]])
        self.query_cache[signature] = rows
        return rows

    def prove(self, candidate, prover):
        result = super().prove(candidate, prover)
        self.sync()
        return result

    def close(self):
        self.sync()
        self.db.close()
