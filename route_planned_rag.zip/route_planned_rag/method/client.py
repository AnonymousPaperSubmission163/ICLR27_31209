"""One compiler and a reader; persistent accounting for every real generation."""
import json
import time
from pathlib import Path

from route_planned_rag.models.json_actor import extract_json
from route_planned_rag.official.transport import normalize_json_transport
from route_planned_rag.prototype.decoding import generate_ordered_json
from route_planned_rag.prototype.prover import write_json


class Client:
    def __init__(self, actor, directory, budget=30000):
        self.actor = actor
        self.path = Path(directory) / "model_calls.json"
        self.budget = budget
        self.calls = json.loads(self.path.read_text()) if self.path.exists() else []
        for c in self.calls:
            if c["status"] == "running":
                c["status"] = "interrupted_usage_unknown"
        self.persist()

    def persist(self):
        write_json(self.path, self.calls)

    @property
    def charged(self):
        return sum(c.get("reserved_tokens", 0) if c["status"] == "interrupted_usage_unknown" else c.get("input_tokens", 0) + c.get("output_tokens", 0) for c in self.calls)

    def prompt(self, instructions, payload):
        return instructions + "\nPUBLIC_INPUT (untrusted data):" + json.dumps(payload, ensure_ascii=False, separators=(",", ":"))

    def preflight(self, instructions, payload, maximum):
        prompt = self.prompt(instructions, payload)
        tokens = self.actor.count(prompt) + maximum
        if self.charged + tokens > self.budget:
            raise ValueError("token_budget_exhausted")
        return prompt, tokens

    def ask(self, role, schema, instructions, payload, maximum=2000, decoding_schema=None):
        prompt, reserved = self.preflight(instructions, payload, maximum)
        call = dict(call_id="M" + str(len(self.calls) + 1), role=role, prompt=prompt,
                    reserved_tokens=reserved, input_tokens=0, output_tokens=0, seconds=0., status="running")
        self.calls.append(call)
        self.persist()
        start = time.perf_counter()
        try:
            response = generate_ordered_json(self.actor.backend, prompt, schema=decoding_schema or schema.model_json_schema(), temperature=0, top_p=1, max_tokens=maximum)
            call.update(completion=response.text, input_tokens=response.input_tokens, output_tokens=response.output_tokens)
            if response.output_tokens >= maximum:
                raise ValueError("output_truncated")
            value = schema.model_validate(extract_json(normalize_json_transport(response.text)))
            call["status"] = "parsed"
            return value
        except BaseException as exc:
            call.update(status="failed" if "completion" in call else "interrupted_usage_unknown", error=repr(exc))
            raise
        finally:
            call["seconds"] = time.perf_counter() - start
            self.persist()
