"""Same-call extraction with an explicit unknown state and original citations."""
from typing import Literal
from pydantic import Field, create_model

from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.logic_control.reader import (
    SourceRow, original_sentences, slot_schema as legacy_schema,
    slots_to_reading as legacy_reading, SLOT_PROMPT as BASE_PROMPT,
)


class SourceCandidate(SourceRow):
    uncertain: bool = False


def slot_schema(nodes, evidence):
    _, sentences = original_sentences(evidence)
    row = create_model("MethodSourceRow", __base__=SourceCandidate,
                       evidence_id=(Literal[tuple(e["evidence_id"] for e in evidence)], ...),
                       sentence_ids=(list[Literal[tuple(sentences)]], Field(min_length=1, max_length=6)))
    slot = create_model("MethodSlot", __base__=Strict, check=(str, Field(max_length=280)), rows=(list[row], Field(max_length=24)))
    return create_model("MethodReading", __base__=Strict, **{"N" + str(i): (slot, ...) for i in nodes})


def slots_to_reading(value, evidence):
    data = value.model_dump()
    unknown = []
    for name, slot in data.items():
        rows = []
        for row in slot["rows"]:
            if row.pop("uncertain", False):
                unknown.append(dict(node=name, status="unknown", reason="reader_uncertain", **row))
            else:
                rows.append(row)
        slot["rows"] = rows
    nodes = [int(name[1:]) for name in data]
    return legacy_reading(legacy_schema(nodes, evidence).model_validate(data), evidence), unknown


SLOT_PROMPT = BASE_PROMPT + '''
Each row also permits uncertain:true. Use it for a speculative, disputed, ambiguous, or merely name-implied relation; the program retains it as unknown and excludes it from proofs. Otherwise use uncertain:false. A name containing a place alone does not establish location. Preserve bounds such as "at least 12" in value; "about 12" is uncertain, never the exact number 12.
When a cited sentence uses a surname or pronoun whose antecedent is in an earlier sentence, cite BOTH original sentence IDs so the source supports the full subject name. A quoted year is the scope of the stated event only when the source connects them. Include the preceding temporal sentence when needed. No independent review or final-answer generation is performed.
'''
