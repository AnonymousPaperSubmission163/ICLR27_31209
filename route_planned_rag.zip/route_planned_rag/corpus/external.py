from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

from route_planned_rag.data.adapters import iter_raw_json


def normalize_external_corpus(dataset: str, source: str | Path, destination: str | Path) -> dict:
    if dataset not in {"multihop_rag", "browsecomp_plus"}:
        raise ValueError("unsupported external corpus")
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + f".tmp-{os.getpid()}")
    count = 0
    with temporary.open("w", encoding="utf-8") as handle:
        for row in iter_raw_json(source):
            if dataset == "multihop_rag":
                doc_id = str(row.get("url") or hashlib.sha256(str(row).encode()).hexdigest())
                title = str(row.get("title", ""))
                text = str(row.get("body", ""))
            else:
                doc_id = str(row["docid"])
                title = str(row.get("url", doc_id))
                text = str(row["text"])
            handle.write(json.dumps({
                "doc_id": doc_id,
                "title": title,
                "text": text,
                "sentence_char_spans": [],
            }, ensure_ascii=False, sort_keys=True) + "\n")
            count += 1
    temporary.replace(target)
    return {
        "status": "complete",
        "dataset": dataset,
        "source_path": str(source),
        "documents_path": str(target),
        "document_count": count,
        "question_association_in_actor_index": False,
        "gold_flags_in_actor_index": False,
    }
