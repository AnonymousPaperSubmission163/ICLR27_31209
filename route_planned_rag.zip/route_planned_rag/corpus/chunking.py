from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from typing import Any, Iterable

from route_planned_rag.config import canonical_hash


@dataclass(frozen=True)
class SourceDocument:
    doc_id: str
    title: str
    text: str
    sentence_char_spans: tuple[tuple[int, int, int], ...] = ()


@dataclass(frozen=True)
class ChunkRecord:
    chunk_id: str
    doc_id: str
    title: str
    text: str
    char_start: int
    char_end: int
    token_start: int
    token_end: int
    sentence_ids: tuple[int, ...]
    tokenizer_revision: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def sentence_spans(text: str) -> list[tuple[int, int, int]]:
    result = []
    start = 0
    sentence_id = 0
    for match in re.finditer(r"(?<=[.!?])\s+|\n+", text):
        end = match.start()
        if text[start:end].strip():
            result.append((sentence_id, start, end))
            sentence_id += 1
        start = match.end()
    if text[start:].strip():
        result.append((sentence_id, start, len(text)))
    return result


def chunk_document(
    document: SourceDocument,
    tokenizer,
    *,
    tokenizer_revision: str,
    chunk_tokens: int,
    overlap_tokens: int,
) -> list[ChunkRecord]:
    if chunk_tokens <= 0 or overlap_tokens < 0 or overlap_tokens >= chunk_tokens:
        raise ValueError("invalid chunk/overlap sizes")
    encoded = tokenizer(
        document.text,
        add_special_tokens=False,
        return_offsets_mapping=True,
        truncation=False,
    )
    ids = list(encoded["input_ids"])
    offsets = list(encoded["offset_mapping"])
    if len(ids) != len(offsets):
        raise ValueError("tokenizer offset mapping length mismatch")
    if not ids:
        return []
    sentences = list(document.sentence_char_spans) or sentence_spans(document.text)
    step = chunk_tokens - overlap_tokens
    chunks = []
    for token_start in range(0, len(ids), step):
        token_end = min(token_start + chunk_tokens, len(ids))
        char_start = int(offsets[token_start][0])
        char_end = int(offsets[token_end - 1][1])
        text = document.text[char_start:char_end]
        sentence_ids = tuple(
            sentence_id
            for sentence_id, sentence_start, sentence_end in sentences
            if sentence_end > char_start and sentence_start < char_end
        )
        digest = hashlib.sha256(
            f"{document.doc_id}:{tokenizer_revision}:{token_start}:{token_end}".encode("utf-8")
        ).hexdigest()[:20]
        chunks.append(ChunkRecord(
            chunk_id=f"chunk-{digest}",
            doc_id=document.doc_id,
            title=document.title,
            text=text,
            char_start=char_start,
            char_end=char_end,
            token_start=token_start,
            token_end=token_end,
            sentence_ids=sentence_ids,
            tokenizer_revision=tokenizer_revision,
        ))
        if token_end == len(ids):
            break
    return chunks


def unique_token_coverage(chunks: Iterable[ChunkRecord]) -> int:
    intervals: dict[str, list[tuple[int, int]]] = {}
    for chunk in chunks:
        intervals.setdefault(chunk.doc_id, []).append((chunk.token_start, chunk.token_end))
    total = 0
    for document_intervals in intervals.values():
        cursor_start = cursor_end = None
        for start, end in sorted(document_intervals):
            if cursor_start is None:
                cursor_start, cursor_end = start, end
            elif start <= cursor_end:
                cursor_end = max(cursor_end, end)
            else:
                total += cursor_end - cursor_start
                cursor_start, cursor_end = start, end
        if cursor_start is not None:
            total += cursor_end - cursor_start
    return total


def index_identity(
    *, encoder_repo: str, encoder_revision: str, tokenizer_revision: str,
    query_instruction: str, dtype: str, chunk_manifest_hash: str
) -> str:
    return canonical_hash({
        "encoder_repo": encoder_repo,
        "encoder_revision": encoder_revision,
        "tokenizer_revision": tokenizer_revision,
        "query_instruction": query_instruction,
        "dtype": dtype,
        "chunk_manifest_hash": chunk_manifest_hash,
    })
