from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Iterator

from route_planned_rag.corpus.chunking import SourceDocument, chunk_document, index_identity


def iter_jsonl(path: str | Path) -> Iterator[dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_chunks(
    documents_path: str | Path,
    chunks_path: str | Path,
    tokenizer,
    *,
    tokenizer_revision: str,
    chunk_tokens: int,
    overlap_tokens: int,
) -> dict[str, Any]:
    chunks_path = Path(chunks_path)
    chunks_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = chunks_path.with_suffix(chunks_path.suffix + f".tmp-{os.getpid()}")
    document_count = chunk_count = 0
    with temporary.open("w", encoding="utf-8") as handle:
        for item in iter_jsonl(documents_path):
            document = SourceDocument(
                doc_id=item["doc_id"],
                title=item.get("title", ""),
                text=item["text"],
                sentence_char_spans=tuple(tuple(span) for span in item.get("sentence_char_spans", [])),
            )
            for chunk in chunk_document(
                document,
                tokenizer,
                tokenizer_revision=tokenizer_revision,
                chunk_tokens=chunk_tokens,
                overlap_tokens=overlap_tokens,
            ):
                handle.write(json.dumps(chunk.to_dict(), ensure_ascii=False, sort_keys=True) + "\n")
                chunk_count += 1
            document_count += 1
    temporary.replace(chunks_path)
    manifest_hash = file_sha256(chunks_path)
    return {
        "documents_path": str(documents_path),
        "chunks_path": str(chunks_path),
        "document_count": document_count,
        "chunk_count": chunk_count,
        "tokenizer_revision": tokenizer_revision,
        "chunk_tokens": chunk_tokens,
        "overlap_tokens": overlap_tokens,
        "chunk_manifest_sha256": manifest_hash,
    }


def dense_index_manifest(config: dict, chunk_manifest: dict) -> dict[str, Any]:
    item = config["models"]["retriever"]
    return {
        **chunk_manifest,
        "index_id": index_identity(
            encoder_repo=item["repo_id"],
            encoder_revision=item["revision"],
            tokenizer_revision=chunk_manifest["tokenizer_revision"],
            query_instruction=item["query_instruction"],
            dtype=item["dtype"],
            chunk_manifest_hash=chunk_manifest["chunk_manifest_sha256"],
        ),
        "encoder_repo": item["repo_id"],
        "encoder_revision": item["revision"],
        "dimensions": item["dimensions"],
        "pooling": "last_non_padding_token",
        "l2_normalize": True,
        "query_instruction_only": True,
    }

