from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import replace
from typing import Protocol

from route_planned_rag.accounting import BudgetUsage, GlobalLedger
from route_planned_rag.types import ObservedPassage


class Retriever(Protocol):
    def retrieve(self, query: str, corpus_id: str, top_k: int) -> list[ObservedPassage]: ...


class RetrievalCache:
    def __init__(self) -> None:
        self._items: dict[tuple[str, str, int], list[ObservedPassage]] = {}

    def get(self, corpus_id: str, query: str, top_k: int) -> list[ObservedPassage] | None:
        value = self._items.get((corpus_id, query, top_k))
        return list(value) if value is not None else None

    def put(self, corpus_id: str, query: str, top_k: int, value: list[ObservedPassage]) -> None:
        self._items[(corpus_id, query, top_k)] = list(value)

    def clone(self) -> "RetrievalCache":
        cloned = RetrievalCache()
        cloned._items = {key: list(value) for key, value in self._items.items()}
        return cloned


class CachedRetriever:
    def __init__(self, backend: Retriever, ledger: GlobalLedger, cache: RetrievalCache | None = None):
        self.backend = backend
        self.ledger = ledger
        self.cache = cache or RetrievalCache()
        self._backend_attempts: dict[str, int] = {}

    def retrieve(self, request_id: str, query: str, corpus_id: str, top_k: int) -> tuple[list[ObservedPassage], str]:
        self.ledger.charge(f"{request_id}:logical", BudgetUsage(logical_retrieval_calls=1))
        cached = self.cache.get(corpus_id, query, top_k)
        cache_status = "hit"
        if cached is None:
            attempt = self._backend_attempts.get(request_id, 0)
            self._backend_attempts[request_id] = attempt + 1
            backend_request_id = f"{request_id}:backend:{attempt}"
            maximum_dense_tokens = int(getattr(self.backend, "max_query_tokens", 0))
            maximum = BudgetUsage(
                physical_backend_requests=1,
                dense_forward_tokens=maximum_dense_tokens,
                dense_gpu_seconds=max(0.0, self.ledger.remaining().dense_gpu_seconds),
            )
            self.ledger.reserve(backend_request_id, maximum)
            try:
                cached = self.backend.retrieve(query, corpus_id, top_k)
            except Exception:
                self.ledger.reconcile(
                    backend_request_id,
                    BudgetUsage(physical_backend_requests=1),
                    complete=True,
                )
                raise
            self.cache.put(corpus_id, query, top_k, cached)
            cache_status = "miss"
            dense_usage = getattr(self.backend, "last_query_usage", None)
            self.ledger.reconcile(
                backend_request_id,
                BudgetUsage(
                    physical_backend_requests=1,
                    dense_forward_tokens=dense_usage.input_tokens if dense_usage else 0,
                    dense_gpu_seconds=dense_usage.gpu_seconds if dense_usage else 0.0,
                ),
            )
        return cached, cache_status


class InMemoryBM25Retriever:
    """Deterministic BM25 control used by tests and supplied-context runs."""

    def __init__(self, corpora: dict[str, list[ObservedPassage]], k1: float = 1.2, b: float = 0.75):
        self.corpora = corpora
        self.k1 = k1
        self.b = b
        self.calls = 0

    @staticmethod
    def _tokens(text: str) -> list[str]:
        return re.findall(r"[\w]+", text.casefold())

    def retrieve(self, query: str, corpus_id: str, top_k: int) -> list[ObservedPassage]:
        self.calls += 1
        docs = self.corpora.get(corpus_id)
        if docs is None:
            raise KeyError(f"unknown corpus {corpus_id}")
        tokenized = [self._tokens(doc.text) for doc in docs]
        average_length = sum(map(len, tokenized)) / max(len(tokenized), 1)
        query_terms = self._tokens(query)
        document_frequency = Counter(term for term in set(query_terms) for tokens in tokenized if term in tokens)
        scored: list[ObservedPassage] = []
        for doc, tokens in zip(docs, tokenized):
            frequencies = Counter(tokens)
            score = 0.0
            for term in query_terms:
                df = document_frequency[term]
                idf = math.log(1 + (len(docs) - df + 0.5) / (df + 0.5))
                tf = frequencies[term]
                denominator = tf + self.k1 * (1 - self.b + self.b * len(tokens) / max(average_length, 1))
                score += idf * tf * (self.k1 + 1) / denominator if denominator else 0.0
            scored.append(replace(doc, retrieval_score=score))
        scored.sort(key=lambda item: (-(item.retrieval_score or 0.0), item.chunk_id))
        return scored[:top_k]
