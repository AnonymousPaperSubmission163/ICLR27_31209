from __future__ import annotations

from dataclasses import dataclass

from route_planned_rag.evaluation.metrics import evaluate_episode
from route_planned_rag.search.engine import PublicEpisode
from route_planned_rag.types import CompletionStatus, PrivateReference


@dataclass(frozen=True)
class TrainingOutcome:
    episode_id: str
    question_id: str
    completion_status: str
    answer_correct: bool | None
    support_coverage: bool | None
    terminal_success: bool | None
    additional_calls: int
    scorer_targets: dict[str, float]
    continuation_policy_id: str

    @property
    def eligible_for_regression(self) -> bool:
        return self.completion_status == CompletionStatus.COMPLETE.value and self.terminal_success is not None


def scorer_target(additional_calls: int, terminal_success: bool, lambda_value: float) -> float:
    return float(additional_calls) + float(lambda_value) * (1.0 - float(terminal_success))


def label_completed_episode(
    episode: PublicEpisode,
    reference: PrivateReference,
    *,
    continuation_policy_id: str,
    lambda_values: tuple[int, ...] = (8, 16, 32),
    calls_at_snapshot: int = 0,
) -> TrainingOutcome:
    additional_calls = episode.ledger.used.logical_retrieval_calls - calls_at_snapshot
    if additional_calls < 0:
        raise ValueError("calls_at_snapshot exceeds completed ledger calls")
    if episode.completion_status != CompletionStatus.COMPLETE or episode.answer is None or episode.selected_route_id is None:
        return TrainingOutcome(
            episode.episode_id,
            episode.sample.question_id,
            episode.completion_status.value,
            None,
            None,
            None,
            additional_calls,
            {},
            continuation_policy_id,
        )
    route = episode.routes[episode.selected_route_id]
    metrics = evaluate_episode(episode.answer, route.observed_passages, reference)
    success = bool(metrics["terminal_success"])
    return TrainingOutcome(
        episode.episode_id,
        episode.sample.question_id,
        episode.completion_status.value,
        bool(metrics["answer_correct"]),
        bool(metrics["support_coverage"]),
        success,
        additional_calls,
        {str(value): scorer_target(additional_calls, success, value) for value in lambda_values},
        continuation_policy_id,
    )

