from __future__ import annotations

import copy
import hashlib
from dataclasses import dataclass

from route_planned_rag.search.state import GlobalSearchState


@dataclass
class Snapshot:
    snapshot_id: str
    question_id: str
    prefix_step: int
    state: GlobalSearchState
    calls_at_snapshot: int
    remaining_call_budget: int

    @classmethod
    def clone_from(cls, state: GlobalSearchState, remaining_call_budget: int) -> "Snapshot":
        cloned = copy.deepcopy(state)
        digest = hashlib.sha256(
            f"{state.sample.question_id}:{state.step}:{remaining_call_budget}".encode("utf-8")
        ).hexdigest()[:16]
        return cls(
            snapshot_id=f"snapshot-{digest}",
            question_id=state.sample.question_id,
            prefix_step=state.step,
            state=cloned,
            calls_at_snapshot=state.ledger.used.logical_retrieval_calls,
            remaining_call_budget=remaining_call_budget,
        )


def deterministic_snapshot_steps(question_id: str, seed: int, episode_length: int) -> tuple[int, ...]:
    if episode_length <= 0:
        return ()
    digest = hashlib.sha256(f"{seed}:{question_id}".encode("utf-8")).digest()
    candidates = sorted({1 + int.from_bytes(digest[i : i + 2], "big") % episode_length for i in (0, 2)})
    return tuple(candidates[:2])

