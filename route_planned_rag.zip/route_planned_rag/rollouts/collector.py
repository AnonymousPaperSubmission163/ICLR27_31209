from __future__ import annotations

import copy
import dataclasses
import hashlib
import json
import uuid
from collections import defaultdict
from pathlib import Path
from typing import Any

from route_planned_rag.evaluation.metrics import evaluate_episode
from route_planned_rag.experiments.vertical import RealVerticalStack, load_fixed_examples
from route_planned_rag.rollouts.snapshots import deterministic_snapshot_steps
from route_planned_rag.search.controllers import Pi0Controller
from route_planned_rag.search.engine import PublicEpisode
from route_planned_rag.types import CompletionStatus


def _stable_choice(parts: tuple[Any, ...], choices: tuple[Any, ...]):
    digest = hashlib.sha256(":".join(map(str, parts)).encode("utf-8")).digest()
    return choices[int.from_bytes(digest[:8], "big") % len(choices)]


def _mode(question_id: str, seed: int, suffix: str) -> str:
    return _stable_choice((question_id, seed, suffix), ("dependency_first", "round_robin"))


def _candidate_menu(state) -> list:
    stops = sorted((action for action in state.pending_actions if action.kind == "STOP"), key=lambda value: value.action_id)
    searches = sorted((action for action in state.pending_actions if action.kind == "SEARCH"), key=lambda value: value.action_id)
    selected = stops[:1]
    if searches:
        selected.append(searches[0])
        different = next((value for value in searches[1:] if value.route_id != searches[0].route_id), None)
        if different is not None:
            selected.append(different)
        elif len(searches) > 1:
            selected.append(searches[1])
    return selected


def _reset_counterfactual_budget(state, config: dict, remaining_calls: int) -> None:
    ledger = state.ledger
    used = ledger.used
    budget = config["budgets"]
    ledger.limits = dataclasses.replace(
        ledger.limits,
        logical_retrieval_calls=used.logical_retrieval_calls + remaining_calls,
        physical_backend_requests=used.physical_backend_requests + remaining_calls,
        reasoning_input_tokens=used.reasoning_input_tokens + int(budget["reasoning_input_tokens"]),
        reasoning_output_tokens=used.reasoning_output_tokens + int(budget["reasoning_output_tokens"]),
        unique_evidence_tokens=used.unique_evidence_tokens + int(budget["unique_evidence_tokens"]),
        reader_input_tokens=used.reader_input_tokens + int(budget["final_reader_input_reserve"]),
        reader_output_tokens=used.reader_output_tokens + int(budget["final_reader_output_reserve"]),
    )


def _append(path: Path, value: dict) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")


def collect_continuations(
    config: dict,
    writer,
    *,
    phase: str,
    datasets: tuple[str, ...],
    limit: int,
    seed: int,
    skip_question_ids: set[str] | None = None,
) -> dict:
    import torch

    if phase not in {"initial", "full", "internal_dev"}:
        raise ValueError("unsupported collection phase")
    role = {"initial": "initial_train", "full": "full_train", "internal_dev": "internal_dev"}[phase]
    stack = RealVerticalStack(config, retrieval_protocol="pooled-corpus")
    labels_path = writer.run_dir / "labels.jsonl"
    raw_path = writer.run_dir / "raw_outcomes.jsonl"
    snapshots_path = writer.run_dir / "snapshots.jsonl"
    for path in (labels_path, raw_path, snapshots_path):
        path.touch()
    planned = completed = eligible_labels = 0
    snapshot_count = 0
    missing_snapshots = 0
    lambda_values = tuple(map(int, config["search"]["lambda_candidates"]))
    budgets = tuple(map(int, config["search"]["snapshot_budgets"]))
    prefix_limit = int(config["search"]["prefix_call_limit"])
    skip_question_ids = skip_question_ids or set()
    skipped = 0
    for dataset in datasets:
        for sample, reference, _ in load_fixed_examples(config, dataset, role, limit):
            if sample.question_id in skip_question_ids:
                skipped += 1
                continue
            prefix_runner, backend, _ = stack.runner_for_sample(
                sample,
                prefix_limit,
                controller=Pi0Controller(_mode(sample.question_id, seed, "prefix")),
            )
            prefix_episode_id = f"prefix-{uuid.uuid4()}"
            try:
                state = prefix_runner.initialize(sample, prefix_episode_id)
            except Exception as exc:
                writer.append_event({"event_type": "prefix_initialization_failure", "dataset": dataset, "question_id": sample.question_id, "error_type": type(exc).__name__, "message": str(exc)})
                continue
            targets = set(deterministic_snapshot_steps(sample.question_id, seed, prefix_limit))
            snapshots = []
            while state.ledger.used.logical_retrieval_calls < prefix_limit:
                outcome = prefix_runner.continue_state(state, prefix_episode_id, maximum_steps=1)
                calls = state.ledger.used.logical_retrieval_calls
                if outcome.completion_status == CompletionStatus.COMPLETE:
                    break
                if outcome.stop_reason != "maximum_steps_guard":
                    break
                if calls in targets:
                    snapshot_id = f"{sample.question_id}-calls-{calls}"
                    snapshots.append((snapshot_id, copy.deepcopy(state), prefix_runner.retriever.cache.clone()))
            missing_snapshots += max(0, 2 - len(snapshots))
            for snapshot_id, snapshot_state, snapshot_cache in snapshots[:2]:
                menu = _candidate_menu(snapshot_state)
                remaining_calls = int(_stable_choice((seed, sample.question_id, snapshot_id), budgets))
                snapshot_count += 1
                _append(snapshots_path, {
                    "snapshot_id": snapshot_id,
                    "question_id": sample.question_id,
                    "dataset": dataset,
                    "prefix_calls": snapshot_state.ledger.used.logical_retrieval_calls,
                    "remaining_call_budget": remaining_calls,
                    "candidate_action_ids": [action.action_id for action in menu],
                    "public_state": snapshot_state.public_scorer_state(float(config["search"]["lambda_default"])),
                })
                grouped = defaultdict(list)
                for action in menu:
                    repetitions = 1 if action.kind == "STOP" else 2
                    planned += repetitions
                    for repetition in range(repetitions):
                        torch.manual_seed(int.from_bytes(hashlib.sha256(f"{seed}:{snapshot_id}:{action.action_id}:{repetition}".encode()).digest()[:4], "big"))
                        continuation_state = copy.deepcopy(snapshot_state)
                        _reset_counterfactual_budget(continuation_state, config, remaining_calls)
                        calls_at_snapshot = continuation_state.ledger.used.logical_retrieval_calls
                        runner, _, _ = stack.runner_for_sample(
                            sample,
                            remaining_calls,
                            controller=Pi0Controller(_mode(sample.question_id, seed, f"{snapshot_id}:{action.action_id}:{repetition}")),
                            ledger=continuation_state.ledger,
                            cache=snapshot_cache.clone(),
                            backend=backend,
                        )
                        episode_id = f"continuation-{uuid.uuid4()}"
                        try:
                            episode = runner.continue_state(
                                continuation_state,
                                episode_id,
                                maximum_steps=remaining_calls + 4,
                                first_action=action,
                            )
                        except Exception as exc:
                            continuation_state.events.append({"event_type": "continuation_failure", "error_type": type(exc).__name__, "message": str(exc)})
                            episode = PublicEpisode(
                                episode_id,
                                sample,
                                continuation_state.graph,
                                continuation_state.ledger,
                                continuation_state.frontier,
                                continuation_state.events,
                                None,
                                None,
                                CompletionStatus.INCOMPLETE_INFRASTRUCTURE,
                                type(exc).__name__,
                            )
                        metrics = None
                        if episode.completion_status == CompletionStatus.COMPLETE and episode.answer and episode.selected_route_id:
                            metrics = evaluate_episode(episode.answer, episode.routes[episode.selected_route_id].observed_passages, reference)
                            completed += 1
                        outcome = {
                            "episode_id": episode_id,
                            "parent_episode_id": prefix_episode_id,
                            "snapshot_id": snapshot_id,
                            "question_id": sample.question_id,
                            "dataset": dataset,
                            "action_id": action.action_id,
                            "action": dataclasses.asdict(action),
                            "repetition": repetition,
                            "completion_status": episode.completion_status.value,
                            "additional_calls": episode.ledger.used.logical_retrieval_calls - calls_at_snapshot,
                            "terminal_success": metrics["terminal_success"] if metrics else None,
                            "answer_correct": metrics["answer_correct"] if metrics else None,
                            "support_coverage": metrics["support_coverage"] if metrics else None,
                            "continuation_policy_id": "pi0_dependency_roundrobin_mixture_v1",
                            "stop_reason": episode.stop_reason,
                        }
                        _append(raw_path, outcome)
                        grouped[action.action_id].append(outcome)
                for action in menu:
                    outcomes = grouped[action.action_id]
                    if len(outcomes) != (1 if action.kind == "STOP" else 2) or any(value["completion_status"] != "complete" for value in outcomes):
                        continue
                    successes = [bool(value["terminal_success"]) for value in outcomes]
                    calls = [int(value["additional_calls"]) for value in outcomes]
                    search_distance = min((call for call, success in zip(calls, successes) if success), default=None)
                    for lambda_value in lambda_values:
                        counterfactual_state = copy.deepcopy(snapshot_state)
                        _reset_counterfactual_budget(counterfactual_state, config, remaining_calls)
                        target = sum(call + lambda_value * (1.0 - float(success)) for call, success in zip(calls, successes)) / len(calls)
                        distance = (
                            lambda_value * (1.0 - float(successes[0]))
                            if action.kind == "STOP"
                            else search_distance
                        )
                        _append(labels_path, {
                            "snapshot_id": snapshot_id,
                            "question_id": sample.question_id,
                            "dataset": dataset,
                            "action": dataclasses.asdict(action),
                            "lambda": lambda_value,
                            "public_state": counterfactual_state.public_scorer_state(float(lambda_value)),
                            "completion_status": "complete",
                            "rollout_count": len(outcomes),
                            "additional_calls": sum(calls) / len(calls),
                            "terminal_success": sum(map(float, successes)) / len(successes),
                            "scorer_target": target,
                            "distance_target": distance,
                            "distance_finite": distance is not None,
                            "continuation_policy_id": "pi0_dependency_roundrobin_mixture_v1",
                        })
                        eligible_labels += 1
            writer.append_event({
                "event_type": "question_collection_complete",
                "dataset": dataset,
                "question_id": sample.question_id,
                "phase": phase,
                "snapshot_count": len(snapshots[:2]),
            })
    return {
        "status": "complete",
        "phase": phase,
        "datasets": list(datasets),
        "question_limit_per_dataset": limit,
        "snapshots": snapshot_count,
        "missing_snapshot_positions": missing_snapshots,
        "planned_continuations": planned,
        "completed_continuations": completed,
        "eligible_aggregate_labels": eligible_labels,
        "skipped_completed_questions": skipped,
        "labels_path": str(labels_path),
        "raw_outcomes_path": str(raw_path),
        "snapshots_path": str(snapshots_path),
    }
