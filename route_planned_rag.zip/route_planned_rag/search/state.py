from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from route_planned_rag.accounting import GlobalLedger
from route_planned_rag.config import canonical_hash
from route_planned_rag.types import Action, InformationNeedGraph, PublicSample, RouteState


@dataclass
class GlobalSearchState:
    sample: PublicSample
    graph: InformationNeedGraph
    frontier: dict[str, RouteState]
    pending_actions: list[Action]
    ledger: GlobalLedger
    step: int = 0
    events: list[dict[str, Any]] = field(default_factory=list)
    overflowed_route_ids: list[str] = field(default_factory=list)

    def public_scorer_state(self, lambda_value: float) -> dict[str, Any]:
        return {
            "question_id": self.sample.question_id,
            "question": self.sample.question,
            "graph_node_count": len(self.graph.nodes),
            "frontier": [self.frontier[key].compact_summary() for key in sorted(self.frontier)],
            "remaining_budget": self.ledger.remaining().to_dict(),
            "lambda": lambda_value,
            "step": self.step,
        }

    def score_context_key(self, lambda_value: float) -> str:
        return canonical_hash(self.public_scorer_state(lambda_value))

    def feasible_actions(self) -> list[Action]:
        if self.ledger.can_search():
            return list(self.pending_actions)
        return [action for action in self.pending_actions if action.kind == "STOP"]

    def prune_frontier_structural(self, cap: int) -> None:
        if len(self.frontier) <= cap:
            return
        ranked = sorted(
            self.frontier.values(),
            key=lambda route: (-route.evidence_backed_count(), route.conflicts, route.route_id),
        )
        keep = {route.route_id for route in ranked[:cap]}
        removed = sorted(set(self.frontier) - keep)
        for route_id in removed:
            del self.frontier[route_id]
        self.pending_actions = [action for action in self.pending_actions if action.route_id in keep]
        self.overflowed_route_ids.extend(removed)
        self.events.append({"event_type": "frontier_prune", "removed_route_ids": removed})

