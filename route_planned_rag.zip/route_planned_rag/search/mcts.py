from __future__ import annotations

import copy
import math
import uuid
from dataclasses import dataclass

from route_planned_rag.corpus.retrieval import CachedRetriever
from route_planned_rag.search.controllers import Pi0Controller
from route_planned_rag.search.engine import EpisodeRunner, PublicEpisode
from route_planned_rag.types import CompletionStatus


@dataclass
class UCTChild:
    action: object
    visits: int = 0
    value_sum: float = 0.0
    best_reward: float = -math.inf
    best_state: object | None = None
    best_episode: PublicEpisode | None = None

    @property
    def mean_value(self) -> float:
        return self.value_sum / self.visits if self.visits else 0.0


def select_uct(children: list[UCTChild], parent_visits: int, exploration: float) -> UCTChild:
    unvisited = [child for child in children if child.visits == 0]
    if unvisited:
        return min(unvisited, key=lambda child: child.action.action_id)
    return min(
        children,
        key=lambda child: (
            -(child.mean_value + exploration * math.sqrt(math.log(max(parent_visits, 1)) / child.visits)),
            child.action.action_id,
        ),
    )


class MCTSEpisodeRunner:
    """UCT controlled adaptation; simulation tools share the question ledger and cache."""

    controller_id = "mcts-uct-controlled-adaptation-v1"

    def __init__(self, base_runner: EpisodeRunner, success_scorer, *, exploration: float, max_depth: int = 4, simulations: int = 8):
        if exploration not in {0.5, 1.0, 2.0}:
            raise ValueError("MCTS exploration must be selected from the frozen dev grid")
        self.base_runner = base_runner
        self.success_scorer = success_scorer
        self.exploration = exploration
        self.max_depth = max_depth
        self.simulations = simulations

    def _leaf_reward(self, state, episode_id: str) -> float:
        stops = [action for action in state.feasible_actions() if action.kind == "STOP"]
        candidates = stops or state.feasible_actions()
        if not candidates:
            return 0.0
        class LeafSelection:
            def __init__(self, values, model_usage):
                self.values = values
                self.scorer_usage = model_usage

        selection = self.base_runner._invoke_scorer(
            f"{episode_id}:leaf-success",
            lambda: LeafSelection(*self.success_scorer.score(state.public_scorer_state(16.0), candidates)),
        )
        priorities = selection.values
        return max(0.0, min(1.0, 1.0 - min(map(float, priorities))))

    def run(self, sample, maximum_decisions: int = 128) -> PublicEpisode:
        episode_id = f"mcts-{uuid.uuid4()}"
        master_events = []
        state = self.base_runner.initialize(sample, episode_id, master_events)
        for decision in range(maximum_decisions):
            feasible = state.feasible_actions()
            searches = [action for action in feasible if action.kind == "SEARCH"]
            if not searches:
                stop = min((action for action in feasible if action.kind == "STOP"), key=lambda item: item.action_id)
                return self.base_runner.continue_state(state, episode_id, maximum_steps=1, first_action=stop)
            children = [UCTChild(action) for action in feasible]
            parent_visits = 0
            for simulation in range(self.simulations):
                child = select_uct(children, parent_visits, self.exploration)
                if child.action.kind == "SEARCH" and not state.ledger.can_search():
                    break
                simulated_state = copy.deepcopy(state)
                simulated_state.ledger = state.ledger
                simulated_state.events = []
                simulation_id = f"{episode_id}:decision:{decision}:simulation:{simulation}"
                simulation_runner = EpisodeRunner(
                    self.base_runner.actor,
                    CachedRetriever(self.base_runner.retriever.backend, state.ledger, self.base_runner.retriever.cache),
                    Pi0Controller("dependency_first"),
                    reranker=self.base_runner.reranker,
                    initial_top_k=self.base_runner.initial_top_k,
                    delivered_top_k=self.base_runner.delivered_top_k,
                    frontier_cap=self.base_runner.frontier_cap,
                    proposals_per_route=self.base_runner.proposals_per_route,
                    simulated_reader=True,
                )
                try:
                    episode = simulation_runner.continue_state(
                        simulated_state,
                        simulation_id,
                        maximum_steps=self.max_depth,
                        first_action=child.action,
                    )
                    reward = self._leaf_reward(simulated_state, simulation_id)
                except Exception as exc:
                    simulated_state.events.append({"event_type": "mcts_simulation_failure", "error_type": type(exc).__name__, "message": str(exc)})
                    episode = PublicEpisode(
                        simulation_id, sample, simulated_state.graph, state.ledger, simulated_state.frontier,
                        simulated_state.events, None, None, CompletionStatus.INCOMPLETE_INFRASTRUCTURE, type(exc).__name__,
                    )
                    reward = 0.0
                child.visits += 1
                child.value_sum += reward
                parent_visits += 1
                if reward > child.best_reward:
                    child.best_reward = reward
                    child.best_state = simulated_state
                    child.best_episode = episode
                master_events.extend({"mcts_simulation": simulation, **event} for event in simulated_state.events)
                master_events.append({
                    "event_type": "mcts_backup", "decision": decision, "simulation": simulation,
                    "action_id": child.action.action_id, "reward_source": "frozen_success_scorer",
                    "reward": reward, "visits": child.visits, "mean_value": child.mean_value,
                    "exploration": self.exploration,
                })
            visited = [child for child in children if child.visits and child.best_state is not None]
            if not visited:
                stop = min((action for action in state.feasible_actions() if action.kind == "STOP"), key=lambda item: item.action_id)
                return self.base_runner.continue_state(state, episode_id, maximum_steps=1, first_action=stop)
            selected = min(visited, key=lambda child: (-child.visits, -child.mean_value, child.action.action_id))
            master_events.append({
                "event_type": "mcts_commit", "decision": decision, "action_id": selected.action.action_id,
                "visits": selected.visits, "mean_value": selected.mean_value,
            })
            if selected.best_episode and selected.best_episode.completion_status == CompletionStatus.COMPLETE:
                selected.best_episode.events = master_events
                return selected.best_episode
            state = selected.best_state
            state.ledger = self.base_runner.retriever.ledger
            state.events = master_events
        return PublicEpisode(
            episode_id, sample, state.graph, state.ledger, state.frontier, master_events, None, None,
            CompletionStatus.INCOMPLETE_INFRASTRUCTURE, "maximum_mcts_decisions_guard",
        )


class MCTSControl:
    controller_id = "mcts-uct-controlled-adaptation-v1"

    def __init__(self, success_scorer, *, exploration: float, max_depth: int, simulations: int):
        self.success_scorer = success_scorer
        self.exploration = exploration
        self.max_depth = max_depth
        self.simulations = simulations

    def run_on_stack(self, stack, sample, call_budget: int):
        base, backend, passage_count = stack.runner_for_sample(
            sample,
            call_budget,
            controller=Pi0Controller("dependency_first"),
        )
        episode = MCTSEpisodeRunner(
            base,
            self.success_scorer,
            exploration=self.exploration,
            max_depth=self.max_depth,
            simulations=self.simulations,
        ).run(sample)
        return episode, backend.offline_document_usage, passage_count
