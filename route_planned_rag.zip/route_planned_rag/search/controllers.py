from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence

from route_planned_rag.models.interfaces import ModelUsage, ScorerModel
from route_planned_rag.search.state import GlobalSearchState
from route_planned_rag.types import Action


@dataclass(frozen=True)
class Selection:
    action: Action
    scores: dict[str, float]
    scorer_usage: ModelUsage


class GlobalGreedyController:
    def __init__(self, scorer: ScorerModel, lambda_value: float = 16.0):
        self.scorer = scorer
        self.lambda_value = lambda_value
        self.controller_id = f"global-greedy:{scorer.scorer_id}"

    def select(self, state: GlobalSearchState) -> Selection:
        candidates = state.feasible_actions()
        if not candidates:
            raise RuntimeError("no feasible actions")
        public_state = state.public_scorer_state(self.lambda_value)
        values, usage = self.scorer.score(public_state, candidates)
        if len(values) != len(candidates) or any(not math.isfinite(float(value)) for value in values):
            raise ValueError("scorer returned invalid values")
        paired = sorted(zip(candidates, values), key=lambda item: (float(item[1]), item[0].action_id))
        return Selection(paired[0][0], {a.action_id: float(v) for a, v in zip(candidates, values)}, usage)


class Pi0Controller:
    """Fixed dependency-first / round-robin mixture chosen once per episode."""

    controller_id = "pi0_dependency_roundrobin_mixture_v1"

    def __init__(self, mode: str):
        if mode not in {"dependency_first", "round_robin"}:
            raise ValueError("invalid pi0 mode")
        self.mode = mode
        self.cursor = 0

    def select(self, state: GlobalSearchState) -> Selection:
        candidates = state.feasible_actions()
        searches = [candidate for candidate in candidates if candidate.kind == "SEARCH"]
        if searches:
            by_route: dict[str, list[Action]] = {}
            for candidate in searches:
                by_route.setdefault(candidate.route_id, []).append(candidate)
            if self.mode == "dependency_first":
                route_id = min(
                    by_route,
                    key=lambda key: (
                        -len(state.frontier[key].resolved_node_ids),
                        state.frontier[key].conflicts,
                        key,
                    ),
                )
            else:
                route_ids = sorted(by_route)
                route_id = route_ids[self.cursor % len(route_ids)]
                self.cursor += 1
            action = sorted(by_route[route_id], key=lambda item: (item.node_id, item.action_id))[0]
            return Selection(action, {candidate.action_id: 0.0 for candidate in candidates}, ModelUsage())
        stops = [candidate for candidate in candidates if candidate.kind == "STOP"]
        if not stops:
            raise RuntimeError("pi0 has no STOP when search budget is exhausted")
        action = min(
            stops,
            key=lambda item: (
                -state.frontier[item.route_id].evidence_backed_count(),
                state.frontier[item.route_id].conflicts,
                item.route_id,
            ),
        )
        return Selection(action, {candidate.action_id: 0.0 for candidate in candidates}, ModelUsage())


class NoRetrievalController:
    controller_id = "no-retrieval-control-v1"

    def select(self, state: GlobalSearchState) -> Selection:
        stops = [candidate for candidate in state.feasible_actions() if candidate.kind == "STOP"]
        if not stops:
            raise RuntimeError("no-retrieval controller has no STOP action")
        action = min(stops, key=lambda item: item.action_id)
        return Selection(action, {candidate.action_id: 0.0 for candidate in stops}, ModelUsage())


class SingleRouteIterativeController:
    """Controlled IRCoT-style adaptation: one route, repeated reformulation, same tools."""

    controller_id = "ircot-single-route-adaptation-v1"

    def select(self, state: GlobalSearchState) -> Selection:
        candidates = state.feasible_actions()
        searches = [candidate for candidate in candidates if candidate.kind == "SEARCH"]
        if searches:
            best_route = min(
                {candidate.route_id for candidate in searches},
                key=lambda route_id: (
                    -state.frontier[route_id].evidence_backed_count(),
                    state.frontier[route_id].conflicts,
                    route_id,
                ),
            )
            action = min((candidate for candidate in searches if candidate.route_id == best_route), key=lambda item: item.action_id)
        else:
            stops = [candidate for candidate in candidates if candidate.kind == "STOP"]
            if not stops:
                raise RuntimeError("iterative controller has no feasible STOP")
            action = min(stops, key=lambda item: item.action_id)
        return Selection(action, {candidate.action_id: 0.0 for candidate in candidates}, ModelUsage())
