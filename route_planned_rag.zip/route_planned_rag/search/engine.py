from __future__ import annotations

import dataclasses
import time
import uuid
from dataclasses import dataclass
from typing import Any

from route_planned_rag.accounting import BudgetUsage, GlobalLedger
from route_planned_rag.corpus.retrieval import CachedRetriever
from route_planned_rag.models.interfaces import ActorModel, RerankerModel
from route_planned_rag.search.controllers import GlobalGreedyController, Pi0Controller
from route_planned_rag.search.state import GlobalSearchState
from route_planned_rag.types import (
    AnswerWithCitations,
    CompletionStatus,
    PublicSample,
    RouteState,
    SearchCandidate,
    StopCandidate,
    ensure_delivered_citations,
)


@dataclass
class PublicEpisode:
    episode_id: str
    sample: PublicSample
    graph: Any
    ledger: GlobalLedger
    routes: dict[str, RouteState]
    events: list[dict[str, Any]]
    answer: AnswerWithCitations | None
    selected_route_id: str | None
    completion_status: CompletionStatus
    stop_reason: str

    def actor_serialization(self) -> dict[str, Any]:
        return {
            "question_id": self.sample.question_id,
            "question": self.sample.question,
            "split_role": self.sample.split_role,
            "corpus_id": self.sample.corpus_id,
            "graph": dataclasses.asdict(self.graph),
            "ledger": self.ledger.snapshot(),
            "routes": [route.compact_summary() for route in self.routes.values()],
            "events": self.events,
            "answer": dataclasses.asdict(self.answer) if self.answer else None,
            "completion_status": self.completion_status.value,
        }


class EpisodeRunner:
    def __init__(
        self,
        actor: ActorModel,
        retriever: CachedRetriever,
        controller: GlobalGreedyController | Pi0Controller,
        *,
        reranker: RerankerModel | None = None,
        initial_top_k: int = 20,
        delivered_top_k: int = 5,
        frontier_cap: int = 8,
        proposals_per_route: int = 4,
        simulated_reader: bool = False,
    ):
        self.actor = actor
        self.retriever = retriever
        self.controller = controller
        self.reranker = reranker
        self.initial_top_k = initial_top_k
        self.delivered_top_k = delivered_top_k
        self.frontier_cap = frontier_cap
        self.proposals_per_route = proposals_per_route
        self.simulated_reader = simulated_reader

    def run(self, sample: PublicSample, maximum_steps: int = 128) -> PublicEpisode:
        episode_id = str(uuid.uuid4())
        events: list[dict[str, Any]] = []
        try:
            state = self.initialize(sample, episode_id, events)
            return self.continue_state(state, episode_id, maximum_steps=maximum_steps)
        except Exception as exc:
            events.append({"event_type": "infrastructure_error", "error_type": type(exc).__name__, "message": str(exc)})
            graph_value = locals().get("graph")
            routes = locals().get("state").frontier if "state" in locals() else {}
            return PublicEpisode(
                episode_id, sample, graph_value, self.retriever.ledger, routes, events, None,
                None, CompletionStatus.INCOMPLETE_INFRASTRUCTURE, type(exc).__name__,
            )

    def initialize(self, sample: PublicSample, episode_id: str, events: list[dict[str, Any]] | None = None) -> GlobalSearchState:
        graph, usage = self._invoke_actor(
            f"{episode_id}:compile",
            lambda: self.actor.compile_graph(sample),
            maximum_output_tokens=2048,
        )
        graph.validate()
        root = RouteState(route_id="r0")
        state = GlobalSearchState(
            sample,
            graph,
            {root.route_id: root},
            [],
            self.retriever.ledger,
            events=events if events is not None else [],
        )
        self._refresh_actions(state, episode_id)
        return state

    def continue_state(
        self,
        state: GlobalSearchState,
        episode_id: str,
        *,
        maximum_steps: int = 128,
        first_action: SearchCandidate | StopCandidate | None = None,
    ) -> PublicEpisode:
        for local_step in range(maximum_steps):
            state.step += 1
            if local_step == 0 and first_action is not None:
                feasible = {action.action_id: action for action in state.feasible_actions()}
                if first_action.action_id not in feasible:
                    raise ValueError("forced first action is not feasible in snapshot")
                action = feasible[first_action.action_id]
                scores = {candidate.action_id: None for candidate in state.feasible_actions()}
            else:
                selection = self._invoke_scorer(
                    f"{episode_id}:score:{state.step}",
                    lambda: self.controller.select(state),
                )
                action = selection.action
                scores = selection.scores
            state.events.append({
                "event_type": "selection",
                "step": state.step,
                "action_id": action.action_id,
                "action_kind": action.kind,
                "forced": local_step == 0 and first_action is not None,
                "scores": scores,
                "budget_before": state.ledger.snapshot(),
            })
            if action.kind == "STOP":
                return self._finish_stop(state, action, episode_id)
            self._execute_search(state, action, episode_id)
            self._refresh_actions(state, episode_id)
            state.prune_frontier_structural(self.frontier_cap)
        return PublicEpisode(
            episode_id, state.sample, state.graph, state.ledger, state.frontier, state.events, None,
            None, CompletionStatus.INCOMPLETE_INFRASTRUCTURE, "maximum_steps_guard",
        )

    def _finish_stop(self, state: GlobalSearchState, action: StopCandidate, episode_id: str) -> PublicEpisode:
        route = state.frontier[action.route_id]
        answer, reader_usage = self._invoke_reader(
            f"{episode_id}:reader:{state.step}",
            lambda: self.actor.answer(state.sample, route),
        )
        ensure_delivered_citations(answer, route.observed_passages)
        state.events.append({"event_type": "stop", "route_id": route.route_id, "stop_reason": "controller_stop"})
        return PublicEpisode(
            episode_id, state.sample, state.graph, state.ledger, state.frontier, state.events, answer,
            route.route_id, CompletionStatus.COMPLETE, "controller_stop",
        )

    def _refresh_actions(self, state: GlobalSearchState, episode_id: str) -> None:
        actions = []
        for route_id in sorted(state.frontier):
            route = state.frontier[route_id]
            actions.append(StopCandidate(action_id=f"{route_id}:stop:{state.step}", route_id=route_id))
            if state.ledger.can_search():
                proposed, usage = self._invoke_actor(
                    f"{episode_id}:propose:{state.step}:{route_id}",
                    lambda: self.actor.propose_queries(
                        state.sample, state.graph, route, self.proposals_per_route
                    ),
                    maximum_output_tokens=1024,
                )
                actions.extend(proposed)
        state.pending_actions = actions

    def _execute_search(self, state: GlobalSearchState, action: SearchCandidate, episode_id: str) -> None:
        request_id = f"{episode_id}:search:{state.step}:{action.action_id}"
        passages, cache_status = self.retriever.retrieve(
            request_id, action.query, state.sample.corpus_id, self.initial_top_k
        )
        reranker_usage = None
        reranker_pair_count = len(passages)
        if self.reranker is not None:
            rerank_request_id = f"{request_id}:rerank"
            maximum_tokens = self.reranker.maximum_forward_tokens(action.query, passages)
            self.retriever.ledger.reserve(
                rerank_request_id,
                BudgetUsage(
                    reranker_forward_tokens=maximum_tokens,
                    reranker_gpu_seconds=max(0.0, self.retriever.ledger.remaining().reranker_gpu_seconds),
                ),
            )
            try:
                passages, reranker_usage = self.reranker.rerank(action.query, passages, self.delivered_top_k)
            except Exception:
                self.retriever.ledger.reconcile(rerank_request_id, BudgetUsage(), complete=False)
                raise
            self.retriever.ledger.reconcile(
                rerank_request_id,
                BudgetUsage(
                    reranker_forward_tokens=reranker_usage.input_tokens,
                    reranker_gpu_seconds=reranker_usage.gpu_seconds,
                ),
            )
        else:
            passages = passages[: self.delivered_top_k]
        state.ledger.observe_evidence(request_id, passages)
        route = state.frontier[action.route_id]
        route.attempted_queries.append(action.query)
        route.observed_passages.extend(passages)
        updates, resolver_usage = self._invoke_actor(
            f"{request_id}:resolve",
            lambda: self.actor.resolve(
                state.sample, state.graph, route, action.node_id, passages
            ),
            maximum_output_tokens=2048,
        )
        if len(updates) > 2:
            raise ValueError("resolver returned more than two binding alternatives")
        if not updates:
            pass
        elif len(updates) == 1:
            route.apply_binding(state.graph, action.node_id, updates[0])
        else:
            del state.frontier[route.route_id]
            for index, update in enumerate(updates):
                branch = route.clone(f"{route.route_id}.{state.step}.{index}")
                branch.apply_binding(state.graph, action.node_id, update)
                state.frontier[branch.route_id] = branch
        state.events.append({
            "event_type": "retrieval",
            "step": state.step,
            "request_id": request_id,
            "route_id": action.route_id,
            "action_id": action.action_id,
            "cache_status": cache_status,
            "observed_chunk_ids": [passage.chunk_id for passage in passages],
            "binding_updates": [dataclasses.asdict(update) for update in updates],
            "reranker_pair_count": reranker_pair_count if reranker_usage else 0,
            "budget_after": state.ledger.snapshot(),
        })

    def _invoke_actor(self, request_id: str, callback, *, maximum_output_tokens: int):
        ledger = self.retriever.ledger
        remaining = ledger.remaining()
        maximum = BudgetUsage(
            actor_requests=int(getattr(self.actor, "format_repairs", 0)) + 1,
            format_repair_requests=int(getattr(self.actor, "format_repairs", 0)),
            reasoning_input_tokens=max(0, int(remaining.reasoning_input_tokens)),
            reasoning_output_tokens=min(maximum_output_tokens, max(0, int(remaining.reasoning_output_tokens))),
            actor_gpu_seconds=max(0.0, remaining.actor_gpu_seconds),
        )
        ledger.reserve(request_id, maximum)
        try:
            value, usage = callback()
        except Exception:
            ledger.reconcile(request_id, BudgetUsage(), complete=False)
            raise
        ledger.reconcile(
            request_id,
            BudgetUsage(
                actor_requests=usage.requests,
                format_repair_requests=usage.format_repairs,
                reasoning_input_tokens=usage.input_tokens,
                reasoning_output_tokens=usage.output_tokens,
                actor_gpu_seconds=usage.gpu_seconds,
            ),
        )
        return value, usage

    def _invoke_scorer(self, request_id: str, callback):
        ledger = self.retriever.ledger
        remaining = ledger.remaining()
        maximum = BudgetUsage(
            scorer_forward_tokens=max(0, int(remaining.scorer_forward_tokens)),
            scorer_gpu_seconds=max(0.0, remaining.scorer_gpu_seconds),
        )
        ledger.reserve(request_id, maximum)
        try:
            selection = callback()
        except Exception:
            ledger.reconcile(request_id, BudgetUsage(), complete=False)
            raise
        usage = selection.scorer_usage
        ledger.reconcile(
            request_id,
            BudgetUsage(
                scorer_forward_tokens=usage.input_tokens,
                scorer_gpu_seconds=usage.gpu_seconds,
            ),
        )
        return selection

    def _invoke_reader(self, request_id: str, callback):
        ledger = self.retriever.ledger
        reserve = ledger.final_reader_reserve
        ledger.final_reader_reserve = BudgetUsage()
        unheld_remaining = ledger.remaining(include_reader_reserve=True)
        maximum = BudgetUsage(
            actor_requests=int(getattr(self.actor, "format_repairs", 0)) + 1,
            format_repair_requests=int(getattr(self.actor, "format_repairs", 0)),
            reasoning_input_tokens=reserve.reasoning_input_tokens or max(0, int(unheld_remaining.reasoning_input_tokens)),
            reasoning_output_tokens=reserve.reasoning_output_tokens or max(0, int(unheld_remaining.reasoning_output_tokens)),
            reader_input_tokens=reserve.reader_input_tokens or max(0, int(unheld_remaining.reader_input_tokens)),
            reader_output_tokens=reserve.reader_output_tokens or max(0, int(unheld_remaining.reader_output_tokens)),
            actor_gpu_seconds=max(0.0, unheld_remaining.actor_gpu_seconds),
        )
        if self.simulated_reader:
            # Simulations pay reader usage but do not consume the final-answer reserve.
            ledger.final_reader_reserve = reserve
            remaining = ledger.remaining()
            maximum = dataclasses.replace(
                maximum,
                reasoning_input_tokens=max(0, int(remaining.reasoning_input_tokens)),
                reasoning_output_tokens=min(reserve.reasoning_output_tokens, max(0, int(remaining.reasoning_output_tokens))),
                reader_input_tokens=max(0, int(remaining.reader_input_tokens)),
                reader_output_tokens=max(0, int(remaining.reader_output_tokens)),
            )
        ledger.reserve(request_id, maximum)
        try:
            answer, usage = callback()
        except Exception:
            ledger.reconcile(request_id, BudgetUsage(), complete=False)
            if not self.simulated_reader:
                ledger.final_reader_reserve = BudgetUsage()
            raise
        ledger.reconcile(
            request_id,
            BudgetUsage(
                actor_requests=usage.requests,
                format_repair_requests=usage.format_repairs,
                reasoning_input_tokens=usage.input_tokens,
                reasoning_output_tokens=usage.output_tokens,
                reader_input_tokens=usage.input_tokens,
                reader_output_tokens=usage.output_tokens,
                actor_gpu_seconds=usage.gpu_seconds,
            ),
        )
        if not self.simulated_reader:
            ledger.events.append({"event_type": "reader_reserve_released", "request_id": request_id, "prior": reserve.to_dict()})
        return answer, usage
