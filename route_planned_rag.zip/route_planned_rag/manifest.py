from __future__ import annotations

import importlib.metadata
import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def package_versions(names: tuple[str, ...] = ("torch", "transformers", "peft", "datasets", "huggingface-hub", "numpy", "PyYAML")) -> dict[str, str | None]:
    versions = {}
    for name in names:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return versions


def git_state(root: str | Path) -> dict[str, Any]:
    result: dict[str, Any] = {"commit": None, "dirty": None}
    try:
        result["commit"] = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL).strip()
        result["dirty"] = bool(subprocess.check_output(["git", "-C", str(root), "status", "--porcelain"], text=True).strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass
    return result


def base_manifest(config: dict, command: str) -> dict[str, Any]:
    return {
        "status": "started",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "command": command,
        "config_path": config["_config_path"],
        "config_sha256": config["_config_sha256"],
        "reconstructed_bundle_contracts": bool(config["project"].get("reconstructed_bundle_contracts")),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "packages": package_versions(),
        "git": git_state(config["project"]["root"]),
        "models": config["models"],
    }

