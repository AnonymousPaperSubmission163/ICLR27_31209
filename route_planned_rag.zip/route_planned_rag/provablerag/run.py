"""Real-model entry point; reuses compiler, model loader, indices and ledgers."""
import argparse,copy,json,hashlib,time,fcntl
from pathlib import Path
from route_planned_rag.method.client import Client
from route_planned_rag.local_expansion.answering import AnswerClient
from route_planned_rag.local_expansion.compiler import compile_episode
from route_planned_rag.local_expansion.schema import Program
from route_planned_rag.prototype.prover import Prover,write_json
from route_planned_rag.local_expansion.full_a import validate_public,freeze_protocol
from route_planned_rag.local_expansion.retrieval import SharedRetriever
from .engine import ProvableRAG


def execute(row,actor,retriever,binary,out,settings,compile_source=None):
    directory=out/row['dataset']/row['question_id'];directory.mkdir(parents=True,exist_ok=True)
    if (directory/'result.json').exists():return json.loads((directory/'result.json').read_text())
    if (directory/'STARTED.json').exists():
        raise RuntimeError('incomplete_episode_retained_no_free_restart:'+str(directory))
    write_json(directory/'STARTED.json',dict(question_id=row['question_id']))
    cache=directory/'compilation';budget=settings['question_token_budget']
    compiler=Client(actor,cache,budget=budget);program=None;error=None
    if compile_source is not None:
        source=compile_source/'compilation_cache'/(row['dataset']+'_'+row['question_id'])
        outcome=json.loads((source/'outcome.json').read_text())
        compiler.calls=json.loads((source/'model_calls.json').read_text());compiler.persist()
        program=Program.model_validate(outcome['program']) if outcome['program'] else None;error=outcome['error']
    else:
        try:program=compile_episode(row['question'],compiler,cache,maximum=3200)
        except (ValueError,RuntimeError) as exc:error=repr(exc)
    write_json(cache/'outcome.json',dict(program=program.model_dump() if program else None,error=error))
    write_json(directory/'model_calls.json',[dict(c,physical_execution=False,shared_compiler_cache='compilation') for c in copy.deepcopy(compiler.calls)])
    client=AnswerClient(actor,directory,budget=budget);engine=None
    prover=Prover(binary,directory/'prover',timeout=settings['execution']['prover_timeout'],cap=settings['execution']['max_prover_calls'])
    start=time.perf_counter()
    try:
        if program is None:raise ValueError('initial_compile_invalid:'+str(error))
        engine=ProvableRAG(row['question'],program.model_copy(deep=True),client,retriever,prover,directory,settings['execution'])
        result=engine.run()
    except (ValueError,RuntimeError,OSError) as exc:
        result=dict(question=row['question'],final_answer='',certified_answer='',proof_status='unverified',
            status='compile_invalid' if program is None else 'execution_error',error=repr(exc),method='ProvableRAG',
            failure_category='initial_compile_invalid' if program is None else 'execution_error',
            retrieval_calls=engine.state['retrieval_calls'] if engine else 0,proof_calls=prover.calls)
    finally:
        if engine is not None:engine.store.close()
    result.update(dataset=row['dataset'],question_id=row['question_id'],initial_compile_invalid=program is None,
        reader_calls=sum(c['role'] in ('reader','reader_verification') for c in client.calls),
        logical_total_tokens=client.charged,logical_compiler_tokens=compiler.charged,
        physical_compiler_tokens=compiler.charged if compile_source is None else 0,
        physical_episode_tokens=sum(c.get('input_tokens',0)+c.get('output_tokens',0) for c in client.calls if c.get('physical_execution',True)),
        elapsed_seconds=time.perf_counter()-start,run_kind='real_model')
    assert result['logical_total_tokens']<=budget
    assert result['reader_calls']<=settings['execution']['max_reader_calls']
    assert result['retrieval_calls']<=settings['execution']['max_retrievals']
    assert result['proof_calls']<=settings['execution']['max_prover_calls']
    write_json(directory/'result.json',result)
    return result


def main():
    import yaml,torch
    from route_planned_rag.logicgraph.runtime import load_models
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True);p.add_argument('--public',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--config',type=Path,default=Path('configs/provablerag.yaml'))
    p.add_argument('--corpus-dir',type=Path,default=Path('experiments/full_a_20260916/data/corpora'))
    p.add_argument('--compile-source',type=Path)
    args=p.parse_args();root=args.root.resolve();source=Path(__file__).resolve().parents[2]
    source_manifest={}
    if (source.parent/'freeze.json').exists():
        source_manifest=json.loads((source.parent/'freeze.json').read_text())['source_sha256']
        for name,expected in source_manifest.items():
            if hashlib.sha256((source/name).read_bytes()).hexdigest()!=expected:raise ValueError('frozen_source_changed:'+name)
    settings=yaml.safe_load((source/args.config).read_text());rows=json.loads((root/args.public).read_text());validate_public(rows)
    models=yaml.safe_load((source/settings['model_config']).read_text());models['project']['root']=str(root)
    output=root/args.output;output.mkdir(parents=True,exist_ok=True)
    lock=(output/'worker.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    freeze_protocol(output/'protocol.json',dict(method='ProvableRAG',settings=settings,source_sha256=source_manifest,
        input_sha256=hashlib.sha256((root/args.public).read_bytes()).hexdigest(),public_questions=rows,
        models={k:models['models'][k] for k in ('actor','retriever')},source_root=str(source),
        compile_source=str(args.compile_source) if args.compile_source else None,
        empirical_claims='No highest-accuracy or 25-percent-savings claim is assumed by implementation.'))
    torch.manual_seed(settings['seed']);actor,_,encoder=load_models(models,with_encoder=True,with_scorer=False)
    retrievers={};results=[]
    for row in rows:
        ds=row['dataset']
        if ds not in retrievers:
            retrievers[ds]=SharedRetriever(root/args.corpus_dir/(ds+'.json'),encoder,root/'artifacts/closed_loop_indices'/ds,models['models']['retriever'])
        r=execute(row,actor,retrievers[ds],root/'vendor/prover9/LADR-2009-11A/bin/prover9',output,settings,
                  root/args.compile_source if args.compile_source else None)
        results.append(r);write_json(output/'results.json',results)
        print(json.dumps({k:r.get(k) for k in ('dataset','question_id','status','final_answer','logical_total_tokens','positive_depth_steps')},ensure_ascii=False),flush=True)
    write_json(output/'COMPLETE.json',dict(questions=len(results),method='ProvableRAG',all_budgets_checked=True))

if __name__=='__main__':main()
