"""Proof-compiled retrieval and reasoning with node-local evidence contexts."""
