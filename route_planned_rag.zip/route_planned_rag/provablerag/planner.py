"""Schedule only proof-compiled obligations, with binding-local proof progress."""
from route_planned_rag.prototype.logic import substitute, ground, opposite
from route_planned_rag.method.schema import signature as digest
from .graph import obligation, good, rule, certified_depth


def progress(engine, plan, binding):
    s=engine.store
    # Collect only the facts belonging to this SAME candidate binding. Incomplete
    # slots cannot create fictional existential witnesses.
    supported=[];fids=set()
    for node in range(len(s.plan.needs)):
        atom=substitute(s.pattern(node),binding)
        if not ground(atom):continue
        hits=s.match(atom)
        if hits:
            supported.append(node);fids.update(hits[0]['facts'])
    leaves,world_rules,_=s.proof_inputs(dict(facts=sorted(fids)))
    facts=[(f,obligation(s.row_atom(s.rows[f]))) for f in sorted(leaves)]
    dynamic=[rule(rid,[obligation(a) for a in r.body],obligation(r.head),r.explanation) for rid,r in world_rules.items()]
    rules={r.id:r for r in [*plan.rules,*dynamic]}
    reached=0;certificate=None;view_id=None;formal=None
    for view in reversed(plan.views):
        if not set(view['original_nodes'])<=set(supported):continue
        if view['logical_depth']==0 and not any(s.rows[f].get('origin')=='program_derived' for f in fids):continue
        goal=substitute(view['atom'],binding)
        if not ground(goal):continue
        signature=digest([facts,list(rules.values()),goal])
        cached=engine.progress_proofs.get(signature)
        if cached is None:
            if engine.prover.calls>=engine.prover.cap-engine.config['final_proof_reserve']:continue
            cached=engine.prover.prove(facts,sorted(rules.items()),[goal],version='actual_subquery_'+signature)
            engine.progress_proofs[signature]=cached
        if good(cached):
            weights={v['id']:int(v['operation']=='natural_join_project') for v in plan.views}
            weights['original_goal_contract']=0
            actual=certified_depth(facts,list(rules.values()),goal,cached,weights)
            if actual is None:continue
            reached=actual;certificate=cached['proof_id'];view_id=view['id']
            formal=cached['proof_depth']['formal_depth'];break
    return dict(supported_nodes=supported,supported_count=len(supported),logical_depth=reached,
                formal_depth=formal,proof_id=certificate,view_id=view_id,
                fact_ids=sorted(fids),basis='actual_observed_leaf_proof_of_canonical_original_subquery',is_correctness=False)


def choose(engine):
    s=engine.store;candidates=[];actions={};progress_cache={}
    for p in engine.plans:
        if p.negative_leaves and any(s.match(s.pattern(n)) for n in p.negative_leaves):continue
        for row in s._join_nodes(p.leaves,partial=True):
            binding=row['binding'];missing={};ready=[]
            # Action bindings are projected to their actual free variables;
            # another candidate can never overwrite unrelated entity bindings.
            for node in p.leaves:
                pattern=opposite(s.pattern(node)) if node in p.negative_leaves else s.pattern(node)
                atom=substitute(pattern,binding)
                if ground(atom) and s.match(atom):continue
                terms=atom.arguments
                constants=[s.names[t.name] if t.kind=='constant' else None for t in terms]
                anchor=constants[0] or (constants[1] if constants[1] not in ('true','false') else None)
                variables={t.name for t in s.pattern(node).arguments if t.kind=='variable'}
                local={k:s.names[v.name] for k,v in binding.items() if k in variables}
                request=dict(id=digest(atom),node=node,target=atom.model_dump(),binding=local,anchor=anchor,
                             executable_plan_id=p.id,plan_proof_id=p.certificate['proof_id'])
                action=(engine.read_option(request) or engine.retrieval_option(request)) if anchor else None
                cost=action['cost'] if action else engine.config['retrieve_cost']+engine.config['read_cost']
                missing.setdefault(digest(atom),dict(node=node,target=atom.model_dump(),cost=cost))
                if action:actions[action['key']]=action;ready.append(action['key'])
            sig=digest([p.id,binding])
            if sig not in progress_cache:progress_cache[sig]=progress(engine,p,binding)
            pr=progress_cache[sig]
            candidates.append(dict(id=sig,plan_id=p.id,binding={k:s.names[v.name] for k,v in binding.items()},
                fact_ids=row['facts'],missing=list(missing.values()),ready=sorted(set(ready)),
                remaining_cost=sum(m['cost'] for m in missing.values()),reasoning_progress=pr,
                plan_formal_depth=p.certificate['proof_depth']['formal_depth']))
    unique={c['id']:c for c in candidates};candidates=list(unique.values())
    def rank(c,depth=True):
        pr=c['reasoning_progress']
        return ((-pr['logical_depth'],) if depth else ())+(-pr['supported_count'],c['remaining_cost'],c['id'])
    sharing={k:sum(k in c['ready'] for c in candidates) for k in actions}
    def select(depth):
        for c in sorted(candidates,key=lambda c:rank(c,depth)):
            if c['ready']:
                action=min((actions[k] for k in c['ready']),key=lambda a:(a['cost'],-sharing[a['key']],a['node'],a['key']))
                return dict(action,candidate_id=c['id'],candidate_binding=c['binding'],reasoning_progress=c['reasoning_progress'],
                            executable_plan_id=c['plan_id'],plan_proof_id=next(p.certificate['proof_id'] for p in engine.plans if p.id==c['plan_id']),priority_key=rank(c,depth),
                            selection_reason='verified subquery proof depth; coverage; remaining acquisition cost; sharing')
    selected=select(engine.config['use_proof_depth']);counterfactual=select(not engine.config['use_proof_depth'])
    audit=dict(step=engine.state['step'],selected=selected['key'] if selected else None,
        without_or_with_depth=counterfactual['key'] if counterfactual else None,
        action_changed=(selected['key'] if selected else None)!=(counterfactual['key'] if counterfactual else None),
        positive_depth=any(c['reasoning_progress']['logical_depth']>0 for c in candidates),
        max_depth=max((c['reasoning_progress']['logical_depth'] for c in candidates),default=0))
    engine.plan_decisions.append(audit)
    if selected:selected['depth_decision']=audit
    return sorted(candidates,key=lambda c:rank(c,engine.config['use_proof_depth'])),selected
