"""Final proofs conclude the rendered answer, including deterministic comparisons."""
from route_planned_rag.local_expansion.store import EvidenceStore
from route_planned_rag.prototype.schemas import Atom,Term,RuleSpec
from route_planned_rag.prototype.logic import substitute
from route_planned_rag.method.schema import signature as digest
from .graph import good


class ProvableStore(EvidenceStore):
    def certificate_valid(self,certificate):
        computation=certificate.get('checked_computation')
        if computation is None:return super().certificate_valid(certificate)
        return (certificate.get('alias_version')==self.alias_version and
                computation.get('checked_against_current_candidates') is True and
                all(self.rows.get(fid,{}).get('status')=='accepted' for fid in computation['premise_fact_ids']) and
                all(fid==computation['lemma_id'] or fid.startswith('QD') or
                    self.rows.get(fid,{}).get('status')=='accepted' for fid in certificate['input_fact_ids']))

    def set_status(self,ids,status,reason):
        super().set_status(ids,status,reason)
        for certificate in self.certificates:certificate['valid']=self.certificate_valid(certificate)
        self.sync()

    def prove(self,candidate,prover):
        # The caller cannot supply an arbitrary readout with valid-looking facts.
        def identity(c):return digest([c['value'],c['binding'],c['facts'],c['computation']])
        if not any(identity(c)==identity(candidate) for c in self.candidates()):
            raise ValueError('answer_not_supported_by_current_original_contract')
        certificate=super().prove(candidate,prover)
        if certificate is None or self.plan.goal.op in ('select','verify'):return certificate
        # The original verifier establishes complete comparison inputs. Replay
        # its observed leaves/rules, adding a checked arithmetic/readout lemma;
        # never assert its derived comparison_inputs conclusion as a new axiom.
        leaves,rules,_=self.proof_inputs(candidate)
        facts=[(fid,self.row_atom(self.rows[fid])) for fid in sorted(leaves)]
        body=[self.pattern(i) for i in range(len(self.plan.needs))]
        for v,values in self.plan.choices.items():
            pattern=Atom(predicate='question_domain_'+v[1:],arguments=[self.term(v)],negated=False)
            body.append(pattern)
            for value in values:facts.append(('QD'+digest([v,value]),pattern.model_copy(update={'arguments':[self.term(value)]})))
        g=self.plan.goal
        inputs=Atom(predicate='comparison_inputs',arguments=[Term(kind='variable',name=v[1:],entity_type='entity') for v in (g.left,g.right)],negated=False)
        rules['question_conjunction']=RuleSpec(id='question_conjunction',body=body,head=inputs,origin='question_definition',
            source_refs=[],explanation='Every unchanged original requirement and finite domain restriction.')
        grounded=substitute(inputs,candidate['binding'])
        answer=Atom(predicate='answer',arguments=[self.term(candidate['value'])],negated=False)
        lemma=Atom(predicate='checked_'+g.op+'_result',arguments=[*grounded.arguments,*answer.arguments],negated=False)
        lemma_id='CHECKED_'+digest([self.plan_hash,candidate['binding'],candidate['value'],candidate['computation']])
        facts.append((lemma_id,lemma))
        rid='checked_'+g.op+'_readout'
        rules[rid]=RuleSpec(id=rid,body=[grounded,lemma],head=answer,origin='builtin',source_refs=[],
            explanation='Deterministic original comparison operator over these exact proved operands. Not an LLM or retrieved world-fact axiom.')
        result=prover.prove(facts,sorted(rules.items()),[answer],version=digest([self.plan_hash,self.alias_version,candidate['computation']]))
        result.update({k:v for k,v in certificate.items() if k in ('alias_version','derived_supports','leaf_fact_ids','proof_uses_auxiliary',
                      'answer_depends_on_expansion','dependency_check','reasoning_depth')})
        result['checked_computation']=dict(lemma_id=lemma_id,operation=g.op,computation=candidate['computation'],
            binding={k:v.model_dump() for k,v in candidate['binding'].items()},premise_fact_ids=sorted(leaves),
            checked_against_current_candidates=True,basis='trusted deterministic date/quantity/identity operator; not observed evidence')
        result['valid']=certificate['valid'] and all(self.rows[f]['status']=='accepted' for f in leaves)
        if result.get('reasoning_depth'):
            result['reasoning_depth']=dict(result['reasoning_depth'],proof_id=result['proof_id'],
                formal_proof_depth=result.get('proof_depth',{}).get('formal_depth'),
                semantic_derivation_depth=(result['reasoning_depth'].get('semantic_derivation_depth') or 0)+1)
        self.certificates.append(result);self.sync()
        return result if good(result) else None
