"""Execute verified plans; documents are node-local, provenance is out of band."""
from route_planned_rag.local_expansion.engine import LocalExpansionEngine
from route_planned_rag.prototype.prover import write_json
from route_planned_rag.method.schema import signature as digest
from .graph import PlanCompiler
from .planner import choose
from .store import ProvableStore


class ProvableRAG(LocalExpansionEngine):
    store_class = ProvableStore
    def __init__(self,question,program,client,retriever,prover,directory,config=None):
        settings=dict(config or {})
        settings.update(planning_policy='remaining_cost',allow_auxiliary=False,answer_policy='certified_only')
        settings.setdefault('max_verified_plans',4)
        settings['final_proof_reserve']=max(settings.get('final_proof_reserve',8),program.goal.count or 1)
        settings.setdefault('use_proof_depth',True)
        self._planning_node=None;self.node_sources={};self.progress_proofs={};self.plan_decisions=[];self.executing=None
        super().__init__(question,program,client,retriever,prover,directory,settings)
        self.plans=[];self.plan_generation=0;self.compiled_signature=None
        self.ensure_plans_current()

    def ensure_plans_current(self):
        signature=digest([self.store.pattern(i) for i in range(len(self.store.catalog))])
        if signature==self.compiled_signature:return
        previous=[p.id for p in self.plans]
        self.plans=PlanCompiler(self.store,self.prover,self.directory,self.config['max_verified_plans'],
                               self.config['final_proof_reserve']).compile()
        self.compiled_signature=signature;self.plan_generation+=1
        write_json(self.directory/('verified_plans_generation_'+str(self.plan_generation)+'.json'),
                   dict(signature=signature,plans=[p.dump() for p in self.plans]))
        self.event('plans_compiled',plan_ids=[p.id for p in self.plans],previous_plan_ids=previous,
                   generation=self.plan_generation,reason='initial_or_question_constant_identity_changed',
                   conditional_not_answer_proof=True,original_program_unchanged=True)

    def plan_actions(self):
        self.ensure_plans_current()
        return choose(self)

    def maybe_expand(self,candidates):
        return False  # All executable alternatives must have a prior plan certificate.

    def reader_nodes(self,action):
        return [action['node']]

    def reading_payload(self,evidence,nodes,binding,retry=False):
        if self.executing is not None:
            nodes=[self.executing['node']];binding=self.executing['binding']
        payload=super().reading_payload(evidence,nodes,binding,retry=False)
        # Only the selected operator's required bound variables cross a node
        # boundary. Raw documents, quotes and unrelated bindings are not inputs.
        variables={t[1:] for i in nodes for t in (self.store.catalog[i].s,self.store.catalog[i].o) if t.startswith('?')}
        payload['structured_inputs']={k:v for k,v in binding.items() if k in variables}
        if retry:payload['task']='Recheck this node and these originals only. Do not guess missing evidence.'
        return payload

    def cache_key(self,request,eid):
        # Include exact node-local I/O contract; global-slot read caches are not reusable.
        node=request.get('node',self.executing['node'] if self.executing else self._planning_node)
        if node is None:raise ValueError('node_local_cache_requires_operator')
        return digest(['provablerag_node',node,super().cache_key(request,eid)])

    def read_option(self,request):
        # Archive references are NOT automatically added to downstream contexts.
        allowed=self.node_sources.get(request['node'],set())
        if not allowed:return None
        evidence=self.store.evidence
        self._planning_node=request['node']
        try:
            self.store.evidence={eid:e for eid,e in evidence.items() if eid in allowed}
            return super().read_option(request)
        finally:
            self.store.evidence=evidence;self._planning_node=None

    def _check_action(self,action):
        p=next((p for p in self.plans if p.id==action['executable_plan_id']),None)
        if p is None or action['node'] not in p.leaves:raise ValueError('action_not_in_verified_plan')
        if action['plan_proof_id']!=p.certificate['proof_id']:raise ValueError('action_certificate_mismatch')
        return p

    def retrieve(self,action):
        self._check_action(action);self.executing=action
        try:
            super().retrieve(action)
            event=next(e for e in reversed(self.state['events']) if e['kind']=='retrieval_completed')
            self.node_sources.setdefault(action['node'],set()).update(event['source_ids'])
            self.event('node_sources_acquired',node=action['node'],source_ids=event['source_ids'])
        finally:self.executing=None

    def read(self,action):
        self._check_action(action)
        if not set(action['source_ids'])<=self.node_sources.get(action['node'],set()):raise ValueError('cross_node_document_context')
        self.executing=action
        try:
            super().read(action)
            # This packet is the ONLY downstream data product. Documents and
            # quotations remain in the provenance archive for verification.
            node=action['node'];need=self.store.catalog[node]
            compiled=self._check_action(action)
            downstream={t[1:] for i,n in enumerate(self.store.catalog) if i in compiled.leaves and i!=node for t in (n.s,n.o) if t.startswith('?')}
            downstream|={v[1:] for v in (self.program.goal.variable,self.program.goal.left,self.program.goal.right,
                                        self.program.goal.left_answer,self.program.goal.right_answer) if v and v.startswith('?')}
            rows=[]
            pattern=self.store.pattern(node).model_copy(update={'negated':action['target']['negated']})
            for hit in self.store.match(pattern,{k:self.store.term(v) for k,v in action['binding'].items()}):
                rows.append(dict(binding={k:self.store.names[v.name] for k,v in hit['binding'].items() if k in downstream},
                                 fact_ids=hit['facts']))
            self.event('node_output',node=node,rows=rows,raw_documents_passed=False)
        finally:self.executing=None

    def terminal(self):
        self.ensure_plans_current()
        if not self.plans:return []
        answers=super().terminal()
        if self.program.goal.op=='verify':
            answers=[a for a in answers if a['value']!='no' or any(
                a['computation'].get('counterexample_node') in p.negative_leaves for p in self.plans)]
        return answers

    def run(self):
        if not self.plans:
            result=dict(question=self.question,final_answer='',certified_answer='',proof_status='unverified',
                        status='no_verified_executable_plan',failure_category='plan_verification_failed',
                        reader_calls=0,retrieval_calls=0,proof_calls=self.prover.calls,logical_total_tokens=self.client.charged)
        else:result=super().run()
        result.update(method='ProvableRAG',answer_policy='certified_only',verified_plan_count=len(self.plans),
            plan_proof_calls=sum(str(p.get('graph_version','')).startswith('conditional_') and p['result'] not in ('unavailable','budget_exhausted') for p in self.prover.records),plan_decisions=self.plan_decisions,
            depth_action_changes=sum(x['action_changed'] for x in self.plan_decisions),
            positive_depth_steps=sum(x['positive_depth'] for x in self.plan_decisions),
            max_verified_subquery_depth=max((x['max_depth'] for x in self.plan_decisions),default=0),
            structured_only_node_transfer=True,document_archive_is_not_downstream_context=True,
            necessity_scope='Inclusion minimal retrieval obligations and inference rules relative to each conditional verified plan; not globally unique documents.',
            logical_total_tokens=self.client.charged,proof_calls=self.prover.calls)
        write_json(self.directory/'result.json',result)
        return result
