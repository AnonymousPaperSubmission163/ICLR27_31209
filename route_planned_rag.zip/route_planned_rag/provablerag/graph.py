"""Conditional plan theorems, canonical relational views and support minimality.

Plan assumptions describe required future evidence, NOT observed world facts.
Signed requirements are positive evidence obligations: evidence for not-P is
separate from absence of evidence for P. Actual answers still use the original
world-level Prover9 verifier and the unchanged question contract.
"""
from dataclasses import dataclass
from itertools import product
import time
from route_planned_rag.prototype.schemas import Atom, Term, RuleSpec
from route_planned_rag.prototype.logic import substitute, unify, ground, key, opposite
from route_planned_rag.method.schema import signature as digest
from route_planned_rag.prototype.prover import write_json
from route_planned_rag.local_expansion.depth import layers


def obligation(atom):
    return atom.model_copy(update={'predicate':'support_'+digest([atom.predicate,atom.negated]),'negated':False})


def rule(identity, body, head, explanation):
    return RuleSpec(id=identity,body=body,head=head,origin='question_definition',source_refs=[],explanation=explanation)


def exact_closure(facts, rules, max_work=20000, seconds=2):
    """Complete finite positive Horn closure or explicit failure; never truncated 'false'."""
    if max_work<=0 or seconds<=0:raise ValueError('plan_closure_budget_exhausted')
    known={key(a):a for a in facts};deadline=time.monotonic()+seconds;work=0
    while True:
        added=False
        for r in rules:
            rows=[{}]
            for body in r.body:
                following={}
                for binding in rows:
                    for atom in list(known.values()):
                        work+=1
                        if work>max_work or time.monotonic()>deadline:raise ValueError('plan_closure_budget_exhausted')
                        b=unify(substitute(body,binding),atom,binding)
                        if b is not None:following[digest(b)]=b
                rows=list(following.values())
            for b in rows:
                head=substitute(r.head,b)
                if not ground(head):raise ValueError('unsafe_plan_rule')
                if key(head) not in known:known[key(head)]=head;added=True
        if not added:return known


def good(proof):
    return (proof.get('result')=='proved' and proof.get('valid') and
            proof.get('source_mapping_status')=='complete' and
            proof.get('proof_depth',{}).get('status')=='complete')


@dataclass
class ExecutablePlan:
    id: str
    leaves: list[int]
    rules: list[RuleSpec]
    goal: Atom
    views: list[dict]
    certificate: dict
    necessity: dict
    gamma_ids: list[str]
    negative_leaves: tuple[int,...] = ()

    def dump(self):
        return dict(id=self.id,leaf_slots=self.leaves,negative_leaves=list(self.negative_leaves),rules=[r.model_dump() for r in self.rules],
                    goal=self.goal.model_dump(),views=[dict(v,atom=v['atom'].model_dump()) for v in self.views],
                    conditional_certificate=self.certificate,necessity=self.necessity,gamma_ids=self.gamma_ids,
                    semantics='If the declared future evidence obligations are obtained with consistent bindings, the original target inputs follow. This is not an answer proof.')


class PlanCompiler:
    def __init__(self, store, prover, directory, max_plans=4, reserve=8):
        self.store,self.prover,self.directory=store,prover,directory
        self.max_plans,self.reserve=max_plans,reserve
        self.rejections=[];self.truncated=False

    def definitions(self):
        s=self.store;needs=[obligation(s.pattern(i)) for i in range(len(s.plan.needs))]
        ls,_=layers(s.plan)
        order=sorted(range(len(needs)),key=lambda i:(ls.get(i) or 999,i))
        # Views are canonical original-question subqueries. Every join adds a
        # distinct original obligation, never a dummy identity/checkpoint step.
        rules=[];views=[];prefix=[];previous=None
        goal_vars={v[1:] for v in (s.plan.goal.variable,s.plan.goal.left,s.plan.goal.right,
                     s.plan.goal.left_answer,s.plan.goal.right_answer) if v and v.startswith('?')}
        goal_vars|={v[1:] for v in s.plan.choices}
        for node in order:
            prefix.append(node)
            body=([previous] if previous is not None else [])+[needs[node]]
            available={t.name:t for a in body for t in a.arguments if t.kind=='variable'}
            downstream={t.name for i in order if i not in prefix for t in needs[i].arguments if t.kind=='variable'}|goal_vars
            args=[available[n] for n in sorted(available.keys() & downstream)]
            head=Atom(predicate='query_view_'+digest([s.plan_hash,sorted(prefix)]),arguments=args,negated=False)
            rid='query_join_'+str(len(prefix))
            rules.append(rule(rid,body,head,'Existential projection of the conjunction of original requirements '+str(sorted(prefix))))
            views.append(dict(id=rid,atom=head,original_nodes=list(prefix),
                              logical_depth=max(0,len(prefix)-1),export_variables=[t.name for t in args],
                              operation='project' if len(prefix)==1 else 'natural_join_project'))
            previous=head
        goal=Atom(predicate='original_goal_inputs_'+s.plan_hash,arguments=previous.arguments,negated=False)
        self.domain_atoms=[Atom(predicate='question_domain_'+v[1:],arguments=[s.term(v)],negated=False) for v in sorted(s.plan.choices)]
        rules.append(rule('original_goal_contract',[previous,*self.domain_atoms],goal,'Complete original Program; original deterministic comparison/count/readout remains mandatory.'))
        return rules,views,goal

    def compile(self):
        s=self.store;definitions,views,goal=self.definitions()
        options=[[([i],[])] + [(r.body,[r.id]) for r in s.acquisition.rules if r.head==i]
                 for i in range(len(s.plan.needs))]
        plans=[];seen=set()
        for number,branch in enumerate(product(*options)):
            if number>=self.max_plans:self.truncated=True;break
            if self.prover.calls>=self.prover.cap-self.reserve:
                self.rejections.append(dict(reason='proof_budget_reserve'));break
            leaves=sorted(set(n for ns,_ in branch for n in ns));gamma_ids=sorted(set(r for _,rs in branch for r in rs))
            gamma=[]
            for rid in gamma_ids:
                r=next(r for r in s.acquisition.rules if r.id==rid)
                gamma.append(rule(rid,[obligation(s.pattern(n)) for n in r.body],obligation(s.pattern(r.head)),r.reason))
            rules=gamma+definitions
            variables={t.name:t for r in rules for a in r.body+[r.head] for t in a.arguments if t.kind=='variable'}
            symbolic={n:Term(kind='constant',name='arbitrary_plan_witness_'+n,entity_type=t.entity_type) for n,t in variables.items()}
            fixed=[('question_domain_'+str(i),substitute(a,symbolic)) for i,a in enumerate(self.domain_atoms)]
            fixed_atoms=[a for _,a in fixed]
            facts={n:substitute(obligation(s.pattern(n)),symbolic) for n in leaves}
            target=substitute(goal,symbolic)
            try:
                # Deduplicate semantically identical obligations before minimization.
                unique={}
                for n,a in facts.items():unique.setdefault(key(a),(n,a))
                facts=dict(unique.values())
                if key(target) not in exact_closure([*fixed_atoms,*facts.values()],rules):raise ValueError('insufficient_plan')
                for n in list(facts):
                    without=[a for k,a in facts.items() if k!=n]
                    if key(target) in exact_closure([*fixed_atoms,*without],rules):del facts[n]
                leaves=sorted(facts)
                necessity={}
                for n in leaves:
                    model=exact_closure([*fixed_atoms,*[a for k,a in facts.items() if k!=n]],rules)
                    assert key(target) not in model
                    necessity['N'+str(n)]=dict(goal_entailed=False,least_model_atoms=sorted(model),
                                               definition='Deletion countermodel in finite positive evidence-obligation theory; inclusion minimal, not minimum cost or globally unique.')
                signature=digest([leaves,[r.model_dump() for r in rules]])
                if signature in seen:continue
                seen.add(signature)
                certificate=self.prover.prove([*fixed,*[('plan_N'+str(n),a) for n,a in facts.items()]],[(r.id,r) for r in rules],[target],version='conditional_'+signature)
                if not good(certificate):raise ValueError('conditional_proof_not_verified:'+certificate['result'])
                # Execute only the assumptions and inference rules appearing in the
                # actual returned proof. No proof means no executable plan.
                used=set(certificate['fact_ids']);leaves=[n for n in leaves if 'plan_N'+str(n) in used]
                if len(leaves)!=len(facts):raise ValueError('minimality_proof_disagreement')
                used_rules=set(certificate['rule_ids']);rules=[r for r in rules if r.id in used_rules]
                if key(target) not in exact_closure([*fixed_atoms,*facts.values()],rules):raise ValueError('proof_compilation_incomplete')
                # Every executed reasoning clause is likewise deletion-essential.
                reasoning_necessity={}
                for r in rules:
                    model=exact_closure([*fixed_atoms,*facts.values()],[q for q in rules if q.id!=r.id])
                    if key(target) in model:raise ValueError('redundant_proof_rule')
                    reasoning_necessity[r.id]=dict(goal_entailed=False,least_model_atoms=sorted(model))
                plans.append(ExecutablePlan(signature,leaves,rules,goal,[v for v in views if v['id'] in used_rules],certificate,
                    dict(retrieval=necessity,reasoning=reasoning_necessity),gamma_ids))
            except ValueError as exc:self.rejections.append(dict(leaves=leaves,error=str(exc)))
        # A ground yes/no conjunction has explicit counterexample alternatives.
        # Missing evidence is never a negative answer.
        if s.plan.goal.op=='verify' and all(ground(s.pattern(i)) for i in range(len(s.plan.needs))):
            for n in range(len(s.plan.needs)):
                if self.prover.calls>=self.prover.cap-self.reserve:break
                premise=obligation(opposite(s.pattern(n)))
                target=Atom(predicate='original_goal_no_'+s.plan_hash,arguments=[],negated=False)
                rid='ground_counterexample_'+str(n)
                r=rule(rid,[premise],target,'An explicitly negated ground original conjunct refutes the question conjunction.')
                certificate=self.prover.prove([('plan_N'+str(n),premise)],[(rid,r)],[target],version='conditional_'+rid)
                if not good(certificate):continue
                assert key(target) not in exact_closure([], [r])
                assert key(target) not in exact_closure([premise], [])
                plans.append(ExecutablePlan(digest([rid,s.plan_hash]),[n],[r],target,[],certificate,
                    dict(retrieval={'N'+str(n):dict(goal_entailed=False,least_model_atoms=[])},
                         reasoning={rid:dict(goal_entailed=False,least_model_atoms=[key(premise)])}),[],(n,)))
        write_json(self.directory/'verified_plans.json',dict(program_hash=s.plan_hash,plans=[p.dump() for p in plans],
                    rejected=self.rejections,truncated=self.truncated,proof_calls=self.prover.calls))
        return plans


def certified_depth(facts, rules, target, certificate, weights, max_work=20000):
    """Normalize ONLY returned-certificate inputs into meaningful inference height.

    Joins and registered domain-rule applications count; identity/projection and
    final readout wrappers do not. This never substitutes for the native DAG.
    """
    if not good(certificate):return None
    used_facts=set(certificate['fact_ids']);used_rules=set(certificate['rule_ids'])
    atoms={key(a):a for fid,a in facts if fid in used_facts}
    depths={k:0 for k in atoms};work=0;deadline=time.monotonic()+2
    while True:
        changed=False
        for r in rules:
            if r.id not in used_rules:continue
            rows=[({},0)]
            for body in r.body:
                following={}
                for binding,height in rows:
                    for k,a in list(atoms.items()):
                        work+=1
                        if work>max_work or time.monotonic()>deadline:return None
                        b=unify(substitute(body,binding),a,binding)
                        if b is not None:
                            signature=digest(b);value=max(height,depths[k])
                            if signature not in following or value<following[signature][1]:following[signature]=(b,value)
                rows=list(following.values())
            for b,height in rows:
                head=substitute(r.head,b)
                if not ground(head):return None
                k=key(head);value=height+weights.get(r.id,1)
                if value<depths.get(k,float('inf')):
                    atoms[k]=head;depths[k]=value;changed=True
        if not changed:return depths.get(key(target))
