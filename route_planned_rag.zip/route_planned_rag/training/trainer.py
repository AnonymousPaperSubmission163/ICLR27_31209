from __future__ import annotations

import json
import math
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from route_planned_rag.models.loaders import load_mistral3_generation
from route_planned_rag.models.scorer import BudgetAwareScorer, assert_trainable_scope, configure_text_only_lora
from route_planned_rag.types import SearchCandidate, StopCandidate


@dataclass(frozen=True)
class ScorerExample:
    question_id: str
    public_state: dict[str, Any]
    action: SearchCandidate | StopCandidate
    lambda_value: float
    target: float


def _action(value: dict):
    if value["kind"] == "STOP":
        return StopCandidate(action_id=value["action_id"], route_id=value["route_id"])
    return SearchCandidate(
        action_id=value["action_id"],
        route_id=value["route_id"],
        node_id=value["node_id"],
        query=value["query"],
        intent=value["intent"],
    )


def load_examples(path: str | Path, target_kind: str) -> list[ScorerExample]:
    examples = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            row = json.loads(line)
            if row.get("completion_status") != "complete" or row.get("terminal_success") is None:
                continue
            if target_kind == "distance" and row.get("distance_target") is None:
                continue
            lambda_value = float(row["lambda"])
            if target_kind == "cost":
                target = float(row["scorer_target"])
            elif target_kind == "success":
                target = float(row["terminal_success"])
            else:
                target = float(row["distance_target"])
            public_state = row["public_state"]
            public_state["lambda"] = lambda_value
            examples.append(ScorerExample(row["question_id"], public_state, _action(row["action"]), lambda_value, target))
    if not examples:
        raise RuntimeError(f"no eligible {target_kind} examples in {path}")
    return examples


def _mean_loss(model, examples: list[ScorerExample], target_kind: str) -> float:
    import torch
    import torch.nn.functional as functional

    model.encoder.eval()
    model.head.eval()
    losses = []
    with torch.inference_mode():
        for example in examples:
            prediction, _ = model.forward_tensors(example.public_state, [example.action])
            target = torch.tensor([example.target], dtype=prediction.dtype, device=prediction.device)
            if target_kind == "success":
                loss = functional.binary_cross_entropy(prediction, target)
            else:
                scale = max(example.lambda_value, 1.0)
                loss = functional.mse_loss(prediction / scale, target / scale)
            losses.append(float(loss.cpu()))
    return sum(losses) / len(losses)


def train_scorer(config: dict, *, target_kind: str, seed: int, train_path: str | Path, dev_path: str | Path, output_dir: str | Path) -> dict:
    import torch
    import torch.nn.functional as functional

    if target_kind not in {"cost", "success", "distance"}:
        raise ValueError("unknown scorer target")
    random.seed(seed)
    torch.manual_seed(seed)
    train = load_examples(train_path, target_kind)
    dev = load_examples(dev_path, target_kind)
    item = config["models"]["scorer"]
    cache = Path(config["project"]["cache_root"]) / "huggingface"
    tokenizer, base = load_mistral3_generation(item, cache_dir=cache)
    hidden_size = int(base.config.text_config.hidden_size)
    encoder, targets = configure_text_only_lora(
        base,
        int(item["lora_rank"]),
        int(item["lora_alpha"]),
        float(item["lora_dropout"]),
        item["target_suffixes"],
    )
    encoder.config.use_cache = False
    if config["training"].get("gradient_checkpointing"):
        encoder.gradient_checkpointing_enable()
    model = BudgetAwareScorer(encoder, tokenizer, hidden_size, output_mode=target_kind)
    model.head.to(dtype=torch.bfloat16)
    assert_trainable_scope(model.encoder, model.head)
    lora_parameters = [parameter for parameter in model.encoder.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW([
        {"params": lora_parameters, "lr": float(config["training"]["lora_learning_rate"])},
        {"params": model.head.parameters(), "lr": float(config["training"]["head_learning_rate"])},
    ])
    accumulation = int(config["training"]["effective_batch"])
    epochs = int(config["training"]["epochs"])
    optimizer_steps = math.ceil(len(train) / accumulation) * epochs
    warmup_steps = int(optimizer_steps * float(config["training"]["warmup_fraction"]))
    from transformers import get_linear_schedule_with_warmup
    scheduler = get_linear_schedule_with_warmup(optimizer, warmup_steps, optimizer_steps)
    started = time.perf_counter()
    history = []
    best_dev = math.inf
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    for epoch in range(epochs):
        random.Random(seed + epoch).shuffle(train)
        model.encoder.train()
        model.head.train()
        optimizer.zero_grad(set_to_none=True)
        running = 0.0
        for index, example in enumerate(train, 1):
            prediction, _ = model.forward_tensors(example.public_state, [example.action])
            target = torch.tensor([example.target], dtype=prediction.dtype, device=prediction.device)
            if target_kind == "success":
                loss = functional.binary_cross_entropy(prediction, target)
            else:
                scale = max(example.lambda_value, 1.0)
                loss = functional.mse_loss(prediction / scale, target / scale)
            (loss / accumulation).backward()
            running += float(loss.detach().cpu())
            if index % accumulation == 0 or index == len(train):
                torch.nn.utils.clip_grad_norm_(list(model.parameters()), float(config["training"]["gradient_clip"]))
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)
        dev_loss = _mean_loss(model, dev, target_kind)
        history.append({"epoch": epoch + 1, "train_loss": running / len(train), "dev_loss": dev_loss})
        if dev_loss < best_dev:
            best_dev = dev_loss
            model.encoder.save_pretrained(output / "adapter")
            torch.save(model.head.state_dict(), output / "head.pt")
    (output / "training_manifest.json").write_text(json.dumps({
        "status": "complete",
        "target": target_kind,
        "seed": seed,
        "train_examples": len(train),
        "dev_examples": len(dev),
        "best_dev_loss": best_dev,
        "history": history,
        "optimizer_steps": optimizer_steps,
        "warmup_steps": warmup_steps,
        "base_repo_id": item["repo_id"],
        "base_revision": item["revision"],
        "hidden_size": hidden_size,
        "text_lora_targets": targets,
        "finite_label_coverage": len(train) if target_kind == "distance" else None,
        "elapsed_seconds": time.perf_counter() - started,
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return json.loads((output / "training_manifest.json").read_text(encoding="utf-8"))
