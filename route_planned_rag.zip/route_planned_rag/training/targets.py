from __future__ import annotations

import heapq
from collections import defaultdict
from typing import Iterable


def aggregate_cost_target(observations: Iterable[tuple[int, bool]], lambda_value: float) -> float:
    values = [calls + lambda_value * (1.0 - float(success)) for calls, success in observations]
    if not values:
        raise ValueError("cannot aggregate zero completed rollouts")
    return sum(values) / len(values)


def reverse_dijkstra_distances(
    transitions: Iterable[tuple[str, str, int]], successful_stop_states: Iterable[str]
) -> dict[str, int]:
    reverse: dict[str, list[tuple[str, int]]] = defaultdict(list)
    for source, target, cost in transitions:
        if cost < 0:
            raise ValueError("transition costs must be non-negative")
        reverse[target].append((source, cost))
    distances: dict[str, int] = {}
    queue: list[tuple[int, str]] = []
    for state in successful_stop_states:
        distances[state] = 0
        heapq.heappush(queue, (0, state))
    while queue:
        distance, state = heapq.heappop(queue)
        if distances[state] != distance:
            continue
        for predecessor, cost in reverse[state]:
            candidate = distance + cost
            if candidate < distances.get(predecessor, 2**63 - 1):
                distances[predecessor] = candidate
                heapq.heappush(queue, (candidate, predecessor))
    return distances

