from __future__ import annotations

import json
from pathlib import Path

from route_planned_rag.models.loaders import load_mistral3_generation
from route_planned_rag.models.scorer import BudgetAwareScorer


def load_trained_scorer(config: dict, checkpoint_dir: str | Path, target_kind: str):
    import torch
    from peft import PeftModel

    checkpoint = Path(checkpoint_dir)
    manifest = json.loads((checkpoint / "training_manifest.json").read_text(encoding="utf-8"))
    if manifest["target"] != target_kind:
        raise RuntimeError(f"checkpoint target is {manifest['target']}, requested {target_kind}")
    item = config["models"]["scorer"]
    if manifest["base_repo_id"] != item["repo_id"] or manifest["base_revision"] != item["revision"]:
        raise RuntimeError("scorer checkpoint base lineage does not match the active config")
    tokenizer, base = load_mistral3_generation(
        item,
        cache_dir=Path(config["project"]["cache_root"]) / "huggingface",
    )
    encoder = PeftModel.from_pretrained(base, checkpoint / "adapter", is_trainable=False).eval()
    model = BudgetAwareScorer(encoder, tokenizer, int(manifest["hidden_size"]), output_mode=target_kind)
    model.head.load_state_dict(torch.load(checkpoint / "head.pt", map_location=next(encoder.parameters()).device))
    model.head.to(dtype=torch.bfloat16).eval()
    model.scorer_id = f"{target_kind}-global:{checkpoint.name}"
    return model
