from __future__ import annotations

import copy
import dataclasses
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable, Union


class CompletionStatus(str, Enum):
    COMPLETE = "complete"
    INCOMPLETE_INFRASTRUCTURE = "incomplete_infrastructure"
    UNEXPLORED = "unexplored"


class BindingStatus(str, Enum):
    UNRESOLVED = "unresolved"
    TENTATIVE = "tentative"
    EVIDENCE_BACKED = "evidence_backed"
    CONFLICTING = "conflicting"


@dataclass(frozen=True)
class PublicSample:
    question_id: str
    question: str
    split_role: str
    corpus_id: str
    public_context: tuple[dict[str, Any], ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_actor_dict(self) -> dict[str, Any]:
        forbidden = {"answer", "reference_answer", "gold", "gold_support", "supporting_facts", "terminal_success"}
        payload = dataclasses.asdict(self)
        leaked = forbidden.intersection(_recursive_keys(payload))
        if leaked:
            raise ValueError(f"actor-facing sample contains private keys: {sorted(leaked)}")
        return payload


@dataclass(frozen=True)
class PrivateReference:
    question_id: str
    reference_answers: tuple[str, ...]
    support_ids: tuple[str, ...] = ()
    supporting_facts: tuple[tuple[str, int], ...] = ()
    reasoning_triples: tuple[tuple[str, str, str], ...] = ()


@dataclass(frozen=True)
class InformationNode:
    id: str
    query_template: str
    input_variables: tuple[str, ...]
    output_variable: str
    depends_on: tuple[str, ...] = ()


@dataclass(frozen=True)
class InformationNeedGraph:
    nodes: tuple[InformationNode, ...]
    answer_dependencies: tuple[str, ...]

    def validate(self, maximum_nodes: int = 16) -> None:
        if not self.nodes:
            raise ValueError("graph needs at least one information node")
        if len(self.nodes) > maximum_nodes:
            raise ValueError(f"graph exceeds {maximum_nodes} information nodes")
        by_id = {node.id: node for node in self.nodes}
        if len(by_id) != len(self.nodes):
            raise ValueError("information node ids must be unique")
        for node in self.nodes:
            unknown = set(node.depends_on) - set(by_id)
            if unknown:
                raise ValueError(f"node {node.id} has unknown dependencies {sorted(unknown)}")
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(node_id: str) -> None:
            if node_id in visiting:
                raise ValueError("information graph must be acyclic")
            if node_id in visited:
                return
            visiting.add(node_id)
            for parent in by_id[node_id].depends_on:
                visit(parent)
            visiting.remove(node_id)
            visited.add(node_id)

        for node_id in by_id:
            visit(node_id)

    def topological_ids(self) -> tuple[str, ...]:
        self.validate()
        by_id = {node.id: node for node in self.nodes}
        remaining = set(by_id)
        result: list[str] = []
        while remaining:
            ready = sorted(n for n in remaining if set(by_id[n].depends_on).issubset(result))
            if not ready:
                raise ValueError("cyclic graph")
            result.extend(ready)
            remaining.difference_update(ready)
        return tuple(result)

    def descendants(self, node_id: str) -> set[str]:
        children: dict[str, set[str]] = {node.id: set() for node in self.nodes}
        for node in self.nodes:
            for parent in node.depends_on:
                children[parent].add(node.id)
        found: set[str] = set()
        stack = list(children.get(node_id, ()))
        while stack:
            current = stack.pop()
            if current not in found:
                found.add(current)
                stack.extend(children[current])
        return found


@dataclass(frozen=True)
class ObservedPassage:
    chunk_id: str
    doc_id: str
    text: str
    char_start: int
    char_end: int
    token_start: int | None = None
    token_end: int | None = None
    sentence_ids: tuple[int, ...] = ()
    retrieval_score: float | None = None
    reranker_score: float | None = None

    def validate(self) -> None:
        if self.char_start < 0 or self.char_end < self.char_start:
            raise ValueError("invalid passage offsets")
        if self.token_start is not None and self.token_end is not None and self.token_end < self.token_start:
            raise ValueError("invalid token offsets")


@dataclass(frozen=True)
class EvidenceCitation:
    doc_id: str
    span_id: str


@dataclass(frozen=True)
class BindingUpdate:
    variable: str
    value: str
    status: BindingStatus
    evidence_chunk_ids: tuple[str, ...]
    invalidates: tuple[str, ...] = ()


@dataclass
class BindingRecord:
    value: str
    status: BindingStatus
    evidence_chunk_ids: tuple[str, ...]
    producing_node_id: str


@dataclass(frozen=True)
class SearchCandidate:
    action_id: str
    route_id: str
    node_id: str
    query: str
    intent: str
    kind: str = "SEARCH"


@dataclass(frozen=True)
class StopCandidate:
    action_id: str
    route_id: str
    kind: str = "STOP"


Action = Union[SearchCandidate, StopCandidate]


@dataclass
class RouteState:
    route_id: str
    bindings: dict[str, BindingRecord] = field(default_factory=dict)
    observed_passages: list[ObservedPassage] = field(default_factory=list)
    attempted_queries: list[str] = field(default_factory=list)
    resolved_node_ids: set[str] = field(default_factory=set)
    conflicts: int = 0

    def clone(self, route_id: str) -> "RouteState":
        cloned = copy.deepcopy(self)
        cloned.route_id = route_id
        return cloned

    def apply_binding(self, graph: InformationNeedGraph, node_id: str, update: BindingUpdate) -> None:
        prior = self.bindings.get(update.variable)
        if prior is not None and prior.value != update.value:
            self.conflicts += 1
            self._invalidate_descendants(graph, prior.producing_node_id)
        self.bindings[update.variable] = BindingRecord(
            value=update.value,
            status=update.status,
            evidence_chunk_ids=update.evidence_chunk_ids,
            producing_node_id=node_id,
        )
        self.resolved_node_ids.add(node_id)
        for explicit_node in update.invalidates:
            self._invalidate_node(graph, explicit_node)

    def _invalidate_node(self, graph: InformationNeedGraph, node_id: str) -> None:
        targets = {node_id} | graph.descendants(node_id)
        self.resolved_node_ids.difference_update(targets)
        self.bindings = {
            name: record
            for name, record in self.bindings.items()
            if record.producing_node_id not in targets
        }

    def _invalidate_descendants(self, graph: InformationNeedGraph, node_id: str) -> None:
        for child in graph.descendants(node_id):
            self._invalidate_node(graph, child)

    def evidence_backed_count(self) -> int:
        return sum(record.status == BindingStatus.EVIDENCE_BACKED for record in self.bindings.values())

    def compact_summary(self, evidence_chars: int = 512) -> dict[str, Any]:
        return {
            "route_id": self.route_id,
            "bindings": {
                name: {"value": record.value, "status": record.status.value}
                for name, record in sorted(self.bindings.items())
            },
            "resolved_node_ids": sorted(self.resolved_node_ids),
            "conflicts": self.conflicts,
            "evidence": [
                {"chunk_id": p.chunk_id, "doc_id": p.doc_id, "text": p.text[:evidence_chars]}
                for p in self.observed_passages
            ],
        }


@dataclass(frozen=True)
class AnswerWithCitations:
    answer: str
    citations: tuple[EvidenceCitation, ...]
    abstain: bool = False
    reasoning_triples: tuple[tuple[str, str, str], ...] = ()


def _recursive_keys(value: Any) -> set[str]:
    found: set[str] = set()
    if isinstance(value, dict):
        for key, child in value.items():
            found.add(str(key))
            found.update(_recursive_keys(child))
    elif isinstance(value, (list, tuple)):
        for child in value:
            found.update(_recursive_keys(child))
    return found


def ensure_delivered_citations(answer: AnswerWithCitations, passages: Iterable[ObservedPassage]) -> None:
    delivered = {passage.chunk_id for passage in passages}
    unknown = {citation.span_id for citation in answer.citations} - delivered
    if unknown:
        raise ValueError(f"answer cites undelivered spans: {sorted(unknown)}")
