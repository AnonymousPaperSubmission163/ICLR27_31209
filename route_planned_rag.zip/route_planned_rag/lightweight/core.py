from __future__ import annotations
import hashlib
import json
import re
from datetime import datetime
from decimal import Decimal,InvalidOperation
from typing import Literal
from pydantic import Field,model_validator
from route_planned_rag.prototype.schemas import Strict,Atom,Term,RuleSpec
from route_planned_rag.prototype.logic import matches,substitute,key,ground,opposite,digest

Type=Literal['person','organization','place','country','date','number','event','work','entity']
class Need(Strict):
    anchor: str | None
    input_step: int | None
    relation: str
    subject_type: Type
    value_type: Type
    time: str | None

class Template(Strict):
    kind: Literal['chain','intersection','same_country','earlier','unsupported']
    needs: list[Need] = Field(max_length=4)
    explanation: str
    @model_validator(mode='after')
    def structure(self):
        if self.kind=='unsupported':
            if self.needs:raise ValueError('unsupported templates must have no executable needs')
            return self
        if not self.needs:raise ValueError('supported template needs at least one relation')
        if self.kind in ['same_country','earlier'] and len(self.needs)!=2:raise ValueError('comparison requires exactly two needs')
        if self.kind=='intersection' and len(self.needs)<2:raise ValueError('intersection requires two or more conditions')
        for i,n in enumerate(self.needs):
            if n.time is not None and not re.fullmatch(r'\d{4}(?:-\d{2}-\d{2})?',n.time):raise ValueError('ambiguous time unsupported; use explicit year or ISO date')
            if n.input_step is None:
                if not n.anchor or not n.anchor.strip():raise ValueError('root need requires explicit named anchor')
            elif self.kind!='chain' or not 0<=n.input_step<i or n.anchor is not None:
                raise ValueError('chain references must point to an earlier need; derived inputs cannot have invented anchors')
            if n.input_step is not None and n.subject_type!=self.needs[n.input_step].value_type:raise ValueError('connected variable types differ')
        if self.kind=='chain':
            if self.needs[0].input_step is not None or any(n.input_step!=i-1 for i,n in enumerate(self.needs[1:],1)):
                raise ValueError('first version supports a connected linear relation chain')
        if self.kind=='intersection' and len({n.value_type for n in self.needs})!=1:raise ValueError('intersection candidates must share a type')
        if self.kind=='same_country' and any(n.value_type!='country' for n in self.needs):raise ValueError('same_country requires country values')
        if self.kind=='earlier' and any(n.value_type!='date' for n in self.needs):raise ValueError('earlier requires explicit dates')
        return self

class FactRow(Strict):
    step: int = Field(ge=0,le=3)
    subject: str
    value: str
    time: str | None
    evidence_id: str
    quote: str
    negated: bool

class Reading(Strict):
    facts: list[FactRow] = Field(max_length=24)
    uncertainty: list[str]
    suggested_query: str | None


def norm(s):return ' '.join(s.casefold().split())
def entity(text,kind):return Term(kind='constant',name=kind+'_'+hashlib.sha256(norm(text).encode()).hexdigest()[:16],entity_type=kind)
def variable(name,kind):return Term(kind='variable',name=name,entity_type=kind)
def atom(predicate,args,negated=False):return Atom(predicate=predicate,arguments=args,negated=negated)

def compile_template(plan,question):
    """Only these rule templates are allowed; model cannot emit rules or Prover9 text."""
    if plan.kind=='unsupported':return [],None
    for n in plan.needs:
        if n.anchor and norm(n.anchor) not in norm(question):raise ValueError('named anchor must appear verbatim in original question: '+n.anchor)
        if n.time and n.time not in question:raise ValueError('time scope is not explicit in question')
    patterns=[]
    for i,n in enumerate(plan.needs):
        subject=entity(n.anchor,n.subject_type) if n.anchor else variable('v'+str(n.input_step),n.subject_type)
        value=variable('candidate' if plan.kind=='intersection' else 'v'+str(i),n.value_type)
        args=[subject,value]
        if n.time:args.append(entity(n.time,'date'))
        # The relation description and declared types are part of predicate identity.
        predicate='rel_'+digest([norm(n.relation),n.subject_type,n.value_type,n.time is not None])
        patterns.append(atom(predicate,args))
    if plan.kind in ['chain','intersection']:
        result=patterns[-1].arguments[1]
        rule=RuleSpec(id='template_goal',body=patterns,head=atom('answer',[result]),origin='builtin',source_refs=[],
            explanation='Versioned '+plan.kind+' template: all original relation slots are required, with shared variables preserved.')
    else:
        rule=None
    return patterns,rule

class Facts:
    def __init__(self,plan,patterns):
        self.plan=plan;self.patterns=patterns
        self.evidence={};self.candidates=[];self.accepted={};self.entities={};self.conflicts=[]
        for n in plan.needs:
            if n.anchor:self.entities[entity(n.anchor,n.subject_type).name]=n.anchor
    def accepted_atoms(self):return [(i,Atom.model_validate(f['atom'])) for i,f in self.accepted.items() if f['status']=='accepted']
    def rows(self,patterns=None):return matches(self.patterns if patterns is None else patterns,[a for _,a in self.accepted_atoms()])
    def admit(self,reading,call_id):
        added=[]
        for row in reading.facts:
            cid='C'+str(len(self.candidates)+1)
            record=dict(candidate_id=cid,**row.model_dump(),extraction_call_id=call_id,status='quarantined',checks=[],semantic_review='pending_manual_audit')
            self.candidates.append(record)
            if row.step>=len(self.plan.needs):record['checks'].append('unknown step');continue
            n=self.plan.needs[row.step];e=self.evidence.get(row.evidence_id)
            if row.time!=n.time:record['checks'].append('fact time differs from required scope or is not safely unscoped');continue
            if not e or not row.quote or row.quote not in e['original_text']:record['checks'].append('quote is not an exact observed span');continue
            if not row.subject.strip() or not row.value.strip() or norm(row.value) in ['unknown','none','null','n/a']:record['checks'].append('missing concrete values');continue
            if n.anchor and norm(row.subject)!=norm(n.anchor):record['checks'].append('subject identity differs from named question anchor');continue
            observed=norm(e['source_metadata'].get('title','')+' '+row.quote)
            if norm(row.subject) not in observed or norm(row.value) not in observed:
                record['checks'].append('subject/value surface is not present in quote or document title');continue
            if n.time and n.time not in row.quote:record['checks'].append('explicit time is not present in cited span');continue
            subject=entity(row.subject,n.subject_type);value=entity(row.value,n.value_type)
            args=[subject,value]
            if n.time:args.append(entity(n.time,'date'))
            a=atom(self.patterns[row.step].predicate,args,row.negated)
            fid='F'+digest(a)
            self.entities[subject.name]=row.subject;self.entities[value.name]=row.value
            record.update(status='program_checked',checks=['quote_exists','typed_template_parameters','named_anchor_consistent','subject_and_value_surface_present','explicit_time_checked'],atom=a.model_dump())
            if fid not in self.accepted:
                self.accepted[fid]=dict(fact_id=fid,atom=a.model_dump(),candidate_ids=[cid],evidence_ids=[row.evidence_id],
                    quote=row.quote,status='accepted',scope={'time':n.time},semantic_review='pending_manual_audit',extraction_call_id=call_id)
                added.append(fid)
            else:
                self.accepted[fid]['candidate_ids'].append(cid)
                if row.evidence_id not in self.accepted[fid]['evidence_ids']:self.accepted[fid]['evidence_ids'].append(row.evidence_id)
        # Multiple positive values are multiple bindings, not a conflict. Only explicit same-ground opposites conflict.
        known={key(a):i for i,a in self.accepted_atoms()}
        for i,a in list(self.accepted_atoms()):
            other=known.get(key(opposite(a)))
            if other:
                self.accepted[i]['status']=self.accepted[other]['status']='conflicted'
                pair=sorted([i,other])
                if pair not in self.conflicts:self.conflicts.append(pair)
        return [i for i in added if self.accepted[i]['status']=='accepted']
    def withdraw(self,fid,reason):
        self.accepted[fid]['status']='withdrawn';self.accepted[fid]['withdraw_reason']=reason
    def snapshot(self):
        return dict(evidence=self.evidence,candidates=self.candidates,accepted_facts=self.accepted,entities=self.entities,
            binding_rows=[{k:v.model_dump() for k,v in row.items()} for row in self.rows()],conflicts=self.conflicts)


def explicit_date(s):
    for fmt,precision in [('%Y-%m-%d','day'),('%B %d, %Y','day'),('%d %B %Y','day'),('%Y','year')]:
        try:return datetime.strptime(s.strip(),fmt),precision
        except ValueError:pass
    return None
