"""Bounded experiment: deterministic missing-premise queries and one structured reader.
Program checks are not semantic verification. All premises remain auditable.
"""
import time
from pathlib import Path
from .core import *
from route_planned_rag.prototype.prover import write_json

TEMPLATE_PROMPT='''Fill a generic question template using ONLY the question, never its answer. Supported: connected relation chain (up to four steps), intersection (each named condition anchor relates to the SAME candidate), same_country (two named subjects, country values), earlier (two named events, explicit date values). Root anchors must be verbatim substrings of the question. A chain starts with anchor, input_step null; later steps have anchor null, input_step previous step index. Use short precise relation descriptions, consistent types, preserve all restrictions. time is null unless a year/date is explicitly requested. Unsupported questions must have kind unsupported and empty needs. Do not force a template that loses a condition.'''
READ_PROMPT='''Extract only facts explicitly supported by the supplied passages for the listed relation slots. Each fact is ONE row containing step, subject, value, time, evidence_id, exact contiguous quote, negated. time must state the fact temporal restriction as YYYY or ISO date, null only for unqualified facts. Copy subject/value as written in evidence or its title. For a root slot the subject must exactly match its question anchor. For derived slots retain the actual subject entity, never splice two entities. Include facts for OTHER slots too if explicitly supported. Keep negation and temporal restrictions; no implicit dates, ambiguous pronouns or remembered answers. Do not supply bindings separately. Empty facts and uncertainty are correct when support is absent. suggested_query may contain ONE short natural language rewrite for the requested subject/relation if retrieval failed; otherwise null. Never replace the requested subject with a similarly named entity.'''

class Engine:
    def __init__(self,question,plan,client,retriever,prover,directory,automatic_proof=True,max_retrievals=8,rerank=False):
        self.rerank=rerank
        self.question=question;self.plan=plan;self.client=client;self.retriever=retriever;self.prover=prover
        self.patterns,self.rule=compile_template(plan,question);self.facts=Facts(plan,self.patterns)
        self.directory=Path(directory);self.automatic=automatic_proof;self.limit=max_retrievals
        self.events=[];self.attempts={};self.queries=set();self.rewrites={};self.visited=set();self.cache={};self.proofs=[]
        self.retrievals=0;self.skipped=set();self.embedding_usage=[];self.started=time.perf_counter()
    def event(self,kind,**data):self.events.append(dict(kind=kind,**data))
    def verify(self,goals,rules=()):
        # Select only predicates that can affect this conclusion. Cache all outcomes,
        # including timeouts: a failed identical input is never retried in this run.
        predicates={a.predicate for a in goals}
        for _,r in rules:predicates.update(a.predicate for a in r.body)
        relevant=[(i,a) for i,a in self.facts.accepted_atoms() if a.predicate in predicates]
        signature=digest([[(i,a.model_dump()) for i,a in relevant],[(i,r.model_dump()) for i,r in rules],[a.model_dump() for a in goals]])
        if signature not in self.cache:
            p=self.prover.prove(relevant,list(rules),goals)
            self.cache[signature]=p;self.proofs.append(p)
            self.event('proof',proof_id=p['proof_id'],result=p['result'])
        p=self.cache[signature]
        available={i for i,_ in self.facts.accepted_atoms()}
        p['valid']=set(p['fact_ids'])<=available
        return p if p['valid'] and p['result']=='proved' and p['source_mapping_status']=='complete' else None
    def actions(self):
        result=[]
        for step,(need,pattern) in enumerate(zip(self.plan.needs,self.patterns)):
            inputs=self.facts.rows(self.patterns[:step]) if need.input_step is not None else [{}]
            for row in inputs:
                bound=substitute(pattern,row);subject=bound.arguments[0]
                if subject.kind!='constant':continue
                action_id=digest([step,subject.model_dump(),need.time])
                if action_id in self.visited:continue
                existing=matches([bound],[a for _,a in self.facts.accepted_atoms()])
                if self.automatic and existing:
                    proofs=[self.verify([substitute(bound,b)]) for b in existing]
                    if any(proofs):
                        if action_id not in self.skipped:
                            self.skipped.add(action_id);self.event('retrieval_skipped_by_proof',step=step,action_id=action_id)
                        continue
                if self.attempts.get(action_id,0)>=2:continue
                display=self.facts.entities.get(subject.name)
                if not display:continue
                default=' '.join(x for x in [display,need.relation,need.time] if x)
                query=self.rewrites.get(action_id,default) if self.attempts.get(action_id,0) else default
                if norm(query) in self.queries:
                    self.attempts[action_id]=2;continue
                result.append(dict(step=step,action_id=action_id,query=query,subject=display))
        return result
    def answers(self):
        answers=[]
        for row in self.facts.rows():
            if self.rule:
                goal=substitute(self.rule.head,row);proof=self.verify([goal],[(self.rule.id,self.rule)])
                value=self.facts.entities[goal.arguments[0].name]
                computation=None
            else:
                goals=[substitute(a,row) for a in self.patterns]
                values=[self.facts.entities[a.arguments[1].name] for a in goals]
                if self.plan.kind=='same_country':
                    # Distinct strings might be aliases. Only equality is conclusive here.
                    if norm(values[0])!=norm(values[1]):continue
                    value='yes';computation=dict(operation='normalized_country_equality',values=values)
                else:
                    dates=[explicit_date(v) for v in values]
                    if not all(dates) or dates[0][1]!=dates[1][1] or dates[0][0]==dates[1][0]:continue
                    value=self.plan.needs[0 if dates[0][0]<dates[1][0] else 1].anchor
                    computation=dict(operation='explicit_date_order',values=values,precision=dates[0][1])
                proof=self.verify(goals)
            if proof:answers.append(dict(value=value,proof_id=proof['proof_id'],binding={k:v.model_dump() for k,v in row.items()},computation=computation))
        return answers
    def run(self):
        status='unsupported' if self.plan.kind=='unsupported' else 'unknown';answers=[];error=None
        try:
            if status!='unsupported':
                while True:
                    actions=self.actions()
                    # Baseline must visit executable slots; guided may discharge them.
                    if self.automatic or not actions:
                        answers=self.answers()
                        if answers:status='proved_with_program_checked_premises';break
                    if not actions or self.retrievals>=self.limit:break
                    action=actions[0];aid=action['action_id'];self.attempts[aid]=self.attempts.get(aid,0)+1
                    self.queries.add(norm(action['query']));self.event('retrieval_started',**action)
                    evidence,usage=self.retriever(action['query'],20 if self.rerank else 5);self.retrievals+=1;self.embedding_usage.append(usage)
                    if self.rerank:
                        from route_planned_rag.prototype.schemas import ranking_schema
                        ranked=[]
                        for start in range(0,len(evidence),5):
                            batch=evidence[start:start+5]
                            scores=self.client.ask('rerank',ranking_schema(len(batch)),
                                'Score each passage for the requested information need in input order, relevance 0 to 1. Flag possible contradictory evidence.',
                                {'query':action['query'],'passages':batch},size='small',max_tokens=512)
                            ranked.extend((score.score,e) for score,e in zip(scores.items,batch))
                        evidence=[e for _,e in sorted(ranked,key=lambda pair:-pair[0])[:5]]
                    for e in evidence:self.facts.evidence[e['evidence_id']]=e
                    reading=self.client.ask('structured_reader',Reading,READ_PROMPT,
                        {'question':self.question,'slots':[n.model_dump() for n in self.plan.needs],
                         'requested':action,'evidence':evidence},max_tokens=2048)
                    added=self.facts.admit(reading,self.client.calls[-1]['call_id'])
                    # A successful acquisition is revisited only if its facts are later withdrawn.
                    need=self.patterns[action['step']]
                    subject=entity(action['subject'],self.plan.needs[action['step']].subject_type)
                    concrete=need.model_copy(update={'arguments':[subject]+need.arguments[1:]})
                    satisfied=bool(matches([concrete],[a for _,a in self.facts.accepted_atoms()]))
                    if satisfied:self.visited.add(aid)
                    else:
                        rewrite=reading.suggested_query
                        if rewrite and norm(action['subject']) in norm(rewrite) and norm(rewrite) not in self.queries:
                            self.rewrites[aid]=rewrite
                        else:self.attempts[aid]=2
                    self.event('facts_processed',action_id=aid,added=added,uncertainty=reading.uncertainty,satisfied=satisfied)
        except Exception as exc:
            status='execution_error';error=repr(exc)
        available={i for i,_ in self.facts.accepted_atoms()}
        for proof in self.proofs:proof['valid']=set(proof['fact_ids'])<=available
        result=dict(question=self.question,template=self.plan.model_dump(),automatic_proof=self.automatic,status=status,
            answers=answers,error=error,retrieval_calls=self.retrievals,proof_calls=self.prover.calls,
            skipped_retrieval_actions=len(self.skipped),seconds=time.perf_counter()-self.started,
            model_calls=len(self.client.calls),input_tokens=sum(c.get('input_tokens') or 0 for c in self.client.calls),
            output_tokens=sum(c.get('output_tokens') or 0 for c in self.client.calls),embedding_usage=self.embedding_usage,
            semantics='program_checked_only; human premise/template audit pending')
        write_json(self.directory/'result.json',result);write_json(self.directory/'facts.json',self.facts.snapshot())
        write_json(self.directory/'events.json',self.events);write_json(self.directory/'model_calls.json',self.client.calls)
        write_json(self.directory/'proofs.json',self.proofs)
        used={i for p in self.proofs if p['valid'] and p['result']=='proved' for i in p['fact_ids']}
        write_json(self.directory/'audit_packet.json',dict(question=self.question,template=self.plan.model_dump(),
            premises=[self.facts.accepted[i] for i in sorted(used)],evidence=self.facts.evidence,human_review='pending',
            automatic_result=result,corrections=[]))
        return result
