from route_planned_rag.cli import main

raise SystemExit(main())

