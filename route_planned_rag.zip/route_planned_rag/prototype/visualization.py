"""Self-contained offline SVG graph and snapshot replay; no external assets."""
import html
import json
from pathlib import Path

def layout(graph):
    if not graph: return {},[]
    levels={};deps={d['target_node_id']:d['prerequisite_options'] for d in graph['dependencies']}
    def level(n,seen=None):
        if n in levels:return levels[n]
        seen=set(seen or ())
        if n in seen:return 0
        levels[n]=1+max([level(p,seen|{n}) for option in deps.get(n,[]) for p in option] or [-1]);return levels[n]
    groups={};positions={}
    for n in graph['nodes']:groups.setdefault(level(n['id']),[]).append(n['id'])
    for col,ids in groups.items():
        for row,i in enumerate(ids):positions[i]=[110+col*260,85+row*145]
    producers={}
    for n in graph['nodes']:
        for a in n['query_atoms']:producers.setdefault(a['predicate'],[]).append(n['id'])
    edges=[]
    for d in graph['dependencies']:
        for oi,option in enumerate(d['prerequisite_options']):
            for p in option:edges.append([p,d['target_node_id'],'dependency',f'option {oi+1} AND'])
    right=max([p[0] for p in positions.values()] or [0])+250
    for i,r in enumerate(graph['rules']):
        rid='rule:'+r['id'];positions[rid]=[right,80+i*110]
        for a in r['body']:
            for source in producers.get(a['predicate'],[]):edges.append([source,rid,'rule','AND'])
        target='goal:'+r['head']['predicate']
        positions.setdefault(target,[right+240,80+len([x for x in positions if x.startswith('goal:')])*110])
        edges.append([rid,target,'rule','implies / OR alternatives'])
    return positions,edges

def static_svg(snapshot):
    state=snapshot.get('state') or {};graph=state.get('graph');positions,edges=layout(graph)
    width=max([p[0] for p in positions.values()] or [200])+140;height=max([p[1] for p in positions.values()] or [100])+100
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" fill="#f7f8fc"/>']
    for a,b,kind,label in edges:
        x,y=positions[a];xx,yy=positions[b]
        parts.append(f'<line x1="{x}" y1="{y}" x2="{xx}" y2="{yy}" stroke="{ "#9aa6bb" if kind=="dependency" else "#c3942d"}" stroke-width="2"/>')
    for i,(x,y) in positions.items():
        parts.append(f'<rect x="{x-85}" y="{y-25}" width="170" height="50" rx="9" fill="#003262"/><text x="{x}" y="{y+5}" text-anchor="middle" fill="white" font-family="sans-serif" font-size="13">{html.escape(i)}</text>')
    parts.append('</svg>');return ''.join(parts)

def visualize(directory):
    directory=Path(directory);cases=[]
    for path in sorted((directory/'cases').glob('*/result.json')):
        snaps=[json.loads(p.read_text()) for p in sorted((path.parent/'states').glob('*.json'))]
        for s in snaps:
            positions,edges=layout((s.get('state') or {}).get('graph'));s['positions']=positions;s['edges']=edges
        result=json.loads(path.read_text());cases.append({'id':path.parent.name,'result':result,'snapshots':snaps})
        valid=[s for s in snaps if s.get('state')]
        if valid:
            (path.parent/'initial.svg').write_text(static_svg(valid[0]));(path.parent/'final.svg').write_text(static_svg(valid[-1]))
    summary=json.loads((directory/'summary.json').read_text()) if (directory/'summary.json').exists() else {}
    payload=json.dumps({'cases':cases,'summary':summary},ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    template=Path(__file__).with_name('dashboard.html').read_text()
    (directory/'dashboard.html').write_text(template.replace('__PAYLOAD__',payload))
    # Optional raster export from actual graph artifacts, no fabricated successful cases.
    exports=[]
    try:
        import cairosvg
        for status in [True,False]:
            example=next((c for c in cases if bool(c['result']['answer_supported'])==status and (directory/'cases'/c['id']/'final.svg').exists()),None)
            if example:
                source=directory/'cases'/example['id']/'final.svg'
                cairosvg.svg2png(url=str(source),write_to=str(source.with_suffix('.png')))
                exports.append({'answer_supported':status,'file':str(source.with_suffix('.png'))})
    except (ImportError,OSError) as exc: exports.append({'png_export_blocked':str(exc)})
    (directory/'visualization_exports.json').write_text(json.dumps(exports,indent=2))
