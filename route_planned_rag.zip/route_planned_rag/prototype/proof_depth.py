"""Conservative native LADR proof DAG parser (just.c sb_write_just format).

Measures clause dependency edges, including normalization and refutation. This
is neither semantic hops nor a shortest-proof claim. Unknown formats fail closed.
"""
import re


def split_args(text):
    parts, start, level = [], 0, 0
    for i, char in enumerate(text):
        if char in '([':
            level += 1
        elif char in ')]':
            level -= 1
        elif char == ',' and level == 0:
            parts.append(text[start:i].strip())
            start = i + 1
        if level < 0:
            raise ValueError('unbalanced justification')
    if level:
        raise ValueError('unbalanced justification')
    return parts + [text[start:].strip()]


def parents(text):
    result = set()
    unary = {'deny', 'clausify', 'copy', 'propositional', 'new_symbol', 'back_rewrite', 'back_unit_del', 'factor', 'xx_res'}
    for part in split_args(text):
        if part in ('assumption', 'goal'):
            continue
        match = re.fullmatch(r'(\w+)\((.*)\)', part)
        if not match:
            raise ValueError('unsupported justification: ' + part)
        op, body = match.groups()
        args = split_args(body)
        if op in unary:
            ids = args[:1]
        elif op in ('resolve', 'hyper', 'ur'):
            # nucleus, then triples: nucleus literal, satellite ID, satellite literal
            if (len(args) - 1) % 3:
                raise ValueError('unsupported resolution arguments')
            ids = [args[0], *args[2::3]]
        elif op == 'unit_del':
            ids = args[1:2]
        elif op == 'expand_def':
            ids = args
        elif op in ('para', 'para_fx', 'para_ix', 'para_fx_ix'):
            ids = [args[0], args[2]]
        elif op == 'rewrite' and body.startswith('[') and body.endswith(']'):
            entries = split_args(body[1:-1])
            ids = []
            for entry in entries:
                item = re.fullmatch(r'(\d+)(?:\(\d+(?:,R)?\))?', entry)
                if not item:
                    raise ValueError('unsupported rewrite')
                ids.append(item[1])
        elif op in ('flip', 'xx', 'merge', 'eval'):
            ids = []  # literal positions, not clause IDs
        else:
            raise ValueError('unsupported justification: ' + op)
        if any(not re.fullmatch(r'\d+', value) for value in ids):
            raise ValueError('unsupported parent ID')
        result.update(map(int, ids))
    return sorted(result)


def proof_depth(text):
    level = re.search(r'% Level of proof is (\d+)\.', text)
    unknown = dict(status='unknown', formal_depth=None, steps=[],
                   reported_level=int(level[1]) if level else None,
                   definition='longest clause-parent path of returned proof; inputs=0; not semantic depth')
    try:
        steps = {}
        for line in text.splitlines():
            if not re.match(r'^\d+\s', line):
                continue
            match = re.fullmatch(r'(\d+)\s+(.*?)\s+\[(.*)\]\.\s*', line)
            if not match:
                raise ValueError('unparsed proof step')
            number, formula, justification = match.groups()
            number = int(number)
            if number in steps:
                raise ValueError('duplicate proof step')
            ps = parents(justification)
            if any(p not in steps for p in ps):
                raise ValueError('unknown or cyclic proof parent')
            steps[number] = dict(id=number, parents=ps, depth=1 + max(steps[p]['depth'] for p in ps) if ps else 0,
                                 contradiction=formula.split(' # ')[0].strip().removesuffix('.') == '$F')
        roots = [s for s in steps.values() if s['contradiction']]
        if not roots:
            raise ValueError('no parsed contradiction')
        return dict(unknown, status='complete', formal_depth=max(s['depth'] for s in roots), steps=list(steps.values()))
    except (ValueError, IndexError) as exc:
        return dict(unknown, reason=str(exc))
