"""Explicit sample/run/resume/visualize workflow; no gold in runtime public inputs."""
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import random
import shutil
import subprocess
import sys
import time
from pathlib import Path
import yaml
from .prover import write_json
from .schemas import GraphProposal,Event,RunResult

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def config(path):
    c=yaml.safe_load(Path(path).read_text())
    if c['train'] or c['sample_count']!=10 or c['allow_unsupported_final_answer']: raise ValueError('prototype contract changed')
    if c['retrieval_setting']!='distractor_context': raise ValueError('this runner requires declared context track')
    for k in ['max_information_nodes','beam_width','max_candidate_supports','max_steps_per_question','max_retrieval_calls_per_question','max_attempts_per_node_binding_version','max_graph_revisions','max_prover_calls_per_question']:
        if not isinstance(c[k],int) or c[k]<=0: raise ValueError('invalid budget '+k)
    return c

def sample(c):
    path=Path(c['sample_dir']);path.mkdir(parents=True,exist_ok=True)
    rows=json.loads(Path(c['data_path']).read_text())
    ids=sorted(r['_id'] for r in rows)
    selected=random.Random(c['seed']).sample(ids,c['sample_count'])
    manifest=dict(seed=c['seed'],sample_ids=selected,source_sha256=sha(c['data_path']),sampling='random.sample(sorted question IDs); no labels or predictions',retrieval_setting=c['retrieval_setting'])
    target=path/'sample_ids.json'
    if target.exists() and json.loads(target.read_text())!=manifest: raise ValueError('existing frozen sample differs')
    write_json(target,manifest)
    byid={r['_id']:r for r in rows}
    public=[{'question_id':i,'question':byid[i]['question'],'context':byid[i]['context']} for i in selected]
    write_json(path/'public.json',public)
    write_json(path/'gold.offline.json',{i:byid[i]['answer'] for i in selected})
    return manifest

def run(c,args):
    samplepath=Path(c['sample_dir'])
    if not (samplepath/'sample_ids.json').exists(): sample(c)
    public=json.loads((samplepath/'public.json').read_text())
    if not 1<=args.limit<=10: raise ValueError('limit must be 1..10')
    if not args.run_id or any(x in args.run_id for x in ['/','\\','..']): raise ValueError('unsafe run ID')
    output=Path(c['run_root'])/args.run_id/args.mode;output.mkdir(parents=True,exist_ok=True)
    sources={str(p):sha(p) for p in sorted((p for p in Path('route_planned_rag/prototype').iterdir() if p.suffix in ['.py','.html']))}
    contract=dict(config=c,mode=args.mode,sample_sha256=sha(samplepath/'public.json'),source_hashes=sources,
        model_config_sha256=sha(c['model_config']),prover_sha256=sha(c['prover_executable']) if Path(c['prover_executable']).exists() else None)
    manifest=output/'manifest.json'
    if manifest.exists():
        if not args.resume: raise ValueError('run exists; explicitly use --resume')
        if json.loads(manifest.read_text())!=contract: raise ValueError('resume configuration/code/data changed; use a new run ID')
    else:
        write_json(manifest,contract)
        write_json(output/'sample_ids.json',json.loads((samplepath/'sample_ids.json').read_text()))
        (output/'resolved_config.yaml').write_text(yaml.safe_dump(c))
        for f in sources:
            dest=output/'source_snapshot'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
    if args.mode!='llm_topological' and not Path(c['prover_executable']).is_file():
        write_json(output/'BLOCKED.json',{'reason':'Prover9 executable unavailable'});return
    pending=[r for r in public[:args.limit] if not (output/'cases'/r['question_id']/'result.json').exists()]
    if pending:
        import torch
        from route_planned_rag.logicgraph.runtime import load_models
        from .model import ModelClient
        from .retrieval import ContextRetriever
        from .engine import Engine
        torch.manual_seed(c['seed']);random.seed(c['seed'])
        mc=yaml.safe_load(Path(c['model_config']).read_text());mc['project']['root']=str(Path.cwd())
        started=time.perf_counter()
        actor,small,encoder=load_models(mc,with_encoder=True)
        env=dict(python=sys.version,platform=platform.platform(),job_id=os.getenv('SLURM_JOB_ID'),device=torch.cuda.get_device_name(),
            model_load_seconds=time.perf_counter()-started,models={k:mc['models'][k] for k in ['actor','scorer','retriever']},train=False,prover_version='LADR-2009-11A',prover_source_sha256=sha('vendor/prover9/LADR-2009-11A.tar.gz'),
            packages={p:importlib.metadata.version(p) for p in ['torch','transformers','pydantic','numpy']},
            generation={'temperature':0,'top_p':1,'seed':c['seed'],'structured_output_enforcement':'xgrammar_json_schema_with_local_semantic_validation','stop':'model EOS or recorded output limit'},
            encoder={'pooling':'last_token','normalization':'L2','metric':'inner_product','query_instruction':mc['models']['retriever']['query_instruction']})
        write_json(output/'environment.json',env)
        for row in pending:
            case=output/'cases'/row['question_id']
            if case.exists():
                # Keep interrupted traces in a sibling attempt, explicitly restart with same public input.
                old=case.with_name(case.name+'.interrupted-'+str(time.time_ns()));case.rename(old)
            print(json.dumps({'event':'question_start','question_id':row['question_id']}),flush=True)
            client=ModelClient(actor,small,c)
            retriever=ContextRetriever(row['context'],encoder)
            engine=Engine(client,retriever,c,case,args.mode)
            result=engine.run(row['question_id'],row['question'])
            write_json(case/'retrieval_preparation.json',retriever.index_usage)
            print(json.dumps({'event':'question_finish',**result}),flush=True)
    # Evaluation is a separate subprocess that loads gold only after execution is complete.
    subprocess.run([sys.executable,'-m','route_planned_rag.prototype.cli','evaluate','--config',args.config,'--run-dir',str(output)],check=True)
    from .visualization import visualize
    visualize(output)
    if args.limit==10: write_json(output/'COMPLETE.json',{'complete':len(list((output/'cases').glob('*/result.json')))==10,'scope':'10_question_development_prototype_not_benchmark'})

def evaluate(c,directory):
    from .evaluator import score
    output=Path(directory)
    gold=json.loads((Path(c['sample_dir'])/'gold.offline.json').read_text())
    ids=json.loads((output/'sample_ids.json').read_text())['sample_ids']
    results=[]
    for qid in ids:
        path=output/'cases'/qid/'result.json'
        if not path.exists(): continue
        r=json.loads(path.read_text());r['em'],r['f1']=score(r['final_answer'],gold[qid]);write_json(path,r);results.append(r)
    with (output/'results.jsonl').open('w') as f:
        for r in results: f.write(json.dumps(r,ensure_ascii=False)+'\n')
    total=len(ids)
    summary=dict(planned=total,completed=len(results),not_run=total-len(results),denominator=total,
        em=sum(r['em'] for r in results)/total,f1=sum(r['f1'] for r in results)/total,
        goal_proved=sum(r['goal_proved'] for r in results),abstained=sum(not r['final_answer'] for r in results),
        blocked=sum('blocked' in (r['failure_reason'] or '') or 'Error' in (r['failure_reason'] or '') for r in results),
        retrieval_setting=c['retrieval_setting'],scope='development_prototype_not_formal_benchmark',
        counters={k:sum(r['counters'].get(k,0) for r in results) for k in ['retrieval_calls','prover_calls','prover_cache_hits','llm_calls','llm_input_tokens','llm_output_tokens']})
    write_json(output/'summary.json',summary)
    lines=['# LogicRAG Prover9 prototype — actual run report','',json.dumps(summary,ensure_ascii=False,indent=2),'',
        '| Question | Answer | EM | F1 | Proved | Failure |','|---|---|---:|---:|---|---|']
    for r in results: lines.append('| '+' | '.join(str(r[k]).replace('|','/').replace('\n',' ') for k in ['question_id','final_answer','em','f1','goal_proved','failure_reason'])+' |')
    lines+=['','Frozen models; no training. All 10 fixed IDs remain in the aggregate denominator; unrun cases are explicitly counted.',
        'Semantic extraction/rule admission is model-reviewed and remains fallible; formal proof is relative to admitted premises.',
        'Real Prover9 input, output, proof labels and source mapping are in cases/*/proofs. No global consistency claim.',
        'Context retrieval is E5 over supplied distractor passages, not a fullwiki reproduction.',
        'dashboard.html embeds snapshots and scripts for offline replay; fixture tests are excluded from these statistics.']
    (output/'report.md').write_text('\n'.join(lines))

def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=['validate-config','sample','run','evaluate','visualize'])
    p.add_argument('--config',default='configs/prototype.yaml');p.add_argument('--count',type=int,default=10);p.add_argument('--seed',type=int,default=2027)
    p.add_argument('--mode',choices=['proof_guided','prover_topological','llm_topological'],default='proof_guided');p.add_argument('--limit',type=int,default=10)
    p.add_argument('--run-id',default='prototype_001');p.add_argument('--resume',action='store_true');p.add_argument('--run-dir')
    args=p.parse_args();c=config(args.config)
    if args.command=='validate-config':
        from . import schemas
        for name,cls in [(name,cls) for name,cls in vars(schemas).items() if isinstance(cls,type) and issubclass(cls,schemas.Strict) and cls is not schemas.Strict]: write_json(Path('schemas')/(name+'.prototype.schema.json'),cls.model_json_schema())
        print(json.dumps({'valid':True,'prover_available':Path(c['prover_executable']).is_file(),'data_available':Path(c['data_path']).exists()}))
    elif args.command=='sample':
        if args.count!=c['sample_count'] or args.seed!=c['seed']: raise ValueError('CLI sample settings differ from config')
        print(json.dumps(sample(c)))
    elif args.command=='run': run(c,args)
    elif args.command=='evaluate': evaluate(c,args.run_dir)
    else:
        from .visualization import visualize
        visualize(Path(args.run_dir))
if __name__=='__main__': main()
