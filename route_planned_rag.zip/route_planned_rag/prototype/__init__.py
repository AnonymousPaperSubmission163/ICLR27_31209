"""Versioned proof-guided prototype; legacy logicgraph remains unchanged."""
VERSION = 'logicrag-prototype-1'
