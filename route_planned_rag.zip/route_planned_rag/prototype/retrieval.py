"""E5 retrieval over allowed public context with immutable original text."""
from .logic import digest

class ContextRetriever:
    def __init__(self,contexts,encoder):
        import numpy as np
        self.encoder=encoder;self.evidence=[];self.index_usage={'input_tokens':0,'seconds':0.}
        tokenizer=encoder.tokenizer
        for title,sentences in contexts:
            text=''.join(sentences)
            # Tokenize to offsets; chunks retain exact original spans rather than decoded approximations.
            offsets=tokenizer(text,add_special_tokens=False,return_offsets_mapping=True)['offset_mapping']
            for start in range(0,len(offsets),448):
                end=min(start+512,len(offsets));lo=offsets[start][0];hi=offsets[end-1][1]
                original=text[lo:hi]
                eid='D'+digest([title,lo,hi,original])
                self.evidence.append(dict(evidence_id='E'+str(len(self.evidence)+1),document_id=digest(title),passage_id=eid,
                    original_text=original,source_metadata={'title':title,'char_start':lo,'char_end':hi,'retrieval_setting':'distractor_context'}))
                if end==len(offsets): break
        matrices=[]
        for i in range(0,len(self.evidence),4):
            batch=self.evidence[i:i+4]
            vec,usage=encoder.encode([x['source_metadata']['title']+'\n'+x['original_text'] for x in batch],is_query=False)
            matrices.append(vec);self.index_usage['input_tokens']+=usage.input_tokens;self.index_usage['seconds']+=usage.gpu_seconds
        self.vectors=np.concatenate(matrices) if matrices else np.empty((0,4096))
    def __call__(self,query,k):
        import numpy as np
        vector,usage=self.encoder.encode([query],is_query=True)
        scores=self.vectors@vector[0]
        ids=np.argsort(-scores,kind='stable')[:k]
        return [dict(self.evidence[int(i)],retrieval_score=float(scores[i])) for i in ids],dict(input_tokens=usage.input_tokens,seconds=usage.gpu_seconds)
