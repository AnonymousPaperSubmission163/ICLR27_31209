"""Typed finite-term operations. Closure is a planning aid, never a ProofRecord."""
import hashlib
import json
from itertools import product
from .schemas import Atom, Term

def digest(x):
    if hasattr(x,'model_dump'): x=x.model_dump()
    return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:20]

def key(a): return json.dumps(a.model_dump(),sort_keys=True)
def ground(a): return all(t.kind=='constant' for t in a.arguments)
def opposite(a): return a.model_copy(update={'negated':not a.negated})
def substitute(a, bindings):
    return a.model_copy(update={'arguments':[bindings.get(t.name,t) if t.kind=='variable' else t for t in a.arguments]})

def unify(pattern, fact, bindings=None):
    if (pattern.predicate,pattern.negated,len(pattern.arguments))!=(fact.predicate,fact.negated,len(fact.arguments)): return None
    b=dict(bindings or {})
    for p,f in zip(pattern.arguments,fact.arguments):
        if p.entity_type!=f.entity_type: return None
        if p.kind=='variable':
            if p.name in b and b[p.name]!=f: return None
            b[p.name]=f
        elif p!=f: return None
    return b

def matches(atoms, facts, initial=None):
    rows=[dict(initial or {})]
    for a in atoms:
        rows=[b for row in rows for f in facts if (b:=unify(substitute(a,row),f,row)) is not None]
        unique={digest({k:v.model_dump() for k,v in b.items()}):b for b in rows}
        rows=list(unique.values())[:256]
    return rows

def closure(facts,rules,limit=512):
    known={key(a):a for a in facts}
    for _ in range(16):
        old=len(known)
        for r in rules:
            for b in matches(r.body,list(known.values())):
                a=substitute(r.head,b)
                if ground(a): known[key(a)]=a
                if len(known)>=limit: return list(known.values())
        if len(known)==old: break
    return list(known.values())

def compile_atom(a, variables=None):
    variables=variables or {}
    def term(t):
        if t.kind=='variable': return variables[t.name]
        return 'c'+digest([t.entity_type,t.name])
    pred='p'+digest(a.predicate)
    literal=pred+('('+','.join(term(t) for t in a.arguments)+')' if a.arguments else '')
    return '-'+literal if a.negated else literal

def compile_rule(r):
    names=sorted({t.name for a in r.body+[r.head] for t in a.arguments if t.kind=='variable'})
    vs={n:'v'+str(i) for i,n in enumerate(names)}
    body=' & '.join(compile_atom(a,vs) for a in r.body)
    formula='(('+body+') -> '+compile_atom(r.head,vs)+')'
    return ' '.join('all '+vs[n] for n in names)+' '+formula
