"""Program-owned evidence, bindings, facts, rule admission and invalidation."""
from .logic import key, ground, digest, opposite, closure
from .schemas import Atom, Term

class State:
    def __init__(self, graph):
        self.graph=graph;self.version=0
        self.evidence={};self.bindings={};self.facts={};self.rules={};self.constraints={}
        self.nodes={};self.proofs={};self.conflicts=[];self.revisions=[]
        self.builtin_comparisons=[];self.judgments=[]

    def accepted_facts(self):
        return [(i,Atom.model_validate(f['atom'])) for i,f in self.facts.items() if f['acceptance_status']=='accepted']
    def accepted_rules(self):
        return [(r.id,r) for r in self.graph.rules if self.rules.get(r.id,{}).get('acceptance_status')=='accepted']
    def known(self):
        return [a for _,a in self.accepted_facts()]+[Atom.model_validate(a) for p in self.proofs.values()
            if p['valid'] and p['result']=='proved' for a in p['target_ground_formula']]+[Atom.model_validate(a) for j in self.judgments if j['valid'] and j['verdict']=='supported' for a in j['targets']]
    def binding_terms(self):
        return {v:Term(kind='constant',name=b['entity_id'],entity_type=b['entity_type'])
            for v,b in self.bindings.items() if b['status']=='accepted'}

    def admit(self, extraction, review, call_id, node_id=None):
        verdicts={x.item_id:x for x in review.items}
        vars={v.name:v.entity_type for v in self.graph.variables}
        predicates={p.name:p.argument_types for p in self.graph.predicates}
        accepted=[]
        for j,f in enumerate(extraction.facts):
            fid='F'+digest([f.model_dump(),call_id]);v=verdicts.get('fact_'+str(j))
            ok=ground(f.atom) and predicates.get(f.atom.predicate)==[t.entity_type for t in f.atom.arguments]
            ok=ok and all(s.evidence_id in self.evidence and s.quote and s.quote in self.evidence[s.evidence_id]['original_text'] for s in f.text_spans)
            ok=ok and bool(v and v.verdict=='supported')
            self.facts[fid]=dict(fact_id=fid,**f.model_dump(),evidence_ids=sorted({s.evidence_id for s in f.text_spans}),
                extraction_call_id=call_id,acceptance_status='accepted' if ok else 'quarantined',
                review_reason=v.reason if v else 'missing semantic review',semantic_status='model_reviewed_not_external_truth')
            if ok: accepted.append(fid)
        for b in extraction.bindings:
            if node_id is not None and b.variable_name not in next(n.output_vars for n in self.graph.nodes if n.id==node_id): continue
            supported=[fid for fid in accepted if any(t.name==b.entity_id and t.entity_type==b.entity_type
                for t in Atom.model_validate(self.facts[fid]['atom']).arguments)]
            # Require the proposed output binding to occupy its declared query-atom position.
            from .logic import unify
            patterns=[a for n in self.graph.nodes for a in n.query_atoms if any(t.kind=='variable' and t.name==b.variable_name for t in a.arguments)]
            aligned=any((m:=unify(pattern,Atom.model_validate(self.facts[fid]['atom']),self.binding_terms())) is not None and b.variable_name in m and m[b.variable_name].name==b.entity_id for pattern in patterns for fid in supported)
            ok=aligned and vars.get(b.variable_name)==b.entity_type and bool(b.evidence_ids) and set(b.evidence_ids)<=self.evidence.keys() and bool(supported)
            if not ok: continue
            old=self.bindings.get(b.variable_name)
            # Multiple incompatible proposed identities are retained as conflicted, not silently overwritten.
            if old and old['status']=='accepted' and old['entity_id']!=b.entity_id:
                old['status']='conflicted'
                self.conflicts.append({'kind':'binding','variable':b.variable_name,'old':old['entity_id'],'new':b.entity_id})
                self.withdraw(old.get('fact_ids',[]),'binding changed/conflicted')
                continue
            self.bindings[b.variable_name]=dict(**b.model_dump(),status='accepted',fact_ids=supported)
        self.detect_conflicts()
        return accepted

    def detect_conflicts(self):
        known={key(a):i for i,a in self.accepted_facts()}
        ids=set()
        for i,a in self.accepted_facts():
            if key(opposite(a)) in known:
                other=known[key(opposite(a))]
                # Scope must be encoded in predicate arguments; also require matching record scope.
                if self.facts[i]['scope']==self.facts[other]['scope']:
                    ids.update([i,other])
        if ids:
            self.conflicts.append({'kind':'explicit_opposites','fact_ids':sorted(ids)})
            self.withdraw(ids,'explicit conflict')
        for c in self.graph.constraints:
            if c.kind=='mutex' and self.constraints.get(c.id,{}).get('acceptance_status')=='accepted':
                from .logic import matches,substitute
                for b in matches([c.left,c.right],[a for _,a in self.accepted_facts()]):
                    pair={key(substitute(c.left,b)),key(substitute(c.right,b))}
                    affected=[i for i,a in self.accepted_facts() if key(a) in pair]
                    if affected:
                        self.conflicts.append({'kind':'mutex','id':c.id,'fact_ids':affected});self.withdraw(affected,'mutex')

    def withdraw(self, ids, reason):
        ids=set(ids)
        while True:
            more={i for i,f in self.facts.items() if ids&set(f.get('parent_fact_ids',[]))}
            if more<=ids: break
            ids|=more
        for j in self.judgments:
            if ids&set(j.get('input_fact_ids',[])): j['valid']=False
        for i in ids:
            if i in self.facts: self.facts[i]['acceptance_status']='quarantined';self.facts[i]['review_reason']=reason
        for p in self.proofs.values():
            if ids&set(p['input_fact_ids']): p['valid']=False
        for b in self.bindings.values():
            if ids&set(b.get('fact_ids',[])): b['status']='quarantined'
        for n in self.nodes.values():
            if ids&set(n.get('fact_ids',[])): n['execution_status']='unresolved'

    def snapshot(self):
        from .schemas import EvidenceRecord,BindingRecord,FactRecord,NodeState,RuleState,ProofRecord
        for cls, records in [(EvidenceRecord,self.evidence),(BindingRecord,self.bindings),(FactRecord,self.facts),
                             (NodeState,self.nodes),(RuleState,self.rules),(ProofRecord,self.proofs)]:
            for record in records.values(): cls.model_validate(record)
        return dict(graph=self.graph.model_dump(),graph_version=self.version,evidence=self.evidence,
            bindings=self.bindings,facts=self.facts,rules=self.rules,constraints=self.constraints,
            nodes=self.nodes,proofs=self.proofs,conflicts=self.conflicts,revisions=self.revisions,
            builtin_comparisons=self.builtin_comparisons,llm_judgments=self.judgments)

    def compare(self):
        """Finite declared comparison language, exact typed IDs or Decimal/ISO-date values."""
        from decimal import Decimal, InvalidOperation
        from datetime import date
        from itertools import product
        terms=list(self.binding_terms().values())
        for pred in self.graph.predicates:
            if pred.name not in ['same_country','same_entity','greater_than','less_than','earlier_than','later_than'] or len(pred.argument_types)!=2: continue
            for a,b in product(terms,repeat=2):
                if [a.entity_type,b.entity_type]!=pred.argument_types: continue
                result=None
                if pred.name in ['same_country','same_entity']:
                    # Different arbitrary model IDs do NOT establish inequality.
                    if a.name==b.name: result=True
                    else: continue
                else:
                    values={v['entity_id']:v['display_value'] for v in self.bindings.values() if v['status']=='accepted'}
                    try:
                        parse=date.fromisoformat if pred.name in ['earlier_than','later_than'] else Decimal
                        x,y=parse(values[a.name]),parse(values[b.name])
                        result=x<y if pred.name in ['less_than','earlier_than'] else x>y
                    except (ValueError,InvalidOperation,KeyError): continue
                atom=Atom(predicate=pred.name,arguments=[a,b],negated=not result)
                fid='B'+digest(atom)
                if fid in self.facts: continue
                sources=[i for v in self.bindings.values() if v['status']=='accepted' and v['entity_id'] in [a.name,b.name] for i in v['fact_ids']]
                evidence=sorted({e for i in sources for e in self.facts[i]['evidence_ids']})
                self.facts[fid]=dict(fact_id=fid,atom=atom.model_dump(),evidence_ids=evidence,text_spans=[],
                    extraction_call_id='builtin-v1',scope='question',acceptance_status='accepted',
                    review_reason='deterministic typed comparison',parent_fact_ids=sources)
                self.builtin_comparisons.append({'fact_id':fid,'inputs':[a.model_dump(),b.model_dump()],'result':result,'parent_fact_ids':sources})
