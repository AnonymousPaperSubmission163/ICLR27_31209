from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid')

class VariableSpec(Strict):
    name: str
    entity_type: str
    description: str

class PredicateSpec(Strict):
    name: str
    argument_types: list[str]
    description: str

class Term(Strict):
    kind: Literal['variable', 'constant']
    name: str
    entity_type: str

class Atom(Strict):
    predicate: str
    arguments: list[Term]
    negated: bool

class InformationNodeSpec(Strict):
    id: str
    information_need: str
    input_vars: list[str]
    output_vars: list[str]
    acquisition_modes: list[Literal['retrieve','infer']]
    query_atoms: list[Atom]
    answer_condition_text: str
    step_group: int | None

class DependencySpec(Strict):
    target_node_id: str
    prerequisite_options: list[list[str]]
    reason: str

class RuleSpec(Strict):
    id: str
    body: list[Atom] = Field(min_length=1)
    head: Atom
    origin: Literal['question_definition','evidence','builtin','model_proposal']
    source_refs: list[str]
    explanation: str

class ConstraintSpec(Strict):
    id: str
    kind: Literal['mutex','equivalent']
    left: Atom
    right: Atom
    scope: str
    source_refs: list[str]
    explanation: str

class GoalAlternative(Strict):
    id: str
    all_of: list[Atom] = Field(min_length=1)
    answer_value: str | None

class GoalSpec(Strict):
    answer_vars: list[str]
    alternatives: list[GoalAlternative] = Field(min_length=1)
    answer_requirement_text: str

class GraphProposal(Strict):
    schema_version: Literal['logicrag-prototype-1']
    question_id: str
    original_question: str
    variables: list[VariableSpec]
    predicates: list[PredicateSpec]
    nodes: list[InformationNodeSpec] = Field(min_length=1, max_length=12)
    dependencies: list[DependencySpec]
    rules: list[RuleSpec]
    constraints: list[ConstraintSpec]
    goal: GoalSpec
    unresolved_design_issues: list[str]

    @model_validator(mode='after')
    def semantics(self):
        def unique(xs, label):
            if len(xs) != len(set(xs)): raise ValueError('duplicate '+label+': '+repr([x for x in xs if xs.count(x)>1]))
        for xs, label in [(self.nodes,'node'),(self.rules,'rule'),(self.constraints,'constraint')]:
            unique([x.id for x in xs],label)
        unique([x.name for x in self.variables],'variable')
        unique([x.name for x in self.predicates],'predicate')
        unique([x.id for x in self.goal.alternatives],'goal')
        variables={x.name:x.entity_type for x in self.variables}
        predicates={x.name:x.argument_types for x in self.predicates}
        constants={}
        def check(atom):
            if atom.predicate not in predicates: raise ValueError('undeclared predicate '+atom.predicate)
            if [x.entity_type for x in atom.arguments] != predicates[atom.predicate]:
                raise ValueError('predicate arity/type mismatch '+atom.predicate+' expected '+repr(predicates[atom.predicate])+' received '+repr([(t.name,t.entity_type) for t in atom.arguments]))
            for t in atom.arguments:
                if t.kind=='variable' and variables.get(t.name)!=t.entity_type:
                    raise ValueError('undeclared or mistyped variable '+t.name)
                if t.kind=='constant':
                    if t.name.upper() in {'ENTITY','UNKNOWN','[UNKNOWN]','COLLEGE','COUNTRY','PERSON','LOCATION'}: raise ValueError('unbound placeholder constant '+t.name)
                    if t.name in constants and constants[t.name]!=t.entity_type: raise ValueError('constant type collision')
                    constants[t.name]=t.entity_type
        for n in self.nodes:
            if not n.acquisition_modes or not n.query_atoms: raise ValueError('node must expose mode and query atoms')
            if set(n.input_vars)&set(n.output_vars): raise ValueError('input/output variables overlap')
            for v in n.input_vars+n.output_vars:
                if v not in variables: raise ValueError('unknown node variable '+v)
            for a in n.query_atoms: check(a)
            av={t.name for a in n.query_atoms for t in a.arguments if t.kind=='variable'}
            if not av <= set(n.input_vars+n.output_vars): raise ValueError('unbound query variable')
        for r in self.rules:
            for a in r.body+[r.head]: check(a)
            bv={t.name for a in r.body for t in a.arguments if t.kind=='variable'}
            hv={t.name for t in r.head.arguments if t.kind=='variable'}
            if not hv<=bv: raise ValueError('unsafe rule head variable')
        for c in self.constraints: check(c.left); check(c.right)
        for g in self.goal.alternatives:
            for a in g.all_of: check(a)
        if not self.goal.answer_vars and any(a.answer_value is None for a in self.goal.alternatives): raise ValueError('goal has neither answer variables nor a fixed answer')
        if not set(self.goal.answer_vars)<=variables.keys(): raise ValueError('unknown answer variable')
        ns={n.id for n in self.nodes}
        if sorted(d.target_node_id for d in self.dependencies)!=sorted(ns): raise ValueError('exactly one dependency per node')
        edges={d.target_node_id:{x for option in d.prerequisite_options for x in option} for d in self.dependencies}
        if any(not d.prerequisite_options for d in self.dependencies): raise ValueError('no prerequisite option')
        if any(not ps<=ns for ps in edges.values()): raise ValueError('missing prerequisite node')
        seen,active=set(),set()
        def visit(n):
            if n in active: raise ValueError('execution dependency cycle')
            if n in seen: return
            active.add(n)
            for p in edges[n]: visit(p)
            active.remove(n);seen.add(n)
        for n in ns: visit(n)
        producers={v:{n.id for n in self.nodes if v in n.output_vars} for v in variables}
        for n in self.nodes:
            ancestors=set()
            def collect(k):
                for p in edges[k]:
                    if p not in ancestors: ancestors.add(p);collect(p)
            collect(n.id)
            if any(not (producers[v]&ancestors) for v in n.input_vars):
                raise ValueError('input variable has no dependency producer '+n.id)
        heads={a.predicate for n in self.nodes for a in n.query_atoms}|{r.head.predicate for r in self.rules}
        if any(a.predicate not in heads for g in self.goal.alternatives for a in g.all_of): raise ValueError('uncovered goal')
        return self

class Span(Strict):
    evidence_id: str
    quote: str

class BindingProposal(Strict):
    variable_name: str
    entity_id: str
    entity_type: str
    display_value: str
    scope: str
    evidence_ids: list[str]

class FactProposal(Strict):
    atom: Atom
    text_spans: list[Span] = Field(min_length=1)
    scope: str

class Extraction(Strict):
    bindings: list[BindingProposal]
    facts: list[FactProposal]
    uncertainty: list[str]

class Query(Strict):
    query: str

class Ranked(Strict):
    evidence_id: str
    score: float = Field(ge=0,le=1)
    potential_conflict: bool
class Ranking(Strict):
    items: list[Ranked]

class ReviewItem(Strict):
    item_id: str
    verdict: Literal['supported','refuted','unknown']
    reason: str
class Review(Strict):
    items: list[ReviewItem]

class LLMJudgment(Strict):
    verdict: Literal['supported','refuted','unknown']
    evidence_ids: list[str]
    reason: str

class RunResult(Strict):
    question_id: str
    mode: str
    run_kind: Literal['real_model','fixture','replay']
    final_answer: str
    answer_source: Literal['proved_readout','unsupported_fallback','abstain','llm_supported_readout']
    goal_proved: bool
    answer_supported: bool
    em: float | None = None
    f1: float | None = None
    failure_reason: str | None
    counters: dict
    timings: dict
    evidence_ids: list[str] = Field(default_factory=list)

class Event(Strict):
    event_id: str
    question_id: str
    graph_version: int
    step: int
    event_type: str
    timestamp: str
    input_refs: list[str]
    output_refs: list[str]
    payload: dict
    counters: dict

# Runtime records are program-owned. These schemas also document optional audit fields.
class EvidenceRecord(Strict):
    evidence_id: str
    document_id: str
    passage_id: str
    original_text: str
    source_metadata: dict
    retrieval_call_id: int
    retrieval_score: float | None = None

class BindingRecord(BindingProposal):
    status: Literal['accepted','conflicted','quarantined']
    fact_ids: list[str]

class FactRecord(Strict):
    fact_id: str
    atom: Atom
    evidence_ids: list[str]
    text_spans: list[Span]
    extraction_call_id: str
    scope: str
    acceptance_status: Literal['proposed','accepted','rejected','quarantined']
    review_reason: str
    semantic_status: str | None = None
    parent_fact_ids: list[str] = Field(default_factory=list)

class NodeState(Strict):
    node_id: str
    binding_id: str
    graph_version: int
    execution_status: Literal['pending','running','resolved','unresolved','failed']
    proposition_status: Literal['supported','refuted','unknown','conflicted']
    attempts: int
    result_value: dict | None
    evidence_ids: list[str]
    fact_ids: list[str]
    last_error: str | None

class RuleState(Strict):
    rule_id: str
    graph_version: int
    acceptance_status: Literal['proposed','accepted','rejected','quarantined']
    basis_refs: list[str]
    review_reason: str
    semantic_status: str

class ProofRecord(Strict):
    proof_id: str
    target_ground_formula: list[Atom]
    fact_ids: list[str]
    rule_ids: list[str]
    input_fact_ids: list[str]
    input_rule_ids: list[str]
    result: Literal['proved','no_proof','timeout','input_error','process_error','budget_exhausted','unavailable']
    proof_text: str
    proof_parent_steps: list[str]
    proof_depth: dict | None = None
    source_mapping_status: Literal['complete','incomplete']
    input_path: str
    stdout_path: str
    stderr_path: str
    exit_code: int | None
    elapsed_seconds: float
    timeout_seconds: float
    graph_version: int
    cache_hit: bool
    valid: bool

class ActionRecord(Strict):
    action_id: str
    node_id: str
    binding_id: str
    mode: Literal['retrieve','infer']
    candidate_ids: list[str]
    estimated_cost: float
    selection_reason: str
    ready: bool
    available: bool
    binding: dict[str,Term]
    graph_version: int
    shared_count: int = 0

class SupportCandidate(Strict):
    candidate_id: str
    goal_alternative_id: str
    answer_bindings: dict[str,Term]
    required_atoms: list[Atom]
    required_actions: list[str]
    missing_actions: list[ActionRecord]
    estimated_remaining_cost: float
    feasibility_status: Literal['ready','no_ready_action']

class GraphRevision(Strict):
    old_version: int
    new_version: int
    reason: str
    added_items: list[str]
    removed_items: list[str]
    changed_items: dict
    invalidated_fact_ids: list[str]
    invalidated_proof_ids: list[str]

class RelevanceScore(Strict):
    score: float = Field(ge=0,le=1)
    potential_conflict: bool

def ranking_schema(count):
    from typing import Annotated
    from pydantic import create_model
    return create_model('OrderedRanking'+str(count),__base__=Strict,
        items=(Annotated[list[RelevanceScore],Field(min_length=count,max_length=count)],...))

def query_schema(required_terms):
    import re
    class GroundedTextQuery(Query):
        @model_validator(mode='after')
        def keep_entities_and_text_search(self):
            if re.search(r'^\s*(SELECT|ASK|CONSTRUCT|DESCRIBE)\b.*\bWHERE\b',self.query,re.I|re.S):
                raise ValueError('text search requires natural-language keywords, not SQL/SPARQL')
            missing=[t for t in required_terms if not re.search(r'(?<!\w)'+re.escape(t)+r'(?!\w)',self.query,re.I)]
            if missing:raise ValueError('copy these exact node entities/time values into the search query: '+repr(missing))
            return self
    return GroundedTextQuery
