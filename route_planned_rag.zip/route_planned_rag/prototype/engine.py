import copy
import json
import time
from datetime import datetime,timezone
from pathlib import Path
from .schemas import Query,query_schema,Ranking,Ranked,ranking_schema,Extraction,Review,LLMJudgment,RunResult,Event,Atom
from .logic import digest,key,ground,matches,substitute,closure,opposite
from .prover import Prover,write_json
from .state import State
from .planner import Planner
from .model import build_graph,review_graph

class Engine:
    def __init__(self,client,retriever,config,output,mode='proof_guided',run_kind='real_model'):
        self.client=client;self.retriever=retriever;self.config=config;self.output=Path(output)
        self.mode=mode;self.kind=run_kind;self.output.mkdir(parents=True,exist_ok=True)
        self.prover=Prover(config['prover_executable'],self.output/'proofs',config['prover_timeout_seconds'],config['max_prover_calls_per_question'])
        self.planner=Planner(config);self.events=[];self.step=0;self.counters={'retrieval_calls':0,'prover_calls':0,'graph_revisions':0}
        self.last_candidates=[];self.last_action=None;self.state=None
    def counts(self):
        return dict(self.counters,prover_calls=self.prover.calls,prover_cache_hits=self.prover.cache_hits,
            llm_calls=len(self.client.calls),llm_input_tokens=sum(c.get('input_tokens') or 0 for c in self.client.calls),
            llm_output_tokens=sum(c.get('output_tokens') or 0 for c in self.client.calls))
    def event(self,kind,payload):
        state=self.state.snapshot() if self.state else None
        eid='E'+str(len(self.events)+1).zfill(5)
        ev=Event(event_id=eid,question_id=self.qid,graph_version=self.state.version if self.state else 0,step=self.step,
            event_type=kind,timestamp=datetime.now(timezone.utc).isoformat(),input_refs=[],output_refs=[],payload=payload,counters=self.counts()).model_dump()
        snapshot=dict(state=state,candidates=self.last_candidates,selected_action=self.last_action,counters=self.counts(),event=ev)
        write_json(self.output/'states'/(eid+'.json'),snapshot)
        with (self.output/'events.jsonl').open('a') as f: f.write(json.dumps(ev,ensure_ascii=False)+'\n')
        self.events.append(ev)
        write_json(self.output/'model_calls.json',self.client.calls)
    def proof(self,targets):
        p=self.prover.prove(self.state.accepted_facts(),self.state.accepted_rules(),targets,self.state.version)
        self.state.proofs[p['proof_id']]=p;self.counters['prover_calls']=self.prover.calls
        self.event('proof',p)
        return p
    def mark_nodes(self):
        s=self.state
        for record in s.nodes.values():
            n=next((n for n in s.graph.nodes if n.id==record['node_id']),None)
            if n is None: continue
            b=s.binding_terms()
            if all(v in b for v in n.input_vars+n.output_vars) and matches([substitute(a,b) for a in n.query_atoms],s.known()):
                record['execution_status']='resolved';record['proposition_status']='supported'
                record['result_value']={v:s.bindings[v]['display_value'] for v in n.output_vars}
    def update_subgoals(self):
        s=self.state
        if self.mode=='llm_topological' or s.conflicts or not self.config.get('automatic_intermediate_proofs',True): return
        derived=closure([a for _,a in s.accepted_facts()],[r for _,r in s.accepted_rules()])
        known={key(a) for a in s.known()}
        if any(key(opposite(a)) in {key(x) for x in derived} for a in derived): return
        for node in s.graph.nodes:
            witnesses=matches(node.query_atoms,derived,s.binding_terms())
            if any(len({b[v].name for b in witnesses if v in b})>1 for v in node.output_vars): continue
            for b in witnesses:
                targets=[substitute(a,b) for a in node.query_atoms]
                if all(ground(a) for a in targets) and any(key(a) not in known for a in targets):
                    if self.prover.calls>=self.config['max_prover_calls_per_question']-4: return
                    proof=self.proof(targets)
                    if proof['result']=='proved' and proof['source_mapping_status']=='complete':
                        self.resolve_from_proof(node,b,proof)
                    known={key(a) for a in s.known()}

    def resolve_from_proof(self,node,b,proof):
        s=self.state
        if not all(v in b and b[v].kind=='constant' for v in node.input_vars+node.output_vars): return
        refs=sorted({e for fid in proof['fact_ids'] for e in s.facts[fid]['evidence_ids']})
        displays={x['entity_id']:x['display_value'] for x in s.bindings.values() if x['status']=='accepted'}
        for v in node.output_vars:
            term=b[v]
            if v in s.bindings and s.bindings[v]['status']=='accepted' and s.bindings[v]['entity_id']!=term.name:return
            s.bindings[v]=dict(variable_name=v,entity_id=term.name,entity_type=term.entity_type,display_value=displays.get(term.name,term.name),
                scope='question',evidence_ids=refs,status='accepted',fact_ids=proof['fact_ids'])
        bid=digest({v:b[v].model_dump() for v in node.input_vars})
        record=s.nodes.setdefault(node.id+':'+bid,dict(node_id=node.id,binding_id=bid,graph_version=s.version,execution_status='pending',
            proposition_status='unknown',attempts=0,result_value=None,evidence_ids=[],fact_ids=[],last_error=None))
        record.update(execution_status='resolved',proposition_status='supported',result_value={v:s.bindings[v]['display_value'] for v in node.output_vars},
            evidence_ids=refs,fact_ids=proof['fact_ids'])
        self.event('node_resolved_by_proof',{'node_id':node.id,'proof_id':proof['proof_id'],'binding_id':bid})

    def try_goal(self):
        s=self.state
        if s.conflicts: return None
        proposed=closure([a for _,a in s.accepted_facts()],[r for _,r in s.accepted_rules()])
        # Detect explicit opposite consequences before giving an inconsistent KB to classical logic.
        ks={key(a) for a in proposed}
        if any(key(opposite(a)) in ks for a in proposed):
            s.conflicts.append({'kind':'derived_opposites','status':'quarantined_kb'})
            for p in s.proofs.values(): p['valid']=False
            self.event('conflict',s.conflicts[-1]);return None
        for alt in s.graph.goal.alternatives:
            for b in matches(alt.all_of,proposed,s.binding_terms()):
                if not all(v in b and b[v].kind=='constant' for v in s.graph.goal.answer_vars): continue
                targets=[substitute(a,b) for a in alt.all_of]
                if not all(ground(a) for a in targets): continue
                if self.mode=='llm_topological':
                    j=self.client.ask('llm_judgment',LLMJudgment,
                        'Judge whether ALL instantiated target atoms follow from cited evidence and admitted rules. No hidden knowledge. Return unknown if any condition is missing.',
                        {'targets':[a.model_dump() for a in targets],'state':s.snapshot()},max_tokens=1024)
                    self.event('llm_judgment',j.model_dump())
                    if j.verdict!='supported' or not j.evidence_ids or not set(j.evidence_ids)<=s.evidence.keys(): continue
                    proved=False;refs=j.evidence_ids
                else:
                    p=self.proof(targets)
                    if p['result']!='proved' or p['source_mapping_status']!='complete': continue
                    refs=sorted({e for fid in p['fact_ids'] for e in s.facts[fid]['evidence_ids']})
                    if not refs: continue
                    proved=True
                answer=alt.answer_value
                if answer is None:
                    displays={v['entity_id']:v['display_value'] for v in s.bindings.values() if v['status']=='accepted'}
                    answer=', '.join(displays.get(b[v].name,b[v].name) for v in s.graph.goal.answer_vars)
                if not answer: continue
                return dict(answer=answer,proved=proved,evidence_ids=refs,goal_alternative_id=alt.id)
        return None
    def retrieve(self,action):
        s=self.state;n=next(n for n in s.graph.nodes if n.id==action['node_id'])
        required_terms=sorted({t.name for a in n.query_atoms for t in a.arguments if t.kind=='constant'}|{s.bindings[v]['display_value'] for v in n.input_vars if v in s.bindings and s.bindings[v]['status']=='accepted'})
        q=self.client.ask('query',query_schema(required_terms),'Generate a SHORT NATURAL-LANGUAGE search query for the CURRENT NODE only. This is dense TEXT retrieval, not a knowledge graph: never emit SQL, SPARQL, SELECT, WHERE, braces or programming syntax. Copy named constants and bound entity display values EXACTLY; never autocomplete a name into a more famous name. Include only time constraints present in this node, not conditions from later nodes. Unbound outputs are unknown.',
            {'question':self.question,'node':n.model_dump(),'bindings':s.bindings},max_tokens=512)
        self.counters['retrieval_calls']+=1
        evidence,usage=self.retriever(q.query,self.config['retrieval_top_k'])
        for e in evidence:
            s.evidence.setdefault(e['evidence_id'],dict(e,retrieval_call_id=self.counters['retrieval_calls']))
        rank=[]
        for start in range(0,len(evidence),self.config['rerank_batch_size']):
            batch=evidence[start:start+self.config['rerank_batch_size']]
            r=self.client.ask('rerank',ranking_schema(len(batch)),'Score each supplied passage for this exact information need in the SAME ORDER as the input list. Return exactly one score per passage, without reordering or emitting IDs. Score relevance from 0 to 1. Flag possible conflicting evidence for review; conflict is not established by this flag.',
                {'question':self.question,'node':n.model_dump(),'bindings':s.bindings,'passages':batch},size='small',max_tokens=2048)
            rank += [Ranked(evidence_id=passage['evidence_id'],**score.model_dump()) for passage,score in zip(batch,r.items)]
        rank.sort(key=lambda r:(-r.score,r.evidence_id))
        ids={r.evidence_id for r in rank[:self.config['rerank_keep_top_k']]}|{r.evidence_id for r in rank if r.potential_conflict}
        selected=[s.evidence[i] for i in sorted(ids)]
        self.event('retrieval',{'query':q.query,'candidates':evidence,'ranking':[r.model_dump() for r in rank],'selected_ids':sorted(ids),'encoder_usage':usage})
        ex=self.client.ask('extract',Extraction,
            'Solve ONLY the CURRENT NODE information need. Missing answers to later nodes must NOT prevent extracting the current fact and binding. For example, identifying an organization does not require knowing its later membership count. Extract ground facts directly supported by supplied verbatim text spans. Use the graph declared predicates and constant IDs. Reuse existing entity IDs for the same identity; NEVER merge different entities. Bind node output variables using the corresponding query atom argument positions. Each fact must include an EXACT nonempty quote from an evidence passage. Preserve entity, relation, time and setting. If evidence is absent or ambiguous, return empty bindings/facts with uncertainty. Do not invent facts to satisfy a rule. scope must be question unless a specific narrower scope is required.',
            {'question':self.question,'node':n.model_dump(),'predicates':[p.model_dump() for p in s.graph.predicates],
             'bindings':s.bindings,'passages':selected},max_tokens=4096)
        review=self.client.ask('fact_review',Review,
            'Review the truth of EACH INDIVIDUAL ATOM against ONLY its cited text and predicate definition. Return supported if its own arguments, relation, negation, time and scene are justified. A true fact need NOT answer the whole question or establish other relations. Do NOT reject a contest-win fact for lacking a brother relationship: those are separate atoms. Relevance to a task is separate from truth. Unknown if the atom itself is ambiguous or unsupported. item_id is fact_0, fact_1 etc. This is a model semantic review, not a formal proof.',
            {'predicates':[p.model_dump() for p in s.graph.predicates],
             'existing_bindings':s.bindings,'proposed_bindings':[b.model_dump() for b in ex.bindings],
             'facts':{f'fact_{i}':f.model_dump() for i,f in enumerate(ex.facts)},'passages':selected},max_tokens=4096) if ex.facts else Review(items=[])
        accepted=s.admit(ex,review,self.client.calls[-1]['call_id'],n.id)
        record=s.nodes[action['node_id']+':'+action['binding_id']]
        record['fact_ids']=accepted;record['evidence_ids']=sorted(ids)
        self.event('fact_admission',{'extraction':ex.model_dump(),'review':review.model_dump(),'accepted_fact_ids':accepted})
    def infer(self,action):
        s=self.state;n=next(n for n in s.graph.nodes if n.id==action['node_id'])
        proposed=closure([a for _,a in s.accepted_facts()],[r for _,r in s.accepted_rules()])
        for b in matches(n.query_atoms,proposed,s.binding_terms()):
            targets=[substitute(a,b) for a in n.query_atoms]
            if not all(ground(a) for a in targets): continue
            if self.mode=='llm_topological':
                judgment=self.client.ask('llm_judgment',LLMJudgment,'Judge if all targets follow from supplied facts and rules; unsupported is unknown.',
                    {'targets':[a.model_dump() for a in targets],'facts':s.facts,'rules':s.rules,'evidence':s.evidence},max_tokens=1024)
                self.event('llm_judgment',judgment.model_dump())
                if judgment.verdict=='supported' and judgment.evidence_ids and set(judgment.evidence_ids)<=s.evidence.keys():
                    s.judgments.append(dict(**judgment.model_dump(),targets=[a.model_dump() for a in targets],valid=True,input_fact_ids=[i for i,_ in s.accepted_facts()]))
            else: self.proof(targets)
    def revise(self,reason):
        s=self.state
        if self.counters['graph_revisions']>=self.config['max_graph_revisions']: return False
        self.counters['graph_revisions']+=1
        old=s.graph
        new=build_graph(self.client,self.qid,self.question,old,{'reason':reason,'bindings':s.bindings,'facts':s.facts,'nodes':s.nodes})
        # Conservative full invalidation: changed formalization must never inherit old proof success.
        badfacts=[i for i,f in s.facts.items() if f['acceptance_status']=='accepted']
        badproofs=[i for i,p in s.proofs.items() if p['valid']]
        s.withdraw(badfacts,'graph revision requires re-admission');s.bindings={};s.nodes={}
        s.graph=new;s.version+=1;s.rules={};s.constraints={}
        rev=dict(old_version=s.version-1,new_version=s.version,reason=reason,
            added_items=sorted({n.id for n in new.nodes}-{n.id for n in old.nodes}),removed_items=sorted({n.id for n in old.nodes}-{n.id for n in new.nodes}),
            changed_items={'old_graph':old.model_dump(),'new_graph':new.model_dump()},invalidated_fact_ids=badfacts,invalidated_proof_ids=badproofs)
        s.revisions.append(rev);review_graph(self.client,s)
        write_json(self.output/'graph_versions'/f'graph_v{s.version}.json',new.model_dump())
        self.event('graph_revision',rev);return True
    def run(self,qid,question,prepared_graph=None,prepared_rules=None):
        self.qid=qid;self.question=question;start=time.perf_counter();answer=None;failure=None
        try:
            if self.mode!='llm_topological' and not self.prover.executable: raise RuntimeError('blocked:Prover9 unavailable')
            graph=prepared_graph or build_graph(self.client,qid,question)
            self.state=State(graph);write_json(self.output/'graph_v0.json',graph.model_dump())
            if prepared_rules is None: review_graph(self.client,self.state)
            else: self.state.rules=copy.deepcopy(prepared_rules)
            self.event('graph_initialized',{'shared_preparation':prepared_rules is not None})
            for step in range(self.config['max_steps_per_question']):
                self.step=step;s=self.state;s.detect_conflicts();s.compare();self.update_subgoals();self.mark_nodes()
                answer=self.try_goal()
                if answer: self.event('answer',answer);break
                self.last_candidates,self.last_action=self.planner.plan(s,self.counts(),self.mode)
                from .schemas import SupportCandidate
                for candidate in self.last_candidates: SupportCandidate.model_validate(candidate)
                self.event('plan',{'enumeration_truncated':self.planner.truncated})
                if self.last_action is None:
                    if self.revise('no executable support; inspect variables, missing rules and failures'): continue
                    failure='no_executable_support';break
                a=self.last_action;nk=a['node_id']+':'+a['binding_id']
                r=s.nodes.setdefault(nk,dict(node_id=a['node_id'],binding_id=a['binding_id'],graph_version=s.version,execution_status='pending',
                    proposition_status='unknown',attempts=0,result_value=None,evidence_ids=[],fact_ids=[],last_error=None))
                r['attempts']+=1;r['execution_status']='running';self.event('action_started',a)
                try:
                    if a['mode']=='retrieve': self.retrieve(a)
                    else: self.infer(a)
                    r['execution_status']='unresolved';self.mark_nodes()
                except (ValueError,RuntimeError) as exc:
                    r['execution_status']='failed';r['last_error']=str(exc);self.event('action_error',{'error':str(exc)})
                self.event('action_completed',r)
            else: failure='step_budget_exhausted'
            if not answer: answer=self.try_goal()
        except Exception as exc:
            failure=repr(exc);self.event('execution_blocked',{'error':failure})
        result=RunResult(question_id=qid,mode=self.mode,run_kind=self.kind,final_answer=answer['answer'] if answer else '',
            answer_source=('proved_readout' if answer['proved'] else 'llm_supported_readout') if answer else 'abstain',
            goal_proved=bool(answer and answer['proved']),answer_supported=bool(answer),failure_reason=None if answer else failure or 'unresolved',
            counters=self.counts(),timings={'seconds':time.perf_counter()-start}).model_dump()
        result['evidence_ids']=answer['evidence_ids'] if answer else []
        self.event('finished',result);write_json(self.output/'result.json',result)
        if self.state:
            write_json(self.output/'final_state.json',self.state.snapshot())
            with (self.output/'evidence.jsonl').open('w') as f:
                for e in self.state.evidence.values(): f.write(json.dumps(e,ensure_ascii=False)+'\n')
        return result
