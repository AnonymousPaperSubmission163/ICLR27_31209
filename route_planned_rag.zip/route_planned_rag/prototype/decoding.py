"""Preserve declaration-first field order in XGrammar; legacy adapter sorts schema keys."""
import json
import time
from route_planned_rag.models.json_actor import GenerationResult

def generate_ordered_json(backend,prompt,*,schema,temperature,top_p,max_tokens):
    import torch
    import xgrammar.contrib.hf
    # Property order is operationally important: variables and predicates must be emitted before their uses.
    serialized=json.dumps(schema,ensure_ascii=False,separators=(',',':'))
    if serialized not in backend.grammars:
        backend.grammars[serialized]=backend.compiler.compile_json_schema(serialized,any_whitespace=False,indent=None,separators=(',',':'))
    backend.grammars.move_to_end(serialized)
    while len(backend.grammars)>32:backend.grammars.popitem(last=False)
    processor=xgrammar.contrib.hf.LogitsProcessor(backend.grammars[serialized])
    batch=backend.tokenizer.apply_chat_template([{'role':'user','content':prompt}],tokenize=True,add_generation_prompt=True,return_tensors='pt',return_dict=True)
    batch=batch.to(next(backend.model.parameters()).device)
    start=time.perf_counter()
    with torch.inference_mode():
        output=backend.model.generate(**batch,do_sample=False,max_new_tokens=max_tokens,pad_token_id=backend.tokenizer.eos_token_id,logits_processor=[processor])
    torch.cuda.synchronize()
    completion=output[0,batch['input_ids'].shape[1]:]
    return GenerationResult(backend.tokenizer.decode(completion,skip_special_tokens=True),int(batch['attention_mask'].sum().item()),int(completion.numel()),time.perf_counter()-start)
