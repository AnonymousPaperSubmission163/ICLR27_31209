"""Real LADR Prover9 subprocess, labeled inputs and conservative source mapping."""
import json
import re
import shutil
import subprocess
import time
from pathlib import Path
from .logic import compile_atom, compile_rule, digest, ground
from .proof_depth import proof_depth

def write_json(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.part')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False));tmp.replace(path)

class Prover:
    def __init__(self, executable, directory, timeout=2, cap=64):
        self.executable=shutil.which(str(executable))
        self.directory=Path(directory);self.timeout=timeout;self.cap=cap
        self.calls=0;self.cache_hits=0;self.cache={};self.records=[]
        self.binary_sha256=None
        if self.executable:
            import hashlib
            self.binary_sha256=hashlib.sha256(Path(self.executable).read_bytes()).hexdigest()

    def prove(self, facts, rules, goals, version=0):
        if not goals or not all(ground(a) for a in goals): raise ValueError('proof requires nonempty ground goals')
        cachekey=digest([[(i,a.model_dump()) for i,a in facts],[(i,r.model_dump()) for i,r in rules],
            [a.model_dump() for a in goals],version,self.timeout,self.binary_sha256])
        if cachekey in self.cache:
            self.cache_hits+=1
            return dict(self.cache[cachekey],cache_hit=True)
        proof_id='P'+str(len(self.records)+1).zfill(4)
        directory=self.directory/proof_id
        directory.mkdir(parents=True,exist_ok=True)
        symbols={}
        lines=[f'assign(max_seconds, {max(1,int(self.timeout))}).','assign(max_megs, 128).','formulas(assumptions).']
        for kind,items in [('fact',facts),('rule',rules)]:
            for i,obj in items:
                label='l'+digest([kind,i]);symbols[label]={'kind':kind,'id':i}
                expression=compile_atom(obj) if kind=='fact' else compile_rule(obj)
                lines.append(expression+' # label('+label+').')
        lines+=['end_of_list.','formulas(goals).','('+' & '.join(compile_atom(a) for a in goals)+').','end_of_list.']
        (directory/'input.in').write_text('\n'.join(lines)+'\n')
        write_json(directory/'source_map.json',symbols)
        record=dict(proof_id=proof_id,target_ground_formula=[a.model_dump() for a in goals],
            fact_ids=[],rule_ids=[],input_fact_ids=[i for i,_ in facts],input_rule_ids=[i for i,_ in rules],
            result='unavailable',proof_text='',proof_parent_steps=[],source_mapping_status='incomplete',
            input_path=str(directory/'input.in'),stdout_path=str(directory/'stdout.txt'),stderr_path=str(directory/'stderr.txt'),
            exit_code=None,elapsed_seconds=0.,timeout_seconds=self.timeout,graph_version=version,cache_hit=False,valid=True)
        out=err='';start=time.perf_counter()
        if self.executable and self.calls<self.cap:
            self.calls+=1
            try:
                p=subprocess.run([self.executable,'-f',str(directory/'input.in')],capture_output=True,text=True,timeout=self.timeout+1)
                out,err=p.stdout,p.stderr;record['exit_code']=p.returncode
                record['result']= {0:'proved',1:'input_error',2:'no_proof',4:'timeout'}.get(p.returncode,'process_error')
                if p.returncode==0:
                    match=re.search(r'=+ PROOF =+\s*(.*?)\s*=+ end of proof =+',out,re.S|re.I)
                    if match:
                        proof=match.group(1);record['proof_text']=proof
                        labels=set(re.findall(r'label\((l[0-9a-f]+)\)',proof))
                        used=[symbols[x] for x in labels if x in symbols]
                        record['fact_ids']=[x['id'] for x in used if x['kind']=='fact']
                        record['rule_ids']=[x['id'] for x in used if x['kind']=='rule']
                        record['proof_parent_steps']=re.findall(r'^\d+ .*?\[([^\]]+)\]',proof,re.M)
                        if labels and labels<=symbols.keys(): record['source_mapping_status']='complete'
                    else: record['result']='process_error'
            except subprocess.TimeoutExpired as exc:
                out=exc.stdout or '';err=exc.stderr or ''
                if isinstance(out,bytes): out=out.decode(errors='replace')
                if isinstance(err,bytes): err=err.decode(errors='replace')
                record['result']='timeout'
            except OSError as exc: err=str(exc);record['result']='process_error'
        elif self.executable: record['result']='budget_exhausted'
        record['elapsed_seconds']=time.perf_counter()-start
        record['proof_depth']=proof_depth(record['proof_text']) if record['result']=='proved' else dict(
            status='unavailable', formal_depth=None, steps=[], reason=record['result'])
        (directory/'stdout.txt').write_text(out);(directory/'stderr.txt').write_text(err)
        write_json(directory/'record.json',record)
        self.records.append(record)
        if record['result'] in ['proved','no_proof']: self.cache[cachekey]=record
        return record
