"""Bounded AND/OR support enumeration with stable remaining-cost action choice."""
from itertools import product
from .logic import digest, key, ground, substitute, unify, matches, opposite

class Planner:
    def __init__(self, config): self.config=config;self.truncated=False

    def plan(self,state,counters,mode='proof_guided'):
        g=state.graph;self.truncated=False
        bound=state.binding_terms();known=state.known();knownkeys={key(a) for a in known}
        rules=[r for _,r in state.accepted_rules()]
        nodes={n.id:n for n in g.nodes};deps={d.target_node_id:d.prerequisite_options for d in g.dependencies}
        maxc=self.config['max_candidate_supports'];beam=self.config['beam_width']
        def trim(xs,n=beam):
            if len(xs)>n: self.truncated=True
            return xs[:n]
        def action(n,way):
            b={v:bound[v].model_dump() for v in n.input_vars if v in bound}
            bid=digest(b)
            aid=digest([n.id,bid,way,state.version])
            previous=state.nodes.get(n.id+':'+bid,{})
            ready=all(v in bound for v in n.input_vars) and any(all(any(x['node_id']==p and x['execution_status']=='resolved' for x in state.nodes.values()) for p in option) for option in deps[n.id])
            available=previous.get('attempts',0)<self.config['max_attempts_per_node_binding_version']
            if way=='retrieve': available &= counters['retrieval_calls']<self.config['max_retrieval_calls_per_question']
            if way=='infer': available &= counters['prover_calls']<self.config['max_prover_calls_per_question'] or mode=='llm_topological'
            return dict(action_id=aid,node_id=n.id,binding_id=bid,mode=way,candidate_ids=[],estimated_cost=1.0 if way=='retrieve' else .1,
                ready=bool(ready and available),available=bool(available),selection_reason='',binding=b,graph_version=state.version)
        def node_support(n,way,seen):
            if n.id in seen: return []
            a=action(n,way)
            if not a['available']: return []
            base=[{a['action_id']:a}]
            if a['ready']: return base
            out=[]
            for option in deps[n.id]:
                sets=base
                for p in option:
                    if any(x['node_id']==p and x['execution_status']=='resolved' for x in state.nodes.values()): continue
                    additions=[]
                    for w in nodes[p].acquisition_modes: additions+=node_support(nodes[p],w,seen|{n.id})
                    sets=trim([{**x,**y} for x in sets for y in additions])
                out+=sets
            return trim(out)
        def expand(atom,seen,depth=0):
            atom=substitute(atom,bound)
            if key(atom) in knownkeys or (not ground(atom) and matches([atom],known)): return [{}]
            if ground(atom) and key(opposite(atom)) in knownkeys: return []
            if key(atom) in seen or depth>12: return []
            out=[]
            for r in rules:
                # Variable names are declared globally, so preserve unbound names through backward expansion.
                b=unify(r.head,atom)
                if b is None: continue
                sets=[{}]
                for pre in r.body:
                    sub=expand(substitute(pre,b),seen|{key(atom)},depth+1)
                    sets=trim([{**x,**y} for x in sets for y in sub])
                out+=sets
            for n in g.nodes:
                if any(unify(substitute(q,bound),atom) is not None or unify(atom,substitute(q,bound)) is not None for q in n.query_atoms):
                    for way in n.acquisition_modes: out+=node_support(n,way,set())
            uniq={tuple(sorted(x)):x for x in out}
            return trim(sorted(uniq.values(),key=lambda x:(sum(a['estimated_cost'] for a in x.values()),tuple(sorted(x)))))
        candidates=[]
        for goal in g.goal.alternatives:
            sets=[{}]
            for atom in goal.all_of:
                options=expand(atom,set())
                sets=trim([{**x,**y} for x in sets for y in options])
            for actions in sets:
                aid=sorted(actions)
                cid='C'+digest([goal.id,aid,{k:v.model_dump() for k,v in bound.items()},state.version])
                candidates.append(dict(candidate_id=cid,goal_alternative_id=goal.id,
                    answer_bindings={k:v.model_dump() for k,v in bound.items()},required_atoms=[a.model_dump() for a in goal.all_of],
                    required_actions=aid,missing_actions=list(actions.values()),estimated_remaining_cost=sum(a['estimated_cost'] for a in actions.values()),
                    feasibility_status='ready' if any(a['ready'] for a in actions.values()) else 'no_ready_action'))
        candidates=trim(sorted(candidates,key=lambda c:(c['estimated_remaining_cost'],c['candidate_id'])),maxc)
        sharing={}
        for c in candidates:
            for a in c['missing_actions']: sharing.setdefault(a['action_id'],[]).append(c['candidate_id'])
        for c in candidates:
            for a in c['missing_actions']: a['candidate_ids']=sharing[a['action_id']];a['shared_count']=len(a['candidate_ids'])
        feasible=[c for c in candidates if c['feasibility_status']=='ready']
        if not feasible: return candidates,None
        if mode=='proof_guided':
            chosen=feasible[0]
            options=[a for a in chosen['missing_actions'] if a['ready']]
            selected=min(options,key=lambda a:(-a['shared_count'],a['estimated_cost'],a['node_id'],a['binding_id'],a['mode']))
            selected['selection_reason']=f"minimum remaining support cost {chosen['estimated_remaining_cost']}; shared {selected['shared_count']}; stable tie order"
        else:
            depth={}
            def level(n):
                if n not in depth: depth[n]=1+max([level(p) for o in deps[n] for p in o] or [-1])
                return depth[n]
            options={a['action_id']:a for c in feasible for a in c['missing_actions'] if a['ready']}
            selected=min(options.values(),key=lambda a:(level(a['node_id']),a['node_id'],a['binding_id'],a['mode']))
            selected['selection_reason']='stable topological depth / node / binding / mode'
        return candidates,selected
