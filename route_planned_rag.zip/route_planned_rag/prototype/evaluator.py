"""Offline answer EM/F1, HotpotQA normalization, gold never passed to Engine."""
import re
import string
from collections import Counter

def normalize(s):
    s=''.join(c for c in s.lower() if c not in string.punctuation)
    return ' '.join(re.sub(r'\b(a|an|the)\b',' ',s).split())
def score(pred,gold):
    p,g=normalize(pred),normalize(gold)
    em=float(p==g)
    if (p in ['yes','no','noanswer'] or g in ['yes','no','noanswer']) and p!=g: return em,0.
    pt,gt=p.split(),g.split();common=sum((Counter(pt)&Counter(gt)).values())
    if not common: return em,0.
    precision=common/len(pt);recall=common/len(gt)
    return em,2*precision*recall/(precision+recall)
