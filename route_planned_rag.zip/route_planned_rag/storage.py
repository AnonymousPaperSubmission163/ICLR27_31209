from __future__ import annotations

import dataclasses
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def jsonable(value: Any) -> Any:
    if dataclasses.is_dataclass(value):
        return {key: jsonable(child) for key, child in dataclasses.asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): jsonable(child) for key, child in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [jsonable(child) for child in value]
    if hasattr(value, "value"):
        return value.value
    return value


class RunWriter:
    REQUIRED = ("manifest.json", "events.jsonl", "predictions.jsonl", "metrics.json", "resources.json")
    EVENT_FIELDS = (
        "question_id", "split_role", "corpus_id", "model_role", "model_revision",
        "tokenizer_revision", "adapter_id", "prompt_version", "controller_id", "seed",
        "episode_id", "parent_episode_id", "snapshot_id", "route_id", "action_id",
        "request_id", "event_type", "budget_before", "reserved_budget", "usage_actual",
        "budget_after", "cache_status", "observed_chunk_ids", "binding_updates",
        "stop_reason", "completion_status",
    )

    def __init__(self, run_root: str | Path, run_id: str, *, project_root: str | Path, resume: bool = False):
        self.project_root = Path(project_root).resolve()
        self.run_dir = Path(run_root).resolve() / run_id
        try:
            self.run_dir.relative_to(self.project_root)
        except ValueError as exc:
            raise ValueError("run directory escapes project root") from exc
        if resume:
            if not self.run_dir.is_dir():
                raise FileNotFoundError(f"cannot resume absent run: {self.run_dir}")
            for name in self.REQUIRED:
                if not (self.run_dir / name).exists():
                    raise RuntimeError(f"cannot resume run missing {name}: {self.run_dir}")
        else:
            self.run_dir.mkdir(parents=True, exist_ok=False)
            (self.run_dir / "events.jsonl").touch()
            (self.run_dir / "predictions.jsonl").touch()
            self.write_json("metrics.json", {"status": "pending", "values": {}})
            self.write_json("resources.json", {"status": "pending", "usage": {}})

    @staticmethod
    def timestamped_id(prefix: str) -> str:
        return f"{prefix}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"

    def write_json(self, name: str, value: Any) -> None:
        target = self.run_dir / name
        temporary = target.with_suffix(target.suffix + f".tmp-{os.getpid()}")
        temporary.write_text(json.dumps(jsonable(value), ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        temporary.replace(target)

    def append_event(self, value: Any) -> None:
        value = jsonable(value)
        if isinstance(value, dict):
            value = {field: value.get(field) for field in self.EVENT_FIELDS} | value
        with (self.run_dir / "events.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())

    def append_prediction(self, value: Any) -> None:
        with (self.run_dir / "predictions.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(jsonable(value), ensure_ascii=False, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
