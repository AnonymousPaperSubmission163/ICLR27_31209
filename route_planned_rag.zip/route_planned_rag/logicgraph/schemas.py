"""Bounded schemas for constrained decoding; semantic validation remains independent."""
S = {"type": "string"}
N = {"type": "number"}
I = {"type": "integer"}
B = {"type": "boolean"}
# Coarse model forecasts, not calibrated probabilities; normalize positive weights in code.
U = {"type": "string", "enum": [format(i / 20, ".2f") for i in range(21)]}
TOKENS = {"type": "integer", "enum": [128, 256, 512, 768, 1024, 1536, 2048, 3072, 4096, 6144, 8192]}
def arr(item, low=0, high=64):
    return {"type": "array", "items": item, "minItems": low, "maxItems": high}
def obj(**properties):
    return {"type": "object", "properties": properties, "required": list(properties),
            "additionalProperties": False}
def enum(*items):
    return {"type": "string", "enum": list(items)}
IDS = arr(S, high=24)
PROP = obj(source=S, target=S, kind=enum("implies", "equivalent"), conclusion=S,
           evidence_ids=IDS, rule_validated=B, scope_validated=B)
SCHEMAS = {
    "compiler": obj(nodes=arr(obj(id=S, need=S, step=I, modes=arr(enum("retrieve", "reason", "tool"), 1, 2),
        scope=S, prerequisites=arr(IDS, high=12)), 1, 12),
        edges=arr(obj(source=S, target=S, kind=enum("implies", "requires", "equivalent", "mutex"),
                      scope=S, rule=S), high=36), goal_options=arr(arr(S, 1, 12), 1, 12)),
    "importance": obj(estimates=arr(obj(node=S, mode=enum("retrieve", "reason", "tool"),
        current_utility=U, expected_generation_tokens=TOKENS,
        outcomes=arr(obj(probability=U, goal_utility=U), 2, 4)), 1, 24)),
    "route_value": obj(utilities=arr(U, 1, 16)),
    "action": obj(query=S, command=S, mutates=B, reason=S),
    "rerank": obj(scores=arr(obj(id=S, relevance=U, conflict=B), 1, 5)),
    "resolver": obj(status=enum("resolved", "pending", "conflict"), satisfies_need=B, value=S, evidence_ids=IDS,
        premise_ids=IDS, invalid_edges=arr(I, high=36), propagations=arr(PROP, high=12)),
    "support_check": obj(supported=B, evidence_ids=arr(S, high=8), unresolved_conflict=B,
        missing={"type": "string", "maxLength": 200}, graph_issue=B, affected_nodes=arr(S, high=12)),
    "final_reader": obj(answer=S, evidence_ids=IDS,
        supporting_facts=arr(obj(evidence_id=S, sentence_ids=arr(I, high=64)), high=24),
        evidences=arr(arr(S, 3, 3), high=12), abstain=B),
}
SCHEMAS["planrag_compiler"] = SCHEMAS["compiler"]
SCHEMAS["graph_repair"] = obj(graph=SCHEMAS["compiler"], reopen=arr(S, high=12),
    reason={"type": "string", "maxLength": 240})
SCHEMAS["ircot_step"] = obj(thought=S, finished=B, evidence_ids=IDS)
SCHEMAS["information_nodes"] = obj(nodes=arr(obj(need=S,
    step={"type": "integer", "enum": list(range(1, 13))},
    modes=arr(enum("retrieve", "reason"), 1, 2), scope={"const": "static"}), 1, 12))
SCHEMAS["logical_edges"] = obj(edges=SCHEMAS["compiler"]["properties"]["edges"],
    prerequisites=arr(obj(node=S, groups=arr(arr(S, 1, 12), 0, 12)), 1, 12),
    goal_options=arr(arr(S, 1, 12), 1, 12))
SCHEMAS["query_proposal"] = obj(query=S)
SCHEMAS["claim_proposal"] = obj(value=S, evidence_ids=IDS, premise_ids=IDS)
SCHEMAS["answer_proposal"] = obj(answer=S, evidence_ids=IDS,
    supporting_facts=arr(obj(evidence_id=S, sentence_ids=arr(I, high=64)), high=24),
    evidences=arr(arr(S, 3, 3), high=12))

def allowed_ids(values, maximum=24):
    values = list(dict.fromkeys(values))
    return arr({"type": "string", "enum": values}, 0, maximum) if values else arr(S, 0, 0)

def schema_for(role, payload):
    import copy
    schema = copy.deepcopy(SCHEMAS[role])
    props = schema["properties"]
    if role == "logical_edges":
        ids = [node["id"] for node in payload["nodes"]]
        node_id = enum(*ids)
        for field in ("source", "target"):
            props["edges"]["items"]["properties"][field] = node_id
        entries = []
        for nid in ids:
            other_ids = [other for other in ids if other != nid]
            groups = arr(arr(enum(*other_ids), 1, len(other_ids)), 0, 12) if other_ids else arr(S, 0, 0)
            entries.append(obj(node={"const": nid}, groups=groups))
        props["prerequisites"] = {"type": "array", "prefixItems": entries,
            "minItems": len(ids), "maxItems": len(ids), "items": False}
        props["goal_options"] = arr(arr(node_id, 1, len(ids)), 1, 12)
    if role == "rerank":
        entries = [obj(id={"const": e["id"]}, relevance=U, conflict=B) for e in payload["candidates"]]
        props["scores"] = {"type": "array", "prefixItems": entries,
                           "minItems": len(entries), "maxItems": len(entries), "items": False}
    if role == "route_value":
        props["utilities"] = arr(U, len(payload["candidates"]), len(payload["candidates"]))
    if role == "importance":
        entries = []
        base = props["estimates"]["items"]
        for node in payload["state"]["graph"]["nodes"]:
            if node["status"] == "resolved" or node["attempts"] >= 2:
                continue
            for mode in node["modes"]:
                entry = copy.deepcopy(base)
                entry["properties"]["node"] = {"const": node["id"]}
                entry["properties"]["mode"] = {"const": mode}
                entries.append(entry)
        props["estimates"] = {"type": "array", "prefixItems": entries,
            "minItems": len(entries), "maxItems": len(entries), "items": False}
    if role == "graph_repair":
        nodes = payload["state"]["graph"]["nodes"]
        props["reopen"] = allowed_ids((n["id"] for n in nodes), maximum=12)
        if payload.get("domain") == "qa":
            node_props = props["graph"]["properties"]["nodes"]["items"]["properties"]
            node_props["modes"] = arr(enum("retrieve", "reason"), 1, 2)
            node_props["scope"] = {"const": "static"}
    if role in {"resolver", "support_check", "final_reader", "ircot_step", "claim_proposal", "answer_proposal"}:
        evidence = payload["state"]["evidence"]
        props["evidence_ids"] = allowed_ids((e["id"] for e in evidence),
                                            maximum=8 if role == "support_check" else 24)
        if role == "support_check":
            props["affected_nodes"] = allowed_ids((n["id"] for n in payload["state"]["graph"]["nodes"]), maximum=12)
        if role in {"resolver", "claim_proposal"}:
            props["premise_ids"] = allowed_ids(n["id"] for n in payload["state"]["graph"]["nodes"]
                                               if n["status"] == "resolved")
        if role in {"final_reader", "answer_proposal"}:
            options = [obj(evidence_id={"const": e["id"]},
                sentence_ids=arr({"type": "integer", "enum": e["sentence_ids"]}, 1, len(e["sentence_ids"])))
                for e in evidence if e["sentence_ids"]]
            props["supporting_facts"] = arr({"anyOf": options}, 0, 24) if options else arr(S, 0, 0)
    return schema


def normalize_forecast_serialization(role, output):
    """Convert explicit decimal-string wire scores; never change model-selected values.

    XGrammar emits long binary-float expansions for numeric enums. Decimal strings
    preserve the same 0.05 grid with exact, compact spellings and bounded token cost.
    """
    def convert(value):
        if isinstance(value, str):
            if value not in U["enum"]:
                raise ValueError("forecast outside declared decimal-string grid")
            return float(value)
        return value  # Semantic validation also supports plain JSON fixture backends.
    if role == "route_value":
        output["utilities"] = [convert(x) for x in output["utilities"]]
    elif role == "rerank":
        for item in output["scores"]:
            item["relevance"] = convert(item["relevance"])
    elif role == "importance":
        for item in output["estimates"]:
            item["current_utility"] = convert(item["current_utility"])
            for outcome in item["outcomes"]:
                for key in ("probability", "goal_utility"):
                    outcome[key] = convert(outcome[key])
    return output
