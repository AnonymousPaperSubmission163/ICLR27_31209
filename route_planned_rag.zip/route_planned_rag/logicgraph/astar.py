"""A* over acquisition states, not paths through information-node edges.

Search assumes an action will acquire ONE node if an independent verifier accepts
its result. Real execution can fail; the caller must replan after each observation.
No proposed Implies/Equivalent edge is a free proof. Optimality is conditional on
the supplied graph and fixed, non-LLM action costs, not on QA accuracy or latency.
"""
from __future__ import annotations

import heapq
import itertools
import math
from dataclasses import dataclass

from .core import Graph


@dataclass(frozen=True)
class ActionCosts:
    modes: dict[str, float]
    nodes: dict[str, dict[str, float]]
    unit: str = "execution_units"
    source: str = "declared_cost_model"

    def __post_init__(self):
        if self.unit not in {"execution_units", "measured_seconds"}:
            raise ValueError("cost units must be explicit")
        for mapping in (self.modes, *self.nodes.values()):
            for mode, value in mapping.items():
                if mode not in {"retrieve", "reason"} or isinstance(value, bool) or not isinstance(value, (int, float)):
                    raise ValueError("invalid non-LLM action cost")
                if not math.isfinite(value) or value <= 0:
                    raise ValueError("action costs must be finite and strictly positive")
        if self.source not in {"declared_cost_model", "declared_unit_cost", "measured_execution"}:
            raise ValueError("only declared algorithmic or measured costs are allowed")

    @classmethod
    def unit_cost(cls):
        # This is an action-count objective, NOT a seconds estimate.
        return cls({"retrieve": 1., "reason": 1.}, {}, source="declared_unit_cost")

    @classmethod
    def from_profile(cls, obj):
        if obj.get("schema") != "logicgraph-astar-cost-v1":
            raise ValueError("legacy LLM token/utility profiles are not A* cost profiles")
        if obj.get("source") != "measured_execution" or obj.get("calibration_split") != "train_internal_dev":
            raise ValueError("measured costs require train-internal execution provenance")
        if obj.get("pipeline") != "logicgraph-astar-strict-v1" or not obj.get("measurement_sha256"):
            raise ValueError("cost measurements must match this pipeline and identify their source")
        if obj.get("node_costs"):
            raise ValueError("node IDs are question-local; a global cost profile cannot bind costs to node IDs")
        # Recompute mode medians from recorded execution durations, never accept
        # model-estimated generation lengths or user-edited summary scores.
        import hashlib
        import json
        import statistics
        records = obj.get("measurements", [])
        wire = json.dumps(records, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        if not records or hashlib.sha256(wire).hexdigest() != obj["measurement_sha256"]:
            raise ValueError("missing or checksum-mismatched execution measurements")
        grouped = {}
        for record in records:
            seconds = record["seconds"]
            if record.get("split") != "train_internal_dev" or not record.get("episode_sha256"):
                raise ValueError("measurement must identify an internal-dev source episode")
            if record["mode"] not in {"retrieve", "reason"} or type(seconds) not in {int, float} or not math.isfinite(seconds) or seconds <= 0:
                raise ValueError("invalid execution duration")
            grouped.setdefault(record["mode"], []).append(seconds)
        medians = {mode: statistics.median(values) for mode, values in grouped.items()}
        if medians != obj["mode_costs"]:
            raise ValueError("mode costs do not equal measured execution medians")
        return cls(medians, {}, "measured_seconds", "measured_execution")

    def get(self, nid, mode):
        value = self.nodes.get(nid, {}).get(mode, self.modes.get(mode))
        if value is None:
            raise ValueError("missing explicit cost for " + nid + ":" + mode)
        return float(value)


@dataclass(frozen=True)
class Action:
    node: str
    mode: str
    cost: float


@dataclass(frozen=True)
class SearchResult:
    status: str  # optimal | infeasible | search_limit
    actions: tuple[Action, ...] = ()
    total_cost: float | None = None
    expanded: int = 0
    initial_lower_bound: float | None = None


def lower_bound(graph: Graph, acquired, costs: ActionCosts):
    """Admissible relaxation: ignore prerequisites, Mutex, calls and mode readiness.

    Every unresolved member of a goal AND-set needs its own positive-cost action.
    The minimum over OR alternatives is therefore a lower bound. This proof stops
    applying if multi-node/free propagation transitions are introduced.
    """
    return min(sum(min(costs.get(n, mode) for mode in graph.nodes[n].modes)
                   for n in set(group) - set(acquired)) for group in graph.goal_options)


def successors(graph, acquired, calls_used, *, remaining_calls, has_evidence, costs):
    for nid in graph.ready(acquired):
        for mode in sorted(graph.nodes[nid].modes):
            if mode == "retrieve" and calls_used >= remaining_calls:
                continue
            if mode == "reason" and not (has_evidence or acquired):
                continue
            if mode not in {"retrieve", "reason"}:
                raise ValueError("A* strict pipeline is QA-only")
            yield Action(nid, mode, costs.get(nid, mode))


def search(graph: Graph, costs: ActionCosts, *, remaining_calls: int,
           has_evidence=False, max_expansions=100000, heuristic=True):
    if isinstance(remaining_calls, bool) or not isinstance(remaining_calls, int) or remaining_calls < 0:
        raise ValueError("remaining_calls must be a nonnegative integer")
    if isinstance(max_expansions, bool) or not isinstance(max_expansions, int) or max_expansions < 0:
        raise ValueError("invalid expansion cap")
    if not 1 <= len(graph.nodes) <= 12 or not graph.goal_options:
        raise ValueError("A* requires 1..12 information nodes and nonempty goals")
    for node in graph.nodes.values():
        if not node.modes or not set(node.modes) <= {"retrieve", "reason"}:
            raise ValueError("A* strict pipeline is QA-only")
        for mode in node.modes:
            costs.get(node.id, mode)
    ids = tuple(sorted(graph.nodes))
    bits = {nid: 1 << i for i, nid in enumerate(ids)}
    initial = graph.resolved()
    if not graph.compatible(initial):
        return SearchResult("infeasible")
    root = (sum(bits[n] for n in initial), 0)
    counter = itertools.count()
    h0 = lower_bound(graph, initial, costs) if heuristic else 0.
    heap = [(h0, 0., next(counter), root, ())]
    best_g = {root: 0.}
    expanded = 0
    while heap:
        _, g, _, key, path = heapq.heappop(heap)
        if g != best_g[key]:
            continue
        mask, used = key
        done = {n for n in ids if bits[n] & mask}
        if any(set(group) <= done for group in graph.goal_options):
            return SearchResult("optimal", path, g, expanded, h0)
        if expanded >= max_expansions:
            return SearchResult("search_limit", expanded=expanded, initial_lower_bound=h0)
        expanded += 1
        for action in successors(graph, done, used, remaining_calls=remaining_calls,
                                 has_evidence=has_evidence, costs=costs):
            nxt = (mask | bits[action.node], used + int(action.mode == "retrieve"))
            ng = g + action.cost
            if ng >= best_g.get(nxt, math.inf):
                continue
            best_g[nxt] = ng  # Reopen a state whenever a cheaper path is found.
            h = lower_bound(graph, done | {action.node}, costs) if heuristic else 0.
            heapq.heappush(heap, (ng + h, ng, next(counter), nxt, path + (action,)))
    return SearchResult("infeasible", expanded=expanded, initial_lower_bound=h0)


def frontier_priorities(graph, costs, *, remaining_calls, has_evidence=False):
    """Auditable local A* priorities; these are NOT predicted success gains.

    Selection uses the complete A* search, not a greedy maximum over this list.
    """
    done = graph.resolved()
    h0 = lower_bound(graph, done, costs)
    rows = []
    for action in successors(graph, done, 0, remaining_calls=remaining_calls,
                             has_evidence=has_evidence, costs=costs):
        h1 = lower_bound(graph, done | {action.node}, costs)
        rows.append({"node": action.node, "mode": action.mode, "cost": action.cost,
                     "remaining_lower_bound": h1, "f": action.cost + h1,
                     "goal_lower_bound_reduction": h0 - h1})
    return sorted(rows, key=lambda r: (r["f"], r["node"], r["mode"]))
