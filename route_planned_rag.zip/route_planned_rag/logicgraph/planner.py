"""Bounded, logic-feasible proposal search and separately scored route utility."""
from __future__ import annotations

from dataclasses import dataclass
from .core import Graph, number

@dataclass(frozen=True)
class Estimate:
    node: str
    mode: str
    current_utility: float
    outcomes: tuple[tuple[float, float], ...]  # probability, final-goal utility
    cost_seconds: float
    forecast_source: str = "model"

    @property
    def gain(self):
        return sum(p * u for p, u in self.outcomes) - self.current_utility

    def importance(self, penalty, reference_seconds, ablation="full"):
        gain = 0. if ablation == "cost_only" else self.gain
        cost = 0. if ablation == "gain_only" else (
            1. if ablation == "equal_cost" else self.cost_seconds / reference_seconds)
        return gain - penalty * cost

def local_cost(cost_profile, mode, generation_tokens=768):
    measured = cost_profile.get("mode_local_seconds", {}).get(mode)
    if measured is not None:
        return number(measured, 0., 86400.)
    return number(float(cost_profile[mode]) + generation_tokens *
                  float(cost_profile.get("generation_seconds_per_token", 0.)), 0., 86400.)


def conservative_estimates(graph, cost_profile, source="invalid_forecast_no_gain"):
    """Explicit uninformative fallback, not a calibrated success prediction."""
    return {(n.id, m): Estimate(n.id, m, 0., ((1., 0.), (0., 0.)),
            local_cost(cost_profile, m), source)
            for n in graph.nodes.values() if n.status != "resolved" and n.attempts < 2
            for m in n.modes}


def parse_estimates(obj, graph, cost_profile):
    result = {}
    for item in obj["estimates"]:
        nid, mode = item["node"], item["mode"]
        if nid not in graph.nodes or mode not in graph.nodes[nid].modes:
            raise ValueError("unknown node/mode estimate")
        current = number(item["current_utility"])
        outcomes = tuple((number(x["probability"]), number(x["goal_utility"]))
                         for x in item["outcomes"])
        if not 2 <= len(outcomes) <= 4:
            raise ValueError("2..4 outcome scenarios required")
        if (nid, mode) in result:
            raise ValueError("duplicate node/mode estimate")
        ptotal = sum(p for p, _ in outcomes)
        generation_tokens = number(item.get("expected_generation_tokens", 768), 1., 16384.)
        cost = local_cost(cost_profile, mode, generation_tokens)
        # Zero-total weights carry no usable expected-utility information. Do not
        # invent a uniform success distribution, or discard every other node.
        source = "model" if ptotal else "zero_weight_no_gain"
        result[nid, mode] = Estimate(nid, mode, current,
            tuple((p / ptotal, u) for p, u in outcomes) if ptotal else ((1., current), (0., current)),
            cost, source)
    required = {(n.id, mode) for n in graph.nodes.values()
                if n.status != "resolved" and n.attempts < 2 for mode in n.modes}
    if result.keys() != required:
        raise ValueError("estimates must cover each unresolved node/mode exactly")
    return result

class Route(tuple):
    """Node order with explicit conditional acquisition modes (JSON-compatible)."""
    def __new__(cls, actions):
        actions = tuple(actions)
        result = super().__new__(cls, (e.node for e in actions))
        result.actions = actions
        return result

    def __reduce__(self):
        return type(self), (self.actions,)


def route_estimate(route, nid, best):
    return next((e for e in getattr(route, "actions", ()) if e.node == nid), best[nid])


def route_key(route):
    return tuple((e.node, e.mode) for e in route.actions) if isinstance(route, Route) else tuple((n, "") for n in route)


def propose_routes(graph: Graph, estimates, *, penalty=.05, reference_seconds=30.,
                   beam_width=8, max_candidates=16, ablation="full", has_context=True,
                   remaining_calls=None):
    """Beam heuristic uses maximum forecast utility, NOT a sum of marginal gains.
    It is only a proposal heuristic. The scorer estimates joint route utility later.
    Prerequisite AND groups and persistent mutex facts are checked at each expansion.
    """
    done = graph.resolved()
    best = {}
    for est in estimates.values():
        key = est.node
        if key not in best or est.importance(penalty, reference_seconds, ablation) > \
                best[key].importance(penalty, reference_seconds, ablation):
            best[key] = est
    def proposal_score(path):
        if not path:
            return 0.
        utility = max(sum(p * u for p, u in e.outcomes) for e in path.actions)
        cost = sum(e.cost_seconds / reference_seconds for e in path.actions)
        if ablation == "cost_only":
            utility = 0.
        if ablation == "gain_only":
            cost = 0.
        if ablation == "equal_cost":
            cost = len(path)
        return utility - penalty * cost
    frontier, candidates = [Route(())], {}
    for _ in range(len(graph.nodes)):
        expanded = []
        for path in frontier:
            calls = sum(e.mode != "reason" for e in path.actions)
            context = has_context or calls > 0
            for nid in graph.ready(done | set(path)):
                for mode in graph.nodes[nid].modes:
                    est = estimates.get((nid, mode))
                    if est is None or (mode == "reason" and not context):
                        continue
                    if mode != "reason" and remaining_calls is not None and calls >= remaining_calls:
                        continue
                    expanded.append(Route(path.actions + (est,)))
        if not expanded:
            break
        # Dedupe acquired sets, retaining a feasible deterministic execution order.
        unique = {}
        for path in sorted(expanded, key=lambda p: (-proposal_score(p), route_key(p))):
            # Different external-call counts can have different feasible continuations.
            unique.setdefault((frozenset(path), sum(e.mode != "reason" for e in path.actions)), path)
        frontier = sorted(unique.values(), key=lambda p: (-proposal_score(p), route_key(p)))[:beam_width]
        for path in frontier:
            candidates[route_key(path)] = (path, proposal_score(path))
    # A route is a goal-covering information plan, not an arbitrarily cheap prefix.
    complete = [(p, score) for p, score in candidates.values()
                if any(set(g) <= done | set(p) for g in graph.goal_options)]
    selected = [p for p, _ in sorted(complete, key=lambda x: (-x[1], route_key(x[0])))[:max_candidates]]
    return selected, best


def select_active(routes, scores, best, ready, *, previous=(), penalty=.05, reference_seconds=30.,
                  ablation="full", has_context=True):
    """Max importance over ALL feasible ready nodes; route utility breaks ties.

    Conditional modes must also be executable NOW. Fixed-route ablation
    deliberately excludes nodes outside its initial residual route.
    """
    remaining_previous = tuple(n for n in previous if n in best)
    candidates = []
    for value, path in scores:
        if ablation == "fixed_route" and previous and tuple(path) != remaining_previous:
            continue
        for nid in path:
            est = route_estimate(path, nid, best)
            if nid in ready and (est.mode != "reason" or has_context):
                candidates.append((est.importance(penalty, reference_seconds, ablation), value, nid, path))
    if not candidates:
        return None, ()
    _, _, active, route = min(candidates, key=lambda x: (-x[0], -x[1], x[2], route_key(x[3])))
    return active, route

def choose_route(routes, joint_utilities, best, *, penalty=.05, reference_seconds=30.,
                 ablation="full", previous=()):
    if len(joint_utilities) != len(routes):
        raise ValueError("one joint utility is required per candidate")
    scored = []
    for path, value in zip(routes, joint_utilities):
        utility = number(value)
        if ablation == "cost_only":
            utility = 0.
        cost = sum(route_estimate(path, n, best).cost_seconds / reference_seconds for n in path)
        if ablation == "equal_cost":
            cost = len(path)
        if ablation == "gain_only":
            cost = 0.
        scored.append((utility - penalty * cost, path))
    if not scored:
        return (), []
    if ablation == "fixed_route" and previous:
        matching = [(s, p) for s, p in scored if p == tuple(n for n in previous if n in best)]
        if matching:
            return matching[0][1], scored
    return sorted(scored, key=lambda x: (-x[0], x[1]))[0][1], scored
