"""Post-episode process only: unrounded per-question scores from pinned official functions.

No online module imports this file. Aggregate equality is checked against the unchanged
official evaluator, including 2Wiki's three-way joint metric and percent scaling.
"""
import argparse
import copy
import importlib.util
import json
import sys
from collections import defaultdict
from pathlib import Path


def load_official(path):
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location("pinned_official_evaluator", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def score_rows(dataset, gold, predictions, official, seed):
    result = []
    for index, row in enumerate(gold):
        key = str(row.get("_id", row.get("id")))
        if dataset == "musique":
            pred = predictions[index]
            if pred["id"] != key or not row["answerable"]:
                raise ValueError("MuSiQue Answerable IDs/track mismatch")
            answer, support = official.AnswerMetric(), official.SupportMetric()
            answer(pred["predicted_answer"], [row["answer"]] + row["answer_aliases"])
            support(pred["predicted_support_idxs"], [p["idx"] for p in row["paragraphs"] if p["is_supporting"]])
            em, f1 = answer.get_metric()
            metrics = dict(answer_em=em, answer_f1=f1, support_f1=support.get_metric()[1])
        else:
            metrics = defaultdict(float)
            em, precision, recall = official.update_answer(metrics, predictions["answer"][key], row["answer"])
            sp_em, sp_precision, sp_recall = official.update_sp(metrics, predictions["sp"][key], row["supporting_facts"])
            joint_em, joint_precision, joint_recall = em * sp_em, precision * sp_precision, recall * sp_recall
            if dataset == "twowiki":
                # The original evaluator normalizes triples in-place; protect source records.
                evi_em, evi_precision, evi_recall = official.update_evi(metrics,
                    copy.deepcopy(predictions["evidence"][key]), copy.deepcopy(row["evidences"]))
                joint_em *= evi_em
                joint_precision *= evi_precision
                joint_recall *= evi_recall
            metrics.update(joint_em=joint_em, joint_prec=joint_precision, joint_recall=joint_recall,
                joint_f1=2 * joint_precision * joint_recall / (joint_precision + joint_recall)
                    if joint_precision + joint_recall else 0.)
            if dataset == "twowiki":
                metrics = {k: v * 100 for k, v in metrics.items()}
        result.append(dict(question_id=key, seed=seed, **metrics))
    return result


def verify_aggregate(rows, aggregate, dataset):
    tolerance = .00050001 if dataset == "musique" else .00500001 if dataset == "twowiki" else 1e-10
    for key, value in aggregate.items():
        average = sum(r[key] for r in rows) / len(rows)
        if abs(average - value) > tolerance:
            raise ValueError(f"official aggregate mismatch for {key}: {average} versus {value}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", choices=["hotpotqa", "twowiki", "musique"])
    parser.add_argument("directory", type=Path)
    parser.add_argument("evaluator", type=Path)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    is_jsonl = args.dataset == "musique"
    extension = ".jsonl" if is_jsonl else ".json"
    def read(name):
        text = (args.directory / (name + extension)).read_text()
        return [json.loads(line) for line in text.splitlines() if line.strip()] if is_jsonl else json.loads(text)
    scores = score_rows(args.dataset, read("gold"), read("predictions"), load_official(args.evaluator), args.seed)
    aggregate = json.loads((args.directory / "official_metrics.json").read_text())
    verify_aggregate(scores, aggregate, args.dataset)
    with (args.directory / "per_question_scores.jsonl").open("w") as output:
        for row in scores:
            output.write(json.dumps(row) + "\n")


if __name__ == "__main__":
    main()
