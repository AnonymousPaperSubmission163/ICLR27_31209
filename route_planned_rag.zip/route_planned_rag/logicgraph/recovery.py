"""Bounded public-state recovery; no labels, fabricated evidence, or budget resets."""
import copy

from .core import Graph
from .model import object_fields

GRAPH_REPAIR = """Repair the information graph using the ORIGINAL QUESTION, observed evidence,
and the supplied failure feedback. Preserve the question's exact scope and answer target.
Never add a time, entity, causal condition, or answer assumption absent from the question.
Correct misinterpreted needs; reopen falsely resolved/exhausted needs if evidence is still
missing; add a missing bridge need when necessary. Information needs are not sub-questions.
Keep every existing node ID (edit its need if wrong); add at most enough nodes to total 12.
Return the complete corrected graph, with only information needs and proposed relations,
NOT values/statuses/evidence. No observed evidence may be erased. Do not remove valid Mutex
or Requires constraints merely to make a route feasible; justify changes from public data.
Requires u->v means acquire u before v. A reason-only comparison must depend on its input
facts. goal_options must cover ALL parts of the original question, not an easier substitute.
Do not invent Equivalent/Mutex relations when none apply. Preserve useful unaffected nodes.
Return {"graph":{"nodes":[{"id":"n1","need":"required fact","step":1,
"modes":["retrieve"],"scope":"static","prerequisites":[]}],"edges":[],
"goal_options":[["n1"]]},"reopen":["existing node ID"],"reason":"at most 240 characters"}.
Reopen only the needs whose grounding is missing or invalid, not every resolved node."""


def validate_repair(obj, state, domain):
    object_fields(obj, {"graph", "reopen", "reason"})
    graph = Graph.parse(obj["graph"], domain)
    # Validate atomically before mutating the actual execution state.
    copy.deepcopy(state).revise(copy.deepcopy(graph), obj["reopen"], obj["reason"])
    return graph, obj["reopen"], obj["reason"]


def compact_support_payload(payload):
    """Lossless request-local citation aliases; stored evidence IDs never change."""
    payload = copy.deepcopy(payload)
    view = payload["state"]
    aliases = {e["id"]: f"e{i + 1}" for i, e in enumerate(view["evidence"])}
    for evidence in view["evidence"]:
        evidence["id"] = aliases[evidence["id"]]
    for node in view["graph"]["nodes"]:
        node["evidence"] = [aliases.get(eid, eid) for eid in node["evidence"]]
    for conflict in view["conflicts"]:
        if "citations" in conflict:
            conflict["citations"] = [aliases.get(eid, eid) for eid in conflict["citations"]]
        if "evidence_id" in conflict:
            conflict["evidence_id"] = aliases.get(conflict["evidence_id"], conflict["evidence_id"])
    return payload, {alias: original for original, alias in aliases.items()}


def validate_support(obj, aliases, state):
    object_fields(obj, {"supported", "evidence_ids", "unresolved_conflict", "missing",
                        "graph_issue", "affected_nodes"})
    for name in ("supported", "unresolved_conflict", "graph_issue"):
        if not isinstance(obj[name], bool):
            raise ValueError(name + " must be boolean")
    ids = obj["evidence_ids"]
    if not isinstance(ids, list) or not all(isinstance(eid, str) for eid in ids) or \
            len(ids) > 8 or len(ids) != len(set(ids)) or not set(ids) <= aliases.keys():
        raise ValueError("support citations must be at most 8 unique observed aliases")
    if not isinstance(obj["missing"], str) or len(obj["missing"]) > 200:
        raise ValueError("missing must be at most 200 characters")
    affected = obj["affected_nodes"]
    if not isinstance(affected, list) or not all(isinstance(n, str) for n in affected) or \
            len(affected) > 12 or len(affected) != len(set(affected)) or not set(affected) <= state.graph.nodes.keys():
        raise ValueError("affected_nodes must contain unique existing node IDs")
    if obj["supported"] and (not ids or obj["unresolved_conflict"] or obj["graph_issue"]):
        raise ValueError("supported requires observed citations and no unresolved scope/conflict issue")
    result = {**obj, "evidence_ids": [aliases[eid] for eid in ids]}
    if any(state.evidence[eid].dynamic and state.evidence[eid].environment_version != state.version
           for eid in result["evidence_ids"]):
        raise ValueError("support cites stale environment evidence")
    return result
