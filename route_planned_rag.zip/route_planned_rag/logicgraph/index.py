"""Corpus-wide exact E5 index with resumable, hashed embedding shards and lazy metadata."""
import argparse
import hashlib
import json
import sqlite3
from dataclasses import asdict
from pathlib import Path

import yaml

from route_planned_rag.corpus.build import file_sha256, iter_jsonl
from route_planned_rag.corpus.chunking import SourceDocument, chunk_document
from route_planned_rag.models.dense_index import ResidentShardedDenseIndex
from route_planned_rag.models.e5 import E5MistralEncoder
from .core import Evidence

def build_metadata(root, dataset, tokenizer, revision):
    directory = root / "indexes" / dataset / revision
    directory.mkdir(parents=True, exist_ok=True)
    corpus = root / "data/corpora" / dataset / "documents.jsonl"
    chunks_path, db_path = directory / "chunks.jsonl", directory / "logicgraph_metadata.sqlite"
    marker = directory / "logicgraph_metadata.json"
    source_hash = file_sha256(corpus)
    if marker.exists():
        meta = json.loads(marker.read_text())
        if meta["corpus_sha256"] != source_hash or meta["tokenizer_revision"] != revision:
            raise ValueError("existing index source differs")
        return meta
    # Recompute deterministic chunk IDs to attach exact, fully observed supporting-sentence spans.
    part, dbpart = directory / "logicgraph_chunks.jsonl.part", directory / "logicgraph_metadata.sqlite.part"
    if dbpart.exists():
        dbpart.unlink()  # Explicit disposable staging DB, never the validated active index.
    db = sqlite3.connect(dbpart)
    db.execute("CREATE TABLE evidence (chunk_id TEXT PRIMARY KEY, payload TEXT NOT NULL)")
    docs = chunks = 0
    with part.open("w", encoding="utf-8") as output:
        for item in iter_jsonl(corpus):
            doc = SourceDocument(item["doc_id"], item["title"], item["text"],
                                 tuple(tuple(x) for x in item.get("sentence_char_spans", [])))
            for c in chunk_document(doc, tokenizer, tokenizer_revision=revision, chunk_tokens=512, overlap_tokens=64):
                full = tuple((sid, doc.text[a:z]) for sid, a, z in doc.sentence_char_spans
                             if c.char_start <= a and z <= c.char_end)
                evidence = Evidence(c.chunk_id, c.text, c.title, tuple(x[0] for x in full),
                    doc_id=c.doc_id, token_start=c.token_start, token_end=c.token_end, sentences=full)
                db.execute("INSERT INTO evidence VALUES (?, ?)",
                           (c.chunk_id, json.dumps(asdict(evidence), ensure_ascii=False)))
                output.write(json.dumps(c.to_dict(), ensure_ascii=False, sort_keys=True) + "\n")
                chunks += 1
            docs += 1
            if docs % 10000 == 0:
                db.commit()
                print(json.dumps({"stage": "chunking", "dataset": dataset, "documents": docs, "chunks": chunks}), flush=True)
    db.commit()
    db.close()
    new_hash = file_sha256(part)
    if chunks_path.exists():
        if file_sha256(chunks_path) != new_hash:
            raise ValueError("recomputed chunks differ from pinned existing index; no overwrite")
        part.unlink()
    else:
        part.replace(chunks_path)
    dbpart.replace(db_path)
    meta = dict(dataset=dataset, documents=docs, chunks=chunks, corpus_sha256=source_hash,
                chunks_sha256=new_hash, tokenizer_revision=revision, chunk_tokens=512, overlap_tokens=64,
                database=str(db_path), chunks_path=str(chunks_path))
    marker.write_text(json.dumps(meta, indent=2))
    return meta

def build_dense(root, dataset, config, batch_size=32):
    import torch
    import numpy as np
    revision = config["models"]["actor"]["revision"]
    directory = root / "indexes" / dataset / revision
    meta = json.loads((directory / "logicgraph_metadata.json").read_text())
    item = config["models"]["retriever"]
    contract = dict(encoder=item, chunks_sha256=meta["chunks_sha256"], storage_dtype="torch.bfloat16",
                    tokenizer_revision=revision, max_tokens=item["max_tokens"])
    index_id = hashlib.sha256(json.dumps(contract, sort_keys=True).encode()).hexdigest()
    output = directory / "dense" / index_id
    output.mkdir(parents=True, exist_ok=True)
    if (output / "manifest.json").exists():
        return json.loads((output / "manifest.json").read_text())
    encoder = E5MistralEncoder(item["repo_id"], item["revision"], query_instruction=item["query_instruction"],
        max_tokens=item["max_tokens"], dtype=item["dtype"], cache_dir=str(root / "cache/huggingface"))
    buffer, shards = [], []
    def flush(items):
        i = len(shards)
        path, ids_path = output / f"embeddings-{i:05d}.pt", output / f"chunks-{i:05d}.jsonl"
        record_path = output / f"shard-{i:05d}.json"
        ids_text = "".join(json.dumps({"chunk_id": x["chunk_id"], "doc_id": x["doc_id"]}, sort_keys=True) + "\n"
                           for x in items)
        ids_hash = hashlib.sha256(ids_text.encode()).hexdigest()
        if record_path.exists():
            record = json.loads(record_path.read_text())
            if record["ids_sha256"] != ids_hash or file_sha256(path) != record["embeddings_sha256"]:
                raise ValueError("resume shard checksum mismatch")
        else:
            vectors, tokens, seconds = [], 0, 0.
            for start in range(0, len(items), batch_size):
                values, usage = encoder.encode([x["text"] for x in items[start:start + batch_size]], is_query=False)
                vectors.append(torch.from_numpy(values).to(torch.bfloat16))
                tokens += usage.input_tokens
                seconds += usage.gpu_seconds
            temporary = path.with_suffix(".pt.part")
            torch.save(torch.cat(vectors), temporary)
            temporary.replace(path)
            ids_path.write_text(ids_text)
            record = dict(embeddings=str(path), chunk_ids=str(ids_path), rows=len(items),
                          ids_sha256=ids_hash, embeddings_sha256=file_sha256(path),
                          dense_forward_tokens=tokens, dense_gpu_seconds=seconds)
            record_path.write_text(json.dumps(record, indent=2))
        shards.append(record)
        print(json.dumps({"stage": "dense", "shards": len(shards), "chunks": sum(s["rows"] for s in shards)}), flush=True)
    for chunk in iter_jsonl(meta["chunks_path"]):
        buffer.append(chunk)
        if len(buffer) == 4096:
            flush(buffer)
            buffer = []
    if buffer:
        flush(buffer)
    manifest = dict(status="complete", chunks=sum(s["rows"] for s in shards), shards=shards,
                    dense_forward_tokens=sum(s["dense_forward_tokens"] for s in shards),
                    dense_gpu_seconds=sum(s["dense_gpu_seconds"] for s in shards), **contract)
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return manifest

class CorpusRetriever:
    def __init__(self, root, dataset, config, encoder):
        revision = config["models"]["actor"]["revision"]
        directory = root / "indexes" / dataset / revision
        meta = json.loads((directory / "logicgraph_metadata.json").read_text())
        manifests = sorted((directory / "dense").glob("*/manifest.json"))
        if len(manifests) != 1:
            raise ValueError("exactly one pinned active dense manifest required")
        self.manifest = json.loads(manifests[0].read_text())
        if self.manifest["chunks"] != meta["chunks"]:
            raise ValueError("dense and metadata counts differ")
        self.index = ResidentShardedDenseIndex(self.manifest)
        self.db = sqlite3.connect("file:" + meta["database"] + "?mode=ro", uri=True)
        self.encoder = encoder

    def __call__(self, query, top_k):
        vector, usage = self.encoder.encode([query], is_query=True)
        result = []
        for chunk_id, score in self.index.search(vector[0], top_k):
            item = self.db.execute("SELECT payload FROM evidence WHERE chunk_id=?", (chunk_id,)).fetchone()
            if item is None:
                raise ValueError("missing dense-result metadata")
            result.append(Evidence(**json.loads(item[0])))
        return result, usage

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["metadata", "dense"])
    parser.add_argument("--dataset", required=True, choices=["hotpotqa", "musique", "twowiki"])
    parser.add_argument("--root", type=Path, default=Path("/blue/du.j/jinjiaguo/logicrag"))
    args = parser.parse_args()
    config = yaml.safe_load((args.root / "configs/default.yaml").read_text())
    if args.stage == "metadata":
        from transformers import AutoTokenizer
        item = config["models"]["actor"]
        tokenizer = AutoTokenizer.from_pretrained(item["repo_id"], revision=item["revision"],
            cache_dir=str(args.root / "cache/huggingface"), fix_mistral_regex=True)
        result = build_metadata(args.root, args.dataset, tokenizer, item["revision"])
    else:
        result = build_dense(args.root, args.dataset, config)
    print(json.dumps({k: v for k, v in result.items() if k != "shards"}, indent=2), flush=True)

if __name__ == "__main__":
    main()

