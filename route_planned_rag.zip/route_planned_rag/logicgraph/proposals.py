"""LLM proposals only: no scores, validation decisions, or accepted facts."""
from .core import Graph

INFORMATION_NODES = """Propose step-aware INFORMATION NEEDS for the original question.
Nodes are information to retrieve or infer, NOT subquestions or action lists.
Use 3..8 nodes where appropriate, at most 12. Keep unknown identities and values
as placeholders. Preserve exact entity/time/property scope. Do not guess answers.
Return {"nodes":[{"need":"information needed","step":1,
"modes":["retrieve","reason"],"scope":"static"}]}.
Do not produce ratings, costs, confidence, correctness or support judgments.
For a simple relation slot, use the exact information-need form "birth year of ENTITY",
"birthplace of ENTITY", "death year of ENTITY", "director of WORK", "author of WORK",
"capital of COUNTRY", "country of PLACE", or "founding year of ORGANIZATION" when
it expresses the requested information precisely. Do not force unsupported needs
into these templates. For other needs use a concise declarative information need.
Relations and goals will be proposed in a separate stage; code assigns stable IDs."""

LOGICAL_EDGES = """Propose relations among the supplied information nodes using exact IDs.
Requires u->v is a mandatory prerequisite, never proof of v. Implies is a proposed
scoped inference rule; Equivalent is proposed same-scope mutual inference; Mutex
forbids two nodes from holding on one route. Complementary facts are not Mutex.
No relation is a verified rule. Do not claim validation or supply numeric scores.
prerequisites covers every node once: groups are OR-of-AND node IDs; [] means none.
goal_options are proposed OR-of-AND sets needed to answer ALL of the original question.
Give reason-only nodes explicit input dependencies. Do not add arbitrary ordering
constraints on independent facts, unstated restrictions, nodes or guessed answers.
Return {"edges":[{"source":"n1","target":"n2","kind":"requires",
"scope":"static","rule":""}],"prerequisites":[{"node":"n1","groups":[]},
{"node":"n2","groups":[["n1"]]}],"goal_options":[["n2"]]}."""

QUERY = """Propose one specific retrieval query for the active information need,
using the original question and observed context. Return {"query":"..."}.
Do not rate evidence or decide correctness, support, conflicts or completion."""

CLAIM = """Propose a concise candidate value for the active information need using
only supplied observed evidence or verified premise nodes. This is a candidate,
not a verification. Return {"value":"...","evidence_ids":["ID"],"premise_ids":["node ID"]}.
Use an empty value if you cannot propose a value. No status, confidence, ratings,
satisfies_need, validation flags, invalid edges or approved propagations."""
CLAIM += """ For an explicit relation-slot need such as 'director of WORK' or
'birth year of ENTITY', value is only the requested binding (a name or year), not
a sentence. For other needs, value is a complete concise factual statement. After
an unknown/rejected verdict, use its public reason to propose a better candidate
or seek missing information; never repeat a failed guess as if it were verified."""

ANSWER = """Propose a short exact answer to the ORIGINAL question from public
evidence and verified nodes. An independent verifier will check the whole candidate.
Return {"answer":"...","evidence_ids":["ID"],
"supporting_facts":[{"evidence_id":"ID","sentence_ids":[0]}],
"evidences":[["entity","relation","entity"]]}.
Use an empty answer if no candidate is available. No confidence or support judgment.
Do not copy gold annotations. Cite only supplied evidence and sentence IDs."""


def compile_information_graph(small, question, ledger):
    def validate_nodes(obj):
        if not isinstance(obj, dict) or set(obj) != {"nodes"}:
            raise ValueError("only node proposals allowed")
        for raw in obj["nodes"]:
            if set(raw) != {"need", "step", "modes", "scope"} or raw["scope"] != "static":
                raise ValueError("only static QA information-node proposals allowed")
        nodes = [{**raw, "id": f"n{i + 1}", "prerequisites": []} for i, raw in enumerate(obj["nodes"])]
        Graph.parse({"nodes": nodes, "edges": [], "goal_options": [[nodes[0]["id"]]]}, "qa")
        return nodes
    nodes = small.ask("information_nodes", INFORMATION_NODES, {"question": question}, ledger,
                      max_output=1536, validator=validate_nodes)

    def validate_edges(obj):
        if set(obj) != {"edges", "prerequisites", "goal_options"}:
            raise ValueError("only graph proposals allowed")
        for raw in obj["edges"]:
            if set(raw) != {"source", "target", "kind", "scope", "rule"} or raw["scope"] != "static":
                raise ValueError("edge self-validation fields forbidden")
        for item in obj["prerequisites"]:
            if set(item) != {"node", "groups"}:
                raise ValueError("invalid prerequisite proposal")
        mapping = {item["node"]: item["groups"] for item in obj["prerequisites"]}
        if set(mapping) != {n["id"] for n in nodes} or len(mapping) != len(obj["prerequisites"]):
            raise ValueError("logical stage must cover every node exactly once")
        return Graph.parse({"nodes": [{**n, "prerequisites": mapping[n["id"]]} for n in nodes],
                            "edges": obj["edges"], "goal_options": obj["goal_options"]}, "qa")
    return small.ask("logical_edges", LOGICAL_EDGES, {"question": question, "nodes": nodes}, ledger,
                     max_output=1536, validator=validate_edges)
