import argparse
import hashlib
import json
import os
import platform
import subprocess
import time
import shutil
import importlib.metadata
from pathlib import Path

from .strict_engine import StrictEngine
from .astar import ActionCosts
from .verification import require_semantic_verifier
from .ledger import Ledger

def load_models(*args, **kwargs):
    # Import GPU dependencies only after the strict preflight gate.
    from .runtime import load_models as load
    return load(*args, **kwargs)

def code_hash(root):
    h = hashlib.sha256()
    for path in sorted((root / "route_planned_rag").rglob("*.py")):
        h.update(str(path.relative_to(root)).encode())
        h.update(path.read_bytes())
    return h.hexdigest()

def load_verifier(path, root):
    """Explicit local executable plugin, never a model prompt or benchmark evaluator.

    The implementation must be reviewed for independence and label isolation before
    a formal protocol can be released; self-declared metadata alone is not a proof.
    """
    import importlib.util
    path = path.resolve()
    if not path.is_relative_to(root) or path.suffix != ".py":
        raise ValueError("verifier source must be a Python file within logicrag")
    spec = importlib.util.spec_from_file_location("logicrag_independent_verifier", path)
    module = importlib.util.module_from_spec(spec)
    # Dataclass-based plugins expect to find their module during import.
    import sys
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    verifier = module.create_verifier()
    require_semantic_verifier(verifier)
    return verifier, {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                      "id": verifier.verifier_id, "version": verifier.version,
                      "kind": verifier.implementation_kind}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("/blue/du.j/jinjiaguo/logicrag"))
    parser.add_argument("--datasets", nargs="+", choices=["hotpotqa", "twowiki", "musique"],
                        default=["musique", "twowiki", "hotpotqa"])
    parser.add_argument("--role", choices=["internal_dev", "e1_official_dev", "e2_official_dev"], default="internal_dev")
    parser.add_argument("--count", type=int, default=2)
    parser.add_argument("--budgets", nargs="+", type=int, default=[4])
    parser.add_argument("--methods", nargs="+", choices=["astar", "sequential_graph"], default=["astar"])
    parser.add_argument("--track", choices=["official_context", "pooled", "fullwiki"], default="official_context")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--seed", type=int, default=11)
    parser.add_argument("--profile", type=Path)
    parser.add_argument("--protocol", type=Path, default=Path("configs/logicgraph_astar_qa.yaml"))
    parser.add_argument("--verifier-file", type=Path)
    args = parser.parse_args()
    if args.track == "fullwiki" and args.datasets != ["hotpotqa"]:
        parser.error("fullwiki is a separate HotpotQA-only track")
    if args.track == "pooled" and "hotpotqa" in args.datasets:
        parser.error("HotpotQA primary retrieval uses --track fullwiki, not a pooled context corpus")
    if args.count <= 0 or any(x < 0 for x in args.budgets):
        parser.error("positive sample count and nonnegative call budgets required")
    root = args.root.resolve()
    if args.verifier_file is None:
        parser.error("verifier_required: A* is search, not a semantic QA verifier; no GPU/model loaded")
    verifier_path = args.verifier_file if args.verifier_file.is_absolute() else root / args.verifier_file
    try:
        verifier, verifier_manifest = load_verifier(verifier_path, root)
    except (ValueError, OSError, AttributeError) as exc:
        parser.error(str(exc))
    import yaml
    from .lexical import LexicalContextRetriever, LexicalCorpusRetriever
    from .qa import export_and_evaluate, frozen_ids, load_selected, qid, paths
    output = (root / "runs/logicgraph_astar" / args.run_id).resolve()
    runs_root = (root / "runs/logicgraph_astar").resolve()
    if not output.is_relative_to(runs_root) or output == runs_root:
        parser.error("run output must remain inside logicrag")
    config = yaml.safe_load((root / "configs/default.yaml").read_text())
    config["project"]["root"] = str(root)
    protocol_path = args.protocol if args.protocol.is_absolute() else root / args.protocol
    protocol_path = protocol_path.resolve()
    if not protocol_path.is_relative_to(root):
        parser.error("protocol must remain inside logicrag")
    protocol_bytes = protocol_path.read_bytes()
    protocol = yaml.safe_load(protocol_bytes)
    if protocol.get("schema") != "logicgraph-astar-strict-v1":
        parser.error("legacy LLM-scored protocols cannot run through the active QA entrypoint")
    if args.role != "internal_dev":
        parser.error("formal A* evaluation is disabled pending independent verifier/protocol validation")
    if args.seed not in protocol["seeds"]:
        parser.error("seed differs from the frozen proposal-model protocol")
    ids = {d: frozen_ids(root, d, args.role, args.count) for d in args.datasets}
    from route_planned_rag.corpus.build import file_sha256
    sources = {}
    for dataset in args.datasets:
        source = paths(root, dataset)[int(args.role != "internal_dev")]
        sources[dataset] = {"path": str(source), "sha256": file_sha256(source)}
        if args.track != "official_context":
            index_dir = root / "indexes" / dataset / config["models"]["actor"]["revision"]
            lexical_manifest = index_dir / "lexical_astar.json"
            if not lexical_manifest.exists() or json.loads(lexical_manifest.read_text())["status"] != "complete":
                raise ValueError("completed corpus-wide lexical index required before loading models; no context fallback")
            sources[dataset].update(index_manifest_path=str(lexical_manifest),
                index_manifest_sha256=file_sha256(lexical_manifest),
                metadata_manifest_sha256=file_sha256(index_dir / "logicgraph_metadata.json"))
    profile = None
    profile_hash = None
    if args.profile:
        profile_path = (args.profile if args.profile.is_absolute() else root / args.profile).resolve()
        if not profile_path.is_relative_to(root):
            parser.error("cost profile must remain within logicrag")
        profile_bytes = profile_path.read_bytes()
        profile_hash = hashlib.sha256(profile_bytes).hexdigest()
        profile = json.loads(profile_bytes)
    costs = ActionCosts.from_profile(profile) if profile is not None else ActionCosts.unit_cost()
    output.mkdir(parents=True, exist_ok=True)
    manifest = dict(schema="logicgraph-astar-strict-v1", code_sha256=code_hash(root),
        dataset_ids=ids, data_sources=sources, methods=args.methods, budgets=args.budgets, role=args.role, track=args.track,
        models=config["models"], seed=args.seed, temperature=0., deterministic_seed_policy="one run; no fake replicates",
        cost_unit=costs.unit, cost_source=costs.source, planned_n=args.count, cost_profile_sha256=profile_hash,
        verifier=verifier_manifest, retrieval_score_source="deterministic_lexical", dense_encoder_loaded=False,
        active_benchmarks=["hotpotqa", "twowiki", "musique"], terminal_bench="excluded_by_user",
        diagnostic=args.role == "internal_dev", slurm_job_id=os.getenv("SLURM_JOB_ID"),
        python=platform.python_version())
    manifest["protocol"] = protocol
    manifest["protocol_sha256"] = hashlib.sha256(protocol_bytes).hexdigest()
    manifest["dependencies"] = {p: importlib.metadata.version(p)
        for p in ("torch", "transformers", "huggingface-hub", "xgrammar", "tokenizers")}
    manifest["structured_decoding"] = "xgrammar_proposal_only_no_llm_scores_or_verdicts"
    manifest["evaluation_exposure"] = "v3 E1 official-dev previously inspected; A* is a different method, no blind-dev claim"
    manifest_path = output / "manifest.json"
    if manifest_path.exists():
        previous = json.loads(manifest_path.read_text())
        for key in ("code_sha256", "dataset_ids", "methods", "budgets", "role", "track", "seed", "verifier",
                    "cost_profile_sha256", "dependencies", "models", "structured_decoding", "protocol_sha256", "data_sources"):
            if previous[key] != manifest[key]:
                raise RuntimeError("resume contract differs: " + key + "; use a new run ID")
    else:
        manifest_path.write_text(json.dumps(manifest, indent=2))
        snapshot = output / "source_snapshot"
        for source in sorted((root / "route_planned_rag").rglob("*.py")):
            target = snapshot / source.relative_to(root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        shutil.copy2(root / "configs/default.yaml", snapshot / "default.yaml")
        shutil.copy2(protocol_path, snapshot / protocol_path.name)
        shutil.copy2(verifier_path, snapshot / "independent_verifier.py")
    import torch
    torch.manual_seed(args.seed)
    actor, small, _ = load_models(config, with_encoder=False)
    frozen_profile_path = output / "frozen_cost_profile.json"
    from dataclasses import asdict
    frozen_profile_path.write_text(json.dumps(asdict(costs), indent=2))
    summary = []
    for dataset in args.datasets:
        rows = load_selected(root, dataset, args.role, ids[dataset])
        retrievers = {}
        corpus_retriever = None
        if args.track != "official_context":
            corpus_retriever = LexicalCorpusRetriever(root, dataset, config["models"]["actor"]["revision"])
        for method in args.methods:
            for budget in args.budgets:
                directory = output / dataset / method / f"calls-{budget}"
                directory.mkdir(parents=True, exist_ok=True)
                episodes = []
                for row in rows:
                    key = qid(row)
                    file = directory / (hashlib.sha256(key.encode()).hexdigest()[:24] + ".json")
                    if file.exists():
                        episode = json.loads(file.read_text())
                        if episode["question_id"] != key:
                            raise ValueError("resume question mismatch")
                    else:
                        if corpus_retriever is not None:
                            retriever = corpus_retriever
                        elif key not in retrievers:
                            retrievers[key] = LexicalContextRetriever(row, dataset, actor.tokenizer,
                                                              config["models"]["actor"]["revision"])
                        if corpus_retriever is None:
                            retriever = retrievers[key]
                        engine = StrictEngine(actor, small, verifier=verifier, costs=costs, method=method,
                            max_steps=protocol["search"]["max_steps"],
                            max_expansions=protocol["search"]["max_expansions"])
                        print(json.dumps({"event": "episode_start", "dataset": dataset, "id": key,
                                          "method": method, "budget": budget}), flush=True)
                        limits = protocol["budgets"]
                        episode = engine.run(str(row["question"]), Ledger(budget,
                            input_limit=limits["input_tokens"], output_limit=limits["output_tokens"],
                            evidence_limit=limits["unique_evidence_tokens"],
                            final_input_reserve=limits["final_input_reserve"],
                            final_output_reserve=limits["final_output_reserve"]), retrieve=retriever)
                        episode.update(question_id=key, question=row["question"], dataset=dataset,
                                       method=method, budget=budget, track=args.track, seed=args.seed,
                                       offline_document_usage={"dense_forward_tokens": 0, "dense_gpu_seconds": 0.}
                                           if corpus_retriever is None else {"shared_index_manifest_sha256": hashlib.sha256(
                                               json.dumps(corpus_retriever.manifest, sort_keys=True).encode()).hexdigest()})
                        part = file.with_suffix(".json.part")
                        part.write_text(json.dumps(episode, ensure_ascii=False), encoding="utf-8")
                        part.replace(file)
                        print(json.dumps({"event": "episode_done", "dataset": dataset, "id": key,
                            "method": method, "budget": budget, "stop": episode["stop_reason"],
                            "seconds": episode["episode_seconds"]}), flush=True)
                    episodes.append(episode)
                evaluated = export_and_evaluate(root, dataset, rows, episodes,
                    directory / "evaluation", root / ".venv/bin/python")
                report = dict(dataset=dataset, method=method, budget=budget, track=args.track,
                    **evaluated, mean_episode_seconds=sum(e["episode_seconds"] for e in episodes) / len(episodes),
                    supported_count=sum(e["supported"] for e in episodes),
                    error_count=sum("failure" in e["stop_reason"] for e in episodes),
                    abstain_count=sum(e["answer"]["abstain"] for e in episodes))
                (directory / "metrics.json").write_text(json.dumps(report, indent=2))
                summary.append(report)
                (output / "summary.json").write_text(json.dumps(summary, indent=2))
                print(json.dumps(report), flush=True)
        if corpus_retriever is not None:
            corpus_retriever.close()
            retriever = None
            del corpus_retriever
            torch.cuda.empty_cache()
    (output / "COMPLETE.json").write_text(json.dumps({"complete": True, "runs": len(summary)}))

if __name__ == "__main__":
    main()
