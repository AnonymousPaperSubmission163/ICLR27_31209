"""Episode-global budget: zero means zero. Every generation is pre-reserved."""
from __future__ import annotations

from dataclasses import dataclass, field

class BudgetExhausted(RuntimeError):
    pass

@dataclass
class Ledger:
    call_limit: int
    input_limit: int = 262144
    output_limit: int = 32768
    evidence_limit: int = 32768
    final_input_reserve: int = 16384
    final_output_reserve: int = 512
    input_tokens: int = 0
    output_tokens: int = 0
    retrieval_calls: int = 0
    tool_calls: int = 0
    dense_tokens: int = 0
    dense_seconds: float = 0.
    events: list = field(default_factory=list)
    intervals: dict = field(default_factory=dict)

    def reserve_generation(self, inputs, outputs, *, final=False):
        rin = 0 if final else self.final_input_reserve
        rout = 0 if final else self.final_output_reserve
        if self.input_tokens + inputs + rin > self.input_limit or \
                self.output_tokens + outputs + rout > self.output_limit:
            raise BudgetExhausted("generation budget exhausted")
        self.input_tokens += inputs
        self.output_tokens += outputs
        return (inputs, outputs)

    def settle_generation(self, reservation, actual_input, actual_output, *, role, seconds, error=None):
        pin, pout = reservation
        if actual_input > pin or actual_output > pout:
            raise RuntimeError(f"backend exceeded reserved generation budget: reserved={reservation}, actual={(actual_input, actual_output)}")
        self.input_tokens += actual_input - pin
        self.output_tokens += actual_output - pout
        self.events.append(dict(kind="generation", role=role, input_tokens=actual_input,
                                output_tokens=actual_output, seconds=seconds, error=error))

    def acquire_call(self, mode):
        if self.retrieval_calls + self.tool_calls >= self.call_limit:
            raise BudgetExhausted("external-call budget exhausted")
        if mode == "retrieve":
            self.retrieval_calls += 1
        elif mode == "tool":
            self.tool_calls += 1
        else:
            raise ValueError(mode)

    @staticmethod
    def union_size(spans):
        end, total = -1, 0
        for start, stop in sorted(spans):
            if stop > max(start, end):
                total += stop - max(start, end)
            end = max(end, stop)
        return total

    @property
    def evidence_tokens(self):
        return sum(self.union_size(spans) for spans in self.intervals.values())

    def admit_evidence(self, doc_id, start, stop):
        if start < 0 or stop < start:
            raise ValueError("invalid evidence token span")
        old = self.intervals.get(doc_id, [])
        difference = self.union_size(old + [(start, stop)]) - self.union_size(old)
        if self.evidence_tokens + difference > self.evidence_limit:
            return False
        self.intervals.setdefault(doc_id, []).append((start, stop))
        return True

    def summary(self):
        return dict(input_tokens=self.input_tokens, output_tokens=self.output_tokens,
                    retrieval_calls=self.retrieval_calls, tool_calls=self.tool_calls,
                    dense_tokens=self.dense_tokens, dense_seconds=self.dense_seconds,
                    unique_evidence_tokens=self.evidence_tokens,
                    generation_seconds=sum(e.get("seconds", 0.) for e in self.events
                                           if e["kind"] == "generation"),
                    events=self.events)
