"""Deterministic lexical retrieval; no E5/LLM scores in the strict pipeline."""
from __future__ import annotations

import argparse
import json
import sqlite3
import uuid
from pathlib import Path

from route_planned_rag.corpus.build import file_sha256
from route_planned_rag.corpus.chunking import chunk_document
from route_planned_rag.corpus.retrieval import InMemoryBM25Retriever
from route_planned_rag.types import ObservedPassage
from .core import Evidence
from .qa import public_documents, qid


class LexicalContextRetriever:
    score_source = "deterministic_lexical"

    def __init__(self, row, dataset, tokenizer, revision):
        self.corpus_id = dataset + ":" + qid(row)
        passages, self.metadata = [], {}
        for doc, idx in public_documents(row, dataset):
            for c in chunk_document(doc, tokenizer, tokenizer_revision=revision, chunk_tokens=512, overlap_tokens=64):
                passages.append(ObservedPassage(chunk_id=c.chunk_id, doc_id=c.doc_id, text=c.text,
                    char_start=c.char_start, char_end=c.char_end, token_start=c.token_start,
                    token_end=c.token_end, sentence_ids=c.sentence_ids))
                full = tuple((sid, doc.text[a:z]) for sid, a, z in doc.sentence_char_spans
                             if c.char_start <= a and z <= c.char_end)
                self.metadata[c.chunk_id] = Evidence(c.chunk_id, c.text, c.title, tuple(x[0] for x in full),
                    idx, c.doc_id, c.token_start, c.token_end, sentences=full)
        self.retriever = InMemoryBM25Retriever({self.corpus_id: passages})

    def __call__(self, query, top_k):
        return [self.metadata[p.chunk_id] for p in self.retriever.retrieve(query, self.corpus_id, top_k)]


class LexicalCorpusRetriever:
    score_source = "deterministic_lexical"

    def __init__(self, root, dataset, revision):
        directory = Path(root) / "indexes" / dataset / revision
        self.manifest = json.loads((directory / "lexical_astar.json").read_text())
        metadata = directory / "logicgraph_metadata.json"
        index = directory / "lexical_astar.sqlite"
        if self.manifest.get("schema") != "logicgraph-lexical-v1" or self.manifest.get("status") != "complete":
            raise ValueError("strict corpus retrieval requires a completed lexical index")
        if self.manifest["metadata_manifest_sha256"] != file_sha256(metadata):
            raise ValueError("lexical index metadata contract changed")
        if self.manifest["index_sha256"] != file_sha256(index):
            raise ValueError("lexical index checksum mismatch")
        if self.manifest["metadata_database_sha256"] != file_sha256(directory / "logicgraph_metadata.sqlite"):
            raise ValueError("public metadata database changed after lexical indexing")
        self.db = sqlite3.connect(index.resolve().as_uri() + "?mode=ro", uri=True)
        self.metadata = sqlite3.connect((directory / "logicgraph_metadata.sqlite").resolve().as_uri() + "?mode=ro", uri=True)

    def __call__(self, query, top_k):
        # Tokenization and parameter binding prevent FTS syntax/SQL injection.
        terms = list(dict.fromkeys(InMemoryBM25Retriever._tokens(query)))
        if not terms:
            return []
        expression = " OR ".join('"' + t + '"' for t in terms)
        rows = self.db.execute("SELECT ids.chunk_id FROM terms JOIN ids ON ids.rowid=terms.rowid "
            "WHERE terms MATCH ? ORDER BY bm25(terms), ids.chunk_id LIMIT ?", (expression, int(top_k)))
        result = []
        for (chunk_id,) in rows:
            payload = self.metadata.execute("SELECT payload FROM evidence WHERE chunk_id=?", (chunk_id,)).fetchone()
            if payload is None:
                raise ValueError("lexical index references missing public evidence")
            item = json.loads(payload[0])
            item["sentence_ids"] = tuple(item["sentence_ids"])
            item["sentences"] = tuple(tuple(s) for s in item.get("sentences", []))
            result.append(Evidence(**item))
        return result

    def close(self):
        self.db.close()
        self.metadata.close()


def build(root, dataset, revision):
    root = Path(root).resolve()
    directory = (root / "indexes" / dataset / revision).resolve()
    if root.name != "logicrag" or not directory.is_relative_to(root):
        raise ValueError("index output must remain within the logicrag project")
    index, marker = directory / "lexical_astar.sqlite", directory / "lexical_astar.json"
    if index.exists() or marker.exists():
        raise FileExistsError("lexical index target exists; no automatic overwrite")
    metadata = directory / "logicgraph_metadata.json"
    contract = json.loads(metadata.read_text())
    # Only the existing public-evidence metadata is indexed; no question/gold file.
    source = directory / "logicgraph_metadata.sqlite"
    before = file_sha256(source)
    temp = directory / ("lexical_astar." + uuid.uuid4().hex + ".sqlite.part")
    read = sqlite3.connect(source.resolve().as_uri() + "?mode=ro", uri=True)
    write = sqlite3.connect(temp)
    count = 0
    try:
        write.execute("CREATE VIRTUAL TABLE terms USING fts5(title, text, content='')")
        write.execute("CREATE TABLE ids (chunk_id TEXT NOT NULL UNIQUE)")
        for chunk_id, payload in read.execute("SELECT chunk_id, payload FROM evidence ORDER BY chunk_id"):
            item = json.loads(payload)
            count += 1
            write.execute("INSERT INTO ids(rowid,chunk_id) VALUES (?,?)", (count, chunk_id))
            write.execute("INSERT INTO terms(rowid,title,text) VALUES (?,?,?)", (count, item["title"], item["text"]))
            if count % 50000 == 0:
                write.commit()
                print(json.dumps({"indexed_public_chunks": count}), flush=True)
        write.commit()
    finally:
        read.close()
        write.close()
    if before != file_sha256(source) or count != contract["chunks"]:
        raise ValueError("source metadata changed or chunk count mismatch; staging retained")
    # Exclusive link prevents replacing an index created concurrently.
    import os
    os.link(temp, index)
    temp.unlink()  # Exact disposable staging file created by this invocation.
    manifest = {"schema": "logicgraph-lexical-v1", "status": "complete", "chunks": count,
                "metadata_manifest_sha256": file_sha256(metadata), "metadata_database_sha256": before,
                "index_sha256": file_sha256(index), "score_source": "deterministic_lexical",
                "implementation": "sqlite_fts5_bm25", "sqlite_version": sqlite3.sqlite_version}
    with marker.open("x", encoding="utf-8") as output:
        json.dump(manifest, output, indent=2)
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--dataset", choices=["hotpotqa", "twowiki", "musique"], required=True)
    parser.add_argument("--revision", required=True)
    options = parser.parse_args()
    print(json.dumps(build(options.root, options.dataset, options.revision), indent=2))
