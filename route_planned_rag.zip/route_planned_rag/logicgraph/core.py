"""Typed graph constraints. Graph topology is not required to be acyclic."""
from __future__ import annotations

import math
import copy
from dataclasses import asdict, dataclass, field
from typing import Any

KINDS = {"implies", "requires", "equivalent", "mutex"}
MODES = {"retrieve", "reason", "tool"}
STATUSES = {"pending", "resolved", "failed", "stale", "conflict"}

def number(value, low=0., high=1.):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("expected a finite number")
    value = float(value)
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError("number outside allowed range")
    return value

@dataclass
class Node:
    id: str
    need: str
    step: int
    modes: tuple[str, ...]
    scope: str = "static"
    # OR over AND prerequisite sets; an empty list means no extra prerequisite.
    prerequisites: tuple[tuple[str, ...], ...] = ()
    status: str = "pending"
    value: str = ""
    evidence: tuple[str, ...] = ()
    premises: tuple[str, ...] = ()
    version: int = 0
    attempts: int = 0

@dataclass
class Edge:
    source: str
    target: str
    kind: str
    scope: str = "static"
    status: str = "proposed"
    rule: str = ""

@dataclass
class Graph:
    nodes: dict[str, Node]
    edges: list[Edge]
    goal_options: tuple[tuple[str, ...], ...]

    @classmethod
    def parse(cls, obj: dict, domain: str):
        if not isinstance(obj, dict) or not isinstance(obj.get("nodes"), list):
            raise ValueError("graph must contain nodes")
        if not 1 <= len(obj["nodes"]) <= 12:
            raise ValueError("graph must contain 1..12 information nodes")
        nodes = {}
        for raw in obj["nodes"]:
            nid = raw["id"]
            if not isinstance(nid, str) or not nid or nid in nodes:
                raise ValueError("invalid or duplicated node ID")
            need = raw["need"]
            step = raw["step"]
            modes = tuple(raw["modes"])
            if not isinstance(need, str) or not need.strip() or len(need) > 800:
                raise ValueError("invalid information need")
            if isinstance(step, bool) or not isinstance(step, int) or not 1 <= step <= 12:
                raise ValueError("invalid step")
            allowed = {"tool", "reason"} if domain == "terminal" else {"retrieve", "reason"}
            if not modes or len(modes) != len(set(modes)) or not set(modes) <= allowed:
                raise ValueError("invalid acquisition modes")
            groups = raw.get("prerequisites", [])
            if not isinstance(groups, list):
                raise ValueError("prerequisites must be a list of AND groups")
            # Flat node-ID lists have an unambiguous legacy meaning: one AND group.
            if groups and all(isinstance(x, str) for x in groups):
                groups = [groups]
            if any(not isinstance(group, list) or not all(isinstance(x, str) for x in group) for group in groups):
                raise ValueError("prerequisites must be [[node IDs], [alternative node IDs]]")
            pre = tuple(tuple(group) for group in groups)
            # A single empty AND group is logically true: equivalent to no extra prerequisite.
            if pre == ((),):
                pre = ()
            if any(not group for group in pre):
                raise ValueError("empty prerequisite group is ambiguous; use [] for none")
            nodes[nid] = Node(nid, need, step, modes, str(raw.get("scope", "static")), pre)
        edges = []
        for raw in obj.get("edges", []):
            kind = raw["kind"].lower()
            if kind not in KINDS or raw["source"] not in nodes or raw["target"] not in nodes:
                raise ValueError("invalid edge")
            if raw["source"] == raw["target"]:
                raise ValueError("self edge not allowed")
            # A compiler's relation is never automatically a validated inference rule.
            edges.append(Edge(raw["source"], raw["target"], kind,
                              str(raw.get("scope", "static")), "proposed", str(raw.get("rule", ""))))
        goals = tuple(tuple(group) for group in obj["goal_options"])
        if not goals or any(not group for group in goals):
            raise ValueError("goal_options must be nonempty OR-of-AND sets")
        refs = [x for group in goals for x in group]
        refs += [x for node in nodes.values() for group in node.prerequisites for x in group]
        if not set(refs) <= nodes.keys():
            raise ValueError("unknown prerequisite/goal ID")
        graph = cls(nodes, edges, goals)
        if not graph.ready(set()):
            raise ValueError("no initially executable node: ungrounded dependency cycle")
        return graph

    def resolved(self):
        return {k for k, v in self.nodes.items() if v.status == "resolved"}

    def mandatory(self, nid):
        return {e.source for e in self.edges if e.kind == "requires"
                and e.target == nid and e.status != "invalid"}

    def compatible(self, ids):
        selected = set(ids)
        return not any(e.kind == "mutex" and e.status != "invalid"
                       and {e.source, e.target} <= selected for e in self.edges)

    def ready(self, acquired=None):
        acquired = self.resolved() if acquired is None else set(acquired)
        result = []
        for nid, node in self.nodes.items():
            if nid in acquired or node.attempts >= 2:
                continue
            if not self.compatible(acquired | {nid}) or not self.mandatory(nid) <= acquired:
                continue
            if node.prerequisites and not any(set(group) <= acquired for group in node.prerequisites):
                continue
            result.append(nid)
        return sorted(result, key=lambda n: (self.nodes[n].step, n))

    def supported_structure(self):
        done = self.resolved()
        return self.compatible(done) and any(set(group) <= done for group in self.goal_options)

    def invalidate_environment(self, new_version):
        """Conservative: ALL dynamic facts and their inferred descendants become stale."""
        invalid = {nid for nid, node in self.nodes.items()
                   if node.scope != "static" and node.status == "resolved"}
        while True:
            descendants = {nid for nid, node in self.nodes.items()
                           if set(node.premises) & invalid and node.status == "resolved"}
            if descendants <= invalid:
                break
            invalid |= descendants
        for nid in invalid:
            self.nodes[nid].status = "stale"
        for edge in self.edges:
            if edge.scope != "static" and edge.status == "validated":
                edge.status = "proposed"
        return sorted(invalid)

    def view(self):
        return {"nodes": [asdict(x) for x in self.nodes.values()],
                "edges": [asdict(x) for x in self.edges],
                "goal_options": self.goal_options}

@dataclass(frozen=True)
class Evidence:
    id: str
    text: str
    title: str = ""
    sentence_ids: tuple[int, ...] = ()
    paragraph_idx: int | None = None
    doc_id: str = ""
    token_start: int = 0
    token_end: int = 0
    environment_version: int = 0
    dynamic: bool = False
    sentences: tuple[tuple[int, str], ...] = ()

@dataclass
class State:
    graph: Graph
    evidence: dict[str, Evidence] = field(default_factory=dict)
    conflicts: list[dict[str, Any]] = field(default_factory=list)
    version: int = 0
    route: tuple[str, ...] = ()
    history: list[dict[str, Any]] = field(default_factory=list)
    graph_revision: int = 0

    def revise(self, replacement, reopen, reason):
        """Atomic, versioned graph repair. Old observations are never removed.

        A replacement contains information needs, never accepted values. Existing
        IDs cannot be deleted/recycled. Changed needs and their dependents must be
        grounded again; unaffected facts retain their provenance and attempts.
        """
        old = self.graph
        if not old.nodes.keys() <= replacement.nodes.keys():
            raise ValueError("graph repair cannot delete existing node IDs")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > 240:
            raise ValueError("graph repair requires a concise public-state justification")
        if not isinstance(reopen, list) or not set(reopen) <= old.nodes.keys():
            raise ValueError("reopen must reference existing nodes")
        def signature(n):
            return n.need, n.step, n.modes, n.scope, n.prerequisites
        affected = set(reopen) | {nid for nid in old.nodes
            if signature(old.nodes[nid]) != signature(replacement.nodes[nid])}
        def edge_key(e):
            return e.source, e.target, e.kind, e.scope, e.rule
        old_edges = {edge_key(e): e for e in old.edges if e.status != "invalid"}
        new_edges = {edge_key(e): e for e in replacement.edges}
        for key in old_edges.keys() ^ new_edges.keys():
            source, target, kind, _, _ = key
            affected.add(target)
            if kind in {"equivalent", "mutex"}:
                affected.add(source)
        if not affected and old.nodes.keys() == replacement.nodes.keys() and old.goal_options == replacement.goal_options:
            raise ValueError("graph repair makes no change")
        while True:
            dependents = {nid for g in (old, replacement) for nid, node in g.nodes.items()
                if (set(node.premises) | g.mandatory(nid) |
                    {p for group in node.prerequisites for p in group}) & affected}
            if dependents <= affected:
                break
            affected |= dependents
        before = old.view()
        for nid in old.nodes.keys() & replacement.nodes.keys():
            if nid not in affected:
                replacement.nodes[nid] = copy.deepcopy(old.nodes[nid])
        for edge in replacement.edges:
            previous = old_edges.get(edge_key(edge))
            if previous and not {edge.source, edge.target} & affected:
                edge.status = previous.status
        self.graph_revision += 1
        self.history.append({"kind": "graph_revision", "revision": self.graph_revision,
            "reason": reason, "reopened": sorted(affected), "before": before,
            "after": replacement.view()})
        self.graph, self.route = replacement, ()
        return sorted(affected)

    def resolve(self, nid, obj, *, ready_before_execution=False):
        node = self.graph.nodes[nid]
        if obj.get("status") not in {"resolved", "pending", "conflict"}:
            raise ValueError("invalid resolution status")
        citations = tuple(obj.get("evidence_ids", []))
        premises = tuple(obj.get("premise_ids", []))
        if not set(citations) <= self.evidence.keys():
            raise ValueError("unknown evidence citation")
        if not set(premises) <= self.graph.resolved():
            raise ValueError("ungrounded premise")
        if any(self.evidence[x].dynamic and self.evidence[x].environment_version != self.version
               for x in citations):
            raise ValueError("stale environment evidence")
        status = obj["status"]
        if status == "resolved":
            if not citations and not premises:
                raise ValueError("a resolved fact requires observed evidence or grounded premises")
            if not self.graph.compatible(self.graph.resolved() | {nid}):
                raise ValueError("resolution would violate mutex")
            if nid not in self.graph.ready() and node.status != "resolved" and not ready_before_execution:
                raise ValueError("unmet prerequisites")
            if not isinstance(obj.get("value"), str) or not obj["value"].strip():
                raise ValueError("resolved node has no value")
        if status == "conflict":
            self.conflicts.append({"node": nid, "citations": citations,
                                   "description": str(obj.get("value", "")), "version": self.version})
        node.status, node.value = status, str(obj.get("value", ""))
        node.evidence, node.premises, node.version = citations, premises, self.version
        return node

    def propagate(self, source, target, kind, conclusion, citations, rule_validated, scope_validated):
        """No Requires or unvalidated-proposal truth propagation."""
        if kind not in {"implies", "equivalent"} or not rule_validated or not scope_validated:
            return False
        edge = next((e for e in self.graph.edges if e.kind == kind and
                     ((e.source == source and e.target == target) or
                      (kind == "equivalent" and e.source == target and e.target == source))
                     and e.status != "invalid"), None)
        if edge is None or source not in self.graph.resolved() or not edge.rule:
            return False
        if not edge.scope == self.graph.nodes[source].scope == self.graph.nodes[target].scope:
            return False
        if target in self.graph.resolved():
            # A propagation must not silently overwrite an already accepted binding.
            return False
        if edge.scope != "static" and self.graph.nodes[source].version != self.version:
            return False
        self.resolve(target, {"status": "resolved", "value": conclusion,
                             "evidence_ids": citations, "premise_ids": [source]})
        edge.status = "validated"
        return True

    def view(self):
        return {"graph": self.graph.view(), "environment_version": self.version,
                "graph_revision": self.graph_revision,
                "evidence": [asdict(e) for e in self.evidence.values()],
                "conflicts": self.conflicts, "current_route": self.route}
