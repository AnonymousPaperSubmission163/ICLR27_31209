"""XGrammar decoding adapter; no changes to model weights or chat templates."""
import json
import time
from collections import OrderedDict

from route_planned_rag.models.json_actor import GenerationResult, TransformersGenerationBackend

class ConstrainedBackend(TransformersGenerationBackend):
    def __init__(self, model, tokenizer):
        super().__init__(model, tokenizer)
        import xgrammar as xgr
        self.xgr = xgr
        vocab_size = int(model.get_output_embeddings().weight.shape[0])
        info = xgr.TokenizerInfo.from_huggingface(tokenizer, vocab_size=vocab_size)
        # Per-example ID enums create distinct grammars. Bound both cache layers.
        self.compiler = xgr.GrammarCompiler(info, max_threads=4, cache_enabled=False)
        self.grammars = OrderedDict()

    def generate_json(self, prompt, *, temperature, top_p, max_tokens, schema):
        import torch
        import xgrammar.contrib.hf
        key = json.dumps(schema, sort_keys=True)
        started = time.perf_counter()
        if key not in self.grammars:
            self.grammars[key] = self.compiler.compile_json_schema(key,
                any_whitespace=False, indent=None, separators=(",", ":"))
        self.grammars.move_to_end(key)
        while len(self.grammars) > 32:
            self.grammars.popitem(last=False)
        processor = xgrammar.contrib.hf.LogitsProcessor(self.grammars[key])
        batch = self.tokenizer.apply_chat_template([{"role": "user", "content": prompt}],
            tokenize=True, add_generation_prompt=True, return_tensors="pt", return_dict=True)
        batch = batch.to(next(self.model.parameters()).device)
        with torch.inference_mode():
            output = self.model.generate(**batch, do_sample=temperature > 0,
                temperature=temperature if temperature > 0 else None,
                top_p=top_p if temperature > 0 else None, max_new_tokens=max_tokens,
                pad_token_id=self.tokenizer.eos_token_id, logits_processor=[processor])
        torch.cuda.synchronize()
        completion = output[0, batch["input_ids"].shape[1]:]
        return GenerationResult(self.tokenizer.decode(completion, skip_special_tokens=True),
            int(batch["attention_mask"].sum().item()), int(completion.numel()), time.perf_counter() - started)
