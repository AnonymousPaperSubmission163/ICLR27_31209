"""LogicGraph v3: step-aware information acquisition with audited costs."""

