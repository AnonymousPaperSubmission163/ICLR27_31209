"""Explicit same-backbone adaptations; not the original papers' published results."""
import time
from dataclasses import asdict
from .core import Graph, State
from .engine import Engine, READER
from .ledger import BudgetExhausted
from .model import JsonFailure, object_fields

IRCOT = """Continue the chain of thought by EXACTLY ONE concise reasoning sentence, using the question
and observed passages. This sentence will be used as the next retrieval query (IRCoT).
Return {"thought":"one next reasoning sentence","finished":false,"evidence_ids":["observed ID"]}.
finished=true only if the available passages and reasoning suffice for a final answer.
A thought is provisional reasoning, NOT new evidence. Do not invent sources or cite predicted outcomes."""

class IRCoT(Engine):
    def run(self, question, ledger, retrieve=None, execute=None, progress=None):
        if execute is not None or retrieve is None:
            raise ValueError("IRCoT is a QA-only baseline")
        start = time.perf_counter()
        state = State(Graph({}, [], ()))
        chain, trace, query = [], [], question
        supported, reason = False, "call_budget"
        answer = {"answer": "", "evidence_ids": [], "supporting_facts": [], "evidences": [], "abstain": True}
        try:
            for step in range(ledger.call_limit):
                ledger.acquire_call("retrieve")
                candidates, usage = retrieve(query, 20)
                ledger.dense_tokens += usage.input_tokens
                ledger.dense_seconds += usage.gpu_seconds
                # No reranker in this adaptation: only the same top-five evidence delivery.
                for e in candidates[:5]:
                    if ledger.admit_evidence(e.doc_id, e.token_start, e.token_end):
                        state.evidence[e.id] = e
                payload = self.payload(question, state, chain=chain)
                def validate(obj):
                    object_fields(obj, {"thought", "finished", "evidence_ids"})
                    if not isinstance(obj["thought"], str) or not set(obj["evidence_ids"]) <= state.evidence.keys():
                        raise ValueError("invalid thought or citation")
                    return obj
                thought = self.actor.ask("ircot_step", IRCOT, payload, ledger, max_output=512, validator=validate)
                chain.append(thought["thought"])
                trace.append({"step": step, "query": query, "thought": thought,
                              "observed_evidence_ids": list(state.evidence)})
                supported = thought["finished"] is True and bool(thought["evidence_ids"])
                if supported:
                    reason = "supported"
                    break
                query = thought["thought"]
                if not query.strip():
                    reason = "empty_next_thought"
                    break
                if progress:
                    progress(ledger.summary())
        except (BudgetExhausted, JsonFailure, ValueError, KeyError) as exc:
            reason = type(exc).__name__ + ": " + str(exc)
        try:
            payload = self.payload(question, state)
            visible = {e["id"]: e for e in payload["state"]["evidence"]}
            def validate_answer(obj):
                object_fields(obj, {"answer", "evidence_ids", "supporting_facts", "abstain"})
                if not set(obj["evidence_ids"]) <= visible.keys():
                    raise ValueError("unobserved citation")
                for sf in obj["supporting_facts"]:
                    if not set(sf["sentence_ids"]) <= set(visible[sf["evidence_id"]]["sentence_ids"]):
                        raise ValueError("unobserved sentence")
                if obj["abstain"] is True:
                    obj["answer"] = ""
                return obj
            answer = self.actor.ask("final_reader", READER, payload, ledger, max_output=512,
                                    validator=validate_answer, final=True)
        except (BudgetExhausted, JsonFailure, ValueError, KeyError) as exc:
            reason += "; final_reader=" + str(exc)
        return {"answer": answer, "supported": supported, "stop_reason": reason,
                "trace": trace, "state": state.view(), "usage": ledger.summary(),
                "episode_seconds": time.perf_counter() - start,
                "adaptation": "IRCoT-style alternating one-sentence reasoning/retrieval; zero-shot frozen Mistral + E5"}
