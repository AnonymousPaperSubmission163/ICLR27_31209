"""Model loading and local cost calibration; no learned scorer weights are implied."""
import hashlib
import json
import statistics
from pathlib import Path

from route_planned_rag.models.e5 import E5MistralEncoder
from route_planned_rag.models.json_actor import TransformersGenerationBackend
from route_planned_rag.models.loaders import load_mistral3_generation
from .model import FrozenJSON
from .constrained import ConstrainedBackend

def load_models(config, *, device=0, with_encoder=True, with_scorer=True):
    cache = Path(config["project"]["root"]) / "cache/huggingface"
    models = []
    for role in (("actor", "scorer") if with_scorer else ("actor",)):
        item = config["models"][role]
        tokenizer, model = load_mistral3_generation(item, cache_dir=cache, device=device)
        models.append(FrozenJSON(ConstrainedBackend(model, tokenizer), tokenizer,
                                 item["repo_id"] + "@" + item["revision"]))
    if not with_scorer:models.append(None)
    encoder = None
    if with_encoder:
        item = config["models"]["retriever"]
        encoder = E5MistralEncoder(item["repo_id"], item["revision"],
            query_instruction=item["query_instruction"], max_tokens=item["max_tokens"],
            device=f"cuda:{device}", dtype=item["dtype"], cache_dir=str(cache))
    return *models, encoder

def calibrate(actor, small, encoder, questions, path):
    """Hardware local profile from train-internal-dev questions ONLY, no answer labels."""
    samples = []
    for role, model in (("actor", actor), ("small", small)):
        for question in questions:
            prompt = ("List, in one short JSON object, the information needed to answer this question. "
                      "Do not answer it. Question: " + question)
            from .schemas import arr, obj, S
            output = model.backend.generate_json(prompt, temperature=0., top_p=.9, max_tokens=256,
                                                  schema=obj(needs=arr(S, 1, 8)))
            samples.append(dict(role=role, input_tokens=output.input_tokens,
                                output_tokens=output.output_tokens, seconds=output.gpu_seconds))
    per_token = statistics.median(s["seconds"] / max(1, s["output_tokens"]) for s in samples)
    query_seconds = []
    if encoder:
        for question in questions:
            _, usage = encoder.encode([question], is_query=True)
            query_seconds.append(usage.gpu_seconds)
    # Marginal local execution excludes past planning and offline indexing; both are separately metered.
    # The generation token estimate is supplied per node by the frozen predictor.
    profile = {"unit": "serial_wall_seconds", "generation_seconds_per_token": per_token,
               "reason": 0., "retrieve": statistics.median(query_seconds) if query_seconds else 0.,
               "active_domain": "qa_only",
               "calibration_split": "train_internal_dev", "samples": samples,
               "query_seconds": query_seconds,
               "question_hashes": [hashlib.sha256(q.encode()).hexdigest() for q in questions]}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(profile, indent=2))
    return profile
