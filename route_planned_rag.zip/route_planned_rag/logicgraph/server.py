"""Authenticated loopback-only frozen-model RPC, for the host-side Harbor agent."""
import argparse
import json
import os
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class RPC:
    def __init__(self, endpoint, token, role):
        self.endpoint, self.token, self.role = endpoint, token, role

    def call(self, operation, **payload):
        request = urllib.request.Request(self.endpoint + "/" + operation,
            data=json.dumps({"role": self.role, **payload}).encode(),
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + self.token})
        with urllib.request.urlopen(request, timeout=600) as response:
            return json.load(response)

class RemoteBackend(RPC):
    def generate_json(self, prompt, *, temperature, top_p, max_tokens, schema):
        from route_planned_rag.models.json_actor import GenerationResult
        return GenerationResult(**self.call("generate", prompt=prompt, temperature=temperature,
                                           top_p=top_p, max_tokens=max_tokens, schema=schema))

    def generate(self, prompt, *, temperature, top_p, max_tokens):
        from route_planned_rag.models.json_actor import GenerationResult
        return GenerationResult(**self.call("generate", prompt=prompt, temperature=temperature,
                                           top_p=top_p, max_tokens=max_tokens))

class RemoteTokenizer(RPC):
    def apply_chat_template(self, messages, **kwargs):
        return [0] * self.call("count", messages=messages)["count"]

    def encode(self, text, **kwargs):
        return self.call("encode", text=text)["ids"]

    def decode(self, ids, **kwargs):
        return self.call("decode", ids=ids)["text"]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--port", type=int, default=18743)
    args = parser.parse_args()
    import yaml
    from dataclasses import asdict
    from .runtime import load_models
    config = yaml.safe_load(open(args.config))
    actor, small, _ = load_models(config, with_encoder=False)
    models, lock = {"actor": actor, "small": small}, threading.Lock()
    secret = os.environ["LOGICGRAPH_RPC_TOKEN"]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *values):
            pass

        def do_POST(self):
            if self.headers.get("Authorization") != "Bearer " + secret:
                self.send_error(403)
                return
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= 4 * 1024 * 1024:
                    raise ValueError("invalid payload size")
                obj = json.loads(self.rfile.read(size))
                model = models[obj["role"]]
                with lock:
                    if self.path == "/generate":
                        if not 1 <= obj["max_tokens"] <= 4096:
                            raise ValueError("invalid generation limit")
                        if model.count(obj["prompt"]) + obj["max_tokens"] > 16384:
                            raise ValueError("context exceeds protocol limit")
                        if "schema" in obj:
                            def check_schema(value, depth=0):
                                if depth > 16:
                                    raise ValueError("schema nesting exceeds fixed limit")
                                if isinstance(value, dict):
                                    if any(k in value for k in ("$ref", "$defs", "pattern")):
                                        raise ValueError("recursive/reference/pattern schemas are not permitted")
                                    for child in value.values():
                                        check_schema(child, depth + 1)
                                elif isinstance(value, list):
                                    for child in value:
                                        check_schema(child, depth + 1)
                            if len(json.dumps(obj["schema"])) > 200000:
                                raise ValueError("schema size exceeds limit")
                            check_schema(obj["schema"])
                            result = asdict(model.backend.generate_json(obj["prompt"], temperature=obj["temperature"],
                                top_p=obj["top_p"], max_tokens=obj["max_tokens"], schema=obj["schema"]))
                        else:
                            result = asdict(model.backend.generate(obj["prompt"], temperature=obj["temperature"],
                                top_p=obj["top_p"], max_tokens=obj["max_tokens"]))
                    elif self.path == "/count":
                        if len(obj["messages"]) != 1 or obj["messages"][0]["role"] != "user":
                            raise ValueError("single user message required")
                        result = {"count": model.count(obj["messages"][0]["content"])}
                    elif self.path == "/encode":
                        result = {"ids": model.tokenizer.encode(obj["text"], add_special_tokens=False)}
                    elif self.path == "/decode":
                        result = {"text": model.tokenizer.decode(obj["ids"], skip_special_tokens=True)}
                    else:
                        raise ValueError("unknown RPC operation")
                body = json.dumps(result).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as exc:
                self.send_error(400, str(exc))
    print("MODEL_RPC_READY", flush=True)
    ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()

if __name__ == "__main__":
    main()
