"""Bounded, deterministic relation grammar. Unsupported language stays unknown.

These rules are deliberately incomplete. No free-text LLM triple is a trusted
fact, no label is read, and lexical overlap alone can never accept a claim.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass

from .verification import Verification


def norm(text):
    return re.sub(r"\s+", " ", text).strip().strip('"“”').casefold()


@dataclass(frozen=True)
class Fact:
    subject: str
    relation: str
    value: str
    evidence_id: str
    start: int
    end: int
    rule: str


# Finite relation inventory; same inventory across every dataset and condition.
RELATIONS = {
    "birth year": "birth_year", "birthplace": "birth_place", "place of birth": "birth_place",
    "death year": "death_year", "director": "director", "author": "author",
    "capital": "capital", "country": "country", "founding year": "founding_year",
}


def need_spec(need, state=None):
    """Parse ONLY explicit information-slot syntax; do not guess semantic roles."""
    text = need.strip().rstrip('.').strip()
    if state is not None:
        values = {n['id']: n['value'] for n in state['graph']['nodes'] if n['status'] == 'resolved'}
        unknown = False
        def substitute(match):
            nonlocal unknown
            if match[1] not in values:
                unknown = True
                return match[0]
            return values[match[1]]
        text = re.sub(r'\{(n\d+)\}', substitute, text)
        if unknown:
            return None
    match = re.fullmatch(r'(?:the )?(' + '|'.join(RELATIONS) + r') of (.+)', text, re.I)
    if match:
        return RELATIONS[match[1].casefold()], match[2].strip()
    return None


def question_spec(question):
    text = question.strip().rstrip('?').strip()
    patterns = [
        (r'Who (?:is|was) the (director|author) of (.+)', 'slot'),
        (r'Who directed (.+)', 'director'), (r'Who wrote (.+)', 'author'),
        (r'(?:In what year|In which year|What year) was (.+) born', 'birth_year'),
        (r'Where was (.+) born', 'birth_place'),
        (r'(?:In what year|In which year|What year) did (.+) die', 'death_year'),
        (r'What is the capital of (.+)', 'capital'),
        (r'(?:In which country|In what country) is (.+) (?:located|situated)', 'country'),
        (r'(?:Which|What) country is (.+) (?:in|located in)', 'country'),
        (r'(?:In what year|In which year|What year) was (.+) founded', 'founding_year'),
    ]
    for pattern, relation in patterns:
        match = re.fullmatch(pattern, text, re.I)
        if match:
            return (match[1].casefold(), match[2]) if relation == 'slot' else (relation, match[1])
    match = re.fullmatch(r'Who was born (first|earlier|later),? (.+?) or (.+)', text, re.I)
    if match:
        return ('later_birth' if match[1].casefold() == 'later' else 'earlier_birth', match[2], match[3])
    match = re.fullmatch(r'(?:In which country|In what country|What country) was (.+) born(?: in)?', text, re.I)
    if match:
        return ('birth_country', match[1])
    return None


def evidence_facts(evidence):
    """Anchored grammar patterns, with exact offsets in the original chunk.

    Deliberately excludes negation, hedging, dates without an explicit relation,
    multi-valued directors/authors, pronoun resolution and bare substring matches.
    """
    output = []
    name = r'[^\n;()!?]+?'
    patterns = [
        (rf'(?P<s>{name}) was born in (?P<v>[12]\d{{3}})\.?', 'birth_year'),
        (rf'(?P<s>{name}) died in (?P<v>[12]\d{{3}})\.?', 'death_year'),
        (rf'(?P<s>{name}) was founded in (?P<v>[12]\d{{3}})\.?', 'founding_year'),
        (rf'(?P<s>{name}) (?:is|was) the capital of (?P<v>{name})\.?', 'capital_of'),
        (rf'(?P<s>{name}) (?:is|was) located in the country of (?P<v>{name})\.?', 'country'),
        (rf'(?P<s>{name}) was born in (?P<v>[A-Z][^\n;()!?\d]+?)\.?', 'birth_place'),
        (rf'(?P<s>{name}) was directed by (?P<v>{name})\.?', 'director'),
        (rf'(?P<s>{name}) was written by (?P<v>{name})\.?', 'author'),
    ]
    for item in evidence:
        text = item['text']
        # Use sentence spans when supplied; a full anchored sentence is required.
        spans = []
        for found in re.finditer(r'[^\n!?]+?(?:\.(?=\s|$)|$)', text):
            raw = found[0]
            if raw.strip():
                left = len(raw) - len(raw.lstrip())
                spans.append((found.start() + left, raw.strip()))
        for start, sentence in spans:
            for pattern, relation in patterns:
                match = re.fullmatch(pattern, sentence)
                if not match:
                    continue
                subject, value = match['s'].strip(), match['v'].strip().rstrip('.')
                # Do not turn a conjunctive name list into a singleton binding.
                if any(re.search(r'\b(and|or|not|allegedly|reportedly)\b', x, re.I) for x in (subject, value)):
                    continue
                if relation == 'capital_of':
                    subject, value, relation = value, subject, 'capital'
                output.append(Fact(subject, relation, value, item['id'], start, start + len(sentence), 'anchored-' + relation))
    return output


def derive(spec, facts):
    if spec is None:
        return None, [], 'unsupported_question_or_need_grammar'
    relation = spec[0]
    if relation in {'earlier_birth', 'later_birth'}:
        left, lp, le = derive(('birth_year', spec[1]), facts)
        right, rp, re_ = derive(('birth_year', spec[2]), facts)
        if left is None or right is None:
            return None, lp + rp, le if left is None else re_
        if left == right:
            return None, lp + rp, 'equal_years_do_not_determine_birth_order'
        select_left = int(left) < int(right) if relation == 'earlier_birth' else int(left) > int(right)
        return spec[1] if select_left else spec[2], lp + rp, 'integer_comparison'
    if relation == 'birth_country':
        place, first, error = derive(('birth_place', spec[1]), facts)
        if place is None:
            return None, first, error
        country, second, error = derive(('country', place), facts)
        return country, first + second, error
    found = [f for f in facts if f.relation == relation and norm(f.subject) == norm(spec[1])]
    values = {norm(f.value) for f in found}
    if len(values) > 1:
        return None, found, 'conflicting_bindings'
    if not found:
        return None, [], 'missing_rule_grounded_fact'
    return found[0].value, found, 'grounded_relation'


def render_statement(spec, value):
    if spec is None:
        return None
    relation, subject = spec[:2]
    forms = {'birth_year': '{s} was born in {v}.', 'death_year': '{s} died in {v}.',
             'birth_place': '{s} was born in {v}.', 'director': '{s} was directed by {v}.',
             'author': '{s} was written by {v}.', 'country': '{s} is located in the country of {v}.',
             'capital': '{v} is the capital of {s}.', 'founding_year': '{s} was founded in {v}.'}
    return forms[relation].format(s=subject, v=value) if relation in forms else None


class RuleVerifier:
    verifier_id = 'bounded-anchored-relation-rules'
    version = '1'
    implementation_kind = 'executable_rules'
    supports_qa_semantics = True  # Only the declared grammar; everything else is unknown.

    def begin_episode(self):
        self.calls = 0

    def usage(self):
        return {'verification_calls': getattr(self, 'calls', 0), 'learned_forward_tokens': 0}

    def _check(self, spec, state, candidate, field):
        self.calls = getattr(self, 'calls', 0) + 1
        # Premise facts must ultimately trace to public evidence, not model text.
        permitted = set(candidate['evidence_ids'])
        nodes = {n['id']: n for n in state['graph']['nodes']}
        stack, seen = list(candidate.get('premise_ids', [])), set()
        while stack:
            nid = stack.pop()
            if nid in seen or nid not in nodes or nodes[nid]['status'] != 'resolved':
                continue
            seen.add(nid)
            permitted.update(nodes[nid]['evidence'])
            stack.extend(nodes[nid]['premises'])
        facts = evidence_facts(state['evidence'])
        answer, proof, reason = derive(spec, facts)
        certificate = {'kind': 'rule_derivation', 'spec': spec, 'facts': [asdict(f) for f in proof],
                       'operation': reason, 'scope': 'bounded_grammar_not_general_natural_language'}
        if answer is None:
            return Verification('unknown', reason, certificate)
        if not {f.evidence_id for f in proof} <= permitted:
            return Verification('unknown', 'candidate_did_not_cite_required_proof', certificate)
        if norm(candidate[field]) != norm(answer):
            return Verification('rejected', 'candidate_differs_from_rule_derived_value', certificate)
        certificate['derived_value'] = answer
        return Verification('accepted', 'bounded_rule_proof', certificate)

    def verify_node(self, *, question, node_id, state, candidate):
        node = next(n for n in state['graph']['nodes'] if n['id'] == node_id)
        return self._check(need_spec(node['need'], state), state, candidate, 'value')

    def verify_answer(self, *, question, state, candidate):
        # Original question, not merely the LLM-proposed graph goals.
        return self._check(question_spec(question), state, candidate, 'answer')
