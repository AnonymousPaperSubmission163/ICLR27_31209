"""Public-only QA inputs and private official evaluation in separate post-run subprocesses."""
from __future__ import annotations
import hashlib
import json
import sqlite3
import subprocess
import ast
from dataclasses import asdict
from pathlib import Path

from route_planned_rag.corpus.chunking import SourceDocument, chunk_document
from route_planned_rag.data.adapters import iter_raw_json, normalized_question_key
from route_planned_rag.models.live_retriever import LiveDenseRetriever
from route_planned_rag.types import ObservedPassage
from .core import Evidence

def qid(row):
    return str(row.get("_id", row.get("id")))

def paths(root, dataset):
    if dataset == "musique":
        return (root / "data/raw/musique/data/musique_ans_v1.0_train.jsonl",
                root / "data/raw/musique/data/musique_ans_v1.0_dev.jsonl")
    if dataset == "twowiki":
        return root / "data/raw/2wiki/data/train.json", root / "data/raw/2wiki/data/dev.json"
    return root / "data/raw/hotpotqa/hotpot_train_v1.1.json", root / "data/raw/hotpotqa/hotpot_dev_distractor_v1.json"

def frozen_ids(root, dataset, role, count):
    """Reuse existing frozen IDs; freeze only HotpotQA extension before observing outcomes."""
    if dataset != "hotpotqa":
        manifest = json.loads((root / "data/manifests/frozen_splits_v1.json").read_text())
        ids = manifest["datasets"][dataset][role + "_ids"]
    else:
        path = root / "data/manifests/hotpotqa_splits_v3.json"
        if not path.exists():
            train_path, dev_path = paths(root, dataset)
            train, dev = list(iter_raw_json(train_path)), list(iter_raw_json(dev_path))
            dev_questions = {normalized_question_key(r["question"]) for r in dev}
            seen = set()
            candidates = []
            for row in train:
                key = normalized_question_key(row["question"])
                if key not in dev_questions and key not in seen:
                    candidates.append(qid(row))
                    seen.add(key)
            rank = lambda ids: sorted(ids, key=lambda x: hashlib.sha256(
                ("20260904:" + x).encode()).hexdigest())
            training, evaluation = rank(candidates), rank([qid(r) for r in dev])
            frozen = {"initial_train_ids": training[:200], "full_train_ids": training[:1000],
                      "internal_dev_ids": training[1000:1200],
                      "e1_official_dev_ids": evaluation[:200], "e2_official_dev_ids": evaluation[:1000],
                      "seed": 20260904, "cross_split_normalized_question_overlap": 0,
                      "definition": "train-internal-dev excluded from both training and official dev"}
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x") as f:
                json.dump(frozen, f, indent=2)
        ids = json.loads(path.read_text())[role + "_ids"]
    if count > len(ids):
        raise ValueError("requested count exceeds frozen split")
    return ids[:count]

def load_selected(root, dataset, role, ids):
    train, dev = paths(root, dataset)
    source = dev if role.startswith(("e1_", "e2_")) else train
    wanted = set(ids)
    rows = {qid(row): row for row in iter_raw_json(source) if qid(row) in wanted}
    if rows.keys() != wanted:
        raise ValueError("missing frozen question IDs")
    return [rows[x] for x in ids]

def public_documents(row, dataset):
    """Explicit allowlist prevents supporting labels/decomposition/answers reaching runtime."""
    result = []
    if dataset == "musique":
        for p in row["paragraphs"]:
            text, title, idx = p["paragraph_text"], p["title"], int(p["idx"])
            result.append((SourceDocument(f"musique:{qid(row)}:{idx}", title, text), idx))
    else:
        for title, sentences in row["context"]:
            text, spans, offset = "", [], 0
            for i, sentence in enumerate(sentences):
                # Match source serialization; Hotpot sentences include their own whitespace.
                prefix = "" if dataset == "hotpotqa" or i == 0 else " "
                text += prefix + sentence
                offset += len(prefix)
                spans.append((i, offset, offset + len(sentence)))
                offset += len(sentence)
            prefix = "hotpotqa" if dataset == "hotpotqa" else "2wiki"
            result.append((SourceDocument(prefix + ":" + title, title, text, tuple(spans)), None))
    return result

class ContextRetriever:
    def __init__(self, row, dataset, encoder, tokenizer, revision):
        self.corpus_id = dataset + ":" + qid(row)
        passages, self.metadata = [], {}
        for doc, idx in public_documents(row, dataset):
            for c in chunk_document(doc, tokenizer, tokenizer_revision=revision,
                                    chunk_tokens=512, overlap_tokens=64):
                passages.append(ObservedPassage(chunk_id=c.chunk_id, doc_id=c.doc_id, text=c.text,
                    char_start=c.char_start, char_end=c.char_end, token_start=c.token_start,
                    token_end=c.token_end, sentence_ids=c.sentence_ids))
                full_sentences = tuple((sid, doc.text[a:z]) for sid, a, z in doc.sentence_char_spans
                                       if a >= c.char_start and z <= c.char_end)
                self.metadata[c.chunk_id] = Evidence(c.chunk_id, c.text, c.title,
                    tuple(x[0] for x in full_sentences), idx, c.doc_id, c.token_start, c.token_end,
                    sentences=full_sentences)
        self.retriever = LiveDenseRetriever(self.corpus_id, passages, encoder, batch_size=8)

    def __call__(self, query, top_k):
        result = self.retriever.retrieve(query, self.corpus_id, top_k)
        return [self.metadata[p.chunk_id] for p in result], self.retriever.last_query_usage

def export_and_evaluate(root, dataset, rows, episodes, directory, evaluator_python):
    """Called only AFTER actor episodes finish. No result feeds back into the search."""
    directory.mkdir(parents=True, exist_ok=True)
    if len(rows) != len(episodes) or any(qid(r) != e["question_id"] for r, e in zip(rows, episodes)):
        raise ValueError("evaluation must retain every planned question in exactly the same order")
    predictions = {"answer": {}, "sp": {}, "evidence": {}}
    musique_preds = []
    for row, episode in zip(rows, episodes):
        key = qid(row)
        answer = episode["answer"]
        evidence = {x["id"]: x for x in (episode.get("state") or {}).get("evidence", [])}
        predictions["answer"][key] = answer["answer"]
        sf = set()
        for fact in answer.get("supporting_facts", []):
            e = evidence.get(fact["evidence_id"])
            if e:
                sf.update((e["title"], int(i)) for i in fact["sentence_ids"]
                          if i in e["sentence_ids"])
        predictions["sp"][key] = sorted(sf)
        predictions["evidence"][key] = answer.get("evidences", [])
        selected = [evidence[eid] for eid in answer.get("evidence_ids", []) if eid in evidence]
        supports = sorted({e["paragraph_idx"] for e in selected if e["paragraph_idx"] is not None})
        if dataset == "musique":
            from route_planned_rag.data.pooling import _document_id
            # Official paragraph-ID conversion is evaluator-side only. The pooled actor never sees
            # per-question associations or supporting flags.
            mapping = {_document_id("musique", p["title"], p["paragraph_text"]): int(p["idx"])
                       for p in row["paragraphs"]}
            supports = sorted(set(supports) | {mapping[e["doc_id"]] for e in selected if e["doc_id"] in mapping})
        musique_preds.append({"id": key, "predicted_answer": answer["answer"],
                             "predicted_support_idxs": supports, "predicted_answerable": True})
    if dataset == "musique":
        gold_path, pred_path = directory / "gold.jsonl", directory / "predictions.jsonl"
        gold_path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")
        pred_path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in musique_preds), encoding="utf-8")
        evaluator = root / "vendor/musique/evaluate_v1.0.py"
    else:
        gold_path, pred_path = directory / "gold.json", directory / "predictions.json"
        gold_path.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
        pred_path.write_text(json.dumps(predictions, ensure_ascii=False), encoding="utf-8")
        evaluator = root / ("vendor/hotpot/hotpot_evaluate_v1.py" if dataset == "hotpotqa"
                            else "vendor/2wikimultihop/2wikimultihop_evaluate.py")
    cmd = [str(evaluator_python), str(evaluator), str(pred_path), str(gold_path)]
    process = subprocess.run(cmd, cwd=evaluator.parent, text=True, capture_output=True)
    (directory / "evaluator.stdout.txt").write_text(process.stdout)
    (directory / "evaluator.stderr.txt").write_text(process.stderr)
    if process.returncode:
        raise RuntimeError("official evaluator failed: " + process.stderr[-1500:])
    from route_planned_rag.evaluation.official import _parse_json_object
    try:
        metrics = _parse_json_object(process.stdout)
    except json.JSONDecodeError:
        # Hotpot's unmodified evaluator prints a Python dictionary, not JSON.
        metrics = ast.literal_eval(process.stdout.strip())
        if not isinstance(metrics, dict):
            raise ValueError("official evaluator did not return a metrics dictionary")
    (directory / "official_metrics.json").write_text(json.dumps(metrics, indent=2))
    seed = episodes[0]["seed"]
    if any(e["seed"] != seed for e in episodes):
        raise ValueError("one evaluation export must have a single seed")
    score_process = subprocess.run([str(evaluator_python), "-m", "route_planned_rag.logicgraph.offline_scores",
        dataset, str(directory), str(evaluator), "--seed", str(seed)], cwd=root, text=True, capture_output=True)
    if score_process.returncode:
        raise RuntimeError("per-question official score audit failed: " + score_process.stderr[-1500:])
    score_path = directory / "per_question_scores.jsonl"
    scores = [json.loads(line) for line in score_path.read_text().splitlines()]
    for score, episode in zip(scores, episodes):
        score.update(episode_seconds=episode["episode_seconds"], supported=int(episode["supported"]),
            stop_reason=episode["stop_reason"], **{k: v for k, v in episode["usage"].items() if k != "events"})
    score_path.write_text("".join(json.dumps(s) + "\n" for s in scores))
    return {"metrics": metrics, "n": len(rows),
            "per_question_scores": str(score_path), "score_units": "percent" if dataset == "twowiki" else "fraction",
            "evaluator": str(evaluator), "evaluator_sha256": hashlib.sha256(evaluator.read_bytes()).hexdigest(),
            "gold_sha256": hashlib.sha256(gold_path.read_bytes()).hexdigest(),
            "predictions_sha256": hashlib.sha256(pred_path.read_bytes()).hexdigest(),
            "evaluation_track": "official_v1.0_no_aliases" if dataset == "twowiki" else "official"}
