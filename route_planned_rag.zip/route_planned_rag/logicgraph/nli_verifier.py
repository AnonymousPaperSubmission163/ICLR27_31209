"""Frozen non-generative NLI verification, explicitly statistical, not a proof.

No target labels, no generative judge, no model-written confidence. The lexical
retriever and graph planner are unchanged. Thresholds are preregistered diagnostic
settings, NOT claimed calibrated probabilities of QA correctness.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

from .rule_verifier import RuleVerifier, need_spec, question_spec, render_statement
from .verification import Verification


class NLIVerifier:
    verifier_id = 'frozen-deberta-v3-large-nli'
    version = '1'
    implementation_kind = 'independent_non_llm'
    supports_qa_semantics = True

    def __init__(self, root, *, device='cuda:0', entail_threshold=.9, contradiction_threshold=.9,
                 token_limit=262144, pair_limit=512):
        self.root = Path(root).resolve()
        self.lock = json.loads((self.root / 'artifacts/independent_verifier/nli_model_lock.json').read_text())
        self.device = device
        self.entail_threshold, self.contradiction_threshold = entail_threshold, contradiction_threshold
        self.token_limit, self.pair_limit = token_limit, pair_limit
        self.model = self.tokenizer = None
        self.begin_episode()

    def begin_episode(self):
        self.stats = {'verification_calls': 0, 'learned_forward_tokens': 0, 'pairs': 0,
                      'seconds': 0., 'budget_exhausted': False}

    def usage(self):
        return dict(self.stats)

    def load(self):
        if self.model is not None:
            return
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        snapshot = Path(self.lock['snapshot']).resolve()
        if not snapshot.is_relative_to(self.root):
            raise ValueError('NLI checkpoint must remain within logicrag')
        # Verify the pinned downloaded artifacts before executing the model.
        for name, expected in self.lock['files'].items():
            file = snapshot / name
            digest = hashlib.sha256()
            with file.open('rb') as stream:
                for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                    digest.update(block)
            if digest.hexdigest() != expected:
                raise ValueError('NLI checkpoint checksum mismatch: ' + name)
        self.tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False)
        self.model = AutoModelForSequenceClassification.from_pretrained(str(snapshot), local_files_only=True,
            trust_remote_code=False, use_safetensors=True, dtype=torch.float32).to(self.device).eval()
        self.labels = {int(k): v.lower() for k, v in self.model.config.id2label.items()}
        if set(self.labels.values()) != {'entailment', 'neutral', 'contradiction'}:
            raise ValueError('NLI class mapping differs from the declared three-way task')
        self.max_tokens = min(512, self.model.config.max_position_embeddings)

    def _pairs(self, state, candidate, hypothesis):
        h = self.tokenizer.encode(hypothesis, add_special_tokens=False)
        room = self.max_tokens - len(h) - self.tokenizer.num_special_tokens_to_add(pair=True)
        if room < 64:
            return [], 'hypothesis_too_long'
        permitted = set(candidate['evidence_ids'])
        nodes = {n['id']: n for n in state['graph']['nodes']}
        stack, seen = list(candidate.get('premise_ids', [])), set()
        while stack:
            nid = stack.pop()
            if nid in seen or nid not in nodes or nodes[nid]['status'] != 'resolved':
                continue
            seen.add(nid)
            permitted.update(nodes[nid]['evidence'])
            stack.extend(nodes[nid]['premises'])
        pairs = []
        # Scan all admitted evidence for conflict, but only cited evidence supports acceptance.
        for item in state['evidence']:
            ids = self.tokenizer.encode(item['text'], add_special_tokens=False)
            for offset in range(0, len(ids), max(1, room - 64)):
                window = ids[offset:offset + room]
                if not window:
                    continue
                # Transformers 5 tokenizers no longer expose prepare_for_model.
                # Use the public paired-text API and explicitly audit round-trip
                # token growth; never silently truncate a premise or hypothesis.
                original_length = len(window)
                while window:
                    text = self.tokenizer.decode(window, skip_special_tokens=True)
                    encoded = self.tokenizer(text, hypothesis, add_special_tokens=True,
                        return_attention_mask=True, return_token_type_ids=True, truncation=False)
                    overflow = len(encoded['input_ids']) - self.max_tokens
                    if overflow <= 0:
                        break
                    window = window[:-max(1, overflow)]
                if not window or original_length - len(window) > 64:
                    return [], 'tokenizer_roundtrip_would_create_unchecked_evidence_gap'
                pairs.append((encoded, {'evidence_ids': [item['id']], 'token_start': offset,
                    'token_end': offset + len(window), 'can_support': item['id'] in permitted,
                    'roundtrip_trimmed_tokens': original_length - len(window)}))
                if offset + len(window) >= len(ids):
                    break
        # Include a joint cited-premise window only when the whole conjunction fits;
        # never pretend that independent max scores prove a multi-premise conjunction.
        cited = [e for e in state['evidence'] if e['id'] in permitted]
        if len(cited) > 1:
            joined = '\n'.join(e['text'] for e in cited)
            ids = self.tokenizer.encode(joined, add_special_tokens=False)
            if len(ids) <= room:
                encoded = self.tokenizer(joined, hypothesis, add_special_tokens=True,
                    return_attention_mask=True, return_token_type_ids=True, truncation=False)
                if len(encoded['input_ids']) <= self.max_tokens:
                    pairs.append((encoded, {'evidence_ids': [e['id'] for e in cited], 'token_start': 0,
                        'token_end': len(ids), 'can_support': True, 'joint_complete': True}))
        return pairs, None

    def _check(self, state, candidate, hypothesis, adapter):
        self.load()
        self.stats['verification_calls'] += 1
        started = time.perf_counter()
        pairs, issue = self._pairs(state, candidate, hypothesis)
        if issue or not pairs:
            return Verification('unknown', issue or 'no_observed_premise')
        needed = sum(len(item['input_ids']) for item, _ in pairs)
        if self.stats['pairs'] + len(pairs) > self.pair_limit or self.stats['learned_forward_tokens'] + needed > self.token_limit:
            self.stats['budget_exhausted'] = True
            return Verification('unknown', 'independent_verifier_budget_exhausted')
        import torch
        rows = []
        for offset in range(0, len(pairs), 8):
            batch_pairs = pairs[offset:offset + 8]
            batch = self.tokenizer.pad([item for item, _ in batch_pairs], padding=True, return_tensors='pt')
            if batch['input_ids'].shape[1] > self.max_tokens:
                raise ValueError('NLI input exceeds explicit window contract')
            self.stats['learned_forward_tokens'] += int(batch['attention_mask'].sum())
            self.stats['pairs'] += len(batch_pairs)
            with torch.inference_mode():
                logits = self.model(**batch.to(self.device)).logits
                probabilities = torch.softmax(logits.float(), dim=-1).cpu().tolist()
            for (_, provenance), probabilities_ in zip(batch_pairs, probabilities):
                rows.append({**provenance, **{self.labels[i]: value for i, value in enumerate(probabilities_)}})
        if self.device.startswith('cuda'):
            torch.cuda.synchronize()
        self.stats['seconds'] += time.perf_counter() - started
        entail = max((r['entailment'] for r in rows if r['can_support']), default=0.)
        contradict = max((r['contradiction'] for r in rows), default=0.)
        certificate = {'kind': 'statistical_nli_acceptance_not_formal_proof',
            'model_revision': self.lock['revision'], 'hypothesis': hypothesis, 'hypothesis_adapter': adapter,
            'entailment_max_cited': entail, 'contradiction_max_observed': contradict,
            'entail_threshold': self.entail_threshold, 'contradiction_threshold': self.contradiction_threshold,
            'calibration_status': 'preregistered_diagnostic_threshold_not_calibrated', 'windows': rows}
        if contradict >= self.contradiction_threshold:
            return Verification('unknown' if entail >= self.entail_threshold else 'rejected',
                'conflicting_evidence' if entail >= self.entail_threshold else 'nli_contradiction', certificate)
        if entail >= self.entail_threshold:
            return Verification('accepted', 'independent_nli_acceptance', certificate)
        return Verification('unknown', 'insufficient_nli_support', certificate)

    def verify_node(self, *, question, node_id, state, candidate):
        node = next(n for n in state['graph']['nodes'] if n['id'] == node_id)
        hypothesis = render_statement(need_spec(node['need'], state), candidate['value'])
        adapter = 'canonical_relation' if hypothesis else 'need_value_wrapper'
        hypothesis = hypothesis or f"Regarding {node['need'].rstrip('.')}, {candidate['value']}"
        return self._check(state, candidate, hypothesis, adapter)

    def verify_answer(self, *, question, state, candidate):
        hypothesis = render_statement(question_spec(question), candidate['answer'])
        adapter = 'canonical_question_relation' if hypothesis else 'original_question_answer_wrapper'
        hypothesis = hypothesis or f'The answer to the question "{question}" is "{candidate["answer"]}".'
        return self._check(state, candidate, hypothesis, adapter)


class HybridVerifier:
    verifier_id = 'anchored-rules-then-frozen-nli'
    version = '1'
    implementation_kind = 'independent_non_llm'
    supports_qa_semantics = True

    def __init__(self, nli):
        self.rules, self.nli = RuleVerifier(), nli

    def begin_episode(self):
        self.rules.begin_episode()
        self.nli.begin_episode()

    def usage(self):
        return {**self.nli.usage(), 'rule_calls': self.rules.usage()['verification_calls']}

    def _check(self, method, request):
        result = getattr(self.rules, method)(**request)
        if result.verdict != 'unknown' or result.reason == 'conflicting_bindings':
            return result
        learned = getattr(self.nli, method)(**request)
        return Verification(learned.verdict, learned.reason,
                            {**learned.certificate, 'rule_fallback_reason': result.reason})

    def verify_node(self, **request):
        return self._check('verify_node', request)

    def verify_answer(self, **request):
        return self._check('verify_answer', request)
