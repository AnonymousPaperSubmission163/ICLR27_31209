"""External Harbor agent. It receives only instruction + the official environment API.
Hidden tests/rewards remain inside Harbor's post-episode verifier, never the online loop.
"""
import asyncio
import json
import os
import re
from pathlib import Path

from harbor.agents.base import BaseAgent
from .engine import Engine
from .ledger import Ledger
from .model import FrozenJSON
from .server import RemoteBackend, RemoteTokenizer

class LogicGraphAgent(BaseAgent):
    @staticmethod
    def name():
        return "logicgraph-v3"

    def version(self):
        return "3.0.0-experimental"

    async def setup(self, environment):
        # Models run on the host's allocated GPU; nothing is installed into the task image.
        pass

    async def run(self, instruction, environment, context):
        endpoint = os.environ["LOGICGRAPH_ENDPOINT"]
        token = os.environ["LOGICGRAPH_RPC_TOKEN"]
        root = Path("/blue/du.j/jinjiaguo/logicrag")
        profile_path = Path(os.environ["LOGICGRAPH_COST_PROFILE"]).resolve()
        if not profile_path.is_relative_to(root):
            raise ValueError("cost profile must remain inside logicrag")
        profile = json.loads(profile_path.read_text())
        actor = FrozenJSON(RemoteBackend(endpoint, token, "actor"),
                           RemoteTokenizer(endpoint, token, "actor"), "pinned-Ministral3-8B")
        small = FrozenJSON(RemoteBackend(endpoint, token, "small"),
                           RemoteTokenizer(endpoint, token, "small"), "pinned-Ministral3-3B")
        method = os.environ.get("LOGICGRAPH_METHOD", "full")
        ledger = Ledger(int(os.environ.get("LOGICGRAPH_TOOL_BUDGET", "32")))
        engine = Engine(actor, small, cost_profile=profile, domain="terminal", ablation=method,
                        max_steps=64, penalty=float(os.environ.get("LOGICGRAPH_PENALTY", ".05")))
        loop = asyncio.get_running_loop()
        async def command(cmd):
            # This is an additional guard, not a replacement for the harness's filesystem isolation.
            if re.search(r"(^|[\s'\"=])/(tests|solution|logs/verifier)(/|[\s'\";]|$)", cmd):
                return "COMMAND_REJECTED: private harness paths are unavailable to the agent."
            result = await environment.exec(cmd, timeout_sec=120)
            return json.dumps({"stdout": result.stdout, "stderr": result.stderr,
                               "exit_code": result.return_code}, ensure_ascii=False)
        def execute(cmd):
            return asyncio.run_coroutine_threadsafe(command(cmd), loop).result(timeout=135)
        def progress(usage):
            context.n_input_tokens = usage["input_tokens"]
            context.n_output_tokens = usage["output_tokens"]
            context.metadata = {"logicgraph_usage": {k: v for k, v in usage.items() if k != "events"},
                                "method": method, "tool_budget": ledger.call_limit}
        result = await asyncio.to_thread(engine.run, instruction, ledger, None, execute, progress)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        (self.logs_dir / "logicgraph_episode.json").write_text(json.dumps(result, ensure_ascii=False))
        progress(result["usage"])
        context.metadata["online_supported"] = result["supported"]
        context.metadata["online_stop_reason"] = result["stop_reason"]

