"""Paired cluster bootstrap: average repeated seeds within task/question first."""
import argparse
import json
import math
import random
from pathlib import Path

def paired_bootstrap(left, right, *, metric, resamples=10000, seed=20260904):
    def group(rows):
        out = {}
        for row in rows:
            key, run_seed = row["question_id"], row["seed"]
            if run_seed in out.setdefault(key, {}):
                raise ValueError("duplicate question/seed")
            value = float(row[metric])
            if not math.isfinite(value):
                raise ValueError("missing/nonfinite outcomes must be explicitly accounted for, not dropped")
            out[key][run_seed] = value
        return out
    a, b = group(left), group(right)
    if not a or a.keys() != b.keys():
        raise ValueError("paired comparisons require exactly the same nonempty question/task set")
    differences = []
    for key in sorted(a):
        if a[key].keys() != b[key].keys():
            raise ValueError("paired comparisons require the same seeds per question/task")
        differences.append(sum(a[key].values()) / len(a[key]) - sum(b[key].values()) / len(b[key]))
    rng, n = random.Random(seed), len(differences)
    samples = sorted(sum(differences[rng.randrange(n)] for _ in range(n)) / n for _ in range(resamples))
    return {"metric": metric, "n_clusters": n, "difference_left_minus_right": sum(differences) / n,
            "ci95": [samples[int(.025 * (resamples - 1))], samples[int(.975 * (resamples - 1))]],
            "resamples": resamples, "seed": seed, "unit": "question_or_task_after_seed_average",
            "reliability_warning": "tiny diagnostic sample" if n < 30 else None}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("left", type=Path)
    parser.add_argument("right", type=Path)
    parser.add_argument("--metric", required=True)
    args = parser.parse_args()
    load = lambda p: [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
    print(json.dumps(paired_bootstrap(load(args.left), load(args.right), metric=args.metric), indent=2))

if __name__ == "__main__":
    main()

