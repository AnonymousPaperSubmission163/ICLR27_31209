"""QA execution with proposal-only LLMs, A*, and independent verification."""
from __future__ import annotations

import time
import copy
from dataclasses import asdict

from .astar import ActionCosts, frontier_priorities, search, successors
from .core import State
from .ledger import BudgetExhausted
from .model import JsonFailure
from .proposals import ANSWER, CLAIM, QUERY, compile_information_graph
from .verification import candidate_fields, require_semantic_verifier, verify


def graph_rerank(graph, nid, evidence):
    """Lexical coverage of the active need, then its graph neighbors, then rank.

    These deterministic relevance keys do not assert entailment or contradiction.
    All admitted candidates remain available to the verifier, including those not
    among the five presented to the claim proposer.
    """
    from route_planned_rag.corpus.retrieval import InMemoryBM25Retriever
    tokens = lambda text: set(InMemoryBM25Retriever._tokens(text))
    active = tokens(graph.nodes[nid].need)
    neighbors = {e.target if e.source == nid else e.source for e in graph.edges
                 if nid in {e.source, e.target} and e.status != "invalid"}
    neighbors |= graph.mandatory(nid)
    neighbors |= {p for group in graph.nodes[nid].prerequisites for p in group}
    related = set().union(*(tokens(graph.nodes[n].need) for n in neighbors)) - active
    rows = []
    for rank, item in enumerate(evidence):
        words = tokens(item.title + " " + item.text)
        rows.append({"id": item.id, "active_coverage": len(words & active) / max(1, len(active)),
                     "neighbor_coverage": len(words & related) / max(1, len(related)), "retrieval_rank": rank})
    rows.sort(key=lambda r: (-r["active_coverage"], -r["neighbor_coverage"], r["retrieval_rank"], r["id"]))
    by_id = {e.id: e for e in evidence}
    return [by_id[r["id"]] for r in rows], rows


class StrictEngine:
    def __init__(self, actor, small, *, verifier, costs=None, method="astar", max_steps=32,
                 max_expansions=100000):
        require_semantic_verifier(verifier)  # Fail before any paid/model execution.
        if method not in {"astar", "sequential_graph", "greedy_graph"}:
            raise ValueError("legacy LLM-scored methods are disabled")
        self.actor, self.small, self.verifier = actor, small, verifier
        self.costs = costs or ActionCosts.unit_cost()
        self.method, self.max_steps, self.max_expansions = method, max_steps, max_expansions

    @staticmethod
    def payload(question, state, selected=None, **extra):
        view = state.view()
        if selected is not None:
            retained = {e.id for e in selected}
            for node in state.graph.nodes.values():
                if node.status == "resolved":
                    retained.update(node.evidence)
            view["evidence"] = [e for e in view["evidence"] if e["id"] in retained]
        return {"question": question, "state": view, **extra}

    def run(self, question, ledger, retrieve=None, *, prepared_graph=None, preparation_seconds=0.):
        if getattr(retrieve, "score_source", None) != "deterministic_lexical":
            raise ValueError("strict retrieval requires deterministic lexical scores, not LLM/dense scores")
        started = time.perf_counter()
        if hasattr(self.verifier, 'begin_episode'):
            self.verifier.begin_episode()
        state, trace, stop, supported = None, [], "step_limit", False
        feedback = {}
        answer = {"answer": "", "evidence_ids": [], "supporting_facts": [], "evidences": [], "abstain": True}
        try:
            state = State(copy.deepcopy(prepared_graph) if prepared_graph is not None else
                          compile_information_graph(self.small, question, ledger))
            trace.append({"phase": "graph_proposal", "graph": state.graph.view(), "semantically_verified": False})
            for step in range(self.max_steps):
                graph = state.graph
                remaining = ledger.call_limit - ledger.retrieval_calls - ledger.tool_calls
                priorities = frontier_priorities(graph, self.costs, remaining_calls=remaining,
                                                has_evidence=bool(state.evidence))
                plan = search(graph, self.costs, remaining_calls=remaining, has_evidence=bool(state.evidence),
                              max_expansions=self.max_expansions)
                trace.append({"phase": "astar", "step": step, **asdict(plan), "priorities": priorities,
                              "cost_unit": self.costs.unit, "cost_source": self.costs.source})
                if plan.status != "optimal":
                    stop = "astar_" + plan.status
                    break
                if not plan.actions:
                    # Normally checked immediately following acceptance below.
                    stop = "answer_unverified"
                    break
                action = plan.actions[0]
                if self.method == "sequential_graph":
                    # Same graph, retrieval, verifier and budget; only selection differs.
                    choices = list(successors(graph, graph.resolved(), 0, remaining_calls=remaining,
                                              has_evidence=bool(state.evidence), costs=self.costs))
                    action = choices[0]
                elif self.method == 'greedy_graph':
                    first = priorities[0]
                    action = next(a for a in successors(graph, graph.resolved(), 0, remaining_calls=remaining,
                        has_evidence=bool(state.evidence), costs=self.costs)
                        if (a.node, a.mode) == (first['node'], first['mode']))
                state.route = tuple(a.node for a in plan.actions) if self.method == "astar" else (action.node,)
                nid, mode = action.node, action.mode
                trace.append({"phase": "selected_action", "node": nid, "mode": mode,
                              "selection": self.method, "planned_cost": action.cost})
                selected = None
                local_started = time.perf_counter()
                try:
                    if mode == "retrieve":
                        def valid_query(obj):
                            if not isinstance(obj, dict) or set(obj) != {"query"} or not isinstance(obj["query"], str) or not obj["query"].strip():
                                raise ValueError("query-only proposal required")
                            return obj["query"]
                        query = self.actor.ask("query_proposal", QUERY,
                            self.payload(question, state, active_node=nid, verification_feedback=feedback), ledger, max_output=256,
                            validator=valid_query)
                        ledger.acquire_call("retrieve")
                        candidates = retrieve(query, 20)
                        admitted = []
                        for item in candidates:
                            if item.id in state.evidence and state.evidence[item.id] != item:
                                raise ValueError("evidence ID reused with changed content")
                            if item.token_end <= item.token_start:
                                raise ValueError("retriever must supply nonempty tokenizer-based evidence spans")
                            if ledger.admit_evidence(item.doc_id or item.id, item.token_start, item.token_end):
                                state.evidence[item.id] = item
                                admitted.append(item)
                        ranked, keys = graph_rerank(graph, nid, admitted)
                        selected = ranked[:5]
                        trace.append({"phase": "lexical_graph_rerank", "node": nid, "query": query,
                                      "ranking": keys, "selected_ids": [e.id for e in selected]})
                    visible = self.payload(question, state, selected, active_node=nid, mode=mode,
                                           verification_feedback=feedback)
                    def valid_claim(obj):
                        candidate_fields(obj)
                        if not set(obj["evidence_ids"]) <= {e["id"] for e in visible["state"]["evidence"]}:
                            raise ValueError("candidate cites evidence it was not shown")
                        return obj
                    candidate = self.actor.ask("claim_proposal", CLAIM, visible, ledger,
                                               max_output=768, validator=valid_claim)
                    verdict = verify(self.verifier, question, state, candidate, node_id=nid)
                    feedback[nid] = {'verdict': verdict.verdict, 'reason': verdict.reason}
                    trace.append({"phase": "node_verification", "node": nid, "candidate": candidate,
                                  "verifier": self.verifier.verifier_id, **asdict(verdict)})
                    if verdict.verdict == "accepted":
                        state.resolve(nid, {**candidate, "status": "resolved"})
                        state.history.append({"kind": "independent_node_certificate", "node": nid,
                                              "verifier": self.verifier.verifier_id, **asdict(verdict)})
                    # Rejected and unknown claims remain pending. No LLM can reopen,
                    # invalidate or certify graph edges, nor approve a propagation.
                except (JsonFailure, ValueError, KeyError) as exc:
                    trace.append({"phase": "node_failure", "node": nid, "error": str(exc)})
                finally:
                    graph.nodes[nid].attempts += 1
                    trace.append({"phase": "measured_execution", "node": nid, "mode": mode,
                                  "seconds": time.perf_counter() - local_started})
                if graph.supported_structure():
                    try:
                        candidate = self.actor.ask("answer_proposal", ANSWER, self.payload(question, state), ledger,
                            max_output=512, final=True, validator=lambda obj: candidate_fields(obj, answer=True))
                        verdict = verify(self.verifier, question, state, candidate)
                        feedback['original_answer'] = {'verdict': verdict.verdict, 'reason': verdict.reason}
                        trace.append({"phase": "answer_verification", "candidate": candidate,
                                      "verifier": self.verifier.verifier_id, **asdict(verdict)})
                        if verdict.verdict == "accepted":
                            answer, supported, stop = {**candidate, "abstain": False}, True, "independently_supported"
                        else:
                            stop = "answer_unverified"
                    except (JsonFailure, ValueError, KeyError) as exc:
                        stop = "answer_verifier_failure"
                        trace.append({"phase": "answer_failure", "error": str(exc)})
                    if supported:
                        break
                    # Deterministic, bounded reacquisition. Do not let an LLM
                    # approve edits or label accepted facts false. Retire a branch
                    # binding to seek additional evidence; retain every observation.
                    reopenable = [n for n in graph.nodes.values() if n.status == 'resolved'
                                  and 'retrieve' in n.modes and n.attempts < 2]
                    if ledger.retrieval_calls >= ledger.call_limit or not reopenable:
                        break
                    target = max(reopenable, key=lambda n: (n.step, n.id)).id
                    affected = {target}
                    while True:
                        descendants = {n.id for n in graph.nodes.values() if n.status == 'resolved' and
                            (set(n.premises) | graph.mandatory(n.id) | {p for g in n.prerequisites for p in g}) & affected}
                        if descendants <= affected:
                            break
                        affected |= descendants
                    record = {'kind': 'algorithmic_reacquisition', 'target': target,
                              'retired_bindings': {n: asdict(graph.nodes[n]) for n in sorted(affected)},
                              'reason': 'original_answer_not_independently_accepted_not_a_proof_of_falsehood'}
                    state.history.append(record)
                    trace.append({'phase': 'algorithmic_reacquisition', **record})
                    for node_id in affected:
                        node = graph.nodes[node_id]
                        node.status, node.value, node.evidence, node.premises = 'pending', '', (), ()
                    state.route = ()
                    # Attempts are never reset: two acquisitions/node remain the cap.
        except BudgetExhausted as exc:
            stop = "budget_exhausted"
            trace.append({"phase": "budget_stop", "error": str(exc)})
        except (JsonFailure, ValueError, KeyError) as exc:
            stop = "proposal_or_verifier_failure"
            trace.append({"phase": "failure", "error": str(exc)})
        return {"implementation_version": "logicgraph-astar-strict-v1", "answer": answer,
                "supported": supported, "stop_reason": stop, "trace": trace,
                "state": state.view() if state else None, "usage": ledger.summary(),
                "episode_seconds": time.perf_counter() - started + preparation_seconds,
                "shared_graph_preparation_seconds_charged": preparation_seconds,
                "verification_usage": self.verifier.usage() if hasattr(self.verifier, 'usage') else {},
                "verifier": {"id": self.verifier.verifier_id, "version": self.verifier.version},
                "cost_unit": self.costs.unit, "method": self.method}
