"""Independent-verifier boundary. Provenance/graph checks are NOT entailment.

An implementation must check the exact information need / original question,
entity, scope, all premises, evidence entailment and contradictions. It receives
only public observations. No gold, expected answer, supporting labels, LLM judge,
LLM confidence, or self-approved edge flags may implement this interface.
"""
from __future__ import annotations

import copy
from dataclasses import asdict, dataclass, field
from typing import Protocol

from .core import State


@dataclass(frozen=True)
class Verification:
    verdict: str  # accepted | rejected | unknown
    reason: str
    certificate: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.verdict not in {"accepted", "rejected", "unknown"} or not self.reason:
            raise ValueError("invalid verifier verdict")
        if self.verdict == "accepted" and not self.certificate:
            raise ValueError("acceptance requires an independently computed certificate")


class IndependentVerifier(Protocol):
    verifier_id: str
    version: str
    implementation_kind: str  # executable_rules | independent_non_llm
    supports_qa_semantics: bool

    def verify_node(self, *, question: str, node_id: str, state: dict, candidate: dict) -> Verification: ...
    def verify_answer(self, *, question: str, state: dict, candidate: dict) -> Verification: ...


def require_semantic_verifier(verifier):
    if verifier is None or getattr(verifier, "supports_qa_semantics", False) is not True:
        raise ValueError("verifier_required: A* and provenance checks cannot verify free-text QA entailment")
    if getattr(verifier, "implementation_kind", None) not in {"executable_rules", "independent_non_llm"}:
        raise ValueError("LLM scoring/verification is forbidden")
    if not getattr(verifier, "verifier_id", "") or not getattr(verifier, "version", ""):
        raise ValueError("verifier identity/version required")
    if not all(callable(getattr(verifier, m, None)) for m in ("verify_node", "verify_answer")):
        raise ValueError("verifier must check both node claims and complete answers")


def candidate_fields(obj, *, answer=False):
    fields = {"answer", "evidence_ids", "supporting_facts", "evidences"} if answer else {
        "value", "evidence_ids", "premise_ids"}
    if not isinstance(obj, dict) or set(obj) != fields:
        raise ValueError("candidate-only schema: ratings, support/status flags and extra fields forbidden")
    value = obj["answer" if answer else "value"]
    if not isinstance(value, str) or len(value) > 1600:
        raise ValueError("invalid candidate value")
    for key in ("evidence_ids",) if answer else ("evidence_ids", "premise_ids"):
        ids = obj[key]
        if not isinstance(ids, list) or len(ids) > 24 or any(not isinstance(x, str) for x in ids) or len(ids) != len(set(ids)):
            raise ValueError("invalid or duplicate provenance IDs")
    if answer:
        if not isinstance(obj["supporting_facts"], list) or len(obj["supporting_facts"]) > 24:
            raise ValueError("invalid supporting facts")
        for item in obj["supporting_facts"]:
            if not isinstance(item, dict) or set(item) != {"evidence_id", "sentence_ids"}:
                raise ValueError("invalid sentence citation")
            if not isinstance(item["evidence_id"], str) or not isinstance(item["sentence_ids"], list):
                raise ValueError("invalid sentence citation types")
            if not item["sentence_ids"] or any(type(i) is not int for i in item["sentence_ids"]):
                raise ValueError("invalid sentence IDs")
        if not isinstance(obj["evidences"], list) or len(obj["evidences"]) > 12:
            raise ValueError("invalid triples")
        for triple in obj["evidences"]:
            if not isinstance(triple, list) or len(triple) != 3 or not all(isinstance(x, str) for x in triple):
                raise ValueError("invalid candidate triple")
    return obj


def check_provenance(state: State, candidate, *, node_id=None):
    """Return an error or None. None means well-formed provenance, NOT truth."""
    candidate_fields(candidate, answer=node_id is None)
    if not candidate["value" if node_id else "answer"].strip():
        return "empty_candidate"
    citations = set(candidate["evidence_ids"])
    premises = set(candidate.get("premise_ids", []))
    if not citations <= state.evidence.keys() or not premises <= state.graph.resolved():
        return "unknown_evidence_or_unverified_premise"
    if not citations and not premises:
        return "no_observed_provenance"
    if any(state.evidence[e].dynamic and state.evidence[e].environment_version != state.version for e in citations):
        return "stale_evidence"
    if node_id is not None:
        if node_id in premises or node_id not in state.graph.ready():
            return "unmet_graph_constraints"
    else:
        if not state.graph.supported_structure():
            return "incomplete_or_incompatible_goal"
        for item in candidate["supporting_facts"]:
            eid = item["evidence_id"]
            if eid not in citations or not set(item["sentence_ids"]) <= set(state.evidence[eid].sentence_ids):
                return "invalid_supporting_sentence"
    return None


def verify(verifier, question, state, candidate, *, node_id=None):
    require_semantic_verifier(verifier)
    issue = check_provenance(state, candidate, node_id=node_id)
    if issue:
        return Verification("rejected", issue)
    # Verifier code cannot mutate live execution state or the candidate it judges.
    request = dict(question=question, state=copy.deepcopy(state.view()), candidate=copy.deepcopy(candidate))
    try:
        result = verifier.verify_answer(**request) if node_id is None else verifier.verify_node(node_id=node_id, **request)
    except Exception as exc:
        # A failed external checker is not acceptance and must not drop the episode.
        return Verification("unknown", "independent_verifier_error: " + type(exc).__name__ + ": " + str(exc))
    if not isinstance(result, Verification):
        raise ValueError("independent verifier returned no typed verification result")
    # Ensure the certificate is persistable; unsupported opaque objects are not evidence.
    import json
    json.dumps(asdict(result), allow_nan=False)
    return result


class ProvenanceOnlyVerifier:
    """Useful diagnostic, explicitly ineligible as the semantic QA verifier."""
    verifier_id = "provenance-only"
    version = "1"
    implementation_kind = "executable_rules"
    supports_qa_semantics = False

    def verify_node(self, **kwargs):
        return Verification("unknown", "citation existence does not prove the requested fact")

    def verify_answer(self, **kwargs):
        return Verification("unknown", "A* goal coverage does not prove the original answer")
