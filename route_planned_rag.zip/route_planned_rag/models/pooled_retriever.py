from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

from route_planned_rag.models.dense_index import ResidentShardedDenseIndex
from route_planned_rag.models.interfaces import ModelUsage
from route_planned_rag.types import ObservedPassage


class PooledDenseRetriever:
    def __init__(self, dataset: str, chunks_path: str | Path, dense_manifest_path: str | Path, encoder, *, device: str = "cuda"):
        self.dataset = dataset
        self.encoder = encoder
        self.max_query_tokens = int(getattr(encoder, "max_tokens", 0))
        self.manifest = json.loads(Path(dense_manifest_path).read_text(encoding="utf-8"))
        self.index = ResidentShardedDenseIndex(self.manifest, device=device)
        self.passages = {}
        with Path(chunks_path).open("r", encoding="utf-8") as handle:
            for line in handle:
                item = json.loads(line)
                passage = ObservedPassage(
                    chunk_id=item["chunk_id"], doc_id=item["doc_id"], text=item["text"],
                    char_start=int(item["char_start"]), char_end=int(item["char_end"]),
                    token_start=int(item["token_start"]), token_end=int(item["token_end"]),
                    sentence_ids=tuple(map(int, item.get("sentence_ids", []))),
                )
                self.passages[passage.chunk_id] = passage
        if len(self.passages) != int(self.manifest["chunks"]):
            raise RuntimeError("pooled chunk metadata does not match dense index")
        self.chunk_count = len(self.passages)
        self.offline_document_usage = ModelUsage()
        self.last_query_usage = ModelUsage()
        self.calls = 0

    def retrieve(self, query: str, corpus_id: str, top_k: int) -> list[ObservedPassage]:
        if corpus_id.split(":", 1)[0] != self.dataset:
            raise KeyError(f"pooled retriever {self.dataset} cannot serve {corpus_id}")
        self.calls += 1
        query_vector, self.last_query_usage = self.encoder.encode([query], is_query=True)
        ranked = self.index.search(query_vector[0], top_k)
        return [replace(self.passages[chunk_id], retrieval_score=score) for chunk_id, score in ranked]


def resolve_pooled_index(config: dict, dataset: str) -> tuple[Path, Path]:
    root = Path(config["project"]["root"])
    actor_revision = config["models"]["actor"]["revision"]
    index_dir = root / "indexes" / dataset / actor_revision
    manifests = sorted((index_dir / "dense").glob("*/manifest.json"))
    if len(manifests) != 1:
        raise RuntimeError(f"expected exactly one active dense manifest for {dataset}, found {len(manifests)}")
    return index_dir / "chunks.jsonl", manifests[0]
