from __future__ import annotations

import re
from typing import Sequence

from route_planned_rag.models.interfaces import ModelUsage
from route_planned_rag.types import (
    Action,
    AnswerWithCitations,
    BindingStatus,
    BindingUpdate,
    EvidenceCitation,
    InformationNeedGraph,
    InformationNode,
    ObservedPassage,
    PublicSample,
    RouteState,
    SearchCandidate,
)


class DeterministicActor:
    """Non-neural contract implementation for tests; never emits benchmark claims."""

    model_role = "deterministic_contract_test"
    model_revision = "builtin-v1"
    tokenizer_revision = "whitespace-v1"

    @staticmethod
    def _tokens(text: str) -> int:
        return len(text.split())

    def compile_graph(self, sample: PublicSample) -> tuple[InformationNeedGraph, ModelUsage]:
        graph = InformationNeedGraph(
            nodes=(InformationNode("n0", sample.question, (), "answer_entity", ()),),
            answer_dependencies=("n0",),
        )
        return graph, ModelUsage(input_tokens=self._tokens(sample.question), output_tokens=16)

    def propose_queries(
        self, sample: PublicSample, graph: InformationNeedGraph, route: RouteState, maximum: int
    ) -> tuple[list[SearchCandidate], ModelUsage]:
        candidates: list[SearchCandidate] = []
        for node_id in graph.topological_ids():
            if node_id not in route.resolved_node_ids and sample.question not in route.attempted_queries:
                candidates.append(
                    SearchCandidate(
                        action_id=f"{route.route_id}:search:{len(route.attempted_queries)}",
                        route_id=route.route_id,
                        node_id=node_id,
                        query=sample.question,
                        intent="direct",
                    )
                )
                break
        return candidates[:maximum], ModelUsage(input_tokens=self._tokens(sample.question), output_tokens=8)

    def resolve(
        self,
        sample: PublicSample,
        graph: InformationNeedGraph,
        route: RouteState,
        node_id: str,
        passages: Sequence[ObservedPassage],
    ) -> tuple[list[BindingUpdate], ModelUsage]:
        if not passages:
            return [], ModelUsage()
        text = passages[0].text.strip()
        value = re.split(r"[.!?\n]", text, maxsplit=1)[0].strip() or text
        node = next(node for node in graph.nodes if node.id == node_id)
        return [
            BindingUpdate(
                variable=node.output_variable,
                value=value,
                status=BindingStatus.EVIDENCE_BACKED,
                evidence_chunk_ids=(passages[0].chunk_id,),
            )
        ], ModelUsage(input_tokens=sum(self._tokens(p.text) for p in passages), output_tokens=self._tokens(value))

    def answer(self, sample: PublicSample, route: RouteState) -> tuple[AnswerWithCitations, ModelUsage]:
        if not route.bindings:
            return AnswerWithCitations(answer="", citations=(), abstain=True), ModelUsage(input_tokens=1, output_tokens=1)
        record = next(reversed(route.bindings.values()))
        citations = tuple(EvidenceCitation(doc_id=p.doc_id, span_id=p.chunk_id) for p in route.observed_passages[:1])
        return AnswerWithCitations(record.value, citations), ModelUsage(
            input_tokens=sum(self._tokens(p.text) for p in route.observed_passages),
            output_tokens=self._tokens(record.value),
        )


class HeuristicScorer:
    scorer_id = "unresolved_nodes_heuristic_v1"

    def score(self, public_state: dict, candidates: Sequence[Action]) -> tuple[list[float], ModelUsage]:
        route_summaries = {route["route_id"]: route for route in public_state["frontier"]}
        node_count = int(public_state["graph_node_count"])
        scores: list[float] = []
        for candidate in candidates:
            route = route_summaries[candidate.route_id]
            unresolved = node_count - len(route["resolved_node_ids"])
            conflict_penalty = route["conflicts"]
            if candidate.kind == "STOP":
                scores.append(float(unresolved * 100 + conflict_penalty * 10))
            else:
                scores.append(float(max(unresolved - 1, 0) + conflict_penalty * 10))
        return scores, ModelUsage(input_tokens=len(candidates))


class FixedScorer:
    def __init__(self, scores: dict[str, float], scorer_id: str = "fixed-test-scorer"):
        self.scores = scores
        self.scorer_id = scorer_id
        self.calls: list[dict] = []

    def score(self, public_state: dict, candidates: Sequence[Action]) -> tuple[list[float], ModelUsage]:
        self.calls.append(public_state)
        return [self.scores.get(candidate.action_id, 0.0) for candidate in candidates], ModelUsage()

