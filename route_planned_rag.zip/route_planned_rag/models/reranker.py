from __future__ import annotations

import time
from dataclasses import replace
from typing import Sequence

from route_planned_rag.models.interfaces import ModelUsage
from route_planned_rag.types import ObservedPassage


def _encode_with_completion_mask(tokenizer, prompt: str, completion: str) -> tuple[list[int], list[int]]:
    full_text = prompt + completion
    try:
        encoded = tokenizer(full_text, add_special_tokens=True, return_offsets_mapping=True)
        input_ids = list(encoded["input_ids"])
        offsets = list(encoded["offset_mapping"])
        mask = [int(end > len(prompt) and end > start) for start, end in offsets]
    except (TypeError, NotImplementedError, KeyError):
        prompt_ids = list(tokenizer(prompt, add_special_tokens=True)["input_ids"])
        input_ids = list(tokenizer(full_text, add_special_tokens=True)["input_ids"])
        if input_ids[: len(prompt_ids)] != prompt_ids:
            raise ValueError("tokenizer cannot establish an exact completion boundary")
        mask = [0] * len(prompt_ids) + [1] * (len(input_ids) - len(prompt_ids))
    if not any(mask):
        raise ValueError("completion produced zero target tokens")
    return input_ids, mask


def completion_mean_log_likelihood(model, tokenizer, prompts: Sequence[str], completions: Sequence[str]):
    import torch
    import torch.nn.functional as functional

    if len(prompts) != len(completions):
        raise ValueError("prompts and completions must have equal length")
    encoded = [_encode_with_completion_mask(tokenizer, prompt, completion) for prompt, completion in zip(prompts, completions)]
    pad_id = tokenizer.pad_token_id
    if pad_id is None:
        pad_id = tokenizer.eos_token_id
    maximum = max(len(ids) for ids, _ in encoded)
    input_ids = []
    attention = []
    completion_mask = []
    for ids, mask in encoded:
        padding = maximum - len(ids)
        input_ids.append(ids + [pad_id] * padding)
        attention.append([1] * len(ids) + [0] * padding)
        completion_mask.append(mask + [0] * padding)
    device = next(model.parameters()).device
    ids_tensor = torch.tensor(input_ids, dtype=torch.long, device=device)
    attention_tensor = torch.tensor(attention, dtype=torch.long, device=device)
    mask_tensor = torch.tensor(completion_mask, dtype=torch.bool, device=device)
    with torch.inference_mode():
        logits = model(input_ids=ids_tensor, attention_mask=attention_tensor).logits
        token_log_probs = functional.log_softmax(logits[:, :-1, :], dim=-1)
        target_ids = ids_tensor[:, 1:]
        selected = token_log_probs.gather(-1, target_ids.unsqueeze(-1)).squeeze(-1)
        shifted_mask = mask_tensor[:, 1:]
        totals = (selected * shifted_mask).sum(dim=1)
        counts = shifted_mask.sum(dim=1)
        if bool((counts == 0).any()):
            raise ValueError("completion mask vanished after causal shift")
        means = totals / counts
    return means, int(attention_tensor.sum().item()), [int(value) for value in counts.tolist()]


class PointwiseMistralReranker:
    def __init__(
        self,
        model,
        tokenizer,
        prompt_template: str,
        positive_completion: str = "yes",
        negative_completion: str = "no",
    ):
        self.model = model.eval()
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        self.tokenizer = tokenizer
        self.prompt_template = prompt_template
        self.positive_completion = positive_completion
        self.negative_completion = negative_completion

    def maximum_forward_tokens(self, query: str, passages: Sequence[ObservedPassage]) -> int:
        prompts = [self.prompt_template.format(query=query, passage=passage.text) for passage in passages]
        total = 0
        for prompt in prompts:
            for completion in (self.positive_completion, self.negative_completion):
                ids, _ = _encode_with_completion_mask(self.tokenizer, prompt, completion)
                total += len(ids)
        return total

    def rerank(
        self, query: str, passages: Sequence[ObservedPassage], top_k: int
    ) -> tuple[list[ObservedPassage], ModelUsage]:
        prompts = [self.prompt_template.format(query=query, passage=passage.text) for passage in passages]
        paired_prompts = [prompt for prompt in prompts for _ in (0, 1)]
        completions = [completion for _ in prompts for completion in (self.positive_completion, self.negative_completion)]
        start = time.perf_counter()
        scores, tokens, _ = completion_mean_log_likelihood(self.model, self.tokenizer, paired_prompts, completions)
        elapsed = time.perf_counter() - start
        scored = []
        for index, passage in enumerate(passages):
            difference = float((scores[2 * index] - scores[2 * index + 1]).item())
            scored.append(replace(passage, reranker_score=difference))
        scored.sort(key=lambda item: (-(item.reranker_score or 0.0), item.chunk_id))
        return scored[:top_k], ModelUsage(input_tokens=tokens, gpu_seconds=elapsed)
