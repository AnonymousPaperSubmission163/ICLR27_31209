from __future__ import annotations

from dataclasses import replace
from typing import Sequence

import numpy as np

from route_planned_rag.models.interfaces import ModelUsage
from route_planned_rag.types import ObservedPassage


class LiveDenseRetriever:
    """Exact dense retrieval for per-example diagnostics and small fixed corpora."""

    def __init__(self, corpus_id: str, passages: Sequence[ObservedPassage], encoder, *, batch_size: int = 8):
        self.corpus_id = corpus_id
        self.passages = list(passages)
        vectors = []
        offline_tokens = 0
        offline_seconds = 0.0
        for start in range(0, len(self.passages), batch_size):
            values, usage = encoder.encode(
                [passage.text for passage in self.passages[start : start + batch_size]], is_query=False
            )
            vectors.append(values)
            offline_tokens += usage.input_tokens
            offline_seconds += usage.gpu_seconds
        self.matrix = np.concatenate(vectors, axis=0) if vectors else np.zeros((0, 4096), dtype=np.float32)
        self.encoder = encoder
        self.max_query_tokens = int(getattr(encoder, "max_tokens", 0))
        self.offline_document_usage = ModelUsage(input_tokens=offline_tokens, gpu_seconds=offline_seconds)
        self.last_query_usage = ModelUsage()
        self.calls = 0

    def retrieve(self, query: str, corpus_id: str, top_k: int) -> list[ObservedPassage]:
        if corpus_id != self.corpus_id:
            raise KeyError(f"retriever is bound to {self.corpus_id}, not {corpus_id}")
        self.calls += 1
        query_vector, self.last_query_usage = self.encoder.encode([query], is_query=True)
        scores = self.matrix @ query_vector[0]
        ranked = sorted(range(len(scores)), key=lambda index: (-float(scores[index]), self.passages[index].chunk_id))
        return [replace(self.passages[index], retrieval_score=float(scores[index])) for index in ranked[:top_k]]
