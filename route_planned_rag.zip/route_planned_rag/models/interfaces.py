from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Sequence

from route_planned_rag.types import (
    Action,
    AnswerWithCitations,
    BindingUpdate,
    InformationNeedGraph,
    ObservedPassage,
    PublicSample,
    RouteState,
    SearchCandidate,
)


@dataclass(frozen=True)
class ModelUsage:
    input_tokens: int = 0
    output_tokens: int = 0
    gpu_seconds: float = 0.0
    requests: int = 0
    format_repairs: int = 0


class ActorModel(Protocol):
    model_role: str
    model_revision: str
    tokenizer_revision: str

    def compile_graph(self, sample: PublicSample) -> tuple[InformationNeedGraph, ModelUsage]: ...

    def propose_queries(
        self, sample: PublicSample, graph: InformationNeedGraph, route: RouteState, maximum: int
    ) -> tuple[list[SearchCandidate], ModelUsage]: ...

    def resolve(
        self,
        sample: PublicSample,
        graph: InformationNeedGraph,
        route: RouteState,
        node_id: str,
        passages: Sequence[ObservedPassage],
    ) -> tuple[list[BindingUpdate], ModelUsage]: ...

    def answer(
        self, sample: PublicSample, route: RouteState
    ) -> tuple[AnswerWithCitations, ModelUsage]: ...


class ScorerModel(Protocol):
    scorer_id: str

    def score(self, public_state: dict, candidates: Sequence[Action]) -> tuple[list[float], ModelUsage]: ...


class RerankerModel(Protocol):
    def maximum_forward_tokens(self, query: str, passages: Sequence[ObservedPassage]) -> int: ...

    def rerank(
        self, query: str, passages: Sequence[ObservedPassage], top_k: int
    ) -> tuple[list[ObservedPassage], ModelUsage]: ...
