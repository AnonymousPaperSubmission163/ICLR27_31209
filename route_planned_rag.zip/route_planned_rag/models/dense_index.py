from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from route_planned_rag.corpus.build import iter_jsonl


def build_embedding_shards(
    chunks_path: str | Path,
    output_dir: str | Path,
    encoder,
    *,
    batch_size: int = 8,
    shard_size: int = 4096,
) -> dict[str, Any]:
    import torch

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    buffer = []
    shard_index = 0
    total = 0
    total_tokens = 0
    total_gpu_seconds = 0.0
    shards = []

    def flush(items: list[dict[str, Any]], index: int) -> None:
        nonlocal total_tokens, total_gpu_seconds
        vectors = []
        for start in range(0, len(items), batch_size):
            batch = items[start : start + batch_size]
            values, usage = encoder.encode([item["text"] for item in batch], is_query=False)
            vectors.append(torch.from_numpy(values).to(torch.bfloat16))
            total_tokens += usage.input_tokens
            total_gpu_seconds += usage.gpu_seconds
        matrix = torch.cat(vectors, dim=0)
        path = output_dir / f"embeddings-{index:05d}.pt"
        ids_path = output_dir / f"chunks-{index:05d}.jsonl"
        torch.save(matrix, path)
        with ids_path.open("w", encoding="utf-8") as handle:
            for item in items:
                handle.write(json.dumps({"chunk_id": item["chunk_id"], "doc_id": item["doc_id"]}, sort_keys=True) + "\n")
        shards.append({"embeddings": str(path), "chunk_ids": str(ids_path), "rows": len(items)})

    for chunk in iter_jsonl(chunks_path):
        buffer.append(chunk)
        total += 1
        if len(buffer) >= shard_size:
            flush(buffer, shard_index)
            buffer = []
            shard_index += 1
    if buffer:
        flush(buffer, shard_index)
    return {
        "status": "complete",
        "chunks": total,
        "shards": shards,
        "dense_forward_tokens": total_tokens,
        "dense_gpu_seconds": total_gpu_seconds,
        "storage_dtype": "torch.bfloat16",
    }


class ExactShardedDenseIndex:
    def __init__(self, manifest: dict[str, Any]):
        self.manifest = manifest

    def search(self, query_vector: np.ndarray, top_k: int) -> list[tuple[str, float]]:
        import torch

        query = torch.from_numpy(query_vector).float().cpu()
        candidates: list[tuple[str, float]] = []
        for shard in self.manifest["shards"]:
            matrix = torch.load(shard["embeddings"], map_location="cpu").float()
            scores = matrix @ query
            ids = [json.loads(line)["chunk_id"] for line in Path(shard["chunk_ids"]).read_text().splitlines()]
            local_k = min(top_k, len(ids))
            values, indices = torch.topk(scores, local_k)
            candidates.extend((ids[int(index)], float(value)) for value, index in zip(values, indices))
        candidates.sort(key=lambda item: (-item[1], item[0]))
        return candidates[:top_k]


class ResidentShardedDenseIndex:
    """Load BF16 shards once and search them on GPU without per-query disk reads."""

    def __init__(self, manifest: dict[str, Any], device: str = "cuda"):
        import torch

        self.torch = torch
        self.device = device
        self.shards = []
        for shard in manifest["shards"]:
            matrix = torch.load(shard["embeddings"], map_location="cpu").to(device=device, dtype=torch.bfloat16)
            ids = [json.loads(line)["chunk_id"] for line in Path(shard["chunk_ids"]).read_text().splitlines()]
            if matrix.shape[0] != len(ids):
                raise RuntimeError("dense shard row/id count mismatch")
            self.shards.append((matrix, ids))

    def search(self, query_vector: np.ndarray, top_k: int) -> list[tuple[str, float]]:
        query = self.torch.from_numpy(query_vector).to(device=self.device, dtype=self.torch.bfloat16)
        candidates: list[tuple[str, float]] = []
        with self.torch.inference_mode():
            for matrix, ids in self.shards:
                scores = matrix @ query
                local_k = min(top_k, len(ids))
                values, indices = self.torch.topk(scores, local_k)
                candidates.extend((ids[int(index)], float(value)) for value, index in zip(values.float().cpu(), indices.cpu()))
        candidates.sort(key=lambda item: (-item[1], item[0]))
        return candidates[:top_k]
