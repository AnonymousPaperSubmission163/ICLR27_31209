from __future__ import annotations

import json
import time
from typing import Iterable, Sequence

from route_planned_rag.models.interfaces import ModelUsage
from route_planned_rag.types import Action


def last_non_padding_pool(last_hidden_state, attention_mask):
    import torch

    sequence_lengths = attention_mask.sum(dim=1) - 1
    indices = torch.arange(last_hidden_state.shape[0], device=last_hidden_state.device)
    return last_hidden_state[indices, sequence_lengths]


def full_text_lora_targets(model, suffixes: Iterable[str] = ("q_proj", "k_proj", "v_proj", "o_proj")) -> list[str]:
    suffixes = tuple(suffixes)
    selected = []
    for name, _ in model.named_modules():
        lowered = name.casefold()
        is_text_path = "language_model" in lowered or "text_model" in lowered
        is_vision_path = "vision" in lowered or "connector" in lowered or "multimodal" in lowered
        if is_text_path and not is_vision_path and name.endswith(suffixes):
            selected.append(name)
    if not selected:
        raise ValueError("no text-only attention projections matched; inspect the loaded module tree")
    return sorted(selected)


def configure_text_only_lora(model, rank: int, alpha: int, dropout: float, suffixes: Iterable[str]):
    from peft import LoraConfig, get_peft_model

    for parameter in model.parameters():
        parameter.requires_grad_(False)
    targets = full_text_lora_targets(model, suffixes)
    config = LoraConfig(
        r=rank,
        lora_alpha=alpha,
        lora_dropout=dropout,
        target_modules=targets,
        bias="none",
        task_type="FEATURE_EXTRACTION",
    )
    adapted = get_peft_model(model, config)
    return adapted, targets


def assert_trainable_scope(model, head) -> None:
    invalid = []
    trainable = []
    for name, parameter in model.named_parameters():
        if parameter.requires_grad:
            trainable.append(name)
            lowered = name.casefold()
            if "vision" in lowered or "connector" in lowered or "lm_head" in lowered:
                invalid.append(name)
    trainable.extend(f"head.{name}" for name, parameter in head.named_parameters() if parameter.requires_grad)
    if invalid:
        raise ValueError(f"non-text parameters are trainable: {invalid}")
    if not any("lora" in name.casefold() for name in trainable):
        raise ValueError("no LoRA parameters are trainable")
    if not any(name.startswith("head.") for name in trainable):
        raise ValueError("scalar head is not trainable")


def _torch_components():
    import torch
    from torch import nn

    class BudgetAwareHead(nn.Module):
        def __init__(self, hidden_size: int, numeric_features: int = 5):
            super().__init__()
            self.network = nn.Sequential(
                nn.Linear(hidden_size * 3 + numeric_features, hidden_size),
                nn.GELU(),
                nn.Linear(hidden_size, 1),
            )

        def forward(self, candidate, frontier_mean, frontier_max, numeric):
            return self.network(torch.cat([candidate, frontier_mean, frontier_max, numeric], dim=-1)).squeeze(-1)

    return torch, nn, BudgetAwareHead


class BudgetAwareScorer:
    """Shared text encoder plus mean/max frontier pooling and non-negative head."""

    scorer_id = "budget-aware-cost-scorer-v1"

    def __init__(self, encoder, tokenizer, hidden_size: int, *, output_mode: str = "cost"):
        torch, _, Head = _torch_components()
        self.torch = torch
        self.encoder = encoder
        self.tokenizer = tokenizer
        self.head = Head(hidden_size).to(next(encoder.parameters()).device)
        self.output_mode = output_mode

    def parameters(self):
        yield from self.encoder.parameters()
        yield from self.head.parameters()

    def _encode(self, texts: Sequence[str]):
        batch = self.tokenizer(texts, padding=True, truncation=True, max_length=4096, return_tensors="pt")
        batch = {key: value.to(next(self.encoder.parameters()).device) for key, value in batch.items()}
        output = self.encoder(**batch, output_hidden_states=True, use_cache=False)
        hidden = output.hidden_states[-1] if getattr(output, "hidden_states", None) else output.last_hidden_state
        return last_non_padding_pool(hidden, batch["attention_mask"]), int(batch["attention_mask"].sum().item())

    def forward_tensors(self, public_state: dict, candidates: Sequence[Action]):
        frontier_texts = [json.dumps(route, ensure_ascii=False, sort_keys=True) for route in public_state["frontier"]]
        frontier_embeddings, frontier_tokens = self._encode(frontier_texts)
        frontier_mean = frontier_embeddings.mean(dim=0, keepdim=True)
        frontier_max = frontier_embeddings.max(dim=0, keepdim=True).values
        candidate_texts = [
            json.dumps(
                {
                    "question": public_state["question"],
                    "route_id": candidate.route_id,
                    "action": vars(candidate),
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            for candidate in candidates
        ]
        candidate_embeddings, candidate_tokens = self._encode(candidate_texts)
        count = len(candidates)
        remaining = public_state["remaining_budget"]
        numeric = self.torch.tensor(
            [[
                float(remaining["logical_retrieval_calls"]),
                float(remaining["reasoning_input_tokens"]),
                float(remaining["reasoning_output_tokens"]),
                float(remaining["unique_evidence_tokens"]),
                float(public_state["lambda"]),
            ]] * count,
            dtype=candidate_embeddings.dtype,
            device=candidate_embeddings.device,
        )
        logits = self.head(
            candidate_embeddings,
            frontier_mean.expand(count, -1),
            frontier_max.expand(count, -1),
            numeric,
        )
        if self.output_mode == "success":
            values = self.torch.sigmoid(logits)
        else:
            values = self.torch.nn.functional.softplus(logits)
        return values, frontier_tokens + candidate_tokens

    def score(self, public_state: dict, candidates: Sequence[Action]) -> tuple[list[float], ModelUsage]:
        start = time.perf_counter()
        values, tokens = self.forward_tensors(public_state, candidates)
        if self.output_mode == "success":
            values = 1.0 - values
        elapsed = time.perf_counter() - start
        return [float(value) for value in values.detach().cpu().tolist()], ModelUsage(
            input_tokens=tokens,
            gpu_seconds=elapsed,
        )
