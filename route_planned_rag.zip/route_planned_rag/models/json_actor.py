from __future__ import annotations

import json
import re
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Sequence

from route_planned_rag.models.interfaces import ModelUsage
from route_planned_rag.types import (
    AnswerWithCitations,
    BindingStatus,
    BindingUpdate,
    EvidenceCitation,
    InformationNeedGraph,
    InformationNode,
    ObservedPassage,
    PublicSample,
    RouteState,
    SearchCandidate,
)


@dataclass(frozen=True)
class GenerationResult:
    text: str
    input_tokens: int
    output_tokens: int
    gpu_seconds: float = 0.0


class OpenAICompatibleBackend:
    """Minimal local vLLM/OpenAI-compatible client with no external SDK."""

    def __init__(self, endpoint: str, model: str, timeout_seconds: int = 600):
        self.endpoint = endpoint.rstrip("/") + "/v1/chat/completions"
        self.model = model
        self.timeout_seconds = timeout_seconds

    def generate(self, prompt: str, *, temperature: float, top_p: float, max_tokens: int) -> GenerationResult:
        body = json.dumps({
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens,
        }).encode("utf-8")
        request = urllib.request.Request(
            self.endpoint,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        start = time.perf_counter()
        with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
            payload = json.loads(response.read().decode("utf-8"))
        elapsed = time.perf_counter() - start
        usage = payload.get("usage", {})
        return GenerationResult(
            text=str(payload["choices"][0]["message"]["content"]),
            input_tokens=int(usage.get("prompt_tokens", 0)),
            output_tokens=int(usage.get("completion_tokens", 0)),
            gpu_seconds=elapsed,
        )


class TransformersGenerationBackend:
    def __init__(self, model, tokenizer):
        self.model = model
        self.tokenizer = tokenizer

    def generate(self, prompt: str, *, temperature: float, top_p: float, max_tokens: int) -> GenerationResult:
        import torch

        messages = [{"role": "user", "content": prompt}]
        batch = self.tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_tensors="pt",
            return_dict=True,
        ).to(next(self.model.parameters()).device)
        torch.cuda.synchronize()
        start = time.perf_counter()
        with torch.inference_mode():
            output = self.model.generate(
                **batch,
                do_sample=temperature > 0,
                temperature=temperature if temperature > 0 else None,
                top_p=top_p if temperature > 0 else None,
                max_new_tokens=max_tokens,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - start
        input_length = batch["input_ids"].shape[1]
        completion = output[0, input_length:]
        return GenerationResult(
            text=self.tokenizer.decode(completion, skip_special_tokens=True),
            input_tokens=int(batch["attention_mask"].sum().item()),
            output_tokens=int(completion.numel()),
            gpu_seconds=elapsed,
        )


def extract_json(text: str) -> Any:
    stripped = text.strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", stripped, flags=re.DOTALL | re.IGNORECASE)
    if fenced:
        stripped = fenced.group(1).strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        starts = [position for position in (stripped.find("{"), stripped.find("[")) if position >= 0]
        if not starts:
            raise
        decoder = json.JSONDecoder()
        value, _ = decoder.raw_decode(stripped[min(starts) :])
        return value


class JsonActor:
    model_role = "actor"

    def __init__(
        self,
        backend,
        *,
        model_revision: str,
        tokenizer_revision: str,
        prompt_dir: str | Path,
        format_repairs: int = 1,
    ):
        self.backend = backend
        self.model_revision = model_revision
        self.tokenizer_revision = tokenizer_revision
        self.prompt_dir = Path(prompt_dir)
        self.format_repairs = format_repairs
        self.trace: list[dict[str, Any]] = []

    def _prompt(self, name: str) -> str:
        return (self.prompt_dir / f"{name}.txt").read_text(encoding="utf-8")

    def _generate_json(
        self,
        role: str,
        prompt: str,
        validator: Callable[[Any], Any],
        *,
        temperature: float,
        top_p: float = 1.0,
        max_tokens: int,
    ) -> tuple[Any | None, ModelUsage]:
        total_input = total_output = repairs = requests = 0
        total_gpu = 0.0
        current = prompt
        error = None
        for attempt in range(self.format_repairs + 1):
            remaining_output = max_tokens - total_output
            if remaining_output <= 0:
                self.trace.append({"role": role, "attempt": attempt, "status": "repair_skipped_output_budget"})
                break
            result = self.backend.generate(
                current,
                temperature=temperature if attempt == 0 else 0.0,
                top_p=top_p,
                max_tokens=remaining_output,
            )
            total_input += result.input_tokens
            total_output += result.output_tokens
            total_gpu += result.gpu_seconds
            requests += 1
            try:
                value = validator(extract_json(result.text))
                self.trace.append({"role": role, "attempt": attempt, "status": "valid"})
                return value, ModelUsage(total_input, total_output, total_gpu, requests, repairs)
            except Exception as exc:  # schema and semantic validation are both repairable once
                error = f"{type(exc).__name__}: {exc}"
                self.trace.append({"role": role, "attempt": attempt, "status": "invalid", "error": error})
                if attempt < self.format_repairs and total_output < max_tokens:
                    repairs += 1
                    current = (
                        "Repair the previous response to valid JSON only. Do not add facts or use gold data.\n"
                        f"Validation error: {error}\nPrevious response:\n{result.text}\nOriginal contract:\n{prompt}"
                    )
        self.trace.append({"role": role, "status": "fallback", "error": error})
        return None, ModelUsage(total_input, total_output, total_gpu, requests, repairs)

    def compile_graph(self, sample: PublicSample) -> tuple[InformationNeedGraph, ModelUsage]:
        prompt = self._prompt("compiler") + "\nPublic question:\n" + sample.question

        def validate(value: Any) -> InformationNeedGraph:
            if not isinstance(value, dict) or not isinstance(value.get("nodes"), list):
                raise ValueError("compiler output needs nodes array")
            nodes = tuple(
                InformationNode(
                    id=str(item["id"]),
                    query_template=str(item["query_template"]),
                    input_variables=tuple(map(str, item.get("input_variables", []))),
                    output_variable=str(item["output_variable"]),
                    depends_on=tuple(map(str, item.get("depends_on", []))),
                )
                for item in value["nodes"]
            )
            graph = InformationNeedGraph(nodes, tuple(map(str, value.get("answer_dependencies", []))))
            graph.validate()
            return graph

        graph, usage = self._generate_json("compiler", prompt, validate, temperature=0.0, max_tokens=2048)
        if graph is None:
            graph = InformationNeedGraph(
                nodes=(InformationNode("direct", sample.question, (), "answer", ()),),
                answer_dependencies=("direct",),
            )
        return graph, usage

    def propose_queries(
        self, sample: PublicSample, graph: InformationNeedGraph, route: RouteState, maximum: int
    ) -> tuple[list[SearchCandidate], ModelUsage]:
        prompt = self._prompt("proposer").format(maximum=maximum) + "\nPublic state:\n" + json.dumps(
            {"question": sample.question, "graph": _graph_dict(graph), "route": route.compact_summary()},
            ensure_ascii=False,
            sort_keys=True,
        )

        def validate(value: Any) -> list[SearchCandidate]:
            if not isinstance(value, list) or len(value) > maximum:
                raise ValueError("proposer output must be a bounded array")
            node_ids = {node.id for node in graph.nodes}
            result = []
            for index, item in enumerate(value):
                if str(item["node_id"]) not in node_ids:
                    raise ValueError("candidate references unknown node")
                intent = str(item["intent"])
                if intent not in {"resolve", "disambiguate", "verify", "direct"}:
                    raise ValueError("invalid query intent")
                query = str(item["query"]).strip()
                if not query:
                    raise ValueError("empty query")
                result.append(SearchCandidate(
                    action_id=f"{route.route_id}:search:{len(route.attempted_queries)}:{index}",
                    route_id=route.route_id,
                    node_id=str(item["node_id"]),
                    query=query,
                    intent=intent,
                ))
            return result

        result, usage = self._generate_json(
            "proposer", prompt, validate, temperature=0.7, top_p=0.9, max_tokens=1024
        )
        if result:
            return result, usage
        unresolved = next((node_id for node_id in graph.topological_ids() if node_id not in route.resolved_node_ids), None)
        if unresolved is None:
            return [], usage
        self.trace.append({"role": "proposer", "status": "public_direct_query_fallback"})
        return [SearchCandidate(
            action_id=f"{route.route_id}:search:{len(route.attempted_queries)}:fallback",
            route_id=route.route_id,
            node_id=unresolved,
            query=sample.question,
            intent="direct",
        )], usage

    def resolve(
        self,
        sample: PublicSample,
        graph: InformationNeedGraph,
        route: RouteState,
        node_id: str,
        passages: Sequence[ObservedPassage],
    ) -> tuple[list[BindingUpdate], ModelUsage]:
        prompt = self._prompt("resolver") + "\nPublic input:\n" + json.dumps(
            {
                "question": sample.question,
                "node_id": node_id,
                "route": route.compact_summary(),
                "delivered_passages": [vars(passage) for passage in passages],
            },
            ensure_ascii=False,
            sort_keys=True,
        )
        passage_by_id = {passage.chunk_id: passage for passage in passages}

        def validate(value: Any) -> list[BindingUpdate]:
            if not isinstance(value, list) or len(value) > 2:
                raise ValueError("resolver must return at most two alternatives")
            updates = []
            for item in value:
                spans = item.get("evidence_spans", [])
                chunk_ids = []
                for span in spans:
                    chunk_id = str(span["chunk_id"])
                    quote = str(span["quote"])
                    if chunk_id not in passage_by_id or quote not in passage_by_id[chunk_id].text:
                        raise ValueError("resolver evidence quote is not locatable in a delivered passage")
                    chunk_ids.append(chunk_id)
                status = BindingStatus(str(item["status"]))
                if status == BindingStatus.EVIDENCE_BACKED and not chunk_ids:
                    raise ValueError("evidence-backed binding needs a delivered evidence span")
                updates.append(BindingUpdate(
                    variable=str(item["variable"]),
                    value=str(item["value"]),
                    status=status,
                    evidence_chunk_ids=tuple(chunk_ids),
                    invalidates=tuple(map(str, item.get("invalidates", []))),
                ))
            return updates

        result, usage = self._generate_json("resolver", prompt, validate, temperature=0.0, max_tokens=2048)
        return result or [], usage

    def answer(self, sample: PublicSample, route: RouteState) -> tuple[AnswerWithCitations, ModelUsage]:
        prompt = self._prompt("reader") + "\nPublic input:\n" + json.dumps(
            {"question": sample.question, "route": route.compact_summary(evidence_chars=100000)},
            ensure_ascii=False,
            sort_keys=True,
        )
        passage_ids = {passage.chunk_id: passage.doc_id for passage in route.observed_passages}

        def validate(value: Any) -> AnswerWithCitations:
            if not isinstance(value, dict):
                raise ValueError("reader output must be an object")
            citations = []
            for item in value.get("citations", []):
                span_id = str(item["span_id"])
                doc_id = str(item["doc_id"])
                if span_id not in passage_ids or passage_ids[span_id] != doc_id:
                    raise ValueError("reader citation is not a delivered doc/span pair")
                citations.append(EvidenceCitation(doc_id, span_id))
            return AnswerWithCitations(
                answer=str(value.get("answer", "")),
                citations=tuple(citations),
                abstain=bool(value.get("abstain", False)),
                reasoning_triples=tuple(tuple(map(str, triple)) for triple in value.get("reasoning_triples", [])),
            )

        result, usage = self._generate_json("reader", prompt, validate, temperature=0.0, max_tokens=512)
        return result or AnswerWithCitations("", (), abstain=True), usage


def _graph_dict(graph: InformationNeedGraph) -> dict[str, Any]:
    return {
        "nodes": [vars(node) for node in graph.nodes],
        "answer_dependencies": graph.answer_dependencies,
    }
