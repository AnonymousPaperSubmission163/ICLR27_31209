from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


class ModelNotAllowed(ValueError):
    pass


@dataclass(frozen=True)
class AllowedModel:
    repo_id: str
    roles: tuple[str, ...]
    revisions: tuple[str, ...]
    lineage: str | None = None


class ModelRegistry:
    def __init__(self, allowlist_path: str | Path):
        payload = json.loads(Path(allowlist_path).read_text(encoding="utf-8"))
        self.models = {
            item["repo_id"]: AllowedModel(
                repo_id=item["repo_id"],
                roles=tuple(item["roles"]),
                revisions=tuple(item.get("revisions", ())),
                lineage=item.get("lineage"),
            )
            for item in payload["models"]
        }

    def require(self, repo_id: str, role: str) -> AllowedModel:
        model = self.models.get(repo_id)
        if model is None:
            raise ModelNotAllowed(f"model is not in the v2.1-Mistral allowlist: {repo_id}")
        if role not in model.roles:
            raise ModelNotAllowed(f"model {repo_id} is not allowed for role {role}")
        return model

    def require_revision(self, repo_id: str, role: str, revision: str | None) -> AllowedModel:
        model = self.require(repo_id, role)
        if not revision:
            raise ModelNotAllowed(f"formal role {role} requires an immutable revision for {repo_id}")
        if revision not in model.revisions:
            raise ModelNotAllowed(f"revision {revision} is not allowlisted for {repo_id}")
        return model

    def validate_configured_roles(self, models: dict) -> None:
        role_map = {
            "actor": ("compiler", "proposer", "resolver", "reader"),
            "scorer": ("scorer",),
            "reranker": ("reranker",),
            "retriever": ("retriever",),
            "judge": ("judge",),
        }
        for config_role, allowed_roles in role_map.items():
            repo_id = models[config_role]["repo_id"]
            for role in allowed_roles:
                self.require_revision(repo_id, role, models[config_role].get("revision"))


def resolve_huggingface_revision(repo_id: str, requested_revision: str | None = None) -> str:
    try:
        from huggingface_hub import HfApi
    except ImportError as exc:
        raise RuntimeError("huggingface-hub is required to resolve immutable revisions") from exc
    info = HfApi().model_info(repo_id, revision=requested_revision)
    if not info.sha:
        raise RuntimeError(f"Hugging Face did not return a commit SHA for {repo_id}")
    return str(info.sha)
