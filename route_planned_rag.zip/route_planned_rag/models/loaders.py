from __future__ import annotations

import hashlib
from pathlib import Path


def chat_template_sha256(tokenizer) -> str:
    return hashlib.sha256((tokenizer.chat_template or "").encode("utf-8")).hexdigest()


def load_mistral3_generation(item: dict, *, cache_dir: str | Path, device: int = 0):
    import torch
    from transformers import AutoTokenizer, Mistral3ForConditionalGeneration

    tokenizer = AutoTokenizer.from_pretrained(
        item["repo_id"],
        revision=item["revision"],
        fix_mistral_regex=bool(item.get("fix_mistral_regex", False)),
        cache_dir=str(cache_dir),
    )
    observed_hash = chat_template_sha256(tokenizer)
    expected_hash = item.get("chat_template_sha256")
    if expected_hash and observed_hash != expected_hash:
        raise RuntimeError(f"chat template hash mismatch for {item['repo_id']}")
    model = Mistral3ForConditionalGeneration.from_pretrained(
        item["repo_id"],
        revision=item["revision"],
        cache_dir=str(cache_dir),
        dtype=getattr(torch, item.get("dtype", "bfloat16")),
        device_map={"": device},
    ).eval()
    return tokenizer, model
