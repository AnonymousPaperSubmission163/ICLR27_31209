from __future__ import annotations

import time
from typing import Sequence

import numpy as np

from route_planned_rag.models.interfaces import ModelUsage


def format_e5_query(query: str, instruction: str) -> str:
    return f"{instruction}{query}"


def last_token_pool(last_hidden_states, attention_mask):
    import torch

    left_padding = bool((attention_mask[:, -1].sum() == attention_mask.shape[0]).item())
    if left_padding:
        return last_hidden_states[:, -1]
    sequence_lengths = attention_mask.sum(dim=1) - 1
    batch_indices = torch.arange(last_hidden_states.shape[0], device=last_hidden_states.device)
    return last_hidden_states[batch_indices, sequence_lengths]


class E5MistralEncoder:
    def __init__(
        self,
        repo_id: str,
        revision: str,
        *,
        query_instruction: str,
        max_tokens: int = 4096,
        device: str = "cuda",
        dtype: str = "bfloat16",
        cache_dir: str | None = None,
    ):
        import torch
        from transformers import AutoModel, AutoTokenizer

        torch_dtype = getattr(torch, dtype)
        self.tokenizer = AutoTokenizer.from_pretrained(repo_id, revision=revision, cache_dir=cache_dir)
        device_map = {"": 0} if device in {"cuda", "cuda:0"} else {"": device}
        self.model = AutoModel.from_pretrained(
            repo_id,
            revision=revision,
            cache_dir=cache_dir,
            dtype=torch_dtype,
            device_map=device_map,
        ).eval()
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        self.query_instruction = query_instruction
        self.max_tokens = max_tokens
        self.revision = revision

    def encode(self, texts: Sequence[str], *, is_query: bool) -> tuple[np.ndarray, ModelUsage]:
        import torch
        import torch.nn.functional as functional

        rendered = [format_e5_query(text, self.query_instruction) if is_query else text for text in texts]
        batch = self.tokenizer(
            rendered,
            max_length=self.max_tokens,
            padding=True,
            truncation=True,
            return_tensors="pt",
        ).to(self.model.device)
        start = time.perf_counter()
        with torch.inference_mode():
            output = self.model(**batch)
            pooled = last_token_pool(output.last_hidden_state, batch["attention_mask"])
            normalized = functional.normalize(pooled.float(), p=2, dim=1)
        if normalized.shape[-1] != 4096:
            raise RuntimeError(f"E5-Mistral embedding dimension is {normalized.shape[-1]}, expected 4096")
        elapsed = time.perf_counter() - start
        tokens = int(batch["attention_mask"].sum().item())
        return normalized.cpu().numpy(), ModelUsage(input_tokens=tokens, gpu_seconds=elapsed)
