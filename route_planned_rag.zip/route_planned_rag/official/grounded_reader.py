"""Node-local evidence with bounded JSON syntax, raw sources and no summary calls."""
import json,time,re
from pydantic import Field,model_validator,field_validator,PrivateAttr
from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.models.json_actor import extract_json
from route_planned_rag.prototype.logic import substitute
from route_planned_rag.indexed.schema import Function,Program,Goal,Reading,Extracted,compile_program,norm,parse_date
from route_planned_rag.official.logic_extension import CompactClient,LogicExtensionEngine
from route_planned_rag.indexed.passages import passage_input,extraction_slots,node_decision_schema,decisions_to_reading

def question_contract(question):
    """Small question-only filter template; never examines retrieved values or labels."""
    shared=re.fullmatch(r'(?:What|Which) (?:university|college|school) did (.+?) (?:graduate(?: from)?|attend) that (.+?) also (?:graduated from|attended)\?',question,re.I)
    if shared:
        return dict(kind='shared_education',subjects=[shared[1],shared[2]])
    m=re.fullmatch(r'(?:Which|What) (company|organization|person)\b.+?\b(based|headquartered|located) in ([A-Z][\w .-]*?)(?: in (\d{4}))?\?',question)
    if not m:
        birth=re.fullmatch(r'Who\b.+\band (?:who )?(?:was |is )?born (?:on|in) (.+?)\??',question,re.I)
        parsed=parse_date(birth[1].rstrip('?')) if birth else None
        if parsed:return dict(kind='person_birth_filter',answer_type='person',expected=parsed[0].strftime('%Y' if parsed[1]=='year' else '%Y-%m-%d'),question_literal=birth[1].rstrip('?'),time=None)
        return None
    return dict(kind='entity_location_filter',answer_type={'company':'organization','organization':'organization','person':'person'}[m[1]],relation=m[2]+' in',expected=m[3],time=m[4])

class Row(Strict):
    subject:str|None=None
    value:str
    evidence_id:str
    negated:bool=False
    @field_validator('value',mode='before')
    @classmethod
    def numeric_surface(cls,value):
        if type(value) in (int,float):return str(value)
        return value

class Node(Function):
    time:str|None=None
    expected:str|None=None
    rows:list[Row]=Field(default_factory=list,max_length=12)

class Grounded(Strict):
    _binding_records:list=PrivateAttr(default_factory=list)
    _reading_rejections:list=PrivateAttr(default_factory=list)
    functions:list[Node]=Field(max_length=6)
    goal:Goal
    limitations:str=''
    @field_validator('limitations',mode='before')
    @classmethod
    def empty_metadata(cls,value):
        # Empty metadata containers carry no semantic content. Never discard a
        # nonempty limitation or alter a generated rule/fact to pass validation.
        return '' if value is None or value=={} or value==[] else value
    def program(self,question):
        # The question template compiles the projection before final Program
        # validation. This intermediate object is never passed to the engine.
        p=Program.model_construct(functions=[Function(**n.model_dump(exclude={'rows'})) for n in self.functions],goal=self.goal,limitations=self.limitations)
        contract=question_contract(question)
        if contract and contract['kind']=='shared_education':
            outputs=[]
            for subject in contract['subjects']:
                matches=[i for i,f in enumerate(p.functions) if norm(f.subject)==norm(subject) and f.value_type in ('organization','entity') and f.expected is None and re.fullmatch(r'(?:graduate[d]? (?:from|at)|attend(?:ed)?|educated at)',f.relation.replace('_',' '),re.I)]
                if len(matches)!=1:raise ValueError('shared education requires one school-output relation for each named person')
                outputs.extend(matches)
            p.goal=Goal(kind='intersection',nodes=outputs)
            p.question_check='Question-only shared education template binds both school outputs to the same variable before graph freeze.'
        elif contract and contract['kind']=='person_birth_filter':
            outputs=[i for i,f in enumerate(p.functions) if f.value_type=='person' and f.expected is None]
            filters=[f for f in p.functions if f.value_type=='date' and re.search(r'\bborn\b|\bbirth',f.relation.replace('_',' '))]
            if len(outputs)!=1 or not filters:raise ValueError('birth-filter template requires one person output and date conditions')
            for node in filters:
                if node.subject!='$'+str(outputs[0]):raise ValueError('birth date must constrain the requested person')
                if node.expected and parse_date(node.expected)!=parse_date(contract['expected']):raise ValueError('birth filter disagrees with question date')
                node.expected=contract['expected']
            p.goal=Goal(kind='value',nodes=outputs);p.question_check='Question-only person/birth conjunction compiles the date filter before graph freeze.'
        elif contract:
            outputs=[i for i,f in enumerate(p.functions) if f.value_type==contract['answer_type'] and f.expected is None]
            filters=[i for i,f in enumerate(p.functions) if f.relation.replace('_',' ').strip()==contract['relation']]
            if len(outputs)!=1 or len(filters)!=1:raise ValueError('question template needs one typed answer and one location filter')
            node=p.functions[filters[0]]
            if node.subject!='$'+str(outputs[0]):raise ValueError('filter must constrain the returned entity')
            if node.expected not in (None,contract['expected']) or node.time not in (None,contract['time']):raise ValueError('generated constraint disagrees with question template')
            node.expected=contract['expected'];node.time=contract['time'];p.goal=Goal(kind='value',nodes=outputs)
            p.question_check='Question-only entity/location template supplies projection, filter and scope before graph freeze.'
        p=Program.model_validate(p.model_dump())
        compile_program(p,question)
        # A quoted work explicitly introduced as the question's subject cannot
        # disappear from the graph in favor of a broad class such as "British".
        work=re.match(r'^"([^"\n]+)"\s+(?:is|was)\s+(?:a |an |the )?(?:song|film|novel|book|episode|album)\b',question,re.I)
        if work and p.goal.kind!='unsupported' and not any(norm(f.subject)==norm(work[1]) for f in p.functions):
            raise ValueError('graph omits the quoted work that anchors the question')
        for f in p.functions:
            if f.subject.startswith('$') and p.functions[int(f.subject[1:])].value_type in ('number','date'):
                raise ValueError('scalar outputs are terminal; use a comparison goal instead of an entity relation')
        if p.goal.kind=='value' and p.functions[p.goal.nodes[0]].expected is not None:
            raise ValueError('value goal must return an unknown output, not a question-given filter')
        return p
    def reading(self,evidence,program=None,binding_values=None):
        lookup={e['evidence_id']:e for e in evidence}
        facts=[];self._binding_records=[];self._reading_rejections=[]
        for i,n in enumerate(self.functions):
            for j,r in enumerate(n.rows):
                source=lookup.get(r.evidence_id)
                subject=r.subject
                if not source:
                    self._reading_rejections.append(dict(node=i,row=j,reason='unobserved_citation'));continue
                if not subject:
                    if not n.subject.startswith('$'):subject=n.subject;origin='fixed_literal_input'
                    else:
                        parent=int(n.subject[1:]);values={norm(x.value):x.value for x in self.functions[parent].rows}
                        values.update({norm(v):v for v in (binding_values or {}).get(parent,[])})
                        if len(values)!=1:
                            text=norm(source['source_metadata'].get('title','')+' '+source['original_text'])
                            values={key:value for key,value in values.items() if key in text}
                        if len(values)!=1:
                            self._reading_rejections.append(dict(node=i,row=j,reason='missing_or_ambiguous_input_binding'));continue
                        subject=next(iter(values.values()));origin='unique_parent_candidate_input'
                    self._binding_records.append(dict(node=i,row=j,subject=subject,origin=origin))
                facts.append(Extracted(node=i,subject=subject,value=r.value,time=(program.functions[i].time if program else n.time),negated=r.negated,evidence_id=r.evidence_id,quote=source['original_text']))
        return Reading(facts=facts,uncertainty=[json.dumps(r) for r in self._reading_rejections[:6]],rewrite=None)

class NodeRows(Strict):
    node:int=Field(ge=0,le=5)
    rows:list[Row]=Field(max_length=12)
class Followup(Strict):
    _binding_records:list=PrivateAttr(default_factory=list)
    _reading_rejections:list=PrivateAttr(default_factory=list)
    nodes:list[NodeRows]=Field(max_length=6)
    def reading(self,evidence,program,binding_values=None):
        if len({n.node for n in self.nodes})!=len(self.nodes):raise ValueError('duplicate node')
        if any(n.node>=len(program.functions) for n in self.nodes):raise ValueError('unknown node')
        rows={n.node:n.rows for n in self.nodes}
        grounded=Grounded(functions=[Node(**f.model_dump(),rows=rows.get(i,[])) for i,f in enumerate(program.functions)],goal=program.goal,limitations=program.limitations)
        reading=grounded.reading(evidence,program,binding_values)
        self._binding_records=grounded._binding_records;self._reading_rejections=grounded._reading_rejections
        return reading

def root_subject(node):
    if node.subject.startswith('$'):raise ValueError('dependent fact requires actual subject')
    return node.subject

WARMUP='''Read the question and original passages. Build a SMALL fixed logical plan and immediately fill each node with its independently supported evidence rows. Return only compact JSON, in this format:
{"functions":[{"subject":"question entity or $0","relation":"one relation","value_type":"entity","time":null,"expected":null,"rows":[{"subject":"actual entity","value":"actual value","evidence_id":"E1"}]}],"goal":{"kind":"value","nodes":[0]},"limitations":""}
Functions are numbered from 0. A literal subject is a phrase copied from the question. $0 is the first function's OUTPUT; references must point backward. value_type describes the output: person, organization, place, work, event, category, number, date, or entity. time is null unless the RELATION is scoped to a year in the question. expected is null unless the question fixes that output to a specific name/date/number. A birth/creation date is a date output, not a time scope. Each condition about $0 must take $0, not a previous condition's date/place. Add ONLY conditions requested by the question; never extra tests about creators, continuity or other institutions.
Goal value returns ONE node's output after ALL functions are satisfied. Returning a person with two attributes uses value, not intersection. Multiple value rows form a list. Goal subject chooses among literal candidate subjects whose expected filters hold (OR branches). Goal greater compares two number nodes; earlier compares two dates; same compares two values. Unsupported means the question cannot be expressed, not that evidence is missing; then functions and goal.nodes are empty.
For EACH function, put all supported rows right beside it. Missing relations get rows [], but do not suppress other nodes' facts. Rows use real entity names, never $0. A row's subject and value must appear in its cited passage or title. Choose the CORRECT source for each relation, using titles/pronouns to resolve the passage's subject. Keep entity spellings consistent across connected rows; prefer the source's full name when it explicitly defines an alias. Dates/numbers may be normalized. Preserve negation with negated:true. No guessed facts. Do not turn approximate quantities into exact counts. Full source text is retained by the program. No commentary, regex, evidence summaries or final answer outside this JSON.'''

WARMUP+='''
Two FICTIONAL examples illustrate the output contract, not evidence for the actual task:
Question: Where was the author of Indigo Road born? E1: Indigo Road was written by Hana Fox. E2: Hana Fox was born in Oslo.
{"functions":[{"subject":"Indigo Road","relation":"written by","value_type":"person","rows":[{"value":"Hana Fox","evidence_id":"E1"}]},{"subject":"$0","relation":"born in","value_type":"place","rows":[{"subject":"Hana Fox","value":"Oslo","evidence_id":"E2"}]}],"goal":{"kind":"value","nodes":[1]}}
Question: Which company founded by Ivo Lin is based in Milan? E1: Ivo Lin founded Eon Ltd. E2: Eon Ltd is based in Milan.
{"functions":[{"subject":"Ivo Lin","relation":"founded","value_type":"organization","rows":[{"value":"Eon Ltd","evidence_id":"E1"}]},{"subject":"$0","relation":"based in","value_type":"place","expected":"Milan","rows":[{"subject":"Eon Ltd","value":"Milan","evidence_id":"E2"}]}],"goal":{"kind":"value","nodes":[0]}}
For a literal node, omit row.subject: it is automatically the node's fixed subject. For a $ reference node, row.subject is REQUIRED and is the named entity returned by the earlier node. Do not use descriptions like 'the author of Indigo Road' as a literal subject: resolve the named work to its author with a separate function. Goal selects the type asked by the QUESTION: a company query returns the company node, not its matching location. Optional null time/expected fields and empty limitations may be omitted. Now process only the actual question and passages below.'''

FOLLOWUP='''Read the original passages for EACH fixed relation independently. Return compact JSON {"nodes":[{"node":0,"rows":[{"subject":"actual entity","value":"actual value","evidence_id":"E1"}]}]}. Include every supported subject/value row, even if another node is unknown. Unknown nodes have rows: []. Do not change the fixed relations. Use actual names, never variables. The subject and value must occur in the cited passage or title. Resolve names/pronouns from that passage; maintain consistent names between connected nodes. Match the requested relation, type, time and filters. Explicit negation uses negated:true. No guessed facts or exact counts from approximations. Program joins relations; you only extract individual rows. The rejection records explain previous invalid citations; do not repeat them. No summaries or final answer.'''

class FreeClient(CompactClient):
    """Same budget ledger, one natural model response, strict post-generation validation."""
    def ask(self,role,schema,instructions,payload,**kwargs):
        maximum=kwargs.get('max_tokens',1200);prompt=self.preflight(instructions,payload,maximum)
        call=dict(call_id='M'+str(len(self.calls)+1),role=role,prompt=prompt,input_tokens=0,output_tokens=0,seconds=0.,max_output_tokens=maximum)
        start=time.perf_counter()
        try:
            if role in ('node_facts','candidate_and_graph'):
                from route_planned_rag.prototype.decoding import generate_ordered_json
                contract=packet_schema(payload['question'],payload['passages']) if role=='candidate_and_graph' else schema.model_json_schema()
                result=generate_ordered_json(self.actor.backend,prompt,schema=contract,temperature=0,top_p=1,max_tokens=maximum)
            else:result=self.actor.backend.generate(prompt,temperature=0,top_p=1,max_tokens=maximum)
            call.update(completion=result.text,input_tokens=result.input_tokens,output_tokens=result.output_tokens)
            try:decoded=extract_json(result.text)
            except ValueError:
                if schema is not AnswerPacket:raise
                decoded=completed_candidate_prefix(result.text);call['partial_graph']=True
            value=schema.model_validate(decoded);call['status']='validated';return value
        except Exception as exc:call.update(status='invalid',error=repr(exc));raise
        finally:call['seconds']=time.perf_counter()-start;self.calls.append(call);self.global_calls.append(call)

class GroundedEngine(LogicExtensionEngine):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.index.admission_guard=self.qualifier_guard
    def qualifier_guard(self,row,function,evidence):
        """A narrow contradiction check, not a general entailment claim."""
        # Do not silently supply background geography as a retrieved fact. This
        # checks explicit region classifiers only, not arbitrary paraphrases.
        region=re.fullmatch(r'(European|Asian|African|North American|South American|Oceanian) country',function.relation.replace('_',' ').strip(),re.I)
        if region and not re.search(r'\b'+re.escape(region[1])+r'\b',evidence['original_text'],re.I):
            return 'geographic_qualifier_not_explicit_in_cited_source'
        direction=re.fullmatch(r'(?:has (?:a )?)?(younger|older) (?:brother|sister|sibling)',function.relation.replace('_',' ').strip(),re.I)
        if not direction or row.negated:return None
        dates={}
        for source in self.raw_evidence.values():
            title=norm(source['source_metadata'].get('title',''))
            match=re.search(r'^(.{0,120}?)\s*\(born ([^;)]+)',source['original_text'])
            if match and (parsed:=parse_date(match[2])):
                for name in {title,norm(match[1])}&{norm(row.subject),norm(row.value)}:dates.setdefault(name,set()).add(parsed)
        a,b=dates.get(norm(row.subject),set()),dates.get(norm(row.value),set())
        if len(a)!=1 or len(b)!=1:return None
        a,b=next(iter(a)),next(iter(b))
        if a[1]!=b[1] or a[0]==b[0]:return None
        younger=b[0]>a[0]
        if younger!=(direction[1].lower()=='younger'):
            return 'age_relation_contradicted_by_observed_birthdates'
        return None
    def payload(self,evidence,action):
        shown,_=passage_input(evidence)
        rejected=[{k:c[k] for k in ('node','subject','value','evidence_id','reason')} for c in self.index.snapshot()['candidates'] if c['status']=='quarantined']
        return dict(question=self.question,relations=extraction_slots(self.program),current_node=action['node'],rejected_rows=rejected[-12:],passages=shown)
    def before_retrieval(self,action):
        self.client.preflight(FOLLOWUP,self.payload(list(self.raw_evidence.values()),action),900)
    def read_evidence(self,selected,action):
        self.raw_evidence.update({e['evidence_id']:e for e in selected});full=list(self.raw_evidence.values())
        value=self.client.ask('node_facts',Followup,FOLLOWUP,self.payload(full,action),max_tokens=900)
        bindings={}
        for i,pattern in enumerate(self.patterns):
            bindings[i]=list({self.index.names[substitute(pattern,h['bindings']).arguments[1].name] for h in self.index.match([pattern])})
        reading=value.reading(full,self.program,bindings)
        return reading,dict(value.model_dump(),binding_resolution=value._binding_records,rejected_rows=value._reading_rejections)

PLAN='''Translate only the question into a small graph of information requirements. Do not answer or invent facts. Return compact JSON with functions and goal. Function fields: subject (named phrase copied from question or $0/$1 referring to an EARLIER output), relation, value_type (person, organization, place, work, event, category, number, date or entity), time (null unless explicitly scoped), expected (null unless question gives this value).
Goal {kind:"value",nodes:[i]} returns node i's unknown output after ALL conditions hold. Pick the output TYPE asked for, not a given filter/date. Goal subject chooses between literal candidate subjects with explicit expected filters; greater/earlier compare two number/date nodes; same compares two outputs. Lists use value with multiple rows. Missing knowledge requires retrieval, not unsupported. No rows or answers at this stage.
Example: Where was the author of Indigo Road born?
{"functions":[{"subject":"Indigo Road","relation":"written by","value_type":"person"},{"subject":"$0","relation":"born in","value_type":"place"}],"goal":{"kind":"value","nodes":[1]}}
Example: Who sang for Violet Echo and was born in 1970?
{"functions":[{"subject":"Violet Echo","relation":"singer","value_type":"person"},{"subject":"$0","relation":"born in year","value_type":"date","expected":"1970"}],"goal":{"kind":"value","nodes":[0]}}
Include only requested conditions. Keep each condition about the same entity bound to the SAME $i. Do not turn a work into an institution, or a place/date into a person. Optional null fields may be omitted.'''

NODE_READ='''Extract each requested relation INDEPENDENTLY from the original passages. The program joins rows; you need not know the final answer. For EACH node_i, return {"evidence_check":"brief source support","status":"supported","rows":[{"subject":"entity","value":"value","evidence_id":"E1","negated":false}]} or {"evidence_check":"what is missing","status":"unknown"}. Do not suppress supported intermediate nodes.
Root subjects are fixed; other subjects are real names from passages, not variables. Copy values from the cited passage or title. Cite the source that supports THIS relation, not another hop. Resolve pronouns from the title and passage. Prefer source-defined full names and consistent spellings. Preserve dates, negation and qualifiers. Do not treat a workplace as birthplace, a movie clip as first appearance, or an approximate count as exact. Extract all relevant rows, keeping alternatives separate. No remembered facts. Unknown is not false. No final answer or summary.'''

class StagedEngine(GroundedEngine):
    def before_retrieval(self,action):
        self.client.preflight(NODE_READ,self.payload(list(self.raw_evidence.values()),action),1100)
    def read_evidence(self,selected,action):
        self.raw_evidence.update({e['evidence_id']:e for e in selected});full=list(self.raw_evidence.values())
        _,lookup=passage_input(full)
        value=self.client.ask('node_facts',node_decision_schema(lookup,self.program,self.index.names.values()),NODE_READ,self.payload(full,action),max_tokens=1100)
        return decisions_to_reading(value,lookup,self.program),value.model_dump()

class AnswerPacket(Strict):
    answer:str|list[str]
    evidence_ids:list[str]
    sufficient:bool
    graph:dict=Field(default_factory=dict)

def packet_schema(question,passages):
    """Constrain syntax and backward references, without forcing any fact or answer."""
    import copy
    from route_planned_rag.indexed.schema import question_program_schema
    s=AnswerPacket.model_json_schema();g=Grounded.model_json_schema();defs=g.pop('$defs')
    s['$defs']=defs;s['properties']['answer']={'type':'string'}
    ids=[p['evidence_id'] for p in passages]
    s['properties']['evidence_ids']={'type':'array','items':{'enum':ids},'maxItems':len(ids)}
    defs['Row']['properties']['evidence_id']={'enum':ids}
    question_schema=question_program_schema(question)
    bounded=question_schema.model_fields['functions'].annotation.__args__[0]
    roots=[x for x in bounded.model_fields['subject'].annotation.__args__ if not x.startswith('$')]
    nodes=[]
    for i in range(6):
        node=copy.deepcopy(defs['Node']);node['properties']['subject']={'enum':roots+[f'${j}' for j in range(i)]}
        if i==0:
            fixed_row=copy.deepcopy(defs['Row']);fixed_row['properties']['subject']={'type':'null'};defs['RootRow']=fixed_row
            node['properties']['rows']['items']={'$ref':'#/$defs/RootRow'}
        defs['Step'+str(i)]=node;nodes.append({'$ref':'#/$defs/Step'+str(i)})
    # This installed XGrammar version requires every prefix item unless the
    # tuple's length is explicit. Enumerate legal lengths instead of silently
    # forcing six nodes. Language-level matcher tests cover 1, 2 and 6 nodes.
    g['properties']['functions']={'anyOf':[dict(type='array',prefixItems=nodes[:n],items=False,minItems=n,maxItems=n) for n in range(7)]}
    # The goal format is explicit even when the natural model would emit nested
    # objects or a goal-level "expected" attribute.
    choices=[]
    for kind in question_schema.model_fields['goal'].annotation.model_fields['kind'].annotation.__args__:
        lo,hi=(0,0) if kind=='unsupported' else (1,1) if kind=='value' else (2,2) if kind in ('same','greater','earlier') else (2,6) if kind=='intersection' else (1,6)
        choices.append(dict(type='object',properties={'kind':{'const':kind},'nodes':{'type':'array','items':{'type':'integer','minimum':0,'maximum':5},'minItems':lo,'maxItems':hi}},required=['kind','nodes'],additionalProperties=False))
    defs['Goal']={'anyOf':choices}
    s['properties']['graph']=g
    return s

def format_candidate(packet,evidence,index):
    """Source-only citation completion and display normalization; preserve raw packet."""
    ids={e['evidence_id']:e for e in evidence};used=list(packet.evidence_ids);changes=[]
    def citations(value):
        if isinstance(value,dict):
            eid=value.get('evidence_id')
            if isinstance(eid,str) and eid in ids and eid not in used:used.append(eid);changes.append(dict(kind='graph_citation',evidence_id=eid))
            for child in value.values():citations(child)
        elif isinstance(value,list):
            for child in value:citations(child)
    citations(packet.graph)
    answer=packet.answer
    if isinstance(answer,list):
        values=answer;answer='; '.join(values)
        for eid in used:
            if eid not in ids:continue
            text=ids[eid]['original_text'];at=0;positions=[]
            for value in values:
                start=text.casefold().find(value.casefold(),at)
                if start<0:break
                positions.append((start,start+len(value)));at=start+len(value)
            if len(positions)!=len(values) or not positions:continue
            between=[text[a[1]:b[0]] for a,b in zip(positions,positions[1:])]
            if any(re.sub(r'\b(?:and|or)\b|[^\w]', '',re.sub(r'\([^)]*\)','',part),flags=re.I) for part in between):continue
            answer=text[positions[0][0]:positions[-1][1]];changes.append(dict(kind='source_enumeration',evidence_id=eid));break
    aliases=index.observed_aliases();alias=aliases.get(norm(answer))
    if alias and alias['kind']=='explicit_biographical_title_lead' and alias['value']!=answer:
        changes.append(dict(alias,kind='source_defined_name',alias_kind=alias['kind'],original=answer));answer=alias['value']
        if alias['evidence_id'] not in used:used.append(alias['evidence_id'])
    return packet.model_copy(update={'answer':answer,'evidence_ids':used}),changes

def completed_candidate_prefix(text):
    """Recover only independently complete candidate fields before a truncated graph.
    Never synthesize graph content, source IDs or missing candidate fields.
    """
    decoder=json.JSONDecoder();position=text.index('{')+1;fields={}
    while position<len(text):
        while position<len(text) and text[position].isspace():position+=1
        key,end=decoder.raw_decode(text,position);position=end
        while position<len(text) and text[position].isspace():position+=1
        if text[position]!=':':raise ValueError('candidate prefix colon missing')
        position+=1
        while position<len(text) and text[position].isspace():position+=1
        if key=='graph':break
        if key not in ('answer','evidence_ids','sufficient'):raise ValueError('unexpected candidate field')
        fields[key],position=decoder.raw_decode(text,position)
        while position<len(text) and text[position].isspace():position+=1
        if text[position]!=',':break
        position+=1
    if set(fields)!={'answer','evidence_ids','sufficient'}:raise ValueError('incomplete candidate fields')
    return fields

PACKET_PROMPT='''Answer the question using ONLY the original passages. Prefer the source's full canonical name; for a requested enumeration preserve its original wording, including parenthetical qualifications. Give a concise answer and the IDs of its supporting passages. sufficient is false if a question condition lacks evidence. Never guess from memory.
Then, in the SAME response, provide an optional logical graph of the QUESTION requirements and the supported rows. Graph errors cannot change the cited candidate answer; the program validates it separately. Return compact JSON:
{"answer":"...","evidence_ids":["E1"],"sufficient":true,"graph":{"functions":[{"subject":"named question entity or $0","relation":"single relation","value_type":"person","rows":[{"value":"observed value","evidence_id":"E1"}]}],"goal":{"kind":"value","nodes":[0]}}}
Graph nodes are numbered from 0. A literal subject must come from the QUESTION; $0 refers to an EARLIER output. Each row of a $ node includes subject: the actual bound entity. A literal node's row omits subject. value_type describes the returned value: person, organization, place, work, event, category, number, date or entity. expected is a question-given filter; time is null unless the RELATION has explicit time scope. Goal value returns ONE UNKNOWN node output after ALL conditions hold. subject selects literal alternatives with expected filters; greater/earlier compare two number/date nodes. Never add extra conditions or guessed answers as filters. Preserve every question qualifier. Missing rows remain unknown.
Fictional example: Who sang for Violet Echo and was born in 1970? graph functions are singer(Violet Echo)->$0 and birth_year($0) expected 1970; goal value nodes [0]. A director's birthplace instead needs director(work)->$0, birthplace($0)->$1; goal value nodes [1]. No summary or commentary outside JSON.'''

def candidate_check(packet,evidence):
    """Citation identity and lexical coverage only; explicitly NOT semantic verification."""
    from route_planned_rag.prototype.evaluator import normalize
    ids={e['evidence_id']:e for e in evidence}
    if not packet.answer.strip() or not packet.evidence_ids:return 'missing_answer_or_citation'
    if not set(packet.evidence_ids)<=ids.keys():return 'unobserved_citation'
    text=' '.join(ids[i]['source_metadata'].get('title','')+' '+ids[i]['original_text'] for i in packet.evidence_ids)
    if normalize(packet.answer) in ('yes','no'):return None
    words=set(normalize(packet.answer).split())-{'and','or'}
    if not words<=set(normalize(text).split()):return 'answer_words_not_in_cited_sources'
    return None
