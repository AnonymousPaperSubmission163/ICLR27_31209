"""Execute pinned upstream method bodies; replace only model/retrieval IO.
AST selection avoids upstream import-time OpenAI client and MiniLM loading.
No prompts, parsers, sorting or stopping rules are rewritten.
"""
import ast
import json
import logging
import re
import time
import typing
from pathlib import Path

PIN = '72a298c95ffd75890c7f9c28fd1c094201f669a7'

class NoColor:
    def __getattr__(self, key): return ''

def load_official(root: Path, responder):
    namespace = dict(json=json, re=re, time=time, logger=logging.getLogger('official'),
                     Fore=NoColor(), Style=NoColor(), BaseRAG=object,
                     get_response_with_retry=responder,
                     **{k:getattr(typing,k) for k in ('List','Dict','Tuple','Any')})
    for relative, kind, name in [('src/utils/utils.py', ast.FunctionDef, 'fix_json_response'),
                                 ('src/models/logic_rag.py', ast.ClassDef, 'LogicRAG')]:
        path=root/relative; tree=ast.parse(path.read_text())
        nodes=[n for n in tree.body if isinstance(n,kind) and n.name==name]
        if len(nodes)!=1: raise ValueError('upstream definition missing: '+name)
        exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)
    return namespace['LogicRAG']

def make_official(root, responder, retrieve, *, top_k=5, max_rounds=3):
    cls=load_official(root,responder)
    rag=cls.__new__(cls) # BaseRAG init exclusively replaced by existing E5 IO.
    rag.MODEL_NAME='OfficialLogicRAG_same_stack';rag.top_k=top_k
    rag.max_rounds=max_rounds;rag.filter_repeats=False
    rag.retrieve=lambda query:retrieve(query,rag.top_k)
    return rag
