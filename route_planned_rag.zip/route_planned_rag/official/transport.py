"""JSON transport schemas mirror upstream requested keys; no factual constraints."""
def analysis_schema(role, bounded=False):
    nullable={'type':['string','null']}
    if role=='warm_up_analysis':
        properties={'can_answer':{'type':'boolean'},'missing_info':nullable,'subquery':nullable,
                    'current_understanding':{'type':'string'},'dependencies':{'type':'array','items':{'type':'string'}},'missing_reason':nullable}
    elif role=='dependency_aware_rag':
        properties={'can_answer':{'type':'boolean'},'current_understanding':{'type':'string'}}
    elif role=='_sort_dependencies':
        properties={'dependency_pairs':{'type':'array','items':{'type':'array','items':{'type':'integer'},'minItems':2,'maxItems':2}}}
    else:raise ValueError(role)
    if bounded:
        def bound(schema):
            if schema.get('type')=='string' or schema.get('type')==['string','null']: schema['maxLength']=400
            if schema.get('type')=='array':
                schema.setdefault('maxItems',8)
                bound(schema['items'])
                if schema['items'].get('type')=='string':schema['items']['maxLength']=160
        for value in properties.values():bound(value)
    return {'type':'object','properties':properties,'required':list(properties),'additionalProperties':False}

def normalize_json_transport(text):
    """Escape raw control characters in complete JSON; never repair missing content."""
    import json
    try:
        json.loads(text)
        return text
    except json.JSONDecodeError as exc:
        if not exc.msg.startswith('Invalid control character'):return text
    try:value=json.loads(text,strict=False)
    except json.JSONDecodeError:return text
    return json.dumps(value,ensure_ascii=False,separators=(',',':'))
