"""Γ v1: frozen lexical/typed definitions, never generated or extended by an LLM.

Relationship labels follow child -> parent, entity -> containing place. A label
ending in 'of' is deliberately unsupported because its argument direction may
be reversed. Unscoped location premises mean the same contemporaneous location
interpretation; birth-location lifting requires an explicit event year.
"""
import re
from pydantic import Field
from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.method.schema import Requirement, signature as digest

GAMMA = [
    dict(rule_id='kin_paternal_grandfather', heads=['paternal grandfather', 'grandfather'], body=['father', 'father'], bridge_type='person', value_type='person', conditions='Child-to-parent orientation; biological/family father sense; no metaphor, step/adoptive reinterpretation.'),
    dict(rule_id='kin_maternal_grandfather', heads=['maternal grandfather', 'grandfather'], body=['mother', 'father'], bridge_type='person', value_type='person', conditions='Child-to-parent orientation; biological/family mother/father sense; no metaphor or step reinterpretation.'),
    dict(rule_id='kin_paternal_grandmother', heads=['paternal grandmother', 'grandmother'], body=['father', 'mother'], bridge_type='person', value_type='person', conditions='Child-to-parent orientation; biological/family parent sense; no metaphor or step reinterpretation.'),
    dict(rule_id='kin_maternal_grandmother', heads=['maternal grandmother', 'grandmother'], body=['mother', 'mother'], bridge_type='person', value_type='person', conditions='Child-to-parent orientation; biological/family parent sense; no metaphor or step reinterpretation.'),
    dict(rule_id='geo_city_country', heads=['located in country'], body=['located in city', 'city in country'], bridge_type='place', value_type='place', container='country', conditions='Positive physical location; city wholly belongs to this country under the SAME temporal and geographic scope; no nationality or affiliation inference.'),
    dict(rule_id='geo_city_state', heads=['located in state'], body=['located in city', 'city in state'], bridge_type='place', value_type='place', container='state', conditions='Positive physical location; city wholly belongs to this state under the SAME temporal and geographic scope.'),
    dict(rule_id='geo_state_country', heads=['located in country'], body=['located in state', 'state in country'], bridge_type='place', value_type='place', container='country', conditions='Positive physical location; state wholly belongs to this country under the SAME temporal and geographic scope.'),
    dict(rule_id='birth_city_country', heads=['born in country', 'country of birth', 'birth country'], body=['born in city', 'city in country'], bridge_type='place', value_type='place', container='country', require_event_year=True, conditions='Birth city and its containing country at the SAME explicit birth-event year; never nationality.'),
]
for rule in GAMMA:
    rule.update(head='H(x,z)', body_formula='B1(x,y) AND B2(y,z)',
                variable_mapping={'x':'original subject', 'y':'fresh typed bridge', 'z':'original object'},
                scope_condition='Both premises inherit exactly head.scope; no scope coercion.', max_depth=1)
GAMMA_HASH = digest(GAMMA)

class RegisteredRule(Strict):
    id: str
    template: str
    head: int
    body: list[int]
    spec_version: int = 1
    valid: bool = True
    origin: str = 'frozen_whitelist'
    source_evidence_id: str | None = None
    source_quote: str | None = None
    reason: str

class RegisteredPlan(Strict):
    body_patterns: list[Requirement] = Field(default_factory=list)
    rules: list[RegisteredRule] = Field(default_factory=list)


def matching_templates(need):
    if need.negated:
        return []
    relation = ' '.join(need.r.lower().split())
    relation = re.sub(r'^has (?:a |the )?', '', relation)
    for t in GAMMA:
        matched = relation in t['heads']
        if t['rule_id'].startswith('geo_'):
            # Require an explicitly named administrative level in the original
            # relation/span. Generic association, origin and nationality fail.
            physical = re.fullmatch(r'(?:is )?(?:located|situated|based|headquartered)(?: in(?: (?:the )?(?:city|state|country)(?: of)?)?)?', relation)
            typed_level=getattr(need,'object_level',None)
            level = typed_level==t['container'] or bool(re.search(r'\b' + t['container'] + r'\b', need.span + ' ' + relation, re.I))
            explicit_levels = set(re.findall(r'\b(city|state|country)\b', relation))
            # A word in another question clause cannot change THIS head's
            # explicitly specified administrative level.
            level_consistent = (not explicit_levels or explicit_levels == {t['container']}) and (not typed_level or typed_level==t['container'])
            matched = bool(physical and level and level_consistent)
        if not matched or need.kind != t['value_type']:
            continue
        if t['rule_id'].startswith('kin_') and need.subject_kind not in ('entity','person'):
            continue
        if t.get('require_event_year') and not (need.scope and re.fullmatch(r'\d{4}', need.scope)):
            continue
        yield t


def bodies(need, template, identity):
    bridge = '?ax_' + digest(identity)[:12]
    relations = list(template['body'])
    if template['rule_id'].startswith('geo_'):
        verb = re.search(r'located|situated|based|headquartered', need.r, re.I).group().lower()
        relations[0] = relations[0].replace('located', verb)
    return [Requirement(s=need.s, r=relations[0], o=bridge, kind=template['bridge_type'], subject_kind=need.subject_kind, scope=need.scope, span=need.span),
            Requirement(s=bridge, r=relations[1], o=need.o, kind=need.kind, subject_kind=template['bridge_type'], scope=need.scope, span=need.span)]
