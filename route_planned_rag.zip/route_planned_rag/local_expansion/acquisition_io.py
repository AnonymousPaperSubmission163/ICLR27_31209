"""v3 acquisition operations, with the catalog including legal auxiliary slots.

Copied from method/engine.py with only catalog/reader imports adapted. Retrieval,
admission, costs and retry behavior remain explicit and independently testable.
"""
from .reader import original_sentences, slot_schema, slots_to_reading, SLOT_PROMPT
import re
from route_planned_rag.method.schema import signature as digest, words, STOP

class AcquisitionIO:
    @property
    def acquisition_reader_limit(self):
        reserve=self.config.get('terminal_max_calls',2) if self.config.get('answer_policy')=='best_effort' else 0
        return self.config['max_reader_calls']-reserve

    def requests(self, nodes, binding):
        requests = []
        for i in nodes:
            n = self.store.catalog[i]
            # Question spans are provenance. Sending the entire question as a
            # slot condition makes the reader require the whole join before it
            # will extract even its first premise.
            requests.append(dict(id="N" + str(i), relation=n.r, condition=n.r,
                                 subject_filter=binding.get(n.s[1:]) if n.s.startswith("?") else n.s,
                                 # A planner hypothesis is not an exhaustive
                                 # list of values that the source may support.
                                 value_filter=None if n.o.startswith("?") else n.o,
                                 subject_type=n.subject_kind, value_type=n.kind, scope=n.scope,
                                 value_level=getattr(n,'object_level',None),
                                 required_negation=n.negated))
            attribution=re.fullmatch(r'(?:described|characterized|characterised) as (.+) by',n.r,re.I)
            if attribution:
                subject=requests[-1]['subject_filter'] or 'the described entity'
                requests[-1]['condition']=f'Who described {subject} as {attribution[1]}? The row subject is the entity being described; the row value is the speaker, author or publication making that description. Extract that named source.'
            if n.kind=='place' and re.search(r'\b(?:burial|buried|grave)\b',n.r,re.I):
                requests[-1]['condition']=n.r+'. Extract the named cemetery or other burial place. A sentence locating the subject\'s grave states their place of burial; the cemetery\'s city is not additionally required.'
            if n.kind=='place' and re.search(r'\b(?:born|birthplace|place of birth)\b',n.r,re.I):
                requests[-1]['condition']=n.r+'. Extract a place attached to the birth event, never nationality, residence, work, death or a later visit.'
                if getattr(n,'object_level',None) is None:
                    requests[-1]['condition']+=' Any explicit place is valid, including country abbreviations US and UK; null value_level imposes no city or country restriction.'
        from .semantics import constraints_for, identity_owners
        for node, request in zip(nodes,requests):
            request['semantic_constraints']=constraints_for(self.store.question,self.store.plan,node)
            request['subject_owner_context']=identity_owners(self.store,node,request['subject_filter'])
        return requests

    def reading_payload(self, evidence, nodes, binding, retry=False):
        payload = dict(requests=self.requests(nodes, binding), passages=original_sentences(evidence)[0])
        if retry:
            payload["task"] = "Re-read the originals for omitted alternatives or a previous format failure. Keep every condition; do not guess unsupported rows."
            payload["previous_rejections"] = self.store.rejected[-6:]
        return payload

    def read_option(self, request):
        if self.state["reader_calls"] >= self.acquisition_reader_limit:
            return None
        eligible = []
        wanted = set(words(self.store.catalog[request["node"]].r)) - STOP
        anchor = request["anchor"] or ""
        neighboring_anchors = [t for n in self.store.catalog for t in (n.s, n.o) if not t.startswith("?") and t not in ("true", "false")]
        for eid, evidence in self.store.evidence.items():
            if evidence.get("withdrawn"):
                continue
            signature = self.read_signature(request, eid)
            attempts = self.state["reads"].get(signature, 0)
            if attempts >= self.config["max_attempts"]:
                continue
            title = evidence["source_metadata"]["title"]
            anchor_present = self.store.source_mentions(anchor,eid)
            overlap = len(wanted & set(words(evidence["original_text"])))
            neighbor_present = any(self.store.source_mentions(a,eid) for a in neighboring_anchors)
            unbound_cached=self.cache_key(dict(target=self.store.pattern(request['node']).model_dump()),eid) in self.state.get('read_cache',{})
            if unbound_cached:
                # An unfiltered slot already requested ALL subjects/values.
                # Binding a subject selects a subset of that same valid result;
                # it does not supply new source evidence. cache_key still checks
                # exact source, relevant aliases, conflicts and active catalog.
                continue
            # A neighboring anchor can seed an unbound multi-slot batch.
            # A concrete subject requires its own source mention, even when
            # alias/cache changes make an old passage appear unread again.
            # A generic verb such as 'directed' appearing in an unrelated film
            # does not make that passage evidence for this concrete entity.
            if not (anchor_present or (neighbor_present and not request["binding"])):
                continue
            eligible.append((attempts, self.store.canonical(anchor) != self.store.canonical(title), not anchor_present, -overlap, eid))
        if not eligible:
            return None
        eligible.sort()
        ids = [row[-1] for row in eligible[:self.config["reading_top_k"]]]
        return dict(request, key=digest(["read", request["id"], ids]), mode="read", source_ids=ids, cost=self.config["read_cost"])

    def retrieval_option(self, request):
        if self.state["retrieval_calls"] >= self.config["max_retrievals"] or self.state["reader_calls"] >= self.acquisition_reader_limit:
            return None
        attempt = self.state["retrieval_attempts"].get(request["id"], 0)
        if attempt >= self.config["max_attempts"]:
            return None
        need = self.store.catalog[request["node"]]
        target = request["target"]
        names = [self.store.names[t["name"]] for t in target["arguments"] if t["kind"] == "constant" and self.store.names[t["name"]] not in ("true", "false")]
        from .semantics import identity_owners
        owners=[o for o in identity_owners(self.store,request['node'],request.get('anchor')) if not o.startswith('?')]
        base = " ".join(dict.fromkeys([*names,*owners, need.r, need.scope or ""])) .strip()
        candidates = [base, self.question + " " + base]
        for query in candidates[attempt:]:
            if query not in self.state["queries"]:
                return dict(request, key=digest(["retrieve", request["id"], query]), mode="retrieve", query=query,
                            cost=self.config["retrieve_cost"] + self.config["read_cost"])
        return None

    def read(self, action):
        evidence = [self.store.evidence[eid] for eid in action["source_ids"]]
        # One reader call fills independent slots for the entire fixed graph.
        # Only the selected slot receives this candidate's binding; other slots
        # stay unbound to avoid excluding alternative entities.
        nodes = list(range(len(self.store.catalog)))
        payload = self.reading_payload(evidence, nodes, {}, retry=any(self.state["reads"].get(self.read_signature(action, eid), 0) for eid in action["source_ids"]))
        selected = self.requests([action["node"]], action["binding"])[0]
        payload["requests"][action["node"]] = selected
        maximum = self.config["reader_output_tokens"]
        if hasattr(self.client, "preflight"):
            self.client.preflight(SLOT_PROMPT, payload, maximum)
        self.state["reader_calls"] += 1
        # The same call reads every slot. Charge every slot/source attempt so
        # switching the selected node cannot buy identical unbound reads again.
        for node in nodes:
            target = action["target"] if node == action["node"] else self.store.pattern(node).model_dump()
            for eid in action["source_ids"]:
                signature = self.read_signature(dict(target=target), eid)
                self.state["reads"][signature] = self.state["reads"].get(signature, 0) + 1
        self.event("reader_started", action=action)
        try:
            raw = self.client.ask("reader", slot_schema(nodes, evidence), SLOT_PROMPT, payload, maximum=maximum)
            reading, unknown = slots_to_reading(raw, evidence)
            self.store.rejected.extend(unknown)
            ids = self.store.propose(reading, self.client.calls[-1]["call_id"])
            self.event("facts_updated", action=action, admitted=ids, missing=reading.missing,
                       source_ids=action["source_ids"], store_version=self.store.version, unknown=unknown)
        except (ValueError, KeyError, IndexError, RuntimeError) as exc:
            self.state["reader_errors"].append(repr(exc))
            self.event("reader_failed", action=action, error=repr(exc))
            if "token_budget_exhausted" in str(exc):
                raise

    def retrieve(self, action):
        # Reserve at least a reader over current originals before spending E5.
        if hasattr(self.client, "preflight"):
            self.client.preflight(SLOT_PROMPT, self.reading_payload([], list(range(len(self.store.catalog))), {}), self.config["reader_output_tokens"])
        self.state["retrieval_calls"] += 1
        self.state["queries"].append(action["query"])
        self.state["retrieval_attempts"][action["id"]] = self.state["retrieval_attempts"].get(action["id"], 0) + 1
        self.event("retrieval_started", action=action)
        evidence, usage = self.retriever(action["query"], self.config["retrieval_top_k"])
        old = set(self.store.evidence)
        self.store.observe(evidence)  # Every returned original is retained, including unread passages.
        self.state["query_usage"].append(usage)
        self.event("retrieval_completed", action=action, source_ids=[e["evidence_id"] for e in evidence],
                   new_source_ids=sorted(set(self.store.evidence) - old), usage=usage)
