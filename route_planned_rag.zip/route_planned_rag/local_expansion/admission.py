"""One source, type, scope and conflict admission path for all acquisition slots.

No source text is rewritten. Linguistic normalizations keep their literal
witness. The reader is still responsible for the relation's textual entailment.
"""
import re
from route_planned_rag.logic_control.core import lexical,align_quote
from route_planned_rag.indexed.store import value_witness
from route_planned_rag.indexed.schema import parse_date
from route_planned_rag.method.schema import signature as digest
from .scalars import quantity,numeric_witness,date_interval,date_witness

# A lexical inflection table, not a rule about a person's nationality or place
# of birth. Only a geographic noun modified by the adjective licenses its use.
# Ambiguous American/Georgian/Congolese/Korean/British are deliberately absent.
COUNTRY_ADJECTIVES=dict(zip(
    'Argentine Australian Austrian Belgian Bolivian Brazilian Bulgarian Cambodian Canadian Chilean Chinese Colombian Croatian Cuban Czech Danish Dutch Ecuadorian Egyptian Estonian Ethiopian Finnish French German Greek Hungarian Icelandic Indian Indonesian Iranian Iraqi Irish Israeli Italian Japanese Kenyan Latvian Lithuanian Malaysian Mexican Moroccan Nepalese Nigerian Norwegian Pakistani Peruvian Polish Portuguese Romanian Russian Serbian Singaporean Slovak Slovenian Spanish Swedish Swiss Thai Turkish Ugandan Ukrainian Venezuelan Vietnamese Zambian Zimbabwean'.casefold().split(),
    ['Argentina','Australia','Austria','Belgium','Bolivia','Brazil','Bulgaria','Cambodia','Canada','Chile','China','Colombia','Croatia','Cuba','Czech Republic','Denmark','Netherlands','Ecuador','Egypt','Estonia','Ethiopia','Finland','France','Germany','Greece','Hungary','Iceland','India','Indonesia','Iran','Iraq','Ireland','Israel','Italy','Japan','Kenya','Latvia','Lithuania','Malaysia','Mexico','Morocco','Nepal','Nigeria','Norway','Pakistan','Peru','Poland','Portugal','Romania','Russia','Serbia','Singapore','Slovakia','Slovenia','Spain','Sweden','Switzerland','Thailand','Turkey','Uganda','Ukraine','Venezuela','Vietnam','Zambia','Zimbabwe']))
for ambiguous in ('irish','chinese'):COUNTRY_ADJECTIVES.pop(ambiguous)
COUNTRY_ABBREVIATIONS={'US':'United States','U.S.':'United States','USA':'United States','U.S.A.':'United States','UK':'United Kingdom','U.K.':'United Kingdom'}

def country_abbreviation_witness(value,quote):
    for abbreviation,country in COUNTRY_ABBREVIATIONS.items():
        if lexical(value) not in (lexical(abbreviation),lexical(country)):continue
        # Case-sensitive source witness keeps the English pronoun 'us' out.
        if re.search(r'(?<!\w)'+re.escape(abbreviation)+r'(?!\w)',quote):
            return dict(value=country,surface=abbreviation,rule='explicit_country_abbreviation')
    return None


def contains(value,text):
    value=lexical(value)
    return bool(value and re.search(r'(?<!\w)'+re.escape(value)+r'(?!\w)',lexical(text)))


def country_witness(value,need,quote):
    level=getattr(need,'object_level',None)
    if need.kind!='place' or not (level=='country' or re.search(r'\bcountry\b',need.r,re.I)):return None
    if need.scope:return None
    physical=bool(re.search(r'\b(?:located|situated|city in|state in|island in)\b',need.r,re.I))
    origin=bool(re.search(r'\b(?:origin|produced|production|from|made)\b',need.r,re.I))
    if not physical and not origin:return None
    vocabulary=dict(COUNTRY_ADJECTIVES,american='United States',british='United Kingdom') if origin else COUNTRY_ADJECTIVES
    for adjective,country in vocabulary.items():
        if lexical(value) not in (adjective,lexical(country)):continue
        suffix=r'(?:state|city|province|island|territory|town|village|district|capital|region)' if physical else r'(?:(?:\d{4}|independent|romantic|comedy|drama|crime|thriller|horror|silent|animated|musical|action|adventure|fantasy|neo[- ]*\s*noir|science[- ]fiction|documentary|feature|black-and-white)\s+){0,5}(?:film|movie)'
        match=re.search(r'\b'+adjective+r'\s+'+suffix+r'\b',quote,re.I)
        if match:return dict(value=country,surface=match.group(),rule='country_adjective_modifies_geographic_entity' if physical else 'film_country_of_origin_adjective')
    return None


def scope_witness(scope,quote):
    if scope is None:return dict(rule='unscoped')
    if contains(scope,quote):return dict(rule='explicit_scope',surface=scope)
    century=re.fullmatch(r'(\d{1,2})(?:st|nd|rd|th) century',scope,re.I)
    if not century:return None
    lower=(int(century[1])-1)*100+1;upper=int(century[1])*100
    # A complete life inside the interval bounds every biographical occupation.
    life=re.search(r'\([^()]*?\b(\d{4})\s*[-–—][^()]*?\b(\d{4})\b[^()]*\)',quote)
    if life and lower<=int(life[1])<=int(life[2])<=upper:
        return dict(rule='complete_lifespan_within_century',surface=life.group(),bounds=[lower,upper])
    # An isolated birth/death date cannot locate a career in the same century.
    outside_parentheses=re.sub(r'\([^()]*\)','',quote)
    for sentence in re.split(r'[.!?]\s+',outside_parentheses):
        if re.search(r'\b(?:born|died|birth|death)\b',sentence,re.I):continue
        years=re.findall(r'\b(?:1|2)\d{3}\b',sentence)
        if years and all(lower<=int(y)<=upper for y in years):
            return dict(rule='explicit_event_year_in_century',surface=sentence,bounds=[lower,upper],relation_association='conditional_on_reader_translation')
    return None


def lifespan_endpoint(value,need,quote):
    if need.kind!='date':return None
    endpoint=1 if re.search(r'\b(?:died|death)\b',need.r,re.I) else 0 if re.search(r'\b(?:born|birth)\b',need.r,re.I) else None
    if endpoint is None:return None
    # Require the conventional parenthesized biographical life interval. An
    # uncertain date range elsewhere is not a pair of birth/death endpoints.
    if not any(value.strip() in m[1] for m in re.finditer(r'\(([^()]+)\)\s+(?:is|was)\b',quote)):return None
    for split in re.finditer(r'[-–—]',value):
        halves=[value[:split.start()].strip(),value[split.end():].strip()]
        dates=[parse_date(x) for x in halves]
        if all(dates) and dates[0][0]<=dates[1][0]:
            return dict(value=halves[endpoint],surface=value,rule='biographical_lifespan_death' if endpoint else 'biographical_lifespan_birth')
    return None


def admit(store,reading,call_id):
    admitted=[]
    for original in reading.rows:
        row=original.model_copy(deep=True);source=store.evidence.get(row.evidence_id)
        need=store.catalog[row.node] if row.node<len(store.catalog) else None
        aligned,position=align_quote(row.quote,source['original_text']) if source and row.quote else (None,None)
        reasons=[];normalizations=[];alias_witnesses=[]
        if need is None:reasons.append('unknown_requirement')
        if not source or not aligned:reasons.append('quote_not_an_observed_exact_span')
        if source and source.get('withdrawn'):reasons.append('source_withdrawn')
        if any(not lexical(v) or v.startswith('?') or lexical(v) in ('unknown','none','null','n a') for v in (row.s,row.o)):
            reasons.append('fact_is_not_ground')
        if not reasons:
            if need.kind in ('person','entity'):
                compact=re.sub(r'\s*\((?:later|also known as|formerly)\b[^()]*\)\s*$','',row.o,flags=re.I).strip()
                if compact!=row.o and contains(compact,aligned):
                    normalizations.append(dict(field='o',original=row.o,value=compact,rule='remove_explicit_explanatory_name_parenthesis'));row.o=compact
            # Preserve explicit preceding full-name context for surname references.
            text=source['source_metadata']['title']+' '+aligned
            endpoint=lifespan_endpoint(row.o,need,aligned)
            if endpoint:
                normalizations.append(dict(field='o',original=row.o,**endpoint));row.o=endpoint['value']
            if not contains(row.s,text):
                antecedent=re.search(re.escape(row.s),source['original_text'][:position['start']],re.I)
                if antecedent and contains(lexical(row.s).split()[-1],aligned):
                    aligned=source['original_text'][antecedent.start():position['end']]
                    position=dict(start=antecedent.start(),end=position['end'],method='retain_explicit_antecedent')
            text=source['source_metadata']['title']+' '+aligned
            if need.kind=='category' and re.fullmatch(r'(?:occupation|profession)s?',need.r,re.I):
                occupation=re.sub(r'^(?:film|television|record|music)\s+(director|actor|producer)$',r'\1',row.o,flags=re.I)
                if occupation!=row.o:
                    normalizations.append(dict(field='o',original=row.o,value=occupation,rule='general_occupation_head_noun'))
                    row.o=occupation
            country=country_witness(row.o,need,aligned)
            if not country and need.kind=='place':country=country_abbreviation_witness(row.o,aligned)
            if country:
                normalizations.append(dict(field='o',original=row.o,**country));row.o=country['value']
            for field,kind in (('s','entity'),('o',need.kind)):
                value=getattr(row,field);witness=contains(value,text)
                if field=='o' and kind=='boolean' and value in ('true','false'):witness=True
                if field=='o' and country:witness=True
                alias=store.aliases.get(lexical(value))
                if not witness and alias:
                    witness=any(d['canonical']==alias['canonical'] and contains(a,text) for a,d in store.aliases.items())
                    if witness:
                        alias_witnesses.append(dict(field=field,value=value,canonical=alias['canonical'],
                            definition_evidence_ids=sorted({alias['evidence_id']}|{d['evidence_id'] for a,d in store.aliases.items() if d['canonical']==alias['canonical'] and contains(a,text)})))
                if kind=='number':
                    numeric=numeric_witness(value,text);witness=numeric is not None
                    if numeric is not None and numeric!=value:normalizations.append(dict(field=field,original=value,surface=numeric,rule='explicit_numeric_surface_equivalence'))
                if not witness and kind=='date':witness=date_witness(value,text) is not None
                if not witness:reasons.append('argument_has_no_source_witness:'+field)
            if row.scope is None and need.scope and scope_witness(need.scope,aligned):
                normalizations.append(dict(field='scope',original=None,value=need.scope,rule='requested_scope_has_literal_temporal_witness'))
                row.scope=need.scope
            if row.scope!=need.scope:reasons.append('scope_mismatch')
            temporal=scope_witness(row.scope,aligned)
            if temporal is None:reasons.append('scope_has_no_source_witness')
            if not need.s.startswith('?') and store.canonical(row.s)!=store.canonical(need.s):reasons.append('literal_subject_mismatch')
            if re.search(r'\b(?:source|origin|headwaters|rises)\b',need.r,re.I) and re.search(r'\bTributaries\b.*\bSource\b.*\bMouth\b',aligned,re.I):
                owner=source['source_metadata']['title']
                if store.canonical(row.s)!=store.canonical(owner):reasons.append('infobox_fields_belong_to_another_subject')
            if not need.o.startswith('?') and need.kind!='boolean' and store.canonical(row.o,need.kind)!=store.canonical(need.o,need.kind):reasons.append('literal_object_mismatch')
            if need.kind=='boolean' and row.o not in ('true','false'):reasons.append('boolean_value_required')
            if need.kind in ('person','place','organization') and (date_interval(row.o) is not None or quantity(row.o) is not None):
                reasons.append('scalar_value_cannot_fill_named_entity_slot')
            if need.kind=='date' and date_interval(row.o) is None:reasons.append('date_value_required')
            if need.kind in ('number','frequency') and quantity(row.o,need.kind) is None:reasons.append('non_comparable_or_ambiguous_quantity')
            if need.kind=='number' and (amount:=quantity(row.o)) and amount['lower']==amount['upper']:
                if re.search(r'\b(?:at least|at most|more than|less than|over|under|about|around|approximately|roughly|estimated(?: at)?)\s+'+re.escape(row.o)+r'\b',aligned,re.I):
                    reasons.append('source_quantity_qualification_was_dropped')
        if need is not None and source and aligned:
            from .semantics import source_semantic_rejections
            reasons.extend(source_semantic_rejections(store,row,need,aligned,source))
        record=dict(row.model_dump(),original_extraction=original.model_dump(),normalizations=normalizations,alias_witnesses=alias_witnesses,extraction_call=call_id)
        if reasons:
            store.rejected.append(dict(record,status='rejected',reason=reasons[0],reasons=reasons));continue
        record.update(quote=aligned,original_quote=original.quote,quote_alignment=position,scope_witness=temporal)
        rid='F'+digest(row.model_dump());record.update(id=rid,status='proposed',base_status='proposed')
        if need.kind=='boolean' and row.o=='false':record.update(o='true',negated=not row.negated,original_boolean_value='false')
        if rid not in store.rows:store.rows[rid]=record;store.version+=1
        if store.rows[rid]['status'] not in ('accepted','proposed'):continue
        admitted.append(rid)
    if admitted:store.set_status(admitted,'accepted','program_checked_source_type_scope; conditional_on_reader_translation')
    store.sync()
    return admitted
