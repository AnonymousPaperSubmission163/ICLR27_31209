"""Original-only goals, alternative support routes, and bounded truth maintenance."""
import re
import copy
import time
import unicodedata
from contextlib import contextmanager
from itertools import product

from route_planned_rag.method.store import Store as V3Store
from route_planned_rag.method.schema import Requirement, signature as digest
from route_planned_rag.indexed.schema import norm
from route_planned_rag.prototype.schemas import Atom
from route_planned_rag.prototype.logic import substitute, unify, key, opposite, ground
from .rules import RegisteredPlan, RegisteredRule, GAMMA, matching_templates, bodies
from route_planned_rag.prototype.schemas import RuleSpec, Term
from route_planned_rag.logic_control.core import compare_quantities,lexical
from .scalars import quantity,date_interval,date_bounds
from .admission import admit
from route_planned_rag.indexed.schema import parse_date
from .relations import relation_identity


class EvidenceStore(V3Store):
    def __init__(self, question, program, path, max_bindings=512, spec_version=1, limits=None):
        self.spec_version = spec_version
        self.acquisition = RegisteredPlan()
        self.activations = []
        self.counterfactual_records = []
        self.original_only_cache = {}
        self.use_derived = True
        self.derivations = {}
        self.reverse_dependencies = {}
        self.closure_records = []
        self.closure_signature = None
        self.limits = dict(max_auxiliary=12, max_rules=8, max_depth=1, max_routes=128,
                           max_derived=1024, max_supports=4096, max_rule_matches=20000,
                           rule_cpu_seconds=2.)
        self.limits.update(limits or {})
        self.routes_truncated = False
        super().__init__(question, program, path, max_bindings)
        for node, need in enumerate(program.needs):
            for template in matching_templates(need):
                rid = template['rule_id'] + '_' + str(node)
                start = len(self.catalog)
                self.acquisition.body_patterns.extend(bodies(need, template, rid))
                self.acquisition.rules.append(RegisteredRule(id=rid, template=template['rule_id'], head=node,
                    body=[start, start + 1], reason=template['conditions']))

    @property
    def catalog(self):
        return self.plan.needs + self.acquisition.body_patterns

    def canonical(self,value,kind='entity'):
        if kind=='date' and (interval:=date_interval(value)):
            return 'date:'+digest({k:v.isoformat() if hasattr(v,'isoformat') else v for k,v in interval.items()})
        if kind in ('number','frequency') and (amount:=quantity(value,kind)):
            return 'quantity:'+digest({k:v for k,v in amount.items() if k!='rule'})
        return super().canonical(value,kind)

    def pattern(self, i):
        n = self.catalog[i]
        return Atom(predicate='r' + digest(relation_identity(n)),
                    arguments=[self.term(n.s), self.term(n.o, n.kind)], negated=n.negated)

    def row_atom(self, row):
        n = self.catalog[row['node']]
        return Atom(predicate=self.pattern(row['node']).predicate,
                    arguments=[self.term(row['s']), self.term(row['o'], n.kind)], negated=row['negated'])

    def source_mentions(self, value, evidence_id):
        """Literal or unambiguous source-defined alias, never fuzzy matching."""
        from .admission import contains
        if not value:return False
        source=self.evidence[evidence_id]
        if source.get('withdrawn'):return False
        title=source['source_metadata']['title'];text=title+' '+source['original_text']
        canonical=self.canonical(value)
        return self.canonical(title)==canonical or contains(value,text) or any(
            record['canonical']==canonical and contains(alias,text)
            for alias,record in self.aliases.items())

    def _refresh_alias_witnesses(self):
        from .admission import contains
        changed=False
        for row in self.rows.values():
            dependencies=row.get('alias_witnesses',[])
            was_alias_invalid=row.get('reason')=='alias_source_witness_invalidated'
            if not dependencies or (row['status'] not in ('accepted','conflicted') and not was_alias_invalid):continue
            source=self.evidence.get(row.get('evidence_id'),{})
            if not source or source.get('withdrawn'):continue
            text=source['source_metadata']['title']+' '+row['quote']
            valid=all(self.canonical(d['value'])==d['canonical'] and
                (contains(d['value'],text) or any(r['canonical']==d['canonical'] and contains(a,text) for a,r in self.aliases.items()))
                for d in dependencies)
            if valid:
                for dependency in dependencies:
                    identity=self.aliases.get(lexical(dependency['value']))
                    dependency['definition_evidence_ids']=sorted(({identity['evidence_id']} if identity else set())|
                        {r['evidence_id'] for a,r in self.aliases.items() if r['canonical']==dependency['canonical'] and contains(a,text)})
            if not valid and not was_alias_invalid:
                row.update(status='invalid',base_status='invalid',reason='alias_source_witness_invalidated');changed=True
            elif valid and was_alias_invalid:
                row.update(status='accepted',base_status='accepted',reason='alias_source_witness_restored');changed=True
        if changed:
            self.version+=1;self.closure_signature=None
            for certificate in self.certificates:certificate['valid']=False
            self._invalidate_unsupported()

    def observe(self, evidence):
        originals = dict(self.evidence)
        for e in evidence:
            eid = e['evidence_id']
            if eid in originals and originals[eid]['original_text'] != e['original_text']:
                raise ValueError('original evidence changed')
            # Re-retrieval cannot resurrect an explicitly withdrawn source.
            if eid not in originals:
                originals[eid] = e
        self.evidence = {eid: e for eid, e in originals.items() if not e.get('withdrawn')}
        super().observe([])
        # The inherited lead matcher accepts arbitrary words before '(ABC)'.
        # Do not let 'Nora works at Cedar University (CU)' define CU as that
        # whole sentence fragment. Local explicit definitions below validate
        # the expanded name's initials before registering the alias.
        invalid=[]
        for name,record in self.aliases.items():
            definition=re.fullmatch(r'(.+?)\s*\(([A-Z]{2,10})(?: or [A-Z]{2,10})?\)',record.get('definition',''))
            if definition:
                initials=''.join(w[0] for w in definition[1].split() if w.casefold() not in ('of','for','the','and'))
                if initials!=definition[2]:invalid.append(name)
        if invalid:
            for name in invalid:self.aliases.pop(name,None)
            self.alias_version+=1;self.version+=1
            for certificate in self.certificates:certificate['valid']=False
        # Source-backed orthographic aliases, only where the observed title has
        # one unambiguous spelling after removing combining diacritics. This is
        # not edit-distance entity linking or a guessed expansion of a name.
        spellings={}
        for eid,e in self.evidence.items():
            title=e['source_metadata']['title']
            plain=''.join(c for c in unicodedata.normalize('NFKD',title) if not unicodedata.combining(c))
            spellings.setdefault(lexical(plain),[]).append((eid,title,plain))
        extra={};biographical_definitions={};acronym_definitions={}
        # Explicit definitions can appear inside a sentence, not only in the
        # document lead. Keep the full parenthetical spelling as an alias too.
        pattern=r'\b([A-Z][A-Za-z]*(?:\s+(?:[A-Z][A-Za-z]*|of|for|the|and)){1,11})\s*\(([A-Z]{2,10})\)'
        for eid,e in self.evidence.items():
            for match in re.finditer(pattern,e['original_text']):
                expanded=re.sub(r'^The\s+','',match[1]);acronym=match[2]
                initials=''.join(w[0] for w in expanded.split() if w.casefold() not in ('of','for','the','and'))
                if initials!=acronym:continue
                record=dict(canonical=lexical(expanded),display=expanded,evidence_id=eid,definition=match[0],kind='explicit_acronym_definition')
                for spelling in (expanded,acronym,match[0]):
                    acronym_definitions.setdefault(lexical(spelling),[]).append(record)
        ambiguous=set()
        for name,records in acronym_definitions.items():
            old=self.aliases.get(name)
            meanings={r['canonical'] for r in records}|({old['canonical']} if old else set())
            if len(meanings)==1:extra[name]=records[0]
            else:ambiguous.add(name)
        for eid,e in self.evidence.items():
            title=e['source_metadata']['title'];text=e['original_text']
            lead=re.match(r'^([A-Z][^()]{1,150}?)\s*\((?:born )?[^)]*\b\d{4}\b[^)]*\)\s+(?:is|was)\b',text)
            if not lead:continue
            title_words=lexical(title).split();lead_words=lexical(lead[1]).split()
            # Explicit biographical lead, same ordered title-name and title.
            # Commas and ordinal peerage titles are allowed; no fuzzy surnames.
            it=iter(lead_words)
            if not title_words or title_words[0]!=lead_words[0] or not all(any(x==word for x in it) for word in title_words):continue
            canonical=self.aliases.get(lexical(title),{}).get('canonical',lexical(title))
            record=dict(canonical=canonical,display=title,evidence_id=eid,definition=lead[0],kind='explicit_biographical_lead')
            for name in (title,lead[1]):biographical_definitions.setdefault(lexical(name),[]).append(record)
        for name,records in biographical_definitions.items():
            if len({r['canonical'] for r in records})==1:extra[name]=records[0]
        for normalized,entries in spellings.items():
            if len({lexical(title) for _,title,_ in entries})!=1:continue
            eid,title,plain=entries[0]
            if title==plain:continue
            canonical=self.aliases.get(lexical(title),{}).get('canonical',lexical(title))
            record=dict(canonical=canonical,display=title,evidence_id=eid,definition=title,kind='source_title_diacritic_spelling')
            for spelling in (title,plain):
                old=self.aliases.get(lexical(spelling))
                if old is None or old['canonical']==canonical:extra[lexical(spelling)]=record
        if any(self.aliases.get(k)!=v for k,v in extra.items()) or any(k in self.aliases for k in ambiguous):
            for name in ambiguous:self.aliases.pop(name,None);extra.pop(name,None)
            self.aliases.update(extra);self.alias_version+=1;self.version+=1
            for certificate in self.certificates:certificate['valid']=False
        self.evidence = originals
        self._refresh_alias_witnesses()
        self.sync()

    def propose(self, reading, call_id):
        # A coordinated occupational expression explicitly states both roles.
        # Keep the same original quote and admission checks for each atomic row.
        expanded=[]
        for row in reading.rows:
            need=self.catalog[row.node]
            if re.search(r'occupation|profession',need.r,re.I) and row.o.casefold() in (
                    'singer-songwriter','actor-director','writer-director','producer-director'):
                expanded.extend(row.model_copy(update={'o':part}) for part in row.o.split('-'))
            else:expanded.append(row)
        reading=reading.model_copy(update={'rows':expanded})
        ids = admit(self,reading,call_id)
        for fid in ids:
            self.rows[fid].update(origin='observed', fact_type='observed', spec_version=self.spec_version)
        self.closure_signature = None
        self.sync()
        return ids

    @contextmanager
    def visibility(self, derived):
        previous = self.use_derived
        self.use_derived = derived
        try:
            yield self
        finally:
            self.use_derived = previous

    def match(self, pattern, binding=None, statuses=('accepted',)):
        hits = super().match(pattern, binding, statuses)
        if not self.use_derived:
            hits = [h for h in hits if all(self.rows[f].get('origin') != 'program_derived' for f in h['facts'])]
        return hits

    def _join_nodes(self, nodes, statuses=('accepted',), partial=False, route_binding=None):
        seed = {k:self.term(v) for k,v in (route_binding or {}).items()}
        rows = [dict(binding=dict(b, **seed), facts=[], missing=[]) for b in self.initial()
                if all(k not in b or b[k]==v for k,v in seed.items())]
        for node in nodes:
            next_rows = {}
            for row in rows:
                for hit in self.match(self.pattern(node), row['binding'], statuses):
                    item = dict(binding=hit['binding'], facts=sorted(set(row['facts'] + hit['facts'])), missing=row['missing'])
                    sig = digest([item['binding'], item['missing']])
                    old = next_rows.get(sig)
                    if old is None or (len(item['facts']), item['facts']) < (len(old['facts']), old['facts']):
                        next_rows[sig] = item
                if partial:
                    item = dict(row, missing=row['missing'] + [node])
                    next_rows.setdefault(digest([item['binding'], item['missing']]), item)
            rows = list(next_rows.values())
            if len(rows) > self.max_bindings:
                if not partial:
                    raise ValueError('complete_binding_budget_exhausted')
                self.truncated = True
                rows.sort(key=lambda r: (len(r['missing']), -len(r['binding']), digest(r)))
                empty = next((r for r in rows if not r['binding']), None)
                rows = rows[:self.max_bindings]
                if empty and empty not in rows:
                    rows[-1] = empty
        return rows

    @property
    def active_nodes(self):
        return sorted(set(range(len(self.plan.needs))) | {n for a in self.activations for n in a['body']})

    def activate(self, rule, binding, goal_key):
        if rule.head >= len(self.plan.needs):
            raise ValueError('recursive_expansion_forbidden')
        if any(a['goal_key'] == goal_key for a in self.activations):
            raise ValueError('duplicate_bound_goal_expansion')
        new_nodes = set(rule.body) - set(self.active_nodes)
        if len(set(self.active_nodes) - set(range(len(self.plan.needs)))) + len(new_nodes) > self.limits['max_auxiliary']:
            raise ValueError('auxiliary_budget_exhausted')
        record = dict(parent_goal_id='N'+str(rule.head), head=rule.head, rule_id=rule.template,
                      instance_id=rule.id, body=rule.body, binding=binding, scope=self.catalog[rule.head].scope,
                      goal_key=goal_key, depth=1)
        self.activations.append(record)
        self.closure_signature = None
        return record

    def support_routes(self):
        self.routes_truncated = False
        options = [[dict(nodes=[i], binding={})] + [dict(nodes=a['body'], binding=a['binding'])
                    for a in self.activations if a['head']==i] for i in range(len(self.plan.needs))]
        routes = []
        for branch in product(*options):
            binding, okay = {}, True
            for item in branch:
                for key, value in item['binding'].items():
                    if key in binding and self.canonical(binding[key]) != self.canonical(value):
                        okay = False
                    binding[key] = value
            if okay:
                routes.append(dict(nodes=list(dict.fromkeys(n for item in branch for n in item['nodes'])), binding=binding))
            if len(routes)>=self.limits['max_routes']:
                self.routes_truncated=True
                break
        return routes

    def joins(self, statuses=('accepted',), partial=False):
        self.lookups += 1
        self.truncated = False
        routes = self.support_routes() if partial else [dict(nodes=list(range(len(self.plan.needs))), binding={})]
        result = {}
        for route in routes:
            # Bindings used to activate a support are hard constraints on that
            # route. They do not change the immutable question Program.
            for row in self._join_nodes(route['nodes'], statuses, partial, route['binding']):
                sig = digest([row['binding'], row['missing']])
                previous = result.get(sig)
                if previous is None or (len(row['facts']), row['facts']) < (len(previous['facts']), previous['facts']):
                    result[sig] = row
        rows = list(result.values())
        if len(rows)>self.max_bindings:
            if not partial:raise ValueError('complete_binding_budget_exhausted')
            self.truncated=True
            rows.sort(key=lambda r:(len(r['missing']),-len(r['binding']),digest(r)))
            rows=rows[:self.max_bindings]
        return rows

    def _ground_matches(self, nodes, operations, deadline):
        rows = [dict(binding={}, facts=[])]
        for node in nodes:
            following = []
            pattern = self.pattern(node)
            for row in rows:
                target = substitute(pattern, row['binding'])
                for fid, fact in list(self.rows.items()):
                    operations[0] += 1
                    if operations[0] > self.limits['max_rule_matches'] or time.process_time() > deadline:
                        raise ValueError('rule_work_budget_exhausted')
                    if fact['status'] != 'accepted' or fact.get('origin') == 'program_derived':
                        continue
                    binding = unify(target, self.row_atom(fact), row['binding'])
                    if binding is not None:
                        following.append(dict(binding=binding, facts=sorted(set(row['facts'] + [fid]))))
            rows = following
            if len(rows) > self.max_bindings:
                raise ValueError('rule_binding_budget_exhausted')
        return rows

    def _has_ancestor(self, fid, ancestor, visited=None):
        if fid == ancestor:
            return True
        visited = set() if visited is None else visited
        if fid in visited:
            return False
        visited.add(fid)
        return any(self._has_ancestor(p, ancestor, visited) for d in self.derivations.values()
                   if d['valid'] and d['conclusion'] == fid for p in d['premise_ids'])

    def _refresh_identity_witnesses(self):
        from .semantics import identity_owners
        changed=False
        for _ in self.plan.needs:
            local=False
            for row in self.rows.values():
                restore=row.get('reason')=='organizational_identity_context_invalidated'
                if row.get('origin')=='program_derived' or (row['status']!='accepted' and not restore):continue
                owners=identity_owners(self,row['node'],row['s'])
                valid=not owners or (len({self.canonical(o) for o in owners})==1 and all(not o.startswith('?') and self.source_mentions(o,row['evidence_id']) for o in owners))
                if not valid and not restore:
                    row.update(status='invalid',base_status='invalid',reason='organizational_identity_context_invalidated');local=True
                elif valid and restore and not self.evidence[row['evidence_id']].get('withdrawn'):
                    row.update(status='accepted',base_status='accepted',reason='organizational_identity_context_restored');local=True
            changed|=local
            if not local:break
        if changed:
            self.version+=1;self.closure_signature=None
            for c in self.certificates:c['valid']=False
            self._invalidate_unsupported()

    def recompute(self):
        self._refresh_alias_witnesses()
        self._refresh_identity_witnesses()
        signature = digest([self.spec_version, self.alias_version, self.acquisition, [(f, r['status'], r.get('base_status')) for f, r in self.rows.items() if r.get('origin') != 'program_derived']])
        if signature == self.closure_signature:
            return None
        started = time.process_time()
        deadline = started + self.limits['rule_cpu_seconds']
        operations = [0]
        previous_valid = {s for s, d in self.derivations.items() if d.get('valid')}
        for d in self.derivations.values():
            d['valid'] = False
        for r in self.rows.values():
            if r.get('origin') == 'program_derived':
                r.update(status='invalid', base_status='invalid', depth=None)
        self.detect_conflicts()
        error = None
        try:
            for depth in range(1, self.limits['max_depth'] + 1):
                additions = []
                for rule in self.acquisition.rules:
                    if not rule.valid:
                        continue
                    for match in self._ground_matches(rule.body, operations, deadline):
                        if any(self.rows[f].get('depth', 0) is None or self.rows[f].get('depth', 0) >= depth for f in match['facts']):
                            continue
                        atom = substitute(self.pattern(rule.head), match['binding'])
                        if not ground(atom):
                            raise ValueError('non_ground_rule_conclusion')
                        fid = 'D' + digest([self.spec_version, atom])
                        if fid in match['facts']:
                            continue
                        sid = 'S' + digest([rule.id, match['facts'], self.alias_version])
                        additions.append((fid, sid, atom, rule, match['facts'], match['binding']))
                for fid, sid, atom, rule, premise_ids, binding in additions:
                    if any(self._has_ancestor(p, fid) for p in premise_ids):
                        continue  # No cyclic support, even when another grounded path exists.
                    if sum(r.get('origin') == 'program_derived' for r in self.rows.values()) >= self.limits['max_derived'] and fid not in self.rows:
                        raise ValueError('derived_item_budget_exhausted')
                    if len(self.derivations) >= self.limits['max_supports'] and sid not in self.derivations:
                        raise ValueError('derivation_support_budget_exhausted')
                    n = self.catalog[rule.head]
                    self.rows.setdefault(fid, dict(id=fid, node=rule.head, s=self.names[atom.arguments[0].name], o=self.names[atom.arguments[1].name],
                                                   negated=atom.negated, scope=n.scope, evidence_id=None, quote=None,
                                                   origin='program_derived', fact_type='derived', spec_version=self.spec_version, extraction_call=None))
                    r = self.rows[fid]
                    r.update(status='accepted', base_status='accepted', reason='bounded_source_supported_rule', depth=min(r.get('depth') or depth, depth))
                    actual_depth = 1 + max(self.rows[p].get('depth', 0) for p in premise_ids)
                    self.derivations[sid] = dict(support_id=sid, conclusion=fid, premise_ids=premise_ids, rule_ids=[rule.id],
                                                spec_version=self.spec_version, alias_version=self.alias_version, depth=actual_depth, valid=True,
                                                parent_goal_id='N'+str(rule.head), rule_id=rule.template, binding={k:self.names[v.name] for k,v in binding.items()}, premise_fact_ids=premise_ids)
                self.detect_conflicts()
                self._invalidate_unsupported()
        except ValueError as exc:
            error = str(exc)
            # Never use a partial closure to certify exact answer cardinality.
            for d in self.derivations.values():
                d['valid'] = False
            for r in self.rows.values():
                if r.get('origin') == 'program_derived':
                    r.update(status='invalid', base_status='invalid')
        self._invalidate_unsupported()
        self.reverse_dependencies = {}
        for sid, d in self.derivations.items():
            for fid in d['premise_ids']:
                self.reverse_dependencies.setdefault(fid, []).append(sid)
        self.version += 1
        self.sync()
        self.closure_signature = signature
        valid = {s for s, d in self.derivations.items() if d['valid']}
        record = dict(cpu_seconds=time.process_time() - started, operations=operations[0], error=error,
                      valid_supports=len(valid), new_supports=sorted(valid - previous_valid), invalidated_supports=sorted(previous_valid - valid),
                      derived_items=sum(r.get('origin') == 'program_derived' and r['status'] == 'accepted' for r in self.rows.values()))
        self.closure_records.append(record)
        return record

    def _invalidate_unsupported(self):
        for _ in range(len(self.derivations) + 1):
            changed = False
            active_rules = {r.id for r in self.acquisition.rules if r.valid}
            for d in self.derivations.values():
                if d['valid'] and (not set(d['rule_ids']) <= active_rules or any(self.rows[f]['status'] != 'accepted' for f in d['premise_ids'])):
                    d['valid'] = False
                    changed = True
            supported = {d['conclusion'] for d in self.derivations.values() if d['valid']}
            for fid, r in self.rows.items():
                if r.get('origin') == 'program_derived' and fid not in supported and r['status'] != 'invalid':
                    r.update(status='invalid', base_status='invalid')
                    changed = True
            if not changed:
                return

    def set_status(self, ids, status, reason):
        if status == 'invalid':
            for fid in ids:
                self.rows[fid].update(status='invalid', base_status='invalid', reason=reason)
            self.version += 1
            self.sync()
        else:
            super().set_status(ids, status, reason)
        self.closure_signature = None
        # Immediate invalidation prevents consumers from observing stale facts
        # between an explicit withdrawal and the next controller iteration.
        self._refresh_identity_witnesses()
        self._invalidate_unsupported()
        self.sync()

    def withdraw_evidence(self, evidence_id, reason='source_withdrawn'):
        self.evidence[evidence_id]['withdrawn'] = reason
        ids = [f for f, r in self.rows.items() if r.get('evidence_id') == evidence_id]
        self.set_status(ids, 'invalid', reason)
        self.aliases = {k: v for k, v in self.aliases.items() if v['evidence_id'] != evidence_id}
        self.alias_version += 1
        self.observe([])  # Rebuild identity definitions from remaining originals.
        for rule in self.acquisition.rules:
            if rule.source_evidence_id == evidence_id:
                rule.valid = False
        self.recompute()

    def leaf_facts(self, ids):
        leaves, seen = set(), set()
        def visit(fid):
            if fid in seen:
                return
            seen.add(fid)
            row = self.rows[fid]
            if row['status'] != 'accepted':
                raise ValueError('invalid fact used in answer')
            if row.get('origin') != 'program_derived':
                leaves.add(fid)
            else:
                supports = [d for d in self.derivations.values() if d['conclusion'] == fid and d['valid']]
                if not supports:
                    raise ValueError('derived fact lacks valid grounded support')
                support = min(supports, key=lambda d: (d['depth'], len(d['premise_ids']), d['support_id']))
                for premise in support['premise_ids']:
                    visit(premise)
        for fid in ids:
            visit(fid)
        return sorted(leaves)

    def rule_sources(self, ids):
        sources, visited = {}, set()
        def visit(fid):
            if fid in visited:
                return
            visited.add(fid)
            for support in self.derivations.values():
                if support['conclusion'] != fid or not support['valid']:
                    continue
                for rid in support['rule_ids']:
                    rule = next(r for r in self.acquisition.rules if r.id == rid)
                    if rule.source_evidence_id:
                        sources[rid] = dict(rule_id=rid, evidence_id=rule.source_evidence_id, quote=rule.source_quote,
                                            origin=rule.origin)
                for premise in support['premise_ids']:
                    visit(premise)
        for fid in ids:
            visit(fid)
        return list(sources.values())

    def snapshot(self):
        return dict(super().snapshot(), spec_version=self.spec_version,
                    requirement_spec=self.plan.model_dump(), registered_rules=self.acquisition.model_dump(), auxiliary_goals=[dict(node=n, **self.catalog[n].model_dump()) for n in self.active_nodes if n>=len(self.plan.needs)], activations=self.activations,
                    derivations=self.derivations, reverse_dependencies=self.reverse_dependencies, counterfactual_records=self.counterfactual_records,
                    closure_records=self.closure_records, use_derived=self.use_derived)

    def candidates(self,statuses=('accepted',)):
        g=self.plan.goal
        if g.op=='same':
            supported=super().candidates(statuses)
            for row in self.joins(statuses):
                terms=[row['binding'].get(v[1:]) for v in (g.left,g.right)]
                if any(t is None for t in terms) or terms[0]==terms[1]:continue
                kinds=[next(n.kind for n in self.plan.needs if n.o==v) for v in (g.left,g.right)]
                values=[self.names[t.name] for t in terms];different=False
                if all(k=='date' for k in kinds):
                    dates=[date_bounds(v) for v in values]
                    different=all(dates) and (dates[0][1]<dates[1][0] or dates[1][1]<dates[0][0])
                elif all(k in ('number','frequency') for k in kinds):
                    amounts=[quantity(v,k) for v,k in zip(values,kinds)]
                    different=compare_quantities(*amounts) is not None
                if different:supported.append(dict(value='no',term=self.term('no'),binding=row['binding'],facts=row['facts'],computation=dict(op='disjoint_source_scalar_intervals',inputs=values)))
            return supported
        if g.op=='select':
            candidates=[]
            for row in self.joins(statuses):
                term=row['binding'].get(g.variable[1:])
                value=self.names.get(term.name) if term else None
                if value:
                    candidates.append(dict(value=value,term=term,binding=row['binding'],facts=row['facts'],computation=None))
            if re.search(r'\b(?:what|which) year\b',self.question,re.I):
                for candidate in candidates:
                    interval=date_interval(candidate['value'])
                    if interval and interval['lower'].year==interval['upper'].year:
                        original=candidate['value'];value=str(interval['lower'].year)
                        candidate.update(value=value,term=self.term(value),computation=dict(op='requested_year_projection',source_value=original,output=value,rule='calendar_year_of_source_date'))
            # A requested answer count is a minimum supported set size; finding
            # another true answer must not invalidate the already supported set.
            if g.count is not None and len({c['term'].name for c in candidates})<g.count:return []
            return candidates
        if g.op not in ('verify','later') and not getattr(g,'left_answer',None):
            candidates=super().candidates(statuses)
            return candidates
        result=[]
        for row in self.joins(statuses):
            if g.op=='verify':
                value='yes';computation=dict(op='all_original_requirements_supported')
            else:
                terms=[row['binding'].get(v[1:]) for v in (g.left,g.right)]
                if any(t is None for t in terms):continue
                values=[self.names[t.name] for t in terms]
                if g.op in ('earlier','later'):
                    dates=[date_bounds(v) for v in values]
                    if any(d is None for d in dates):continue
                    winner=0 if dates[0][1]<dates[1][0] else 1 if dates[1][1]<dates[0][0] else None
                    if winner is None:continue
                    if g.op=='later':winner=1-winner
                    computation=dict(op='date_interval_comparison',inputs=values,winner=winner)
                else:
                    kinds=[next(n.kind for n in self.plan.needs if n.o==v) for v in (g.left,g.right)]
                    winner=compare_quantities(*[quantity(v,k) for v,k in zip(values,kinds)])
                    if winner is None:continue
                    computation=dict(op='quantity_interval_comparison',inputs=values,winner=winner)
                projection=(g.left_answer,g.right_answer)[winner]
                if projection.startswith('?'):
                    term=row['binding'].get(projection[1:])
                    if term is None:continue
                    value=self.names[term.name]
                else:value=projection
                computation.update(output_projection=projection,output=value)
            result.append(dict(value=value,term=self.term(value),binding=row['binding'],facts=row['facts'],computation=computation))
        if g.op=='verify' and not result and all(ground(self.pattern(i)) for i in range(len(self.plan.needs))):
            # For a ground conjunction, one explicit denied conjunct proves no.
            # An absent fact, or one failed existential binding, proves nothing.
            for i in range(len(self.plan.needs)):
                for hit in self.match(opposite(self.pattern(i)),statuses=statuses):
                    result.append(dict(value='no',term=self.term('no'),binding=hit['binding'],facts=hit['facts'],computation=dict(op='explicit_counterexample_to_ground_conjunction',counterexample_node=i)))
        if g.count is not None and len({r['term'].name for r in result})<g.count:return []
        return result

    def proof_inputs(self, candidate):
        from .depth import fact_depths
        depths = fact_depths(self)
        leaves, rules, used_supports = set(), {}, []
        def visit(fid):
            row = self.rows[fid]
            if row['status']!='accepted':raise ValueError('invalid proof premise')
            if row.get('origin')!='program_derived':
                leaves.add(fid)
                return
            ds=[d for d in self.derivations.values() if d['valid'] and d['conclusion']==fid
                and d['premise_ids'] and all(p in depths for p in d['premise_ids'])]
            if not ds:raise ValueError('derived fact has no valid support')
            d=min(ds,key=lambda d:(1+max(depths[p] for p in d['premise_ids']),len(d['premise_ids']),d['support_id']))
            used_supports.append(d)
            for rid in d['rule_ids']:
                r=next(r for r in self.acquisition.rules if r.id==rid)
                rules[rid]=RuleSpec(id=rid,body=[self.pattern(n) for n in r.body],head=self.pattern(r.head),
                        origin='builtin',source_refs=[],explanation=r.reason)
            for premise in d['premise_ids']:visit(premise)
        for fid in candidate['facts']:visit(fid)
        return leaves,rules,used_supports

    def prove(self,candidate,prover):
        leaves,rules,used_supports=self.proof_inputs(candidate)
        facts=[(fid,self.row_atom(self.rows[fid])) for fid in sorted(leaves)]
        body=[self.pattern(i) for i in range(len(self.plan.needs))]
        question_fact_ids=set()
        for v,values in self.plan.choices.items():
            pattern=Atom(predicate='question_domain_'+v[1:],arguments=[self.term(v)],negated=False)
            body.append(pattern)
            for value in values:
                fid='QD'+digest([v,value]);question_fact_ids.add(fid)
                facts.append((fid,pattern.model_copy(update={'arguments':[self.term(value)]})))
        if self.plan.goal.op=='verify':
            head=Atom(predicate='verified_question',arguments=[self.term('yes')],negated=False)
        elif self.plan.goal.op=='select':
            head=Atom(predicate='answer',arguments=[Term(kind='variable',name=self.plan.goal.variable[1:],entity_type='entity')],negated=False)
        else:
            head=Atom(predicate='comparison_inputs',arguments=[Term(kind='variable',name=v[1:],entity_type='entity') for v in [self.plan.goal.left,self.plan.goal.right]],negated=False)
        rule=RuleSpec(id='question_conjunction',body=body,head=head,origin='question_definition',source_refs=[],explanation='All unchanged original requirements; auxiliary bodies are alternative proofs, not appended goals.')
        question_rules=[(rule.id,rule)]
        if self.plan.goal.op=='verify' and candidate['value']=='no':
            node=candidate['computation']['counterexample_node']
            if not all(ground(self.pattern(i)) for i in range(len(self.plan.needs))):raise ValueError('counterexample_cannot_disprove_existential_goal')
            head=Atom(predicate='verified_question',arguments=[self.term('no')],negated=False)
            denial=RuleSpec(id='question_counterexample_N'+str(node),body=[opposite(self.pattern(node))],head=head,origin='question_definition',source_refs=[],explanation='Explicit negation of an original ground conjunct entails that the original conjunction is false.')
            question_rules.append((denial.id,denial))
        target=substitute(head,candidate['binding'])
        if not ground(target):return None
        certificate=prover.prove(facts,[*sorted(rules.items()),*question_rules],[target],version=digest([self.plan_hash,self.alias_version,self.activations]))
        certificate['valid']=all(fid in question_fact_ids or self.rows[fid]['status']=='accepted' for fid in certificate['input_fact_ids'])
        uses_auxiliary = any(self.rows[f]['node']>=len(self.plan.needs) for f in leaves)
        original_answers = self.original_observation_answers() if uses_auxiliary else {self.canonical(candidate['value'])}
        certificate.update(alias_version=self.alias_version,derived_supports=used_supports,leaf_fact_ids=sorted(leaves),
                           proof_uses_auxiliary=uses_auxiliary,
                           answer_depends_on_expansion=bool(used_supports) and uses_auxiliary and self.canonical(candidate['value']) not in original_answers,
                           dependency_check='Program counterfactual: original-slot observations + common passive Gamma; no LLM, retrieval, or Prover calls.')
        from .depth import fact_depths, layers
        depths = fact_depths(self)
        premise_depth = max((depths[f] for f in candidate['facts'] if f in depths), default=0)
        certificate['reasoning_depth'] = dict(
            semantic_derivation_depth=1 + premise_depth if certificate['result']=='proved' and certificate['valid']
                and certificate['source_mapping_status']=='complete' and all(f in depths for f in candidate['facts']) else None,
            semantic_definition='minimum known valid support height for candidate plus question rule; observations=0; conditional on accepted facts',
            dependency_layers={str(k):v for k,v in layers(self.plan)[0].items()},
            formal_proof_depth=certificate.get('proof_depth', {}).get('formal_depth'),
            formal_parse_status=certificate.get('proof_depth', {}).get('status', 'unavailable'),
            proof_id=certificate['proof_id'], is_correctness_score=False)
        self.certificates.append(certificate)
        self.sync()
        return certificate if certificate['result']=='proved' and certificate['valid'] and certificate['source_mapping_status']=='complete' else None

    def original_observation_answers(self):
        """Answer support without auxiliary-slot observations; no live mutation."""
        signature = digest([self.plan_hash,self.aliases,self.evidence,
                            [(f,r) for f,r in self.rows.items() if r.get('origin')!='program_derived' and r['node']<len(self.plan.needs)]])
        if signature in self.original_only_cache:
            return set(self.original_only_cache[signature])
        clone = EvidenceStore(self.question,self.plan.model_copy(deep=True),':memory:',self.max_bindings,limits=self.limits)
        try:
            clone.observe(copy.deepcopy(list(self.evidence.values())))
            clone.rows = {f:copy.deepcopy(r) for f,r in self.rows.items()
                          if r.get('origin')!='program_derived' and r['node']<len(self.plan.needs)}
            clone.names = copy.deepcopy(self.names)
            clone.sync()
            work = clone.recompute()
            if work and work['error']:
                # An incomplete counterfactual cannot establish dependency.
                raise ValueError('counterfactual_'+work['error'])
            answers = {self.canonical(c['value']) for c in clone.candidates()}
            self.original_only_cache[signature] = sorted(answers)
            self.counterfactual_records.append(dict(signature=signature,answers=sorted(answers),
                observed_fact_ids=sorted(f for f,r in clone.rows.items() if r.get('origin')!='program_derived'),
                rule_cpu_seconds=sum(r['cpu_seconds'] for r in clone.closure_records),
                diagnostic='No auxiliary observations; same original conjunction and passive Gamma; no extra model/retrieval/prover calls.'))
            return answers
        finally:
            clone.close()
