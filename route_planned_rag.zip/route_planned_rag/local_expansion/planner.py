"""Bounded support enumeration; unit acquisition costs, shared actions counted once."""
from route_planned_rag.prototype.logic import substitute
from route_planned_rag.method.schema import signature as digest
from .depth import ProgressScorer, ProverDepthScorer, candidate_rank, prover_candidate_rank


def plan(engine):
    store = engine.store
    policy = engine.config.get('planning_policy', 'remaining_cost')
    if policy not in ('remaining_cost', 'reasoning_depth', 'prover_depth'):
        raise ValueError('unknown planning_policy')
    if policy in ('reasoning_depth', 'prover_depth') and (engine.config.get('allow_auxiliary') or store.activations):
        raise ValueError('reasoning_depth currently requires A: auxiliary acquisition disabled')
    scorer = (ProverDepthScorer(engine) if policy == 'prover_depth' or engine.config.get('proof_depth_measurement')
              else ProgressScorer(engine)) if policy in ('reasoning_depth', 'prover_depth') else None
    rank = prover_candidate_rank if policy == 'prover_depth' else candidate_rank
    candidates = []
    actions = {}
    for row in store.joins(partial=True):
        missing = {}
        ready = []
        facts = set(row["facts"])
        for node in row["missing"]:
            target = substitute(store.pattern(node), row["binding"])
            # A later join can bind an earlier hypothetical omission. Recheck
            # the now-ground requirement in SQL before scheduling acquisition.
            if all(t.kind == "constant" for t in target.arguments):
                hits = store.match(target)
                if hits:
                    facts.update(hits[0]["facts"])
                    continue
            action_id = digest(target)
            if action_id in missing:
                continue
            binding = {k: store.names[v.name] for k, v in row["binding"].items()}
            constants = [store.names[t.name] if t.kind == "constant" else None for t in target.arguments]
            anchor = constants[0] or (constants[1] if constants[1] not in ("true", "false") else None)
            request = dict(id=action_id, node=node, binding=binding, target=target.model_dump(), anchor=anchor)
            choice = None
            if anchor:
                choice = engine.read_option(request) or engine.retrieval_option(request)
            cost = choice["cost"] if choice else engine.config["retrieve_cost"] + engine.config["read_cost"]
            missing[action_id] = dict(id=action_id, node=node, pattern=target.model_dump(), cost=cost, executable=choice is not None)
            if choice:
                ready.append(choice["key"])
                actions[choice["key"]] = choice
        cid = digest([row["binding"], sorted(missing), store.plan_hash])
        candidates.append(dict(id=cid, binding={k: store.names[v.name] for k, v in row["binding"].items()},
                               fact_ids=sorted(facts), missing=list(missing.values()),
                               remaining_cost=sum(a["cost"] for a in missing.values()), ready=sorted(set(ready))))
        if scorer:
            candidates[-1]['reasoning_progress'] = scorer.candidate(row['binding'])
    # Resolving hypothetical omissions can collapse several rows to the same
    # support. Count that support once when measuring action sharing.
    unique = {}
    for candidate in candidates:
        old = unique.get(candidate["id"])
        if old is None or (len(candidate["fact_ids"]), candidate["fact_ids"]) < (len(old["fact_ids"]), old["fact_ids"]):
            unique[candidate["id"]] = candidate
    candidates = sorted(unique.values(), key=rank if scorer else
                        lambda c: (c["remaining_cost"], len(c["missing"]), c["id"]))
    if scorer:
        for candidate in candidates:
            candidate['priority_key'] = list(rank(candidate))
    sharing = {a: sum(a in c["ready"] for c in candidates) for a in actions}
    # Existing originals are always considered before purchasing another retrieval.
    readable = {key for key, a in actions.items() if a["mode"] == "read"}
    allowed = (readable or set(actions)) if engine.config.get("global_read_priority", False) else set(actions)
    def choose(ordered):
        selected = None
        for candidate in ordered:
            choices = [actions[k] for k in candidate["ready"] if k in allowed]
            if choices:
                if scorer:
                    choices = [dict(a, reasoning_potential=scorer.action(a, candidate['reasoning_progress'])) for a in choices]
                    selected = min(choices, key=lambda a: (-len(a['reasoning_potential']['potential_unlocked_nodes']),
                        -sharing[a['key']], a['cost'], a['node'], a['key']))
                else:
                    selected = min(choices, key=lambda a: (-sharing[a["key"]], a["cost"], a["node"], a["key"]))
                selected = dict(selected, candidate_id=candidate["id"], remaining_cost=candidate["remaining_cost"], shared_count=sharing[selected["key"]],
                                selection_reason="minimum distinct remaining acquisition cost; shared action tie break")
                if scorer:
                    selected.update(planning_policy=policy, reasoning_progress=candidate['reasoning_progress'],
                        priority_key=candidate['priority_key'],
                        selection_reason='original premise coverage; completed dependency depth; remaining cost; potential unlocks; sharing')
                break
        return selected
    selected = choose(candidates)
    if scorer:
        legacy = choose(sorted(candidates, key=candidate_rank))
        depth_first = choose(sorted(candidates, key=prover_candidate_rank))
        audit = dict(
            legacy_action_key=legacy['key'] if legacy else None,
            depth_action_key=depth_first['key'] if depth_first else None,
            action_changed=(legacy['key'] if legacy else None) != (depth_first['key'] if depth_first else None),
            legacy_candidate_id=legacy['candidate_id'] if legacy else None,
            depth_candidate_id=depth_first['candidate_id'] if depth_first else None,
            max_certified_depth=max((c['reasoning_progress']['semantic_derivation_depth'] for c in candidates), default=0),
            positive_depth_candidates=sum(c['reasoning_progress']['semantic_derivation_depth'] > 0 for c in candidates),
            comparison='same state, candidates, proof calls, actions and costs; only primary ranking key differs')
        if not hasattr(engine, 'depth_decisions'):
            engine.depth_decisions = []
        engine.depth_decisions.append(audit)
        if selected:
            selected['depth_decision'] = audit
            if policy == 'prover_depth':
                selected['selection_reason'] = 'Prover9-certified semantic depth first; unchanged legacy tie breaks'
    return candidates, selected
