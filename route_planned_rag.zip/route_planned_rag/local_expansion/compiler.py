"""Compile and check the question before A/B split; never see retrieved facts or gold."""
import re
import json
import unicodedata
from pathlib import Path
from route_planned_rag.prototype.prover import write_json
from route_planned_rag.method.schema import signature, words, normalized
from route_planned_rag.logic_control.compiler import requested_count
from .schema import Program,question_operator,entity_literal,output_mode

COMPILE_PROMPT='''Compile the QUESTION into a small executable relational Program. You have no evidence. Never supply an answer, remembered entity, or invented fact. All constants must be copied from the question. Output only JSON.

1. interpretation: ONE SHORT plain-language sentence (under 300 characters), not a nested JSON object or a transcript. anchors: ONLY complete proper names copied from the question. Common nouns, roles, pronouns and relation words are NOT anchors. Exclude grammatical possessive suffixes, not internal apostrophes.
2. needs: conjunction of (s,r,o,kind,subject_kind,object_level,scope,span,negated). Unknowns are ?variables. Each relation's span is an exact original question substring covering its meaning. A full-question span is allowed. A relation always runs subject -> value. Use 'father', 'mother', 'spouse' from child/person to the relative, 'directed by' from film to director, 'birth date' for a date, 'born in' for a birthplace. Never write 'mother of' for child -> mother. Use descriptive unambiguous English for other relations.
3. goal: select returns the requested bound variable; earlier/later/greater compare left/right values AND use left_answer/right_answer to return the entity actually asked for; same compares two attributes and returns yes/no; verify answers whether all stated predicates hold. output_mode is single for a singular answer request and set for a requested list/plural answer. count is ONLY an explicitly requested number of returned answers. A 'how many' question needs a number-valued relation, not an entity projection or a guessed count of retrieved rows.
4. choices is only a finite domain explicitly offered in the question, otherwise {}. Comparisons already have two named branches: do not add choice-membership evidence needs. unrepresented lists ONLY semantics you truly cannot express, not unavailable evidence.

All stated restrictions must remain executable. Preserve negation, temporal scopes, ordinal/superlative roles, geographical conditions and output ownership. Proper names containing Independent, Current, First, etc. are names, not additional predicates. A quoted description is preserved verbatim in its relation; words inside it are not independent superlative tests. A given biography description can remain a qualified boolean guard when necessary.
Use shared variables for an equality or intersection: do not create 'same as', 'identified by', or 'common between' retrieval needs. Quantities of requested answers belong in goal.count, not a count-of-an-occupation fact. A role such as managing editor belongs in the relation 'managing editor of', not as an entity between the person and magazine. Scope means TIME only; 'occupation of Nora', 'common between', 'explicitly two' are never scopes. Dates/numbers are terminal values, not subjects. Use the whole exact question as span when a shorter span would omit context. unrepresented should normally be []; missing evidence is not missing semantics.
The span is ONLY provenance, never an executable condition. Put every restriction into s/r/o/scope/types or an additional need. Attach a year ONLY to the event it modifies, not to every downstream relation. Keep event/role attribution joined: 'goalkeeper at Event E' is one qualified relation; generic goalkeeper plus generic participation is not sufficient. Likewise 'described as QUOTE by' keeps the quoted description on the attribution relation, rather than joining unrelated descriptions of the same subject. The interrogative 'who' can be a person OR organization/publication; use entity for an unspecified speaker/author/attributor.
Represent every explicitly mentioned intermediate unknown with its own variable. Do not compress 'the actor playing the title character of WORK' into WORK->actor: first identify the character, then its actor with the WORK qualifier retained. River origin means source/headwaters, not the river it flows into; rivers are places, not creative works. A 'how many' (or obvious typo 'who many') question selects a numeric count relation from the identified place/organization, never a list of centers or teams.
Use the complete name 'Nora Ames', not 'Nora Ames\'s'. Never truncate a multiword name at an apostrophe. Do not change spelling of question names. Correct only obvious grammar/typing in the interpretation, retaining exact source spans.
An appositive title after a comma identifies the SAME person: 'Nora Vale, 2nd Baron Cedar' is one anchor, not a parent-child relation. Parenthetical occupations are name disambiguators. Never invent father/mother relations from a title or ordinal. Preserve unqualified grandfather/grandmother as one requirement. Explicit paternal/maternal lineage may be compiled to the two stated parent edges before the Program is frozen. If a person is given only a first name plus regional restrictions, use a person variable with a name relation and those restrictions; do not recall a full identity.

TYPES: entity/person/organization/place/work/event/category/number/date/frequency/boolean. object_level is city/state/country/locality only when that particular level is required by the question; otherwise null. Plain 'where', 'place of birth', or 'place of death' accepts any stated place, including a country; do not invent a locality-only restriction. The country containing a location is a DIFFERENT variable from the location itself. For physical country requirements use r='located in country', object_level='country'; for city use 'located in city'. Film country of origin is not physical filming location. Never equate birthplace with nationality. Scope is only an explicit question time restriction, not a birth date you recall.
When asking 'by how much' something changed, use the requested source-stated numeric change or percentage as a relation. Do not invent before/after quantities and then select an unbound arithmetic variable: this Program has no arithmetic assignment operator. A question about an employer's school keeps the university-level employer as a distinct entity from an internal department. A party controlling one chamber and taking control of another chamber has TWO different chamber arguments, joined only through the party; never collapse the two chambers.

EXAMPLES (not facts):
Q: Which film has the older director, Cedar or Aspen?
needs: (Cedar,directed by,?d1,person), (Aspen,directed by,?d2,person), (?d1,birth date,?t1,date), (?d2,birth date,?t2,date).
goal: {op:earlier,left:?t1,right:?t2,left_answer:Cedar,right_answer:Aspen}. Return film, not director or date.
Q: Where was Cedar filmed in the country where Nora was born?
needs: (Cedar,filmed in,?place,place,object_level:locality), (?place,located in country,?country,place,object_level:country), (Nora,born in country,?country,place,object_level:country). select ?place. The place and country must NOT be the same variable.
Q: Were Nora and Ivo both poets during the 19th century?
needs: (Nora,worked as a poet,true,boolean,scope:19th century), (Ivo,worked as a poet,true,boolean,scope:19th century). goal verify, no output variable.
Q: Which university does the team Nora played for represent?
needs: (Nora,played for,?team,organization), (?team,represents university,?university,organization). select ?university.
Q: Which two occupations do Nora and Ivo share?
needs: (Nora,occupation,?occupation,category), (Ivo,occupation,?occupation,category). select ?occupation, count 2. One variable, multiple rows, not two different occupation variables.
For every actual need include its exact question span. No examples, supporting world facts, proof rules or final answers in the output.'''

def _example(q,needs,goal,anchors):
    return dict(question=q,program=dict(interpretation='Follow the stated relations and return the requested value.',anchors=anchors,
        needs=[dict(s=s,r=r,o=o,kind=k,subject_kind=sk,scope=None,span=q,negated=False,object_level=None) for s,r,o,k,sk in needs],
        goal=goal,choices={},unrepresented=[]))

COMPILE_PROMPT += """
FINAL TRANSLATION CHECK BEFORE OUTPUT:
- Read the interrogative answer noun separately from the intermediate nouns. 'What company is the label for WORK part of?' needs WORK -> label -> company and returns company. Never stop at label.
- For the city where someone coached/worked, first find the institution/team and its city when that is the stated intermediate organization; an institution cannot fill the city slot.
- Keep restrictive answer nouns: body of water, film series/franchise, personal title/honorific, and a region WITHIN a place. A generic place or work is not enough; spell the restriction into the final relation. A region within a state has object_level null, not state.
- A generic organizational subunit MUST keep its owning institution in the chain. Prefer relation 'head of Department of X at UNIVERSITY' when no separate department identity is needed; otherwise keep owner -> department -> head and do not conflate names across owners.
- 'What do X and Y have in common?' requests the supported common attributes as a set, not the first one found. Return atomic occupations.
- Comparisons with two explicitly offered alternatives, including 'came out first', return the named alternative using earlier/later/greater. A superlative inside a description ('the oldest college in the state') is a qualified relation, NOT a comparison between two absent alternatives.
- Paternal grandmother is father then mother; paternal grandfather is father then father; maternal grandmother is mother then mother; maternal grandfather is mother then father. These are QUESTION-DEFINED paths, compiled once before freezing. Do not add such paths for a title/apposition or an unqualified grandparent.
- Unknown descriptions ('the English king', 'the country that ...') are variables with stated qualifier relations, not literal named people/countries. Do not use a whole descriptive clause as a constant anchor.
- Keep event date, ordinary location and temporary exhibition distinct. Do not add 'current' or 'permanent' when the question does not specify it; preserve explicit temporal constraints when it does.
- Copy entity spellings from the question. Never insert a recalled country for a nationality adjective; keep the adjective as a relation/condition.
"""

COMPILE_PROMPT+='\nCOMPLETE JSON EXAMPLES (unrelated invented names):\n'+json.dumps([
    _example('What does the magazine Nora edits focus on?', [('Nora','editor of','?magazine','work','person'),('?magazine','focuses on','?topic','category','work')],dict(op='select',variable='?topic',output_mode='single'),['Nora']),
    _example('Which band was formed first, Cedar or Aspen?', [('Cedar','band formation date','?t1','date','organization'),('Aspen','band formation date','?t2','date','organization')],dict(op='earlier',left='?t1',right='?t2',left_answer='Cedar',right_answer='Aspen',output_mode='single'),['Cedar','Aspen']),
    _example('Which two occupations do Nora and Ivo share?', [('Nora','occupation','?job','category','person'),('Ivo','occupation','?job','category','person')],dict(op='select',variable='?job',count=2,output_mode='set'),['Nora','Ivo']),
    _example("Where was Nora's mother born?", [('Nora','mother','?mother','person','person'),('?mother','born in','?place','place','person')],dict(op='select',variable='?place',output_mode='single'),['Nora']),
    _example('Where was the mother of Nora Vale, 2nd Baron Cedar born?', [('Nora Vale, 2nd Baron Cedar','mother','?mother','person','person'),('?mother','born in','?place','place','person')],dict(op='select',variable='?place',output_mode='single'),['Nora Vale, 2nd Baron Cedar']),
    _example('Does Cedar Hospital or Aspen Hospital have more beds?', [('Cedar Hospital','number of beds','?n1','number','organization'),('Aspen Hospital','number of beds','?n2','number','organization')],dict(op='greater',left='?n1',right='?n2',left_answer='Cedar Hospital',right_answer='Aspen Hospital',output_mode='single'),['Cedar Hospital','Aspen Hospital']),
    _example('Were Nora and Ivo both poets?', [('Nora','was a poet','true','boolean','person'),('Ivo','was a poet','true','boolean','person')],dict(op='verify',output_mode='single'),['Nora','Ivo']),
    _example('Who plays the title character in the film Cedar?', [('Cedar','title character','?character','person','work'),('?character','portrayed in Cedar by','?actor','person','person')],dict(op='select',variable='?actor',output_mode='single'),['Cedar']),
    _example('How many sports centers are in the city where Nora worked?', [('Nora','worked in','?city','place','person'),('?city','number of sports centers','?count','number','place')],dict(op='select',variable='?count',output_mode='single'),['Nora']),
    dict(question='Who called the founder of Orion in 1998 "a thoughtful leader"?',program=dict(interpretation='Find who gave the quoted description of the 1998 founder; the attribution has no stated date.',anchors=['Orion'],needs=[dict(s='Orion',r='founded by',o='?founder',kind='person',subject_kind='organization',scope='1998',span='founder of Orion in 1998'),dict(s='?founder',r='described as "a thoughtful leader" by',o='?speaker',kind='entity',subject_kind='person',scope=None,span='Who called the founder of Orion in 1998 "a thoughtful leader"?')],goal=dict(op='select',variable='?speaker',output_mode='single'),choices={},unrepresented=[])),
    dict(question='Who was the goalkeeper for Aland at the 2004 Sun Cup held in Luma?',program=dict(interpretation='Find the goalkeeper for Aland at that event, preserving the host location.',anchors=['Aland','2004 Sun Cup','Luma'],needs=[dict(s='Aland',r='goalkeeper at the 2004 Sun Cup',o='?keeper',kind='person',subject_kind='organization',scope='2004',span='goalkeeper for Aland at the 2004 Sun Cup'),dict(s='2004 Sun Cup',r='held in',o='Luma',kind='place',subject_kind='event',scope='2004',span='2004 Sun Cup held in Luma')],goal=dict(op='select',variable='?keeper',output_mode='single'),choices={},unrepresented=[])),
],ensure_ascii=False,separators=(',',':'))

def contract(question,program):
    program.checked(question)
    from .semantics import check_translation
    check_translation(question,program)
    expected=question_operator(question)
    if program.goal.op!=expected:raise ValueError('question requires goal operator '+expected)
    if any(n.negated for n in program.needs) and not re.search(r'\b(?:not|never|without|except|excluding)\b',question,re.I):
        raise ValueError('cannot add an unstated negative condition')
    for need in program.needs:
        relation=need.r.casefold().strip()
        if relation in ('father','mother') and not re.search(r'\b'+relation+r"(?:['’]s)?\b",question,re.I):
            lineage=bool(re.search(r'\b(?:paternal|maternal) grand(?:mother|father)\b',question,re.I))
            if lineage:continue
            raise ValueError('unstated '+relation+' relation: a comma/title is apposition, not kinship; preserve explicitly stated family relations')
    # Lexical coverage is only a diagnostic. Capitalization and words in proper
    # names are not reliable semantic validators (e.g. 'Goal keeper').
    represented=' '.join(n.r+' '+(n.scope or '')+' '+n.s+' '+n.o for n in program.needs)
    missing=sorted(set(words(question))-set(words(represented))-
        set('which what who where when how whose is are was were does did do has have both same first more earlier older later younger'.split()))
    return dict(valid=True,plan_hash=signature(program),phase='question_only_before_freeze',
                semantic_status='typed structural validation; natural-language translation remains model-proposed',
                lexical_coverage_diagnostic=missing,
                coverage=[dict(node=i,**n.model_dump()) for i,n in enumerate(program.needs)])

def question_spelling(value,question):
    """Copy a unique accent-equivalent span; never fuzzy-match different names."""
    if value.casefold() in question.casefold():return value
    fold=lambda text: ''.join(c for c in unicodedata.normalize('NFKD',text.casefold()) if not unicodedata.combining(c))
    tokens=list(re.finditer(r"\w+",question));wanted=re.findall(r"\w+",fold(value))
    original_tokens=list(re.finditer(r"\w+",value))
    if not original_tokens:return value
    prefix=value[:original_tokens[0].start()];suffix=value[original_tokens[-1].end():]
    matches=[]
    for start in range(len(tokens)-len(wanted)+1):
        chunk=tokens[start:start+len(wanted)]
        if chunk and [fold(m[0]) for m in chunk]==wanted:
            left,right=chunk[0].start(),chunk[-1].end()
            if prefix and question[max(0,left-len(prefix)):left]!=prefix:continue
            if suffix and question[right:right+len(suffix)]!=suffix:continue
            matches.append(question[left-len(prefix):right+len(suffix)])
    return matches[0] if len(set(matches))==1 else value

def normalize(question,proposal):
    p=proposal.model_copy(deep=True);operations=[]
    for i,n in enumerate(p.needs):
        if not n.span.strip() or normalized(n.span) not in normalized(question):
            # A provenance span is a pointer, not an extra semantic guard. The
            # full original question is always a valid source for the proposed
            # translation; preserve the failed pointer for post-run inspection.
            operations.append(dict(node=i,old=n.span,new=question,reason='question_provenance_fallback_to_full_original'))
            n.span=question
        for field in ('s','o'):
            old=getattr(n,field)
            if not old.startswith('?'):
                new=question_spelling(entity_literal(old),question)
                if new!=old:setattr(n,field,new);operations.append(dict(node=i,field=field,old=old,new=new,reason='question_only_possessive_or_title_orthography'))
        if n.kind=='place':
            level=re.search(r'\b(city|state|country)\s*$',n.r,re.I)
            if level:n.object_level=level[1].lower()
            if n.object_level=='locality' and n.r.lower() in ('born in','birthplace','place of birth','died in','death place','place of death') and not re.search(r'\b(?:city|town|village|island|locality)\b',question,re.I):
                operations.append(dict(node=i,old='locality',new=None,reason='unqualified_where_does_not_exclude_country'))
                n.object_level=None
        if re.search(r'\briver$',n.s,re.I) and n.r.casefold().strip() in ('origin','source','originates in','originates from') and not re.search(r'\b(?:film|movie|novel|book|song|album)\b',question,re.I):
            operations.append(dict(node=i,old=n.r,new='river source (headwaters) located in',reason='explicit_river_origin_sense'))
            n.r='river source (headwaters) located in';n.subject_kind='place';n.kind='place'
    p.anchors=[question_spelling(entity_literal(a),question) for a in p.anchors]
    for field in ('left_answer','right_answer'):
        if getattr(p.goal,field):setattr(p.goal,field,question_spelling(entity_literal(getattr(p.goal,field)),question))
    expected=question_operator(question)
    if p.goal.op!=expected:raise ValueError('operator must be '+expected)
    p.goal.count=requested_count(question)
    p.goal.output_mode=output_mode(question,p.goal.count)
    # Equality of logical variables is substitution, not an evidence relation.
    # This normalization happens once, before the immutable A/B Program exists.
    equalities=[n for n in p.needs if n.r.casefold().strip() in ('same as','identical to','equals','equal to') and n.s.startswith('?') and n.o.startswith('?') and not n.negated and n.scope is None]
    for equality in equalities:
        old,new=equality.s,equality.o
        if old!=new:
            for n in p.needs:
                if n.s==old:n.s=new
                if n.o==old:n.o=new
            for field in ('variable','left','right','left_answer','right_answer'):
                if getattr(p.goal,field)==old:setattr(p.goal,field,new)
            if old in p.choices:
                if new in p.choices and p.choices[old]!=p.choices[new]:raise ValueError('incompatible finite domains under equality')
                p.choices[new]=p.choices.pop(old)
            operations.append(dict(old=old,new=new,reason='logical_variable_equality_substitution'))
        p.needs.remove(equality)
    record=contract(question,p)
    record.update(operations=operations,raw_proposal=proposal.model_dump())
    return p,record

def compile_episode(question,client,directory,maximum=3200):
    directory=Path(directory);error=None;previous=None
    schema=Program.model_json_schema()
    schema['required']=['interpretation','anchors','needs','goal','choices','unrepresented']
    schema['$defs']['Requirement']['required']=['s','r','o','kind','subject_kind','scope','span','negated','object_level']
    op=question_operator(question);goal_schema=schema['$defs']['Goal']
    goal_schema['properties']['op']={'enum':[op]}
    goal_schema['properties']['output_mode']={'enum':[output_mode(question,requested_count(question))]}
    null_fields=['left','right','left_answer','right_answer'] if op=='select' else ['variable','left','right','left_answer','right_answer'] if op=='verify' else ['variable']
    if op=='same':null_fields+=['left_answer','right_answer']
    for field in null_fields:goal_schema['properties'][field]={'type':'null'}
    variables=['variable'] if op=='select' else ['left','right'] if op!='verify' else []
    for field in variables:goal_schema['properties'][field]={'type':'string','pattern':r'^\?[a-z][a-z0-9_]{0,30}$'}
    goal_schema['required']=['op','output_mode',*variables]+(['left_answer','right_answer'] if op in ('earlier','later','greater') else [])
    for attempt in range(3):
        payload=dict(question=question)
        if previous is not None:payload.update(previous=previous,error=error,instruction='Repair the question translation. No facts or answers are available. Keep the full original question semantics.')
        try:
            proposal=client.ask('compile' if attempt==0 else 'compile_repair',Program,COMPILE_PROMPT,payload,maximum=maximum,decoding_schema=schema)
            previous=proposal.model_dump();write_json(directory/f'proposal_{attempt}.json',previous)
            p,record=normalize(question,proposal)
            write_json(directory/'compilation.json',record);write_json(directory/'program.json',p.model_dump())
            return p
        except (ValueError,RuntimeError) as exc:
            error=str(exc);write_json(directory/f'compile_error_{attempt}.json',dict(error=error,proposal=previous))
            if 'token_budget_exhausted' in error:break
    raise ValueError('plan_invalid: '+str(error))
