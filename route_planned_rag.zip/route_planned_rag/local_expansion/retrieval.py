"""Read/write shared index format, copied from closed_loop v1 before freezing."""
import hashlib
import json
import time
import re
import unicodedata
from pathlib import Path
from route_planned_rag.prototype.prover import write_json
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def title_tokens(value):
    plain=''.join(c for c in unicodedata.normalize('NFKD',value) if not unicodedata.combining(c))
    return tuple(re.findall(r'\w+', plain.casefold().replace('’', "'")))

def anchor_ranking(query, evidence, scores, k, anchor=None):
    """Reserve at most two slots for explicitly named titles; fill with dense hits.

    This changes retrieval, not evidence admission. A title match is never a fact.
    Keep the lead of each matched title. For a single title, also keep its best
    dense chunk, so a career-heavy tail cannot displace a biography's birth data.
    """
    import numpy as np
    dense = [int(i) for i in np.argsort(-scores, kind='stable')]
    query_words = title_tokens(query)
    anchor_words = title_tokens(anchor or '')
    matched = {}
    for i in dense:
        title = evidence[i]['source_metadata']['title']
        full = title_tokens(title)
        short = title_tokens(re.sub(r'\s*\([^()]*\)\s*$', '', title))
        size = max((len(tokens) for tokens in (full, short)
                    if tokens and (len(tokens) >= 2 or tokens == query_words or tokens == anchor_words)
                    and any(query_words[j:j+len(tokens)] == tokens
                            for j in range(len(query_words)-len(tokens)+1))), default=0)
        if size:
            matched.setdefault(full, []).append((i,size))
    groups=sorted(matched.values(),key=lambda g:(-g[0][1],-float(scores[g[0][0]]),g[0][0]))
    anchors=[]
    for group in groups[:min(2,k)]:
        lead=min((i for i,_ in group),key=lambda i:(evidence[i]['source_metadata'].get('char_start',0),i))
        anchors.append(lead)
    if len(groups)==1 and k>1:
        best=groups[0][0][0]
        if best not in anchors:anchors.append(best)
    chosen = anchors + [i for i in dense if i not in anchors]
    return chosen[:k], set(anchors)

class SharedRetriever:
    def __init__(self, corpus_path, encoder, cache, model_identity):
        import numpy as np
        from route_planned_rag.prototype.retrieval import ContextRetriever
        self.encoder = encoder
        cache.mkdir(parents=True, exist_ok=True)
        signature = hashlib.sha256((sha(corpus_path) + json.dumps(model_identity, sort_keys=True)).encode()).hexdigest()
        directory = cache / signature
        self.physical_index_seconds = 0.
        if not (directory / 'COMPLETE.json').exists():
            docs = json.loads(corpus_path.read_text())
            start = time.perf_counter()
            index = ContextRetriever([(d['title'], [d['text']]) for d in docs], encoder)
            for e in index.evidence:
                e['source_metadata']['retrieval_setting'] = 'shared_public_candidate_pool'
            if not index.evidence:
                raise ValueError('empty shared corpus')
            directory.mkdir(parents=True, exist_ok=True)
            write_json(directory / 'evidence.json', index.evidence)
            np.save(directory / 'vectors.npy', index.vectors)
            write_json(directory / 'COMPLETE.json', dict(corpus_sha256=sha(corpus_path), documents=len(docs), chunks=len(index.evidence),
                       index_usage=index.index_usage, model_identity=model_identity, wall_seconds=time.perf_counter() - start))
            self.physical_index_seconds = time.perf_counter() - start
        self.evidence = json.loads((directory / 'evidence.json').read_text())
        self.vectors = np.load(directory / 'vectors.npy', mmap_mode='r')
        self.index_record = json.loads((directory / 'COMPLETE.json').read_text())
        if len(self.evidence) != len(self.vectors) or not np.isfinite(self.vectors).all():
            raise ValueError('invalid_shared_index_vectors')
        self.cache_path = str(directory)

    def __call__(self, query, k):
        return self.search(query,k)

    def search(self, query, k, *, anchor=None, subject_type=None):
        import numpy as np
        vectors, usage = self.encoder.encode([query], is_query=True)
        scores = self.vectors @ vectors[0]
        ids, anchors = anchor_ranking(query, self.evidence, scores, k, anchor=anchor)
        return [dict(self.evidence[int(i)], retrieval_score=float(scores[i]),
                     retrieval_method='explicit_title' if i in anchors else 'dense') for i in ids], dict(input_tokens=usage.input_tokens, seconds=usage.gpu_seconds)
