"""A-only full-scale execution using the unchanged v4 compiler and engine."""
import argparse
import copy
import fcntl
import hashlib
import json
import os
import signal
import shutil
import time
from pathlib import Path

from route_planned_rag.method.client import Client
from route_planned_rag.prototype.prover import Prover, write_json
from .answering import AnswerClient, reserve_terminal, generate_terminal
from .compiler import compile_episode
from .engine import LocalExpansionEngine, DEFAULTS
from .retrieval import SharedRetriever
from .rules import GAMMA_HASH
from .schema import Program


def load(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def a_config(settings):
    return {**DEFAULTS, **settings['execution'], 'allow_auxiliary': False}


def validate_public(rows):
    if not rows or len({(r['dataset'],r['question_id']) for r in rows})!=len(rows):
        raise ValueError('Empty or duplicate evaluation sample')
    for r in rows:
        if r['dataset'] not in ('hotpotqa','twowiki','musique') or Path(r['question_id']).name!=r['question_id']:
            raise ValueError('Unsafe dataset/question identifier')
        if set(r)-{'dataset','question_id','question','development_exposed'}:
            raise ValueError('Unexpected fields in public input; labels cannot reach runtime')


def freeze_protocol(path, protocol):
    if path.exists():
        if load(path)!=protocol:raise ValueError('Resume requires identical frozen protocol')
    else:write_json(path,protocol)


def check_result(row, budget, config):
    if row.get('variant')!='A' or row.get('auxiliary_goals') or row.get('auxiliary_actions_executed'):
        raise ValueError('A-only invariant violated')
    if row['logical_total_tokens']>budget or row['reader_calls']>config['max_reader_calls'] or row['retrieval_calls']>config['max_retrievals']:
        raise ValueError('Question budget violated')
    if row.get('answer_depends_on_expansion'):
        raise ValueError('A answer cannot depend on activated expansion')


def failed(question, reason, category='infrastructure_error'):
    return dict(question=question,final_answer='',certified_answer='',proof_status='unverified',
        status=category,acquisition_status=category,error=reason,answer_source='abstain',failure_category=category,
        expansion_triggered=False,matched_rule_ids=[],auxiliary_goals=[],auxiliary_actions_executed=[],
        answer_depends_on_expansion=False,no_progress_reads=0,reader_calls=0,retrieval_calls=0,proof_calls=0)


def execute_question(row, actor, retriever, binary, run, config, budget, compilation_source_run=None):
    """Same compile -> engine -> terminal path as cli.py A, with durable question results."""
    directory=run/row['dataset']/row['question_id']/'A';result_path=directory/'result.json'
    if result_path.exists():
        result=load(result_path);check_result(result,budget,config);return result
    cache=run/'compilation_cache'/(row['dataset']+'_'+row['question_id'])
    if compilation_source_run is not None:
        source_cache=compilation_source_run/'compilation_cache'/cache.name
        if not (source_cache/'outcome.json').exists():
            raise ValueError('paired initial compilation is incomplete')
        if not cache.exists():
            shutil.copytree(source_cache,cache)
        if sha(cache/'outcome.json') != sha(source_cache/'outcome.json'):
            raise ValueError('paired Program changed')
    outcome_path=cache/'outcome.json'
    compiler=Client(actor,cache,budget=budget)
    started=time.perf_counter();program=None;compile_error=None
    interrupted_compile=bool(compiler.calls) and not outcome_path.exists()
    if outcome_path.exists():
        outcome=load(outcome_path);compile_error=outcome['error']
        program=Program.model_validate(outcome['program']) if outcome['program'] else None
    elif not interrupted_compile:
        try:program=compile_episode(row['question'],compiler,cache,maximum=3200)
        except (ValueError,RuntimeError) as exc:compile_error=repr(exc)
        write_json(outcome_path,dict(error=compile_error,program=program.model_dump() if program else None))
    directory.mkdir(parents=True,exist_ok=True)
    interrupted_episode=(directory/'model_calls.json').exists()
    if not interrupted_episode:
        inherited=[dict(c,physical_execution=False,shared_compiler_cache=str(cache.relative_to(run))) for c in copy.deepcopy(compiler.calls)]
        write_json(directory/'model_calls.json',inherited)
    client=AnswerClient(actor,directory,budget=budget)
    engine=None
    if interrupted_compile or interrupted_episode:
        # Completed questions resume without work. A killed in-flight question is
        # retained as a technical failure, never silently restarted with free budget.
        result=failed(row['question'],'Incomplete prior execution retained with original ledger; no rerun budget granted','execution_interrupted')
        if (directory/'checkpoint.json').exists():
            checkpoint=load(directory/'checkpoint.json')
            result.update({k:checkpoint.get(k,0) for k in ('reader_calls','retrieval_calls','no_progress_reads')})
    else:
        try:
            if program is None:raise ValueError(compile_error)
            prover=Prover(binary,directory/'prover',timeout=config['prover_timeout'],cap=config['max_prover_calls'])
            engine=LocalExpansionEngine(row['question'],program.model_copy(deep=True),client,retriever,prover,directory,dict(config,allow_auxiliary=False))
            result=engine.run()
        except (ValueError,RuntimeError,OSError) as exc:
            result=failed(row['question'],repr(exc),'plan_invalid' if program is None else 'execution_error')
            result['initial_compile_invalid']=program is None
            if program is None and config['answer_policy']=='best_effort':
                sources=[];state=dict(reader_calls=0,terminal_calls=0);events=[]
                def emit(kind,**data):events.append(dict(kind=kind,**data))
                try:
                    reserve_terminal(client,config)
                    if client.charged+config['terminal_token_reserve']<=client.budget:
                        result['retrieval_calls']=1;sources,usage=retriever(row['question'],config['retrieval_top_k'])
                        result['query_embedding_usage']=[usage]
                    result.update(generate_terminal(row['question'],client,config,state,sources,
                        unresolved=[dict(reason='initial_compile_invalid')],event=emit))
                    if result['final_answer']:result['status']='best_effort'
                except (ValueError,RuntimeError,OSError) as terminal_exc:result['terminal_error']=repr(terminal_exc)
                result.update(reader_calls=state['reader_calls'],terminal_calls=state['terminal_calls'])
                write_json(directory/'terminal_events.json',events);write_json(directory/'terminal_sources.json',sources)
        finally:
            if engine is not None:engine.store.close()
    # The authoritative reader count includes verification and terminal calls.
    result['reader_calls']=sum(c['role'] in ('reader','reader_verification','terminal_answer') for c in client.calls)
    result.update(dataset=row['dataset'],question_id=row['question_id'],variant='A',run_kind='real_model',
        development_exposed=row['development_exposed'],relative_directory=str(directory.relative_to(run)),
        seconds_this_episode=time.perf_counter()-started,initial_compile_invalid=program is None,
        answer_policy=config['answer_policy'],logical_compiler_tokens=compiler.charged,
        logical_compiler_seconds=sum(c['seconds'] for c in compiler.calls),logical_total_tokens=client.charged,
        physical_compiler_tokens=0 if compilation_source_run is not None else sum(c.get('input_tokens',0)+c.get('output_tokens',0) for c in compiler.calls),
        physical_episode_tokens=sum(c.get('input_tokens',0)+c.get('output_tokens',0) for c in client.calls if c.get('physical_execution',True)),
        interrupted_usage_unknown=any(c['status']=='interrupted_usage_unknown' for c in client.calls),
        input_tokens=sum(c.get('input_tokens',0) for c in client.calls),output_tokens=sum(c.get('output_tokens',0) for c in client.calls))
    check_result(result,budget,config);write_json(result_path,result)
    return result


def main(argv=None):
    import yaml
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--experiment',required=True)
    p.add_argument('--shard',type=int,required=True);a=p.parse_args(argv)
    root=a.root.resolve();exp=root/a.experiment;source=Path(os.environ['LOGICRAG_SOURCE_ROOT'])
    frozen=load(exp/'freeze.json')
    for path,value in frozen['source_sha256'].items():
        if sha(source/path)!=value:raise ValueError('Frozen source changed: '+path)
    manifest=load(exp/'data/manifest.json');spec=manifest['shards'][a.shard]
    public=load(exp/'data'/spec['path']);validate_public(public)
    assert spec['index']==a.shard and sha(exp/'data'/spec['path'])==spec['sha256']
    settings=yaml.safe_load((source/frozen.get('config_path','configs/answer_policy.yaml')).read_text())
    models=yaml.safe_load((source/settings['model_config']).read_text())
    config=a_config(settings)
    run=root/frozen.get('run_path','runs/full_a/full_a_20260916');out=run/'shards'/f'{a.shard:03d}';out.mkdir(parents=True,exist_ok=True)
    lock=(out/'worker.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    binary=root/'vendor/prover9/LADR-2009-11A/bin/prover9'
    if not binary.is_file():raise ValueError('Prover9 binary absent')
    protocol=dict(version='full-a-v1',variant='A',allow_auxiliary=False,question_count=len(public),
        execution=config,question_token_budget=settings['question_token_budget'],seed=settings['seed'],
        models={k:models['models'][k] for k in ('actor','retriever')},gamma_hash=GAMMA_HASH,
        source_sha256=frozen['source_sha256'],public_sha256=spec['sha256'],prover_sha256=sha(binary),
        data_manifest_sha256=sha(exp/'data/manifest.json'),evaluation=f"Offline Str-Acc and LLM-Acc after all {manifest['questions']} final results",
        resume='Completed questions are reused; killed in-flight questions retain all usage and remain technical failures in denominator',
        public_questions=public)
    freeze_protocol(out/'protocol.json',protocol)
    paired = frozen.get('paired_experiment')
    if paired:
        paired_exp=root/paired
        paired_frozen=load(paired_exp/'freeze.json')
        assert paired_frozen['source_sha256']==frozen['source_sha256']
        assert sha(paired_exp/'data/manifest.json')==sha(exp/'data/manifest.json')
        paired_settings=yaml.safe_load((source/paired_frozen['config_path']).read_text())
        paired_config=a_config(paired_settings)
        assert {k:v for k,v in paired_config.items() if k!='planning_policy'}=={k:v for k,v in config.items() if k!='planning_policy'}
        assert config['planning_policy']=='reasoning_depth' and paired_config['planning_policy']=='prover_depth'
        paired_run=root/paired_frozen['run_path']
        paired_out=paired_run/'shards'/f'{a.shard:03d}'
        paired_out.mkdir(parents=True,exist_ok=True)
        paired_lock=(paired_out/'worker.lock').open('w');fcntl.flock(paired_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        freeze_protocol(paired_out/'protocol.json',dict(protocol,execution=paired_config))
    completed=[run/r['dataset']/r['question_id']/'A/result.json' for r in public]
    if not paired and (out/'COMPLETE.json').exists() and all(path.exists() for path in completed):
        print('SHARD_ALREADY_COMPLETE',a.shard,flush=True);return
    import torch
    from route_planned_rag.logicgraph.runtime import load_models
    torch.manual_seed(settings['seed']);models['project']['root']=str(root)
    start=time.perf_counter();actor,_,encoder=load_models(models,with_encoder=True,with_scorer=False)
    write_json(out/'runtime.json',dict(job_id=os.getenv('SLURM_JOB_ID'),device=torch.cuda.get_device_name(),
        model_load_seconds=time.perf_counter()-start,torch_version=torch.__version__))
    ds=spec['dataset'];index=load(exp/'indices'/(ds+'.json'));corpus=exp/'data/corpora'/(ds+'.json')
    if index['corpus_sha256']!=sha(corpus):raise ValueError('Index/corpus mismatch')
    if not (Path(index['cache_path'])/'COMPLETE.json').exists():raise ValueError('Index incomplete')
    retriever=SharedRetriever(corpus,encoder,root/'artifacts/closed_loop_indices'/ds,models['models']['retriever'])
    if paired:
        # Shared immutable index/model only; independent retriever and episode state.
        paired_retriever=SharedRetriever(corpus,encoder,root/'artifacts/closed_loop_indices'/ds,models['models']['retriever'])
        write_json(paired_out/'runtime.json',load(out/'runtime.json'))
        paired_results=[]
    stop=[False]
    signal.signal(signal.SIGUSR1,lambda *_:stop.__setitem__(0,True))
    results=[]
    for row in public:
        result=execute_question(row,actor,retriever,binary,run,config,settings['question_token_budget'])
        results.append(result);write_json(out/'results.json',results)
        if paired:
            other=execute_question(row,actor,paired_retriever,binary,paired_run,paired_config,
                settings['question_token_budget'],compilation_source_run=run)
            paired_results.append(other);write_json(paired_out/'results.json',paired_results)
            print(json.dumps(dict(event='paired_question',dataset=row['dataset'],question_id=row['question_id'],
                control=result['final_answer'],depth=other['final_answer'],depth_action_changes=other.get('depth_action_changes',0))),flush=True)
        print(json.dumps({k:result.get(k) for k in ('dataset','question_id','variant','status','final_answer','logical_total_tokens','initial_compile_invalid')},ensure_ascii=False),flush=True)
        if stop[0] and len(results)<len(public):raise SystemExit(75)
    write_json(out/'COMPLETE.json',dict(questions=len(results),variant='A',logical_total_tokens=sum(r['logical_total_tokens'] for r in results),
        physical_compiler_tokens=sum(r['physical_compiler_tokens'] for r in results),physical_episode_tokens=sum(r['physical_episode_tokens'] for r in results)))
    if paired:
        write_json(paired_out/'COMPLETE.json',dict(questions=len(paired_results),variant='A',
            logical_total_tokens=sum(r['logical_total_tokens'] for r in paired_results),
            physical_compiler_tokens=sum(r['physical_compiler_tokens'] for r in paired_results),
            physical_episode_tokens=sum(r['physical_episode_tokens'] for r in paired_results)))


if __name__=='__main__':main()
