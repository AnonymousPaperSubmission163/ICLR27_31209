"""Source-preserving numeric values, including ranks, fractions and percentages."""
import re
import calendar
from datetime import datetime
from decimal import Decimal
from route_planned_rag.logic_control.core import quantity as base_quantity
from route_planned_rag.indexed.schema import parse_date


def date_interval(value):
    parsed=parse_date(value)
    if parsed:
        date,precision=parsed
        return dict(lower=date,upper=datetime(date.year,12,31) if precision=='year' else date,precision=precision)
    s=value.strip()
    for fmt in ('%B %Y','%b %Y','%b. %Y','%Y-%m'):
        try:
            date=datetime.strptime(s,fmt)
            return dict(lower=date,upper=datetime(date.year,date.month,calendar.monthrange(date.year,date.month)[1]),precision='month')
        except ValueError:pass
    century=re.fullmatch(r'(?:the )?(?:(early|mid|late)[ -])?(\d{1,2})(?:st|nd|rd|th) century',s,re.I)
    if century and 1<=int(century[2])<=99:
        n=int(century[2])
        return dict(lower=datetime((n-1)*100+1,1,1),upper=datetime(n*100,12,31),precision='qualified_century' if century[1] else 'century')
    interval=re.fullmatch(r'(\d{4})\s*(?:[-–—]|to)\s*(\d{4})',s)
    if interval and 1<=int(interval[1])<=int(interval[2])<=9999:
        return dict(lower=datetime(int(interval[1]),1,1),upper=datetime(int(interval[2]),12,31),precision='year_range')
    return None


def date_bounds(value):
    interval=date_interval(value)
    return (interval['lower'],interval['upper']) if interval else None


def date_witness(value,text):
    from route_planned_rag.indexed.store import value_witness
    if value_witness(value,'date',text):return value_witness(value,'date',text)
    target=date_interval(value)
    if target is None:return None
    months='January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec'
    patterns=[r'\b(?:'+months+r')\.?\s+\d{4}\b',r'\b\d{4}-\d{2}\b',r'\b(?:(?:early|mid|late)[ -])?\d{1,2}(?:st|nd|rd|th) century\b',r'\b\d{4}\s*(?:[-–—]|to)\s*\d{4}\b']
    return next((m.group() for pattern in patterns for m in re.finditer(pattern,text,re.I) if date_interval(m.group())==target),None)


def quantity(value,kind='number'):
    existing=base_quantity(value,kind)
    if existing or kind!='number':return existing
    s=value.strip().casefold().replace(',','')
    magnitude=re.fullmatch(r'(?:(at least|at most|more than|less than|over|under) )?([\d.]+) (thousand|million|billion)',s)
    if magnitude:
        amount=Decimal(magnitude[2])*{'thousand':1000,'million':1000000,'billion':1000000000}[magnitude[3]]
        result=base_quantity(((magnitude[1]+' ') if magnitude[1] else '')+format(amount,'f'))
        if result:return dict(result,rule='explicit_count_magnitude')
    ordinal=re.fullmatch(r'(\d+)(?:st|nd|rd|th)',s)
    if ordinal:return dict(base_quantity(ordinal[1]),rule='explicit_ordinal_rank')
    fractions={'half':(1,2),'one half':(1,2),'a half':(1,2),'one third':(1,3),'two thirds':(2,3),
               'a third':(1,3),'one quarter':(1,4),'a quarter':(1,4),'three quarters':(3,4)}
    clean=s.replace('-',' ')
    fraction=fractions.get(clean)
    ratio=re.fullmatch(r'(\d+)\s*/\s*(\d+)',s)
    if ratio and int(ratio[2]):fraction=(int(ratio[1]),int(ratio[2]))
    if fraction:
        amount=str(Decimal(fraction[0])/Decimal(fraction[1]))
        return dict(lower=amount,upper=amount,lower_open=False,upper_open=False,unit='ratio',rule='explicit_fraction')
    percent=re.fullmatch(r'([\d.]+)(?:\s*%?\s*(?:[-–—]|to)\s*([\d.]+))?\s*(?:%|percent|per cent)',s)
    if percent:
        lo,hi=Decimal(percent[1])/100,Decimal(percent[2] or percent[1])/100
        if lo<=hi:return dict(lower=str(lo),upper=str(hi),lower_open=False,upper_open=False,unit='ratio',rule='explicit_percentage')
    return None


def numeric_witness(value,text):
    target=quantity(value)
    if target is None:return None
    expressions=re.finditer(r'(?<![\w.])(?:(?:at least|at most|more than|less than|over|under|about|approximately|around|estimated at)\s+)?(?:\d+(?:\.\d+)?(?:\s*%?\s*(?:[-–—]|to)\s*\d+(?:\.\d+)?)?\s*(?:%|percent|per cent)|\d+/\d+|\d+(?:st|nd|rd|th)|\d[\d,]*(?:\.\d+)?(?:\s+(?:thousand|million|billion))?|one[- ]third|two[- ]thirds|three[- ]quarters|one[- ]quarter|one[- ]half|half|a quarter|a third|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)(?!\w|\.\d)',text,re.I)
    keys=('lower','upper','lower_open','upper_open','unit')
    for match in expressions:
        parsed=quantity(match.group())
        if parsed and all((Decimal(parsed[k])==Decimal(target[k]) if k in ('lower','upper') and parsed[k] is not None and target[k] is not None else parsed[k]==target[k]) for k in keys):return match.group()
    return None
