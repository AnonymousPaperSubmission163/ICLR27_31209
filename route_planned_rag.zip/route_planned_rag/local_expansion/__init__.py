"""Fixed-rule local acquisition expansion; immutable original Program."""
VERSION = 'local-expansion-ab-v2'
