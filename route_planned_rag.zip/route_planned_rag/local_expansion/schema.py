"""Question-only typed Program, including boolean and comparison projections."""
import re
from typing import Literal
from pydantic import Field
from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.method.schema import Requirement as BaseRequirement, words, normalized
from route_planned_rag.indexed.schema import explicit_in_question as _explicit_in_question

def title_spelling(value):
    # Common title spelling, never fuzzy editing of a person's proper name.
    return re.sub(r'\bemporer\b','emperor',value,flags=re.I)

def explicit_in_question(value,question):
    return _explicit_in_question(value,question) or _explicit_in_question(title_spelling(value),title_spelling(question))

def entity_literal(value):
    """Remove grammatical possessives at the END, never inside a work's name."""
    return title_spelling(re.sub(r"['’]s$", '', value.strip().rstrip('?,')).strip())

class Requirement(BaseRequirement):
    object_level: Literal['city','state','country','locality'] | None = None

class Goal(Strict):
    op: Literal['select','greater','earlier','later','same','verify'] = 'select'
    variable: str | None = None
    left: str | None = None
    right: str | None = None
    left_answer: str | None = None
    right_answer: str | None = None
    count: int | None = Field(default=None,ge=1,le=30)
    output_mode: Literal['single','set'] = 'single'

class Program(Strict):
    interpretation: str = Field(default='',max_length=320)
    anchors: list[str] = Field(default_factory=list,max_length=16)
    needs: list[Requirement] = Field(min_length=1,max_length=12)
    goal: Goal
    choices: dict[str,list[str]] = Field(default_factory=dict)
    unrepresented: list[str] = Field(default_factory=list)

    def checked(self,question):
        variable=lambda x:bool(re.fullmatch(r'\?[a-z][a-z0-9_]{0,30}',x))
        connected=set(self.choices);variables=set(self.choices);types={};levels={};links=[]
        for v,values in self.choices.items():
            if not variable(v) or not 1<=len(values)<=8:raise ValueError('invalid question-defined finite domain')
            if any(not explicit_in_question(x,question) for x in values):raise ValueError('finite choices must come from question')
        for n in self.needs:
            if not n.r.strip() or not n.span.strip() or normalized(n.span) not in normalized(question):
                raise ValueError('every relation must cite an exact question span')
            local=set()
            for t in (n.s,n.o):
                if t.startswith('?'):
                    if not variable(t):raise ValueError('malformed variable '+t)
                    variables.add(t);local.add(t)
                elif t not in ('true','false') and not explicit_in_question(t,question):
                    raise ValueError('constant is not in the question: '+t)
                elif re.search(r"['’]s$",t):
                    raise ValueError('external possessive is not part of an entity name: '+t)
                elif t.casefold() in ('that','which','what','who','it','he','she','they','them'):
                    raise ValueError('pronoun/reference must use a connected variable, not an entity literal: '+t)
            if any(not t.startswith('?') and t not in ('true','false') for t in (n.s,n.o)):connected.update(local)
            links.append(local)
            if n.o.startswith('?'):
                previous=types.get(n.o,'entity')
                if previous not in ('entity',n.kind) and n.kind!='entity':raise ValueError('incompatible types for '+n.o)
                if n.kind!='entity':types[n.o]=n.kind
                if n.object_level:
                    if n.o in levels and levels[n.o]!=n.object_level:raise ValueError('different geographic levels require different variables: '+n.o)
                    levels[n.o]=n.object_level
            if n.object_level and n.kind!='place':raise ValueError('geographic levels require place type')
            if n.scope and not explicit_in_question(n.scope,question):raise ValueError('scope must be explicit in question')
        for _ in links:
            for link in links:
                if connected & link:connected.update(link)
        if not variables<=connected:raise ValueError('all unknowns need a path to a question anchor')
        for n in self.needs:
            if types.get(n.s) in ('date','number','frequency'):raise ValueError('a scalar cannot be used as an entity subject')
            if n.s.startswith('?') and types.get(n.s,'entity')!='entity' and n.subject_kind not in ('entity',types[n.s]):
                raise ValueError('incompatible subject type for '+n.s+': '+n.subject_kind+' versus '+types[n.s])
        g=self.goal
        if g.op=='select':
            if g.variable not in variables or g.left or g.right:raise ValueError('select requires one bound output variable')
            if re.match(r'(?:(?:By )?How (?:many|much)|Who many)\b',question,re.I) and types.get(g.variable)!='number':
                raise ValueError('quantity question must return a source-supported number, not a listed entity')
            if re.match(r'When\b',question,re.I) and types.get(g.variable)!='date':
                raise ValueError('when question must return a source-supported date, not an intermediate entity')
        elif g.op=='verify':
            if g.variable or g.left or g.right:raise ValueError('verify checks the original conjunction and returns yes/no')
        else:
            if g.variable or g.left not in variables or g.right not in variables or g.left==g.right:
                raise ValueError('comparison requires distinct scalar/entity inputs')
            for t in (g.left_answer,g.right_answer):
                if t and t.startswith('?') and t not in variables:raise ValueError('comparison answer must be bound')
                if t and not t.startswith('?') and not explicit_in_question(t,question):raise ValueError('comparison answer must come from question')
            if g.op in ('earlier','later') and any(types.get(v)!='date' for v in (g.left,g.right)):
                raise ValueError('temporal comparison inputs must be dates')
            if g.op=='greater' and any(types.get(v)!='number' for v in (g.left,g.right)):
                raise ValueError('quantity comparison inputs must be source-supported numbers, not category names or incomplete lists')
            if g.op in ('greater','earlier','later') and not (g.left_answer and g.right_answer):
                raise ValueError('comparison must explicitly identify both possible answer entities')
        executable=' '.join(t for n in self.needs for t in (n.s,n.o,n.r,n.scope or '') if not t.startswith('?'))
        executable+=' '+' '.join(v for values in self.choices.values() for v in values)
        for anchor in self.anchors:
            if not explicit_in_question(anchor,question):raise ValueError('anchor must come from question')
            if normalized(entity_literal(anchor)) not in normalized(executable):raise ValueError('question anchor is not executable: '+anchor)
        if self.unrepresented:raise ValueError('conditions omitted: '+repr(self.unrepresented))
        return self

def question_operator(question):
    q=question.strip()
    comparison=bool(re.search(r'\bor\b|\bbetween\b.+\band\b',q,re.I))
    if comparison and re.search(r'\b(?:earlier|older|oldest)\b|\b(?:born|formed|founded|established|built|released|came out) first\b',q,re.I):return 'earlier'
    if comparison and re.search(r'\b(?:later|younger|youngest)\b|\bmore recently\b',q,re.I):return 'later'
    if re.search(r'\b(?:more|greater|larger|higher|taller|longer|bigger|most)\b',q,re.I) and re.search(r'\bor\b',q,re.I):return 'greater'
    if re.match(r'^(?:Is|Are|Was|Were|Do|Does|Did|Has|Have|Can)\b',q,re.I):
        return 'same' if re.search(r'\bsame\b',q,re.I) else 'verify'
    return 'select'

def output_mode(question,count=None):
    if count and count>1:return 'set'
    if re.search(r'\b(?:have in common|occupations? .*share|shared occupations?)\b',question,re.I):return 'set'
    if re.match(r'^(?:List\b|Name all\b|(?:What|Which|Who) are\b)',question,re.I):return 'set'
    noun=re.match(r'^(?:What|Which)\s+(\w+)\b',question,re.I)
    if noun and noun[1].casefold().endswith('s') and not noun[1].casefold().endswith('ss') and noun[1].casefold() not in ('is','was','news','species'):return 'set'
    return 'single'
