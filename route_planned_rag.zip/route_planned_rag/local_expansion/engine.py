"""One existing planner, immutable Program, and gated depth-one Γ supports."""
import time
import re
from pathlib import Path
from route_planned_rag.method.engine import DEFAULTS as V3_DEFAULTS
from route_planned_rag.method.schema import signature as digest, words, STOP
from .compiler import contract
from route_planned_rag.prototype.logic import substitute, unify, key
from route_planned_rag.prototype.prover import write_json
from .store import EvidenceStore
from .acquisition_io import AcquisitionIO
from .reader import slot_schema, slots_to_reading, SLOT_PROMPT
from .verification import PROMPT as VERIFY_PROMPT, schema_for, payload_for, apply_verdicts, cache_keys
from .planner import plan
from .answering import reserve_terminal, generate_terminal, answer_choices, answer_contract

DEFAULTS = dict(V3_DEFAULTS, allow_auxiliary=False, global_read_priority=True, planning_policy='remaining_cost',
                max_auxiliary=12,max_rules=24,max_depth=1,max_routes=128,max_derived=1024,
                max_supports=4096,max_rule_matches=20000,rule_cpu_seconds=2.,
                answer_policy='certified_only',terminal_token_reserve=6000,
                terminal_first_call_cap=5000,terminal_output_tokens=512,terminal_max_calls=2)

def executed_auxiliary_actions(events,original_count):
    """Count actual acquisition starts, including shared reads of active slots."""
    result=[]
    for event in events:
        action=event.get('action',{})
        if event['kind']=='reader_started':
            auxiliary=[n for n in event['active_slots'] if n>=original_count]
        elif event['kind']=='retrieval_started':
            auxiliary=[action['node']] if action['node']>=original_count else []
        else:continue
        if auxiliary:result.append(dict(action,step=event['step'],auxiliary_nodes=auxiliary,selected_goal_is_auxiliary=action['node']>=original_count))
    return result

class LocalExpansionEngine(AcquisitionIO):
    store_class = EvidenceStore
    def plan_actions(self):
        return plan(self)

    def reader_nodes(self, action):
        return self.store.active_nodes

    def __init__(self,question,program,client,retriever,prover,directory,config=None):
        self.question,self.program=question,program
        self.coverage=contract(question,program)
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        if (self.directory/'checkpoint.json').exists():raise ValueError('immutable episode exists')
        self.config=dict(DEFAULTS,**(config or {}))
        if self.config['planning_policy'] not in ('remaining_cost','reasoning_depth','prover_depth'):
            raise ValueError('unknown planning_policy')
        if self.config['planning_policy'] in ('reasoning_depth','prover_depth') and self.config['allow_auxiliary']:
            raise ValueError('reasoning_depth currently requires A: auxiliary acquisition disabled')
        self.client,self.retriever,self.prover=client,retriever,prover
        if self.config['answer_policy'] not in ('certified_only','best_effort'):
            raise ValueError('unknown_answer_policy')
        reserve_terminal(client,self.config)
        limits={k:self.config[k] for k in ('max_auxiliary','max_rules','max_depth','max_routes','max_derived','max_supports','max_rule_matches','rule_cpu_seconds')}
        self.store=self.store_class(question,program,self.directory/'relations.sqlite',self.config['max_bindings'],limits=limits)
        self.started=time.perf_counter()
        self.state=dict(plan_hash=digest(program),retrieval_calls=0,reader_calls=0,step=0,reads={},queries=[],retrieval_attempts={},query_usage=[],events=[],last_candidate=None,reader_errors=[],proof_attempts={},proofs=[],run_seconds=0.,read_cache={},gap_history={},expansion_attempts=[],triggered_goals=[],matched_rule_ids=[],auxiliary_actions_executed=[],no_progress_reads=0,read_outcomes=[])
        self.event('initialized')

    def save(self):
        assert digest(self.program)==self.state['plan_hash']
        self.store.sync()
        write_json(self.directory/'checkpoint.json',self.state)
        write_json(self.directory/'events.json',self.state['events'])
        write_json(self.directory/'program.json',self.program.model_dump())
        write_json(self.directory/'evidence_state.json',self.store.snapshot())

    def event(self,kind,**data):
        index=len(self.state['events'])
        snapshot=self.directory/'states'/f'{index:04d}.json'
        write_json(snapshot,dict(self.store.snapshot(),budget={k:self.state[k] for k in ('retrieval_calls','reader_calls','step')},charged_tokens=getattr(self.client,'charged',None)))
        self.state['events'].append(dict(index=index,step=self.state['step'],kind=kind,snapshot=str(snapshot.relative_to(self.directory)),**data))
        self.save()

    def read_signature(self,request,eid):
        # Same-input attempts are bounded, while changed relevant inputs may
        # be reread under unchanged global reader/token budgets.
        return digest([eid,self.store.plan_hash,self.cache_key(request,eid)])

    def cache_key(self,request,eid):
        source=self.store.evidence[eid]
        target=request['target']
        # Reader leaves variable values open, even when the planner is testing
        # one value. Such a value-only change is identical reader input.
        matching=[i for i in self.store.active_nodes if self.store.pattern(i).predicate==target['predicate']]
        if matching and all(self.store.catalog[i].o.startswith('?') for i in matching):
            target=dict(target,arguments=[target['arguments'][0],dict(kind='variable',name='reader_value',entity_type='entity')])
        conflicts=[(r['s'],r['o'],r['status']) for r in self.store.rows.values() if r.get('evidence_id')==eid and r['status'] in ('conflicted','invalid')]
        from .admission import contains
        text=source['source_metadata']['title']+' '+source['original_text']
        constants={t['name'] for t in target['arguments'] if t['kind']=='constant'}
        aliases={a:d for a,d in self.store.aliases.items() if contains(a,text) or self.store.term(a).name in constants}
        from .semantics import identity_owners
        contexts=[identity_owners(self.store,i) for i in matching]
        return digest([target,source['original_text'],source['source_metadata'],source.get('withdrawn'),aliases,conflicts,self.store.active_nodes,contexts])

    def read_option(self,request):
        # Reuse valid parsed slot results only. A parse failure never fills this
        # cache. An unfiltered result also covers a later bound subset; changed
        # source/alias/status/catalog still permits a re-read.
        saved=self.state['reads']
        self.state['reads']=dict(saved)
        try:
            for eid in self.store.evidence:
                if self.cache_key(request,eid) in self.state['read_cache']:
                    self.state['reads'][self.read_signature(request,eid)]=self.config['max_attempts']
            return super().read_option(request)
        finally:
            self.state['reads']=saved

    def requests(self,nodes,binding):
        requests=super().requests(nodes,binding)
        for node,request in zip(nodes,requests):
            if node>=len(self.program.needs):
                conditions=sorted({r.reason for r in self.store.acquisition.rules if node in r.body})
                request['condition'] += ' Fixed-rule applicability: ' + ' '.join(conditions)
        return requests

    def reading_payload(self,evidence,nodes,binding,retry=False):
        # Base evidence reader prompt/admission is unchanged. Only activated
        # bodies, not every formula in Γ, enter requests.
        return super().reading_payload(evidence,nodes,binding,retry)

    def source_relevant(self,request,eid):
        anchor=request.get('anchor') or ''
        neighbors=[t for n in self.program.needs for t in (n.s,n.o) if not t.startswith('?') and t not in ('true','false')]
        return self.store.source_mentions(anchor,eid) or any(self.store.source_mentions(t,eid) for t in neighbors)

    def relevant_bindings(self,node,binding):
        variables={t[1:] for t in (self.store.catalog[node].s,self.store.catalog[node].o) if t.startswith('?')}
        fixed={k:self.store.term(v) for k,v in binding.items()}
        results=set()
        for row in self.store.joins(partial=True):
            if any(k in row['binding'] and row['binding'][k]!=v for k,v in fixed.items()):continue
            projected={k:v for k,v in row['binding'].items() if k in variables}
            if projected:results.add(digest(projected))
        return results

    def observable(self):
        accepted={digest(self.store.row_atom(r)) for r in self.store.rows.values() if r['status']=='accepted'}
        bindings={digest(row['binding']) for row in self.store.joins(partial=True) if row['binding']}
        satisfied={str(i)+':'+digest(h['binding']) for i in range(len(self.program.needs)) for h in self.store.match(self.store.pattern(i))}
        return accepted,bindings,satisfied

    def gap_key(self,request):
        return digest([request['node'],request['target'],self.store.catalog[request['node']].scope])

    def history(self,action):
        gap=self.gap_key(action)
        return self.state['gap_history'].setdefault(gap,dict(node=action['node'],target=action['target'],binding=action['binding'],retrievals=0,reads=0,pending_sources=[],last_read_no_progress=False,last_read_outcome=None))

    def retrieve(self,action):
        if hasattr(self.client,'preflight'):
            self.client.preflight(SLOT_PROMPT,self.reading_payload([],self.store.active_nodes,{}),self.config['reader_output_tokens'])
        self.state['retrieval_calls']+=1
        self.state['queries'].append(action['query'])
        self.state['retrieval_attempts'][action['id']]=self.state['retrieval_attempts'].get(action['id'],0)+1
        self.event('retrieval_started',action=action)
        old=set(self.store.evidence)
        if hasattr(self.retriever,'search'):
            need=self.store.catalog[action['node']]
            evidence,usage=self.retriever.search(action['query'],self.config['retrieval_top_k'],anchor=action['anchor'],subject_type=need.subject_kind)
        else:evidence,usage=self.retriever(action['query'],self.config['retrieval_top_k'])
        self.store.observe(evidence)
        new=sorted(set(self.store.evidence)-old)
        h=self.history(action);h['retrievals']+=1
        # Every returned source not already validly read for this gap is pending,
        # including re-retrieved originals. New originals are never 'no progress'.
        h['pending_sources']=sorted(set(h['pending_sources'])|{e['evidence_id'] for e in evidence if self.source_relevant(action,e['evidence_id']) and self.cache_key(action,e['evidence_id']) not in self.state['read_cache']})
        self.state['query_usage'].append(usage)
        self.event('retrieval_completed',action=action,source_ids=[e['evidence_id'] for e in evidence],new_source_ids=new,pending_sources=h['pending_sources'],usage=usage)

    def read(self,action):
        evidence=[self.store.evidence[eid] for eid in action['source_ids']]
        nodes=self.reader_nodes(action)
        payload=self.reading_payload(evidence,nodes,{},retry=any(self.state['reads'].get(self.read_signature(action,eid),0) for eid in action['source_ids']))
        selected=self.requests([action['node']],action['binding'])[0]
        payload['requests'][nodes.index(action['node'])]=selected
        maximum=self.config['reader_output_tokens']
        if hasattr(self.client,'preflight'):self.client.preflight(SLOT_PROMPT,payload,maximum)
        before=self.observable();old_conflicts={f for f,r in self.store.rows.items() if r['status']=='conflicted'}
        selected_before={digest(h['binding']) for h in self.store.match(self.store.pattern(action['node']),{k:self.store.term(v) for k,v in action['binding'].items()})}
        gap_bindings_before=self.relevant_bindings(action['node'],action['binding'])
        self.state['reader_calls']+=1
        for node in nodes:
            target=action['target'] if node==action['node'] else self.store.pattern(node).model_dump()
            for eid in action['source_ids']:
                signature=self.read_signature(dict(target=target),eid)
                self.state['reads'][signature]=self.state['reads'].get(signature,0)+1
        cache_inputs={(node,eid):self.cache_key(dict(target=action['target'] if node==action['node'] else self.store.pattern(node).model_dump()),eid) for node in nodes for eid in action['source_ids']}
        self.event('reader_started',action=action,active_slots=nodes)
        h=self.history(action);h['reads']+=1
        try:
            raw=self.client.ask('reader',slot_schema(nodes,evidence,payload['requests']),SLOT_PROMPT,payload,maximum=maximum)
            reading,unknown=slots_to_reading(raw,evidence)
            self.store.rejected.extend(unknown)
            extraction_call=self.client.calls[-1]['call_id']
            verification_records=[]
            from .semantics import source_semantic_rejections
            kept=[]
            for row in reading.rows:
                reasons=source_semantic_rejections(self.store,row,self.store.catalog[row.node],row.quote,self.store.evidence[row.evidence_id])
                if reasons:self.store.rejected.append(dict(row.model_dump(),status='rejected',reason=reasons[0],reasons=reasons,extraction_call=extraction_call))
                else:kept.append(row)
            reading=reading.model_copy(update={'rows':kept})
            if reading.rows:
                verification_payload=payload_for(reading,self.store)
                checked_candidates=verification_payload['candidates']
                keys=cache_keys(verification_payload);cache=self.state.setdefault('verification_cache',{})
                pending=[i for i,k in enumerate(keys) if k not in cache]
                if pending:
                    if self.state['reader_calls']>=self.acquisition_reader_limit:
                        raise ValueError('reader_budget_exhausted')
                    pending_reading=reading.model_copy(update={'rows':[reading.rows[i] for i in pending]})
                    verification_payload=payload_for(pending_reading,self.store)
                    # Each verdict has one <=240-character explanation. Reserve
                    # output for the actual batch, under the existing 2000 cap,
                    # rather than blocking a single short check with 2000 tokens.
                    verification_maximum=min(maximum,512*len(pending))
                    if hasattr(self.client,'preflight'):self.client.preflight(VERIFY_PROMPT,verification_payload,verification_maximum)
                    self.state['reader_calls']+=1
                    self.state['verification_calls']=self.state.get('verification_calls',0)+1
                    self.event('reader_verification_started',candidate_count=len(pending),extraction_call=extraction_call)
                    verdicts=self.client.ask('reader_verification',schema_for(len(pending)),VERIFY_PROMPT,verification_payload,maximum=verification_maximum)
                    for j,i in enumerate(pending):cache[keys[i]]=dict(verdicts.model_dump()['C'+str(j)],call_id=self.client.calls[-1]['call_id'])
                verdicts=schema_for(len(reading.rows)).model_validate({'C'+str(i):{k:v for k,v in cache[c].items() if k!='call_id'} for i,c in enumerate(keys)})
                call_ids={'C'+str(i):cache[c]['call_id'] for i,c in enumerate(keys)}
                reading,rejected,verification_records=apply_verdicts(reading,verdicts,call_ids)
                for i,record in enumerate(verification_records):record['checked_value']=checked_candidates[i]['value']
                self.store.rejected.extend(rejected)
                self.event('reader_verification_completed',records=verification_records,cached_candidates=len(keys)-len(pending))
            ids=self.store.propose(reading,extraction_call)
            for fid in ids:
                row=self.store.rows[fid]
                row['semantic_verification']=[r for r in verification_records if r['node']==row['node'] and r['s']==row['original_extraction']['s'] and (r['o']==row['original_extraction']['o'] or row['original_extraction']['o'] in r['o'].split('-')) and r['evidence_id']==row['evidence_id']]
            closure=self.store.recompute()
            if closure and closure['error']:raise ValueError(closure['error'])
            after=self.observable()
            added=[sorted(a-b) for a,b in zip(after,before)]
            conflicts=sorted({f for f,r in self.store.rows.items() if r['status']=='conflicted'}-old_conflicts)
            outcome='conflict' if conflicts else ('supported' if any(added) else 'legal_no_support')
            no_progress=not any(added)
            self.state['no_progress_reads']+=int(no_progress)
            # Bindings to unrelated candidates do not count as progress for g.
            selected_after={digest(m['binding']) for m in self.store.match(self.store.pattern(action['node']),{k:self.store.term(v) for k,v in action['binding'].items()})}
            h['last_read_no_progress']=not bool(selected_after-selected_before or self.relevant_bindings(action['node'],action['binding'])-gap_bindings_before)
            h['last_read_outcome']=outcome
            for node in nodes:
                target=action['target'] if node==action['node'] else self.store.pattern(node).model_dump()
                for eid in action['source_ids']:
                    self.state['read_cache'][cache_inputs[node,eid]]=dict(call_id=self.client.calls[-1]['call_id'],outcome=outcome)
            for gap,history in self.state['gap_history'].items():
                # Unbound slots cover every candidate; bound slots cover only
                # their exact binding. Others remain pending.
                if history['node'] in nodes:
                    covered={eid for eid in action['source_ids'] if history['node']!=action['node'] or self.cache_key(history,eid)==self.cache_key(action,eid) or not action['binding']}
                    history['pending_sources']=[eid for eid in history['pending_sources'] if eid not in covered]
            self.state['read_outcomes'].append(dict(outcome=outcome,no_progress=no_progress))
            self.event('facts_updated',action=action,admitted=ids,new_fact_atoms=added[0],new_bindings=added[1],new_satisfied_requirements=added[2],conflict_ids=conflicts,outcome=outcome,no_progress=no_progress,missing=reading.missing,unknown=unknown)
        except (ValueError,KeyError,IndexError,RuntimeError) as exc:
            if 'budget_exhausted' in str(exc):
                h['last_read_no_progress']=False;h['last_read_outcome']='budget_exhausted'
                self.state['read_outcomes'].append(dict(outcome='budget_exhausted',error=repr(exc)))
                self.event('reader_stopped',action=action,outcome='budget_exhausted',error=repr(exc))
                raise
            if isinstance(exc,RuntimeError):
                h['last_read_no_progress']=False;h['last_read_outcome']='infrastructure_error'
                self.state['reader_errors'].append(repr(exc))
                self.state['read_outcomes'].append(dict(outcome='infrastructure_error',error=repr(exc)))
                self.event('reader_failed',action=action,outcome='infrastructure_error',error=repr(exc))
                raise
            h['last_read_no_progress']=False;h['last_read_outcome']='parse_failure'
            self.state['reader_errors'].append(repr(exc));self.state['read_outcomes'].append(dict(outcome='parse_failure',error=repr(exc)))
            self.event('reader_failed',action=action,outcome='parse_failure',error=repr(exc))
            if 'budget_exhausted' in str(exc) or 'rule_' in str(exc):raise

    def maybe_expand(self,candidates):
        # Inspect concrete missing instances from the same planner support set.
        for candidate in candidates:
            for missing in candidate['missing']:
                node=missing['node']
                if node>=len(self.program.needs):continue
                target=missing['pattern']
                request=dict(node=node,target=target,binding=candidate['binding'])
                gap=self.gap_key(request)
                history=self.state['gap_history'].get(gap)
                if not history or not history['retrievals'] or not history['reads'] or not history['last_read_no_progress'] or history['last_read_outcome']=='parse_failure':continue
                if history['pending_sources']:continue
                typed={k:self.store.term(v) for k,v in candidate['binding'].items()}
                if self.store.match(self.store.pattern(node),typed):continue
                # Exhaust all currently executable relevant originals before
                # interpreting a direct read as stalled acquisition.
                atom=substitute(self.store.pattern(node),typed)
                constants=[self.store.names[t.name] if t.kind=='constant' else None for t in atom.arguments]
                anchor=constants[0] or (constants[1] if constants[1] not in ('true','false') else None)
                full=dict(request,id=digest(atom),anchor=anchor)
                if self.read_option(full):continue
                if gap not in self.state['triggered_goals']:
                    self.state['triggered_goals'].append(gap)
                matches=[r for r in self.store.acquisition.rules if r.head==node and r.valid]
                self.state['matched_rule_ids']=sorted(set(self.state['matched_rule_ids'])|{r.template for r in matches})
                if not self.config['allow_auxiliary'] or gap in self.state['expansion_attempts']:continue
                self.state['expansion_attempts'].append(gap)
                if not matches:
                    self.event('expansion_unsupported',parent_goal_id='N'+str(node),binding=candidate['binding'],goal_key=gap)
                    continue
                ranked=[]
                for rule in matches:
                    costs={}
                    for child in rule.body:
                        pattern=substitute(self.store.pattern(child),typed)
                        if self.store.match(pattern):continue
                        names=[self.store.names[t.name] if t.kind=='constant' else None for t in pattern.arguments]
                        child_anchor=names[0] or (names[1] if names[1] not in ('true','false') else None)
                        req=dict(id=digest(pattern),node=child,target=pattern.model_dump(),binding=candidate['binding'],anchor=child_anchor)
                        option=(self.read_option(req) or self.retrieval_option(req)) if child_anchor else None
                        costs[digest(pattern)]=option['cost'] if option else self.config['retrieve_cost']+self.config['read_cost']
                    ranked.append((sum(costs.values()),rule.id,rule))
                _,_,rule=min(ranked,key=lambda x:(x[0],x[1]))
                try:activation=self.store.activate(rule,candidate['binding'],gap)
                except ValueError as exc:
                    self.event('expansion_budget_blocked',error=str(exc),goal_key=gap)
                    continue
                self.event('auxiliary_activated',activation=activation,matched_rule_ids=[r.template for r in matches],estimated_remaining_cost=min(ranked,key=lambda x:(x[0],x[1]))[0])
                return True
        return False

    def terminal(self):
        closure=self.store.recompute()
        if closure:
            self.event('closure_updated',**closure)
            if closure['error']:raise ValueError(closure['error'])
        candidates=self.store.candidates();selected={}
        for c in sorted(candidates,key=lambda c:(len(c['facts']),digest(c))):selected.setdefault(c['term'].name,c)
        if getattr(self.program.goal,'output_mode',None) in ('single','set'):
            # A singular request returns one complete supported answer. Prefer
            # the earliest explicit mention across its supporting originals;
            # hash order is not a meaningful choice among equally valid answers.
            def source_rank(candidate):
                positions=[];value=candidate['value'].casefold()
                for i,need in enumerate(self.program.needs):
                    if need.o!=self.program.goal.variable:continue
                    alternatives=[]
                    # Proof enumeration retains one support per binding. Use
                    # all compatible supports for display priority so an extra
                    # later citation cannot demote the same supported answer.
                    for hit in self.store.match(self.store.pattern(i),candidate['binding']):
                        for fid in self.store.leaf_facts(hit['facts']):
                            row=self.store.rows[fid]
                            if self.store.canonical(row['o'])!=self.store.canonical(candidate['value']):continue
                            source=self.store.evidence[row['evidence_id']]
                            original=source['original_text'].casefold();position=original.find(value)
                            title_match=self.store.canonical(source['source_metadata']['title'])==self.store.canonical(row['s'])
                            if position>=0:alternatives.append((not title_match,position/max(1,len(original))))
                    if alternatives:positions.append(min(alternatives))
                return (max(positions,default=(True,1.)),sum(p[1] for p in positions)/max(1,len(positions)),len(candidate['facts']),candidate['value'].casefold())
            ordered=sorted(selected.values(),key=source_rank)
            if self.program.goal.count:ordered=ordered[:self.program.goal.count]
            elif self.program.goal.output_mode=='single':ordered=ordered[:1]
            selected={c['term'].name:c for c in ordered}
        answers=[]
        for c in selected.values():
            signature=digest([c['binding'],c['facts'],self.store.alias_version,self.store.plan_hash,self.store.derivations])
            cached=next((r['certificate'] for r in self.state['proofs'] if r['signature']==signature and r['certificate']['valid']),None)
            if cached is None:
                if self.state['proof_attempts'].get(signature,0)>=2:continue
                self.state['proof_attempts'][signature]=self.state['proof_attempts'].get(signature,0)+1
                self.event('proof_started',fact_ids=c['facts'],value=c['value'])
                cached=self.store.prove(c,self.prover)
                self.event('proof_finished',record=self.prover.records[-1] if self.prover.records else None)
                if cached:self.state['proofs'].append(dict(signature=signature,certificate=cached))
            if cached:answers.append(dict(value=c['value'],fact_ids=c['facts'],leaf_fact_ids=cached['leaf_fact_ids'],proof_id=cached['proof_id'],computation=c['computation'],proof_uses_auxiliary=cached['proof_uses_auxiliary'],answer_depends_on_expansion=cached['answer_depends_on_expansion'],derived_supports=cached['derived_supports'],reasoning_depth=cached.get('reasoning_depth')))
        if self.program.goal.count is not None and len(answers)!=self.program.goal.count:return []
        return answers

    def run(self):
        answers,status,error=[],'unknown',None
        try:
            while True:
                answers=self.terminal()
                if answers:status='proved';break
                if self.state['step']>=self.config['max_steps']:status='step_budget_exhausted';break
                candidates,action=self.plan_actions()
                self.event('support_plan',candidates=candidates,selected=action,enumeration_truncated=self.store.truncated)
                if self.maybe_expand(candidates):continue
                if not action:
                    status='reader_budget_exhausted' if self.state['reader_calls']>=self.acquisition_reader_limit else 'retrieval_budget_exhausted' if self.state['retrieval_calls']>=self.config['max_retrievals'] else 'conflicted' if any(r['status']=='conflicted' for r in self.store.rows.values()) else 'unknown_no_executable_action'
                    break
                self.state['step']+=1
                if action['mode']=='read':self.read(action)
                else:self.retrieve(action)
        except (ValueError,KeyError,RuntimeError,OSError) as exc:
            error=repr(exc);budget_error=re.search(r'\b[a-z_]+_budget_exhausted\b',str(exc))
            status=budget_error.group() if budget_error else 'execution_error'
        acquisition_status=status
        terminal=dict(certified_answer=', '.join(dict.fromkeys(a['value'] for a in answers)),
                      proof_status='proved' if answers else 'unverified',terminal_calls=0,
                      terminal_tokens=0,terminal_prediction=None,unresolved_goals=[])
        if not answers and self.config['answer_policy']=='best_effort':
            # Describe unresolved original slots under the best current partial binding.
            candidates,_=self.plan_actions()
            candidate=candidates[0] if candidates else None
            # The planner already preserves typed scalar bindings. Do not
            # reconstruct dates/numbers as untyped entity constants here.
            missing={m['node'] for m in candidate['missing']} if candidate else set(range(len(self.program.needs)))
            missing|={r.head for r in self.store.acquisition.rules if any(n in missing for n in r.body)}
            unresolved=[dict(goal_id='N'+str(i),**n.model_dump()) for i,n in enumerate(self.program.needs) if i in missing]
            facts=[dict(fact_id=fid,node=r['node'],subject=r['s'],relation=self.store.catalog[r['node']].r,
                        value=r['o'],evidence_id=r.get('evidence_id'),fact_type=r.get('fact_type'))
                   for fid,r in self.store.rows.items() if r['status']=='accepted']
            terminal=generate_terminal(self.question,self.client,self.config,self.state,
                                       list(self.store.evidence.values()),facts,unresolved,event=self.event,
                                       choices=answer_choices(self.question,self.program),
                                       contract=answer_contract(self.program,
                                           [f for f in facts if candidate and f['fact_id'] in candidate['fact_ids']],
                                           candidate['binding'] if candidate else {}))
            terminal['terminal_calls']=self.state.get('terminal_calls',0)
            if terminal['final_answer']:status='best_effort'
        leaves=sorted({f for a in answers for f in a['leaf_fact_ids']})
        self.state['auxiliary_actions_executed']=executed_auxiliary_actions(self.state['events'],len(self.program.needs))
        values=list(dict.fromkeys(a['value'] for a in answers))
        rendered=', '.join(values)
        result=dict(question=self.question,final_answer=rendered,status=status,error=error,answers=answers,
            answer_source='proved_readout' if answers else 'abstain',plan_hash=self.state['plan_hash'],question_contract=self.coverage,
            expansion_triggered=bool(self.state['triggered_goals']),matched_rule_ids=self.state['matched_rule_ids'],
            auxiliary_goals=[dict(node=n,**self.store.catalog[n].model_dump()) for n in self.store.active_nodes if n>=len(self.program.needs)],
            auxiliary_actions_executed=self.state['auxiliary_actions_executed'],trigger_eligible=bool(self.state['triggered_goals']),expansion_activated=bool(self.store.activations),proof_uses_auxiliary=any(a['proof_uses_auxiliary'] for a in answers),answer_depends_on_expansion=any(a['answer_depends_on_expansion'] for a in answers),
            no_progress_reads=self.state['no_progress_reads'],read_outcomes=self.state['read_outcomes'],verification_calls=self.state.get('verification_calls',0),
            failure_category=None if answers else ('budget_exhausted' if 'budget' in acquisition_status else 'infrastructure_error' if acquisition_status=='execution_error' else 'parse_failure' if self.state['reader_errors'] else 'conflict' if acquisition_status=='conflicted' else 'retrieval_or_extraction_unresolved'),
            rule_coverage='matched' if self.state['matched_rule_ids'] else 'unmatched_after_stall' if self.state['triggered_goals'] else 'not_triggered',
            citations=[dict(fact_id=f,evidence_id=self.store.rows[f]['evidence_id'],quote=self.store.rows[f]['quote']) for f in leaves],
            evidence_ids=sorted({self.store.rows[f]['evidence_id'] for f in leaves}),retrieval_calls=self.state['retrieval_calls'],reader_calls=self.state['reader_calls'],model_calls=len(self.client.calls),
            input_tokens=sum(c.get('input_tokens',0) for c in self.client.calls),output_tokens=sum(c.get('output_tokens',0) for c in self.client.calls),
            proof_calls=self.prover.calls,proof_seconds=sum(r['elapsed_seconds'] for r in self.prover.records),
            rule_cpu_seconds=sum(r['cpu_seconds'] for r in self.store.closure_records)+sum(r['rule_cpu_seconds'] for r in self.store.counterfactual_records),counterfactual_checks=len(self.store.counterfactual_records),query_embedding_usage=self.state['query_usage'],seconds=time.perf_counter()-self.started,
            semantic_status='Prover9 verifies observed facts + actual fixed Γ instances + unchanged question conjunction; all translations remain conditional.')
        result.update(terminal,acquisition_status=acquisition_status,answer_policy=self.config['answer_policy'],initial_compile_invalid=False)
        result['planning_policy']=self.config['planning_policy']
        result['reasoning_depth']=[a['reasoning_depth'] for a in answers]
        decisions=getattr(self, 'depth_decisions', [])
        result['depth_decisions']=decisions
        result['depth_action_changes']=sum(d['action_changed'] for d in decisions)
        result['max_certified_planning_depth']=max((d['max_certified_depth'] for d in decisions), default=0)
        if self.config['planning_policy'] in ('reasoning_depth','prover_depth'):
            plans=[e for e in self.state['events'] if e['kind']=='support_plan']
            result['last_reasoning_progress']=(plans[-1]['selected'] or {}).get('reasoning_progress') if plans else None
        self.event('finished',status=status,answer=result['final_answer'])
        write_json(self.directory/'result.json',result);write_json(self.directory/'proofs.json',self.store.certificates)
        return result
