"""Question-derived constraints and local identity checks; no answer knowledge."""
import re


def answer_class(question):
    q=question.strip()
    if re.search(r'\b(?:what|which)\s+(?:(?:is|was|are|were)\s+)?(?:the\s+)?(?:body|bodies) of water\b',q,re.I):return 'water_body'
    if re.search(r'\b(?:what|which)\s+(?:sea|ocean|river|lake|creek|bay|gulf|strait)\b',q,re.I):return 'water_body'
    if re.search(r'\b(?:what|which) (?:movie|film|television|TV) series\b',q,re.I):return 'series'
    if re.match(r'(?:In\s+)?(?:what|which) city\b',q,re.I):return 'city'
    if re.match(r'(?:In\s+)?(?:what|which) (?:part|region) of\b',q,re.I):return 'region'
    if re.match(r'What is the title of the person\b',q,re.I):return 'personal_title'
    return None


def constraints_for(question,program,node):
    need=program.needs[node] if node<len(program.needs) else None
    if need is None:return []
    result=[]
    if program.goal.op=='select' and need.o==program.goal.variable:
        category=answer_class(question)
        text={
            'water_body':'The returned value must be a body of water, such as a river, lake, sea or creek; an adjacent neighborhood is not a water body.',
            'series':'Return the series or franchise, not an individual work listed as a member of that series.',
            'city':'Return a city, not the university, employer, building or institution located there.',
            'region':'Return the requested region WITHIN the named place, not the containing state or country itself.',
            'personal_title':'Return the explicitly stated personal title, honorific or official role requested; a research specialty alone is not a title.',
        }
        if category:result.append(text[category])
    if getattr(need,'object_level',None)=='city':result.append('The value is a city, not an institution or employer.')
    return list(dict.fromkeys(result))


def check_translation(question,program):
    executable=' '.join(t for n in program.needs for t in (n.s,n.o,n.r,n.scope or '') if not t.startswith('?'))
    for year in set(re.findall(r'\b(?:1[0-9]{3}|20[0-9]{2})\b',question)):
        if not re.search(r'(?<!\d)'+year+r'(?!\d)',executable):
            raise ValueError('semantic_contract: explicit year '+year+' must occur in an executable literal, relation or time scope, not just span or variable name')
    if any(n.r.lower().strip() in ('equal to','equals','same as','identical to') for n in program.needs):
        raise ValueError('semantic_contract: bind equality to its original relation; equality is not an evidence acquisition predicate')
    g=program.goal
    if g.op!='select':return
    lineage=re.search(r'\b(paternal|maternal) grand(mother|father)\b',question,re.I)
    if lineage and re.match(r'Who\b',question,re.I) and any(n.r.lower() in ('father','mother') for n in program.needs):
        first='father' if lineage[1].lower()=='paternal' else 'mother'
        last=lineage[2].lower()
        if not any(a.r.lower()==first and b.r.lower()==last and a.o==b.s and b.o==g.variable for a in program.needs for b in program.needs):
            raise ValueError('semantic_contract: explicit lineage must follow '+first+' then '+last+' to the answer')
    for n in program.needs:
        for term in (n.s,n.o):
            if re.fullmatch(r'(?:the )?(?:English|British|French|German|American)? ?(?:king|queen|country|city|organization|person|man|woman)',term,re.I):
                raise ValueError('semantic_contract: descriptive role must be a variable with its stated qualifiers, not a named constant: '+term)
    outputs=[n for n in program.needs if n.o==g.variable]
    # In an embedded "made the first what" question, the subject of the
    # accomplishment is an intermediate entity, not the requested event.
    if re.search(r'\b(?:made|performed|achieved|accomplished) the first what\b',question,re.I):
        milestones=[n for n in program.needs if re.search(r'\bfirst\b',n.r,re.I) and n.o.startswith('?')]
        if milestones and not any(n.o==g.variable for n in milestones):
            raise ValueError('semantic_contract: the requested first accomplishment is the relation object, not the person who performed it; project the accomplishment variable')
    category=answer_class(question)
    if category=='city' and not any(n.kind=='place' and n.object_level=='city' for n in outputs):
        raise ValueError('semantic_contract: requested city must be the place/city output, not an institution')
    if category=='region' and any(n.object_level in ('state','country') for n in outputs):
        raise ValueError('semantic_contract: requested region within a place cannot be projected as a state or country')
    if re.search(r'\brecord label\b.*\b(?:part of|belongs? to|owned by)\b',question,re.I):
        labels={n.o for n in program.needs if re.search(r'\b(?:record label|released.*label)\b',n.r,re.I) and n.o.startswith('?')}
        if not labels or g.variable in labels or not any(n.s in labels and n.o==g.variable for n in outputs):
            raise ValueError('semantic_contract: preserve work -> record label -> owning company; return owning company')


def identity_owners(store,node,subject=None):
    """Owner context for generic organizational subunits, never global name aliases."""
    need=store.catalog[node]
    owners=[]
    for parent in store.plan.needs:
        if parent.o!=need.s or not need.s.startswith('?') or parent.kind!='organization':continue
        if not (re.search(r'\b(?:department|faculty|division|branch|committee|school)\b',parent.r,re.I)
                or subject and re.search(r'\b(?:department|faculty|division|branch|committee)\b',subject,re.I)):continue
        if not parent.s.startswith('?'):
            owners.append(parent.s)
        else:
            found=[]
            for row in store.rows.values():
                if row['status']=='accepted' and row['node']<len(store.plan.needs) and store.plan.needs[row['node']]==parent and (subject is None or store.canonical(row['o'])==store.canonical(subject)):
                    found.append(row['s'])
            owners.extend(found or [parent.s])
    return sorted(set(owners))


def source_semantic_rejections(store,row,need,quote,source):
    reasons=[]
    constraints=constraints_for(store.question,store.plan,row.node)
    category=answer_class(store.question) if store.plan.goal.op=='select' and need.o==store.plan.goal.variable else None
    value=row.o
    if (getattr(need,'object_level',None)=='city' or category=='city') and re.search(r'\b(?:university|college|institute|hospital|school|department|company|corporation)\b',value,re.I):
        reasons.append('institution_cannot_fill_city_slot')
    if category=='water_body':
        water=r'(?:river|lake|sea|ocean|creek|bay|gulf|canal|strait|reservoir|stream|estuary|pond|waterway)'
        # Require a category marker belonging to THIS value, not any water in a list.
        named=bool(re.search(r'\b'+water+r'\b',value,re.I))
        described=bool(re.search(r'\b'+water+r'\s+(?:of\s+)?'+re.escape(value)+r'\b|'+re.escape(value)+r'\s+(?:is|was),?\s+(?:an?\s+)?(?:\w+\s+){0,3}'+water+r'\b',quote,re.I))
        if not (named or described):reasons.append('water_body_category_has_no_witness')
    if category=='series':
        if not re.search(re.escape(value)+r"(?:['’]s)?\s+(?:(?:film|movie|television|TV|book)\s+)?(?:series|franchise|films|movies)\b|(?:series|franchise)\s+(?:of\s+|called\s+)?"+re.escape(value),quote,re.I):
            reasons.append('series_category_has_no_witness')
    if category=='region':
        match=re.match(r'(?:In\s+)?(?:what|which) (?:part|region) of\s+(.+?)\s+(?:is|was|does|did)\b',store.question,re.I)
        if match and store.canonical(value)==store.canonical(match[1]):reasons.append('containing_place_is_not_requested_subregion')
    if category=='personal_title' and re.search(r'(?:ologist|anatomist|scientist)$',value,re.I) and not re.search(r'\b(?:titled|appointed|styled)\b',quote,re.I):
        reasons.append('occupation_is_not_personal_title')
    if re.search(r'\b(?:initial|original|former) name\b',need.r,re.I) and re.search(r'\breplacement for\b|\breplaced\b',quote,re.I) and not re.search(r'\b(?:named|called|known as|renamed)\b',quote,re.I):
        reasons.append('replacement_does_not_establish_previous_name')
    owners=identity_owners(store,row.node,row.s)
    if len({store.canonical(owner) for owner in owners})>1:
        reasons.append('organizational_subunit_identity_ambiguous')
    if owners and not any(not owner.startswith('?') and store.source_mentions(owner,row.evidence_id) for owner in owners):
        reasons.append('organizational_subunit_owner_not_in_source')
    return reasons
