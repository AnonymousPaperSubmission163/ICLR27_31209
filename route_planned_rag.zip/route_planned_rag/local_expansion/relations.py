"""Deterministic predicate spelling and type keys; no world-fact implications.

The same physical containment predicate must have the same identifier when it
occurs in an original slot and in a registered rule body. Administrative levels
remain distinct. Nationality, provenance, birth and headquarters stay distinct.
"""
import re


def relation_identity(need):
    relation=' '.join(need.r.casefold().split())
    level=getattr(need,'object_level',None)
    suffix=re.search(r'\b(city|state|country)(?: of)?$',relation)
    if level is None and suffix:level=suffix[1]
    if need.kind=='place' and level:
        physical=re.fullmatch(r'(?:is )?(?:(?:located|situated)(?: in)?|(?:city|state) in)(?: (?:the )?(?:city|state|country)(?: of)?)?',relation)
        if physical:relation='physical containment'
    # Two slots with the same English label but different ranges are different
    # predicates (e.g. 'born in' a year versus 'born in' a place).
    return [relation,need.scope,need.kind,level]
