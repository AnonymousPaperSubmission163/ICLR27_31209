"""Paired A/B runner on the existing fixed public development sample and index."""
import argparse
import copy
import hashlib
import json
import os
import shutil
import time
from pathlib import Path
from route_planned_rag.method.client import Client
from route_planned_rag.method.cli import source_hashes
from .compiler import compile_episode
from .schema import Program
from route_planned_rag.prototype.prover import Prover,write_json
from . import VERSION
from .engine import LocalExpansionEngine,DEFAULTS
from .rules import GAMMA,GAMMA_HASH
from .retrieval import SharedRetriever
from .answering import AnswerClient, reserve_terminal, generate_terminal

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path.cwd())
    parser.add_argument('--sample',type=Path,default=Path('experiments/method_selection_20260915/data/development.public.json'))
    parser.add_argument('--corpus-dir',type=Path,default=Path('experiments/method_selection_20260915/data/corpora'))
    parser.add_argument('--run-id',required=True)
    parser.add_argument('--compiler-cache-run',type=Path,help='Immutable prior run: copy its exact initial compilation successes/failures, never regenerate.')
    parser.add_argument('--config',type=Path,default=Path('configs/local_expansion.yaml'))
    parser.add_argument('--variants', nargs='+', choices=('A','B'), default=['A','B'])
    args=parser.parse_args(argv);root=args.root.resolve()
    if Path(args.run_id).name!=args.run_id or args.run_id in ('','.','..'):parser.error('unsafe run ID')
    import yaml
    source_root=Path(os.environ.get('LOGICRAG_SOURCE_ROOT',str(root))).resolve()
    settings=yaml.safe_load((source_root/args.config).read_text());models=yaml.safe_load((source_root/settings['model_config']).read_text())
    config=dict(DEFAULTS,**settings['execution'])
    if len(args.variants)!=len(set(args.variants)):
        parser.error('duplicate variants')
    if config['planning_policy']=='reasoning_depth' and args.variants!=['A']:
        parser.error('reasoning_depth requires --variants A')
    public=[{k:r[k] for k in ('dataset','question_id','question')} for r in json.loads((root/args.sample).read_text())]
    if len(public)!=30 or {ds:sum(r['dataset']==ds for r in public) for ds in ('hotpotqa','twowiki','musique')}!={'hotpotqa':10,'twowiki':10,'musique':10}:raise ValueError('must run all fixed 30 development questions')
    if any(Path(r['question_id']).name!=r['question_id'] for r in public):raise ValueError('unsafe ID')
    prior = (root/args.compiler_cache_run).resolve() if args.compiler_cache_run else None
    if prior:
        previous=json.loads((prior/'protocol.json').read_text())
        if not (prior/'COMPLETE.json').exists():raise ValueError('prior compiler cache run incomplete')
        if previous['dataset_sample']['sha256']!=sha(root/args.sample) or previous['models']!={k:models['models'][k] for k in ('actor','retriever')} or previous['gamma_hash']!=GAMMA_HASH:
            raise ValueError('compiler cache protocol/model/Gamma mismatch')
    out=root/'runs/local_expansion'/args.run_id
    if out.exists():raise ValueError('immutable run exists; preserve and use another run ID')
    out.mkdir(parents=True)
    sources=source_hashes(source_root)
    # Unused closed_loop sources are not dependencies of this independent module.
    sources={p:h for p,h in sources.items() if '/closed_loop/' not in p}
    for p in (source_root/'scripts/run_local_expansion.py',source_root/'scripts/local_expansion.sbatch',source_root/args.config,source_root/settings['model_config']):sources[str(p.relative_to(source_root))]=sha(p)
    if config['answer_policy']=='best_effort':
        sources['scripts/answer_policy.sbatch']=sha(source_root/'scripts/answer_policy.sbatch')
    protocol=dict(version=VERSION,run_kind='real_model',question_count=30,episode_count=30*len(args.variants),no_gold_online=True,
        primary_question='Evaluate the selected frozen acquisition policy under unchanged question constraints and budgets.',
        variants={v:dict(allow_auxiliary=v=='B') for v in args.variants},seed=settings['seed'],execution=config,
        question_token_budget=settings['question_token_budget'],compiler_output_tokens=3200,source_hashes=sources,
        answer_policy=config['answer_policy'],
        terminal_generation='In best_effort mode reserve tokens and reader calls inside existing limits. Generate from original question and retrieved originals on acquisition stop, with unverified output separate from certified_answer. Never add generated predictions to facts.',
        models={k:models['models'][k] for k in ('actor','retriever')},gamma=GAMMA,gamma_hash=GAMMA_HASH,
        initial_program='One question-only typed compilation per question; at most three initial attempts for structural/type errors; success/failure and all costs copied into both arms; frozen during acquisition. The unreliable same-model semantic-review veto was removed after full-run regressions; semantic translation errors are separately inspected offline.',
        source_root=str(source_root),
        compilation_cache_origin=str(prior) if prior else None,
        question_cost='Each arm charged the same logical compiler cost; physical compiler work recorded once separately.',
        acquisition_state='Independent facts, seen evidence, queries, read/proof caches, budgets; immutable shared E5 vectors only.',
        dataset_sample=dict(path=str(args.sample),sha256=sha(root/args.sample),public_questions=public),
        corpora={ds:dict(path=str(args.corpus_dir/f'{ds}.json'),sha256=sha(root/args.corpus_dir/f'{ds}.json')) for ds in sorted({r['dataset'] for r in public})},
        ordering='Fixed question order, A/B order alternates by question index; greedy generation seed 2027.',
        common_fixes=['typed question compiler with verify and comparison projection','explicit title and lead recovery within existing top-k; stable dense fallback','one source-grounded admission path with numeric/temporal/geographic lexical witnesses','type-preserving physical containment predicate identity','singular/set output and deterministic source-mention selection','unfiltered extraction cache covers bound subsets; source/alias/conflict changes invalidate reuse','source/fact/binding/satisfied-need delta logging','parsed-no-support vs parse-failure vs conflict','valid result cache indexed by slot, binding, source/alias/conflict state and active catalog','new originals remain pending until legal reading','same bounded passive Gamma closure and actual Prover9 interface'],
        evaluation='Offline Str-Acc and LLM-Acc after all episodes; unanswered and initial compiler failures remain in the denominator. No B comparison in A-only runs.',
        limits_note='Existing closed-loop 12 auxiliary/128 routes/512 bindings caps retained; max two active children per selected rule, depth1, no LLM expansion or ranking calls.',
        retrieval_policy='Explicit normalized title anchors occupy at most two existing top-k slots, preserving leads and the best dense chunk for a single matched page; remaining slots use unchanged dense E5 scores. Same index and one charged embedding per query; no extra retrieval calls.',
        source_verification='Every nonempty reader batch requires a separate source-entailment check using the same actor, charged against the same reader/token budget. Verification output reservation is min(reader_output_tokens, 512 * pending_candidates). It is fallible model checking, not a formal semantic guarantee.',
        semantic_review='No human annotation supplied. Post-run source/Program inspection is explicitly model-assisted, not an independent semantic audit.')
    write_json(out/'protocol.json',protocol)
    for name in sources:
        destination=out/'source_code'/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source_root/name,destination)
    binary=root/'vendor/prover9/LADR-2009-11A/bin/prover9'
    if not binary.exists():raise ValueError('required Prover9 binary absent')
    write_json(out/'prover_binary.json',dict(path=str(binary),sha256=sha(binary),internal_timeout=2,external_timeout=3))
    import torch
    from route_planned_rag.logicgraph.runtime import load_models
    torch.manual_seed(settings['seed']);models['project']['root']=str(root)
    start=time.perf_counter();actor,_,encoder=load_models(models,with_encoder=True,with_scorer=False)
    write_json(out/'runtime.json',dict(model_load_seconds=time.perf_counter()-start,job_id=os.getenv('SLURM_JOB_ID'),device=torch.cuda.get_device_name(),torch_version=torch.__version__))
    retrievers={}
    for ds in sorted({r['dataset'] for r in public}):
        # Shared index is COMPLETE and immutable; never race an in-progress build.
        corpus=root/args.corpus_dir/f'{ds}.json'
        sig=hashlib.sha256((sha(corpus)+json.dumps(models['models']['retriever'],sort_keys=True)).encode()).hexdigest()
        cache=root/'artifacts/closed_loop_indices'/ds
        if not (cache/sig/'COMPLETE.json').exists():raise ValueError('shared index not COMPLETE; refuse concurrent construction')
        r=SharedRetriever(corpus,encoder,cache,models['models']['retriever']);retrievers[ds]=r
        write_json(out/f'{ds}.index.json',dict(r.index_record,physical_index_seconds=r.physical_index_seconds,cache_path=r.cache_path))
    results=[];physical_compiler_tokens=0
    for qi,row in enumerate(public):
        cache=out/'compilation_cache'/(row['dataset']+'_'+row['question_id'])
        if prior:shutil.copytree(prior/'compilation_cache'/cache.name,cache)
        compiler=Client(actor,cache,budget=settings['question_token_budget'])
        program,compile_error=None,None
        if prior:
            cached=json.loads((cache/'outcome.json').read_text());compile_error=cached['error']
            program=Program.model_validate(cached['program']) if cached['program'] is not None else None
        else:
            try:program=compile_episode(row['question'],compiler,cache,maximum=3200)
            except (ValueError,RuntimeError) as exc:compile_error=repr(exc)
            write_json(cache/'outcome.json',dict(error=compile_error,program=program.model_dump() if program else None))
            physical_compiler_tokens+=compiler.charged
        for variant in (args.variants if qi%2==0 else list(reversed(args.variants))):
            directory=out/row['dataset']/row['question_id']/variant;directory.mkdir(parents=True)
            inherited=[dict(c,physical_execution=False,shared_compiler_cache=str(cache.relative_to(out))) for c in copy.deepcopy(compiler.calls)]
            write_json(directory/'model_calls.json',inherited);client=AnswerClient(actor,directory,budget=settings['question_token_budget'])
            engine=None;start=time.perf_counter()
            try:
                if program is None:raise ValueError(compile_error)
                prover=Prover(binary,directory/'prover',timeout=config['prover_timeout'],cap=config['max_prover_calls'])
                engine=LocalExpansionEngine(row['question'],program.model_copy(deep=True),client,retrievers[row['dataset']],prover,directory,dict(config,allow_auxiliary=variant=='B'))
                result=engine.run()
            except (ValueError,RuntimeError,OSError) as exc:
                result=dict(question=row['question'],final_answer='',status='plan_invalid' if program is None else 'execution_error',error=repr(exc),answer_source='abstain',failure_category='compile_invalid' if program is None else 'infrastructure_error',expansion_triggered=False,matched_rule_ids=[],auxiliary_goals=[],auxiliary_actions_executed=[],answer_depends_on_expansion=False,no_progress_reads=0,reader_calls=0,retrieval_calls=0,proof_calls=0,input_tokens=sum(c.get('input_tokens',0) for c in client.calls),output_tokens=sum(c.get('output_tokens',0) for c in client.calls))
                result.update(initial_compile_invalid=program is None,certified_answer='',proof_status='unverified',
                              acquisition_status=result['status'],answer_policy=config['answer_policy'])
                if program is None and config['answer_policy']=='best_effort':
                    # Compilation failures stay visible; the original question can
                    # still receive one ordinary retrieval and a labelled prediction.
                    sources=[];state=dict(reader_calls=0,terminal_calls=0);events=[]
                    def emit(kind,**data):events.append(dict(kind=kind,**data))
                    try:
                        reserve_terminal(client,config)
                        if client.charged+config['terminal_token_reserve']<=client.budget:
                            result['retrieval_calls']=1
                            sources,usage=retrievers[row['dataset']](row['question'],config['retrieval_top_k'])
                            result['query_embedding_usage']=[usage]
                        result.update(generate_terminal(row['question'],client,config,state,sources,
                                                        unresolved=[dict(reason='initial_compile_invalid')],event=emit))
                        if result['final_answer']:result['status']='best_effort'
                    except (ValueError,RuntimeError,OSError) as terminal_exc:
                        result['terminal_error']=repr(terminal_exc)
                    result.update(reader_calls=state['reader_calls'],terminal_calls=state['terminal_calls'],
                                  input_tokens=sum(c.get('input_tokens',0) for c in client.calls),
                                  output_tokens=sum(c.get('output_tokens',0) for c in client.calls))
                    write_json(directory/'terminal_events.json',events)
                    write_json(directory/'terminal_sources.json',sources)
            finally:
                if engine is not None:engine.store.close()
            result.update(dataset=row['dataset'],question_id=row['question_id'],variant=variant,run_kind='real_model',relative_directory=str(directory.relative_to(out)),seconds_this_episode=time.perf_counter()-start,
                logical_compiler_tokens=compiler.charged,logical_compiler_seconds=sum(c['seconds'] for c in compiler.calls),logical_total_tokens=client.charged,
                physical_episode_tokens=sum(c.get('input_tokens',0)+c.get('output_tokens',0) for c in client.calls if c.get('physical_execution',True)))
            write_json(directory/'result.json',result);results.append(result);write_json(out/'results.json',results)
            print(json.dumps({k:result.get(k) for k in ('dataset','question_id','variant','status','final_answer','logical_total_tokens','expansion_triggered','matched_rule_ids','answer_depends_on_expansion','error')}),flush=True)
    (out/'episodes.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in results))
    write_json(out/'COMPLETE.json',dict(questions=30,episodes=len(results),variants=args.variants,logical_total_tokens=sum(r['logical_total_tokens'] for r in results),physical_episode_tokens=sum(r['physical_episode_tokens'] for r in results),physical_compiler_tokens=physical_compiler_tokens))
    return results
if __name__=='__main__':main()
