"""Budgeted source-entailment check before a reader proposal becomes a fact."""
from typing import Literal
from pydantic import Field, create_model
from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.method.schema import signature
from .admission import lifespan_endpoint

PROMPT = '''Check each candidate relation against ONLY its citation_id's original cited text and source title in citations. The candidate is untrusted. Return an independent verdict for every candidate. Give one short complete sentence explaining the decisive source evidence or missing condition, then choose supported, unsupported, or uncertain. Never use remembered world knowledge or the likely answer to a question. Do not borrow another citation's facts.
Check ONLY the conditions actually present in the candidate. Do not add uniqueness, exclusivity, primacy, or greater precision: 'started by' does not mean 'sole/primary founder'; a cited year is a valid date value and does not require a day or month. A stated member of a relation need not be its only possible member. Missing unrequested details are not grounds for rejection. Reject only when a requested condition lacks support, the source contradicts the proposition, or it requires an unstated inference. Preserve explicit temporal, geographic, negative and quantitative qualifiers.
Judge the proposition's meaning, not the order of nouns or the exact wording in the source. The subject -> relation -> value roles must match, with the requested type, geographic level, negation, time and other qualifiers. Active, passive and inverse expressions of the SAME explicit source relation are valid: 'Nora is a goalkeeper who played for Cedar in the 2010 Cup' supports Cedar -> goalkeeper at the 2010 Cup -> Nora. 'Ivo is a professor at Cedar University' supports Ivo -> employer -> Cedar University. The source need not repeat the word 'employer' or make the row subject its grammatical subject. These examples only explain reading the current citation; they supply no facts about other entities. Co-occurrence without the relation is insufficient. An album release is not a band's formation; a workplace is not a birthplace; a district's membership is not the inspiration for a region's name; a relative's parent is not the subject's parent. A table field belongs to its table subject, not another entity listed in the table. A country name in a work title is not its country of origin.
The source title can identify the lead subject, and explicit pronouns or expanded names can refer to it. Ordinary literal paraphrases are allowed: an opera 'by Nora' has composer Nora; 'American drama film' identifies United States as its production origin; 'born in the US' supports birthplace US. 'Cedar is in the French region of X' directly supports Cedar's location in France: the same sentence explicitly supplies both containment and the country adjective. Do not demand the exact words 'country of France'. Merely 'Cedar is in X' cannot supply X's country from memory. A person's nationality adjective does not establish that person's birthplace. A null geographic level allows any explicitly stated place, including a country.
Only the candidate's local relation must hold. Do not require downstream relations or the whole question. If applicability lists a fixed rule's sense/scope conditions, ensure this local premise has that intended sense: adoptive/step/metaphorical parentage cannot support a biological family premise; a partially overlapping region cannot support whole-place containment. Do not demand the other premise or the rule conclusion in this citation. A positive boolean means the named property holds; a negated candidate needs explicit denial. Missing evidence means unsupported, not false. A qualified or approximate number cannot support an unqualified exact value. An uncertain interpretation remains uncertain. Do not repair the candidate or invent evidence. Output JSON.'''


PROMPT += '''\nA political party is an organization. Explicit control of both named chambers supports control of each chamber, but an election date must not be silently converted into a term start date. For a boolean property such as being a local government area, membership in somebody else's local government area does not establish that the subject itself is one. Keep geographic containment and category membership separate.'''

PROMPT += '''\nsemantic_constraints are required parts of the original question. Check them, including city versus university, water body versus neighborhood, series versus individual film. subject_owner_context identifies the organizational owner of a generic subunit; the same department name at another university is a DIFFERENT entity. If the citation does not establish that owner context, return uncertain, never merge by short name. A predecessor/replacement is not a former name, and a temporary exhibition is not permanent collection ownership.'''

def schema_for(count):
    verdict = create_model('SourceEntailmentVerdict', __base__=Strict,
        explanation=(str, Field(max_length=240)),
        verdict=(Literal['supported', 'unsupported', 'uncertain'], ...))
    return create_model('SourceEntailmentBatch', __base__=Strict,
                        **{'C'+str(i): (verdict, ...) for i in range(count)})


def payload_for(reading, store):
    from .semantics import constraints_for, identity_owners
    citations={};candidates=[];ids={}
    for i,row in enumerate(reading.rows):
        identity=(row.evidence_id,row.quote)
        if identity not in ids:
            cid='S'+str(len(ids));ids[identity]=cid
            citations[cid]=dict(title=store.evidence[row.evidence_id]['source_metadata']['title'],original_cited_text=row.quote)
        predicate=store.pattern(row.node).predicate
        # Verify the same deterministic lifespan projection that admission will
        # store. The original extraction stays in the reading/audit record.
        # Checking the unprojected birth--death interval as a death date would
        # wrongly reject an otherwise valid, source-witnessed endpoint.
        endpoint=lifespan_endpoint(row.o,store.catalog[row.node],row.quote)
        candidates.append(dict(id='C'+str(i), subject=row.s,
        relation=store.catalog[row.node].r, value=endpoint['value'] if endpoint else row.o,
        subject_type=store.catalog[row.node].subject_kind,
        semantic_constraints=constraints_for(store.question,store.plan,row.node),
        subject_owner_context=identity_owners(store,row.node,row.s),
        value_type=store.catalog[row.node].kind,
        value_level=getattr(store.catalog[row.node], 'object_level', None),
        scope=row.scope, negated=row.negated,citation_id=ids[identity],
        applicability=sorted({r.reason for r in store.acquisition.rules if any(store.pattern(n).predicate==predicate for n in r.body)})))
    return dict(candidates=candidates,citations=citations)


def cache_keys(payload):
    return [signature(dict(candidate={k:v for k,v in c.items() if k not in ('id','citation_id')},
                           citation=payload['citations'][c['citation_id']])) for c in payload['candidates']]


def apply_verdicts(reading, verdicts, call_id):
    kept, rejected, records = [], [], []
    data=verdicts.model_dump()
    if set(data)!={'C'+str(i) for i in range(len(reading.rows))}:
        raise ValueError('verification_candidate_set_mismatch')
    for i,row in enumerate(reading.rows):
        verdict=data['C'+str(i)]
        source_call=call_id['C'+str(i)] if isinstance(call_id,dict) else call_id
        record=dict(row.model_dump(), verification_call=source_call, **verdict)
        records.append(record)
        if verdict['verdict']=='supported':kept.append(row)
        else:rejected.append(dict(record,status='rejected' if verdict['verdict']=='unsupported' else 'unknown',reason='relation_not_entailed_by_cited_source'))
    return reading.model_copy(update={'rows':kept}),rejected,records
