"""The v3 source reader, extended to at most 24 independent acquisition slots."""
from pydantic import Field,create_model
from typing import Literal
from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.logic_control.core import Row
from route_planned_rag.method.reader import slot_schema as base_slot_schema, SourceCandidate, SLOT_PROMPT, original_sentences

def slot_schema(nodes,evidence,requests=None):
    if requests is None:return base_slot_schema(nodes,evidence)
    _,sentences=original_sentences(evidence);slots={}
    for node,request in zip(nodes,requests):
        subject_field={'subject':(Literal[request['subject_filter']],...)} if request.get('subject_filter') is not None else {}
        row=create_model('ScopedSourceRow'+str(node),__base__=SourceCandidate,
            evidence_id=(Literal[tuple(e['evidence_id'] for e in evidence)],...),
            sentence_ids=(list[Literal[tuple(sentences)]],Field(min_length=1,max_length=6)),
            scope=(Literal[request['scope']],request['scope']),**subject_field)
        slot=create_model('ScopedSlot'+str(node),__base__=Strict,rows=(list[row],Field(max_length=24)),check=(str,Field(max_length=280)))
        slots['N'+str(node)]=(slot,...)
    return create_model('ScopedAcquisitionReading',__base__=Strict,**slots)

SLOT_PROMPT=SLOT_PROMPT.replace('first write check (one brief sentence describing source support or what is missing), then rows','write rows first, then check (one brief sentence explaining their source support or why no rows exist)')
SLOT_PROMPT=SLOT_PROMPT.replace('No independent review or final-answer generation is performed.','The program separately checks proposed relations against their source and assembles the answer.')
SLOT_PROMPT += '''
Translate the MEANING of each local relation, not an exact predicate string. A named political party is an organization. 'Party X gained control of both chambers' states control of each explicitly identified chamber; do not require the literal word organization. Do not confuse an election date with the date a new term or control began.
Geographic country adjectives are explicit location evidence: 'the Italian island Z' supports Z located in country Italy, citing that sentence. Do not require a separate sentence 'Z is in Italy'. This never supplies a person's birthplace.
Distinguish category membership from geographic containment: 'X is part of the Y local government area' does NOT say X itself is a local government area. A boolean property must apply to the row subject itself.
An empty slot MUST use rows:[], never a row with '(no supported rows)' or a guessed value. For every nonempty row the quoted sentences must state the requested relation, not merely mention both arguments. A workplace does not state a birthplace; an album release date does not state the band's formation date. Keep the relation's subject separate from a father, mother or other relative mentioned in the same passage. A null value_level accepts a country as a place. Copy compact entity names, leaving explanatory '(later ...)' or '(also known as ...)' outside the value.
value_type:entity includes people, organizations, publications and other named things. In 'Nora was described by "The Ledger" as "an influential writer"', the relation (Nora, described as "an influential writer" by, ?) has value 'The Ledger'. Quotation marks around a publication name do not make it a non-entity. Active and passive descriptions have the same attribution direction from the described subject to the source making the description.
For (Ivo, born in, ?, value_type:place, value_level:null), the sentence 'Ivo was born in the UK' directly supplies the place 'UK'. A country is a valid place. Do not invent a locality/city restriction when value_level is null, and do not reject an explicit country abbreviation merely because no city is supplied. This differs from 'Ivo is British', which alone supplies no birthplace.
Interpret request fields literally: value_filter:null means the value is UNKNOWN and must be extracted, not that an already mentioned answer should be excluded. value_type:"person" means the answer is a person; it is not a person named "person" and is not a value filter. If the passage says 'Cedar is an opera by Nora', a request (subject_filter:Cedar, relation:composed by, value_filter:null, value_type:person) must extract Nora, even if no birthplace or other requested relation is known.
For an infobox or table flattened into text, Source/Mouth/Born/Died and similar fields belong to the named table subject. A river merely listed under Tributaries does NOT inherit the main river's source, mouth or other fields. River source/headwaters is upstream, while a confluence or receiving river is downstream. Do not invert them.
Read the whole original passage for each local relation. A fact can be supported by TWO OR MORE adjacent sentences; do not require the entity, relation and year to occur in one sentence. Resolve 'this', 'the current organization', and similar references to their explicit preceding antecedent. For example, 'In 1945 Cedar was replaced by a new organization, Aspen. This new organization was founded by Nora.' supports Aspen's founder Nora at that stated event, citing BOTH sentences. This does not transfer a rename date to the original organization's earlier foundation, or a person's birth date to their career. Only demand the local relation and the listed scope; other slots are independent.
Relation direction is subject -> value. 'mother' of a named subject asks for that subject's mother, not the subject's children. Read family appositions and coordinated clauses: 'X is a son of Y and his first wife Z' states X's mother is Z; cite the full sentence, not just names. 'X succeeded his father Y' states X's father is Y.
Biography titles establish the subject of their lead, including full-name expansions and quoted nicknames. A provided subject filter may use the exact title while the lead uses the expanded name. Return the filter name when both refer explicitly to that page's subject, retaining the cited original antecedent.
value_level=country requires a country, not a city, island or state. value_level=locality requires the concrete location. Do not silently replace one by the other or derive nationality from birthplace. A geographical adjective modifying a geographic entity (e.g. 'French city') identifies the country of that entity; retain the literal source sentences. Nationality of a person does not establish the person's birth country. The admission layer checks a fixed adjective normalization table.
For general occupations, extract atomic profession nouns: a 'film director' is a 'director'; a 'singer-songwriter' explicitly has both 'singer' and 'songwriter' occupations. Preserve qualifiers when the request itself requires them. Never combine two occupations into one row if the question asks for separate occupations.
Extract all supported rows from a list, even when another requested relation is unknown. Only the absence of source support justifies an empty slot. An unfamiliar spelling or grammatical defect in the question does not erase a plainly stated source relation.
'''


SLOT_PROMPT += '''\nsemantic_constraints are mandatory answer-category constraints from the question. subject_owner_context distinguishes a department or branch from equally named subunits of OTHER organizations. Keep that identity in every slot; if the source cannot establish it, return no row for that subject. A university is not a city; a neighborhood is not a water body; a single film is not a franchise. 'Replaced X' does not mean 'was formerly called X'. Preserve explicit names and requested categories, and do not substitute an occupation for a personal honorific.'''

class AcquisitionRow(Row):
    node: int = Field(ge=0, le=95)


class AcquisitionReading(Strict):
    rows: list[AcquisitionRow] = Field(default_factory=list, max_length=2304)
    complete: list[int] = Field(default_factory=list, max_length=96)
    missing: list[str] = Field(default_factory=list, max_length=96)


def slots_to_reading(value, evidence):
    _, sentences = original_sentences(evidence)
    sources = {e['evidence_id']: e['original_text'] for e in evidence}
    rows, unknown, missing = [], [], []
    for name, slot in value.model_dump().items():
        node = int(name[1:])
        for source_row in slot['rows']:
            row = dict(source_row)
            spans = [sentences[sid] for sid in row.pop('sentence_ids')]
            if any(s['evidence_id'] != row['evidence_id'] for s in spans):
                raise ValueError('sentence belongs to another source')
            quote = sources[row['evidence_id']][min(s['start'] for s in spans):max(s['end'] for s in spans)]
            uncertain = row.pop('uncertain', False)
            row.update(node=node, s=row.pop('subject'), o=row.pop('value'), quote=quote)
            if uncertain:
                unknown.append(dict(row, status='unknown', reason='reader_uncertain'))
            else:
                rows.append(row)
        if not slot['rows']:
            missing.append(name + ': ' + slot['check'])
    return AcquisitionReading(rows=rows, missing=missing), unknown
