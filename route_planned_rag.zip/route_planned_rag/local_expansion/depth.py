"""Goal-relative acquisition progress, separate from formal proof depth.

No new requirements or facts are introduced. Distances are shortest paths in
the original variable graph, not proof lengths or estimated truth probabilities.
"""
from route_planned_rag.prototype.logic import ground, substitute
from route_planned_rag.method.schema import signature as digest


def variable(value):
    return value.startswith('?')


def layers(program, included=None):
    """Shortest acquisition layers from question anchors; unseeded cycles stay unknown."""
    needs = program.needs
    nodes = set(range(len(needs))) if included is None else set(included)
    distances = {v: 0 for v, values in program.choices.items() if values}
    for _ in range(len(needs) + 1):
        changed = False
        for i in sorted(nodes):
            n = needs[i]
            ends = (n.s, n.o)
            anchors = [distances[t] for t in ends if variable(t) and t in distances]
            if any(not variable(t) and t not in ('true', 'false') for t in ends):
                anchors.append(0)
            if not anchors:
                continue
            depth = min(anchors) + 1
            for t in ends:
                if variable(t) and depth < distances.get(t, float('inf')):
                    distances[t] = depth
                    changed = True
        if not changed:
            break
    result = {}
    for i in sorted(nodes):
        n = needs[i]
        anchors = [distances[t] for t in (n.s, n.o) if variable(t) and t in distances]
        if any(not variable(t) and t not in ('true', 'false') for t in (n.s, n.o)):
            anchors.append(0)
        result[i] = min(anchors) + 1 if anchors else None
    return result, distances


def fact_depths(store):
    """Least known valid AND/OR derivation height. No reward for cyclic detours."""
    depths = {fid: 0 for fid, row in store.rows.items()
              if row['status'] == 'accepted' and row.get('origin') != 'program_derived'}
    for _ in range(len(store.rows) + 1):
        changed = False
        for support in store.derivations.values():
            head, premises = support['conclusion'], support['premise_ids']
            if (not support.get('valid') or not premises or
                    store.rows.get(head, {}).get('status') != 'accepted' or
                    any(p not in depths for p in premises)):
                continue
            value = 1 + max(depths[p] for p in premises)
            if value < depths.get(head, float('inf')):
                depths[head] = value
                changed = True
        if not changed:
            break
    return depths


class ProgressScorer:
    def __init__(self, engine):
        self.engine = engine
        self.store = engine.store
        self.static_layers, _ = layers(engine.program)
        self.depths = fact_depths(self.store)
        self.verified = {}
        self.match_cache = {}

    def verified_fact(self, fid):
        """Observed facts retain admission standards; derived credit requires real proof."""
        if fid in self.verified:
            return self.verified[fid]
        s = self.store
        if fid not in self.depths:
            return None
        if s.rows[fid].get('origin') != 'program_derived':
            value = dict(fact_id=fid, semantic_depth=0, basis='accepted_observation', proof_id=None)
        else:
            leaves, rules, _ = s.proof_inputs(dict(facts=[fid]))
            prover = self.engine.prover
            # Leave one call for final verification. No extra proof budget.
            facts = [(f, s.row_atom(s.rows[f])) for f in sorted(leaves)]
            goal = s.row_atom(s.rows[fid])
            key = digest([facts, rules, goal, s.version, s.alias_version])
            cache = getattr(self.engine, '_depth_proofs', {})
            self.engine._depth_proofs = cache
            if key not in cache:
                if prover.calls >= prover.cap - 1:
                    self.verified[fid] = None
                    return None
                cache[key] = prover.prove(facts, sorted(rules.items()), [goal], version=key)
            proof = cache[key]
            if (proof['result'] != 'proved' or not proof.get('valid') or
                    proof['source_mapping_status'] != 'complete'):
                self.verified[fid] = None
                return None
            value = dict(fact_id=fid, semantic_depth=self.depths[fid],
                         basis='prover9_verified_derivation', proof_id=proof['proof_id'])
        self.verified[fid] = value
        return value

    def candidate(self, binding):
        supported, witnesses = [], {}
        for node in range(len(self.engine.program.needs)):
            target = substitute(self.store.pattern(node), binding)
            # Never combine independently existential matches across candidates.
            if not ground(target):
                continue
            key = digest(target)
            if key not in self.match_cache:
                options = []
                for hit in self.store.match(target):
                    for fid in hit['facts']:
                        if fid in self.depths:
                            options.append((self.depths[fid], fid))
                witness = None
                for _, fid in sorted(options):
                    witness = self.verified_fact(fid)
                    if witness is not None:
                        break
                self.match_cache[key] = witness
            witness = self.match_cache[key]
            if witness is not None:
                supported.append(node)
                witnesses[str(node)] = witness
        reached_layers, reached_variables = layers(self.engine.program, supported)
        # Report only the original shortest layer, never a longer alternative
        # path created by withholding a shortcut.
        depth = max((self.static_layers[i] for i in supported
                     if reached_layers.get(i) is not None and self.static_layers[i] is not None), default=0)
        missing = sorted(set(range(len(self.engine.program.needs))) - set(supported))
        return dict(supported_nodes=supported, missing_original_nodes=missing,
                    supported_count=len(supported), total_requirements=len(self.engine.program.needs),
                    coverage=len(supported)/len(self.engine.program.needs),
                    completed_dependency_depth=depth,
                    remaining_dependency_layers=sorted({self.static_layers[i] for i in missing
                                                        if self.static_layers[i] is not None}),
                    unanchored_nodes=[i for i in missing if self.static_layers[i] is None],
                    reached_variables=sorted(reached_variables), witnesses=witnesses,
                    node_scores=[dict(node=i, dependency_layer=self.static_layers[i],
                        supported=i in supported, semantic_depth=witnesses.get(str(i), {}).get('semantic_depth'),
                        proof_id=witnesses.get(str(i), {}).get('proof_id'),
                        support_basis=witnesses.get(str(i), {}).get('basis', 'unknown'))
                        for i in range(len(self.engine.program.needs))],
                    semantic_derivation_depth=max((w['semantic_depth'] for w in witnesses.values()), default=0),
                    basis='binding_consistent_original_requirements',
                    depth_is_correctness=False)

    def action(self, action, progress):
        """Structural potential only: unknown retrieval outcomes receive no factual credit."""
        node = action['node']
        n = self.engine.program.needs[node]
        bound = {'?' + k.lstrip('?') for k in action['binding']}
        new_variables = {t for t in (n.s, n.o) if variable(t)} - bound
        unlocked = []
        for other in progress['missing_original_nodes']:
            if other == node:
                continue
            need = self.engine.program.needs[other]
            vs = {t for t in (need.s, need.o) if variable(t)}
            anchored = bool(vs & bound) or any(not variable(t) and t not in ('true', 'false')
                                               for t in (need.s, need.o))
            if not anchored and vs & new_variables:
                unlocked.append(other)
        return dict(potential_unlocked_nodes=unlocked,
                    dependency_layer=self.static_layers[node],
                    potential_only=True)


def candidate_rank(candidate):
    p = candidate['reasoning_progress']
    return (-p['supported_count'], -p['completed_dependency_depth'],
            candidate['remaining_cost'], len(candidate['missing']), candidate['id'])


def certificate_depth(store, fid, proof):
    """Least known support height restricted to the returned proof's used inputs.

    This is semantic normalization of a real certificate, not its clause count
    or a global shortest-proof claim. Fail closed if the native DAG is unknown.
    """
    if (proof.get('result') != 'proved' or not proof.get('valid') or
            proof.get('source_mapping_status') != 'complete' or
            proof.get('proof_depth', {}).get('status') != 'complete'):
        return None
    depths = {f: 0 for f in proof['fact_ids'] if f in store.rows and
              store.rows[f]['status'] == 'accepted' and
              store.rows[f].get('origin') != 'program_derived'}
    used_rules = set(proof['rule_ids'])
    for _ in range(len(store.rows) + 1):
        changed = False
        for d in store.derivations.values():
            ps, head = d['premise_ids'], d['conclusion']
            if (not d.get('valid') or not ps or not d['rule_ids'] or
                    not set(d['rule_ids']) <= used_rules or
                    store.rows.get(head, {}).get('status') != 'accepted' or
                    any(p not in depths for p in ps)):
                continue
            value = 1 + max(depths[p] for p in ps)
            if value < depths.get(head, float('inf')):
                depths[head] = value
                changed = True
        if not changed:
            break
    return depths.get(fid)


class ProverDepthScorer(ProgressScorer):
    """Strict A: only certified, target-related registered-rule applications count."""
    def verified_fact(self, fid):
        value = super().verified_fact(fid)
        if value is None or value['basis'] == 'accepted_observation':
            return value  # accepted observations are depth-zero base cases
        proof = next(p for p in self.engine.prover.records if p['proof_id'] == value['proof_id'])
        depth = certificate_depth(self.store, fid, proof)
        if depth is None:
            self.verified[fid] = None
            return None
        value = dict(value, semantic_depth=depth,
                     basis='prover9_certificate_normalized_depth',
                     formal_proof_depth=proof['proof_depth']['formal_depth'],
                     used_rule_ids=sorted(proof['rule_ids']),
                     used_fact_ids=sorted(proof['fact_ids']))
        self.verified[fid] = value
        return value


def prover_candidate_rank(candidate):
    # Preserve every old tie break so a changed action must be due to depth.
    return (-candidate['reasoning_progress']['semantic_derivation_depth'],
            *candidate_rank(candidate))
