from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml


class ConfigError(ValueError):
    pass


def load_config(path: str | Path) -> dict[str, Any]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ConfigError("configuration root must be a mapping")
    validate_config(config)
    config["_config_path"] = str(config_path)
    config["_config_sha256"] = hashlib.sha256(config_path.read_bytes()).hexdigest()
    return config


def validate_config(config: dict[str, Any]) -> None:
    required = {"project", "models", "retrieval", "search", "budgets", "data", "training", "resources"}
    missing = sorted(required - set(config))
    if missing:
        raise ConfigError(f"missing config sections: {missing}")
    root = Path(config["project"]["root"])
    if str(root) != "/blue/du.j/jinjiaguo/logicrag":
        raise ConfigError("project.root must remain /blue/du.j/jinjiaguo/logicrag")
    for key in ("artifact_root", "run_root", "cache_root"):
        candidate = Path(config["project"][key])
        try:
            candidate.relative_to(root)
        except ValueError as exc:
            raise ConfigError(f"project.{key} escapes logicrag") from exc
    if int(config["resources"]["maximum_b200_gpus"]) > 2:
        raise ConfigError("maximum_b200_gpus cannot exceed 2")
    if int(config["retrieval"]["delivered_top_k"]) > int(config["retrieval"]["initial_top_k"]):
        raise ConfigError("delivered_top_k cannot exceed initial_top_k")


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()

