from __future__ import annotations


def metric_namespace(*, evaluator_kind: str, judge_model: str | None = None) -> str:
    if evaluator_kind == "official_deterministic":
        if judge_model is not None:
            raise ValueError("deterministic official metrics cannot carry an LLM judge model")
        return "official_deterministic"
    if evaluator_kind == "mistral_judge":
        if judge_model != "mistralai/Mistral-Small-3.2-24B-Instruct-2506":
            raise ValueError("Mistral judge provenance requires the frozen allowlisted 24B checkpoint")
        return "accuracy_mistral_judge"
    raise ValueError("unknown evaluator kind")

