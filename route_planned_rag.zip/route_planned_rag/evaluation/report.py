from __future__ import annotations

import json
from pathlib import Path


def build_actual_run_report(run_root: str | Path, destination: str | Path) -> dict:
    rows = []
    for manifest_path in sorted(Path(run_root).glob("*/manifest.json")):
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        metrics_path = manifest_path.parent / "metrics.json"
        metrics = json.loads(metrics_path.read_text(encoding="utf-8")) if metrics_path.exists() else None
        rows.append({
            "run_id": manifest_path.parent.name,
            "command": manifest.get("command", manifest.get("test")),
            "status": manifest.get("status"),
            "metrics": metrics,
            "path": str(manifest_path.parent),
        })
    result = {
        "status": "complete",
        "scope": "actual_runs_only",
        "run_count": len(rows),
        "complete_count": sum(row["status"] == "complete" for row in rows),
        "failed_count": sum(row["status"] == "failed" for row in rows),
        "runs": rows,
    }
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result
