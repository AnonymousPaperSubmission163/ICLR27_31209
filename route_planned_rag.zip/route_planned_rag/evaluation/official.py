from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any


def _parse_json_object(output: str) -> dict[str, Any]:
    start = output.find("{")
    if start < 0:
        raise RuntimeError(f"official evaluator returned no JSON: {output[-1000:]}")
    value, _ = json.JSONDecoder().raw_decode(output[start:])
    if not isinstance(value, dict):
        raise RuntimeError("official evaluator output is not an object")
    return value


def _run(command: list[str], cwd: Path) -> str:
    process = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if process.returncode != 0:
        raise RuntimeError(
            f"official evaluator failed with code {process.returncode}\n"
            f"stdout:\n{process.stdout[-4000:]}\n"
            f"stderr:\n{process.stderr[-4000:]}"
        )
    return process.stdout


def run_musique_official(
    evaluator: str | Path,
    predictions: str | Path,
    gold: str | Path,
    python_executable: str | Path | None = None,
) -> dict[str, Any]:
    evaluator = Path(evaluator).resolve()
    output = _run([str(python_executable or sys.executable), str(evaluator), str(predictions), str(gold)], evaluator.parent)
    return _parse_json_object(output)


def run_twowiki_official(
    evaluator: str | Path,
    predictions: str | Path,
    gold: str | Path,
    alias_file: str | Path | None = None,
    python_executable: str | Path | None = None,
) -> dict[str, Any]:
    evaluator = Path(evaluator).resolve()
    command = [str(python_executable or sys.executable), str(evaluator), str(predictions), str(gold)]
    if alias_file is not None:
        command.append(str(alias_file))
    return _parse_json_object(_run(command, evaluator.parent))
