"""Offline LogicRAG paper metrics, separate from exact-match QA evaluators.

Source: chensyCN/LogicRAG, commit 72a298c95ffd75890c7f9c28fd1c094201f669a7,
src/utils/utils.py. The judge prompt and normalization are kept verbatim.
Only final answers and canonical gold answers are scored, never proofs.
"""
from __future__ import annotations

import re


JUDGE_SYSTEM = "You are a helpful assistant."
JUDGE_PROMPT = """You are an expert evaluator. Please evaluate if the generated answer is correct by comparing it with the gold answer.

Generated answer: {generated}
Gold answer: {gold}

The generated answer should be considered correct if it:
1. Contains the key information from the gold answer
2. Is factually accurate and consistent with the gold answer
3. Does not contain any contradicting information

Respond with ONLY 'correct' or 'incorrect'.
Response:"""


def normalize_answer(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = text.replace('-', ' ')
    text = re.sub(r'[^\w\s]', '', text)
    return ' '.join(text.split())


def string_accuracy(generated: str, gold: str) -> bool:
    """Official normalized substring test; do not add aliases or remove articles."""
    if not isinstance(gold, str) or not normalize_answer(gold):
        raise ValueError("A nonempty canonical gold answer is required")
    return normalize_answer(gold) in normalize_answer(generated)


def judge_prompt(generated: str, gold: str) -> str:
    return JUDGE_PROMPT.format(generated=generated, gold=gold)


def parse_judgment(text: str) -> bool | None:
    """Keep malformed judgments pending, rather than score a transport error as wrong."""
    value = text.strip().lower()
    if value == "correct":
        return True
    if value == "incorrect":
        return False
    return None
