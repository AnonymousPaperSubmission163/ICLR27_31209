from __future__ import annotations

import collections
import re
import string
from typing import Iterable

from route_planned_rag.types import AnswerWithCitations, ObservedPassage, PrivateReference


def normalize_answer(text: str) -> str:
    def remove_articles(value: str) -> str:
        return re.sub(r"\b(a|an|the)\b", " ", value)

    def white_space_fix(value: str) -> str:
        return " ".join(value.split())

    def remove_punctuation(value: str) -> str:
        return "".join(character for character in value if character not in string.punctuation)

    return white_space_fix(remove_articles(remove_punctuation(text.casefold())))


def token_f1(prediction: str, reference: str) -> tuple[float, float, float]:
    prediction_tokens = normalize_answer(prediction).split()
    reference_tokens = normalize_answer(reference).split()
    if not prediction_tokens or not reference_tokens:
        exact = float(prediction_tokens == reference_tokens)
        return exact, exact, exact
    overlap = collections.Counter(prediction_tokens) & collections.Counter(reference_tokens)
    common = sum(overlap.values())
    if common == 0:
        return 0.0, 0.0, 0.0
    precision = common / len(prediction_tokens)
    recall = common / len(reference_tokens)
    return precision, recall, 2 * precision * recall / (precision + recall)


def evaluate_answer(prediction: str, references: Iterable[str]) -> dict[str, float]:
    candidates = list(references)
    if not candidates:
        raise ValueError("at least one reference answer is required")
    em = max(float(normalize_answer(prediction) == normalize_answer(reference)) for reference in candidates)
    scores = [token_f1(prediction, reference) for reference in candidates]
    precision, recall, f1 = max(scores, key=lambda item: item[2])
    return {"answer_em": em, "answer_precision": precision, "answer_recall": recall, "answer_f1": f1}


def set_metrics(predicted: set, gold: set) -> dict[str, float]:
    if not predicted and not gold:
        return {"support_precision": 1.0, "support_recall": 1.0, "support_f1": 1.0}
    common = len(predicted & gold)
    precision = common / len(predicted) if predicted else 0.0
    recall = common / len(gold) if gold else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"support_precision": precision, "support_recall": recall, "support_f1": f1}


def delivered_support_ids(passages: Iterable[ObservedPassage]) -> tuple[set[str], set[tuple[str, int]]]:
    docs: set[str] = set()
    facts: set[tuple[str, int]] = set()
    for passage in passages:
        docs.add(passage.doc_id)
        title = passage.doc_id.removeprefix("2wiki:")
        facts.update((title, sentence_id) for sentence_id in passage.sentence_ids)
    return docs, facts


def evaluate_episode(
    answer: AnswerWithCitations,
    delivered_passages: Iterable[ObservedPassage],
    reference: PrivateReference,
) -> dict[str, float | bool]:
    answer_scores = evaluate_answer(answer.answer, reference.reference_answers)
    delivered_docs, delivered_facts = delivered_support_ids(delivered_passages)
    if reference.supporting_facts:
        support_scores = set_metrics(delivered_facts, set(reference.supporting_facts))
        coverage = set(reference.supporting_facts).issubset(delivered_facts)
    else:
        support_scores = set_metrics(delivered_docs, set(reference.support_ids))
        coverage = set(reference.support_ids).issubset(delivered_docs)
    answer_correct = bool(answer_scores["answer_em"])
    terminal_success = answer_correct and coverage and not answer.abstain
    joint_precision = answer_scores["answer_precision"] * support_scores["support_precision"]
    joint_recall = answer_scores["answer_recall"] * support_scores["support_recall"]
    joint_f1 = 2 * joint_precision * joint_recall / (joint_precision + joint_recall) if joint_precision + joint_recall else 0.0
    return {
        **answer_scores,
        **support_scores,
        "joint_precision": joint_precision,
        "joint_recall": joint_recall,
        "joint_f1": joint_f1,
        "answer_correct": answer_correct,
        "support_coverage": coverage,
        "terminal_success": terminal_success,
    }

