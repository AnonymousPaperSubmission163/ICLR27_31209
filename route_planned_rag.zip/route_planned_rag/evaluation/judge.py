from __future__ import annotations

import re

from route_planned_rag.evaluation.provenance import metric_namespace


MISTRAL_JUDGE_PROMPT = """Judge whether the response is semantically equivalent to the reference answer for the question.
Do not solve the question independently. Return exactly `correct: yes` or `correct: no`.

Question: {question}
Reference answer: {reference}
Response: {response}
"""


class MistralOfflineJudge:
    evaluator_kind = "mistral_judge"

    def __init__(self, backend, model_id: str, revision: str):
        self.backend = backend
        self.model_id = model_id
        self.revision = revision

    def judge(self, question: str, response: str, reference: str) -> tuple[dict, object]:
        result = self.backend.generate(
            MISTRAL_JUDGE_PROMPT.format(question=question, reference=reference, response=response),
            temperature=0.0,
            top_p=1.0,
            max_tokens=16,
        )
        match = re.search(r"correct\s*:\s*(yes|no)", result.text, flags=re.IGNORECASE)
        if not match:
            raise RuntimeError(f"Mistral judge output could not be parsed: {result.text[:200]}")
        correct = match.group(1).casefold() == "yes"
        return {
            "metric_namespace": metric_namespace(evaluator_kind="mistral_judge", judge_model=self.model_id),
            "metric_label": "Accuracy (Mistral judge)",
            "correct": correct,
            "judge_model": self.model_id,
            "judge_revision": self.revision,
            "not_official_answer_evaluator": True,
        }, result
