from __future__ import annotations

import random
from collections import defaultdict
from typing import Iterable


def paired_question_bootstrap_ci(
    rows: Iterable[tuple[str, float, float]],
    *,
    resamples: int = 10_000,
    seed: int = 20260904,
    alpha: float = 0.05,
) -> dict[str, float | int]:
    """Paired percentile CI with question IDs as the sampling clusters."""
    grouped: dict[str, list[float]] = defaultdict(list)
    for question_id, method_value, control_value in rows:
        grouped[str(question_id)].append(float(method_value) - float(control_value))
    if not grouped:
        raise ValueError("paired CI needs at least one question")
    cluster_means = [sum(values) / len(values) for _, values in sorted(grouped.items())]
    observed = sum(cluster_means) / len(cluster_means)
    rng = random.Random(seed)
    draws = []
    for _ in range(resamples):
        sample = [cluster_means[rng.randrange(len(cluster_means))] for _ in cluster_means]
        draws.append(sum(sample) / len(sample))
    draws.sort()
    lower = draws[max(0, int((alpha / 2) * resamples))]
    upper = draws[min(resamples - 1, int((1 - alpha / 2) * resamples) - 1)]
    return {
        "paired_difference": observed,
        "ci_lower": lower,
        "ci_upper": upper,
        "question_clusters": len(cluster_means),
        "resamples": resamples,
        "seed": seed,
    }
