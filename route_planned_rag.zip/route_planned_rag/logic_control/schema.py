"""Question-only conjunctive queries with explicit variables and projections."""
import re
from typing import Literal
from pydantic import Field,model_validator
from route_planned_rag.prototype.schemas import Strict
from route_planned_rag.indexed.schema import explicit_in_question,norm

class Need(Strict):
    s:str
    r:str
    o:str
    kind:Literal['entity','person','organization','place','work','event','category','number','date','frequency','boolean']='entity'
    subject_kind:Literal['entity','person','organization','place','work','event','category']='entity'
    scope:str|None=None
    span:str

class Goal(Strict):
    op:Literal['select','greater','earlier','same']='select'
    variable:str|None=None
    left:str|None=None
    right:str|None=None
    count:int|None=Field(default=None,ge=1,le=30)

class Plan(Strict):
    interpretation:str=Field(default='',max_length=900)
    needs:list[Need]=Field(min_length=1,max_length=12)
    goal:Goal
    choices:dict[str,list[str]]=Field(default_factory=dict)
    unrepresented:list[str]=Field(default_factory=list)

    def checked(self,question):
        variables=set(self.choices)
        for v,values in self.choices.items():
            if not re.fullmatch(r'\?[a-z][a-z0-9_]*',v) or not values or len(values)>8:
                raise ValueError('invalid finite subject domain')
            if any(norm(x) not in norm(question) for x in values):raise ValueError('domain names must come from the question')
        types={v:'entity' for v in variables};connected=set(variables);links=[]
        for i,n in enumerate(self.needs):
            if not n.r.strip() or not n.span.strip() or norm(n.span) not in norm(question):
                raise ValueError('each requirement must cite a verbatim question span')
            for t in [n.s,n.o]:
                if t.startswith('?'):
                    if not re.fullmatch(r'\?[a-z][a-z0-9_]*',t):raise ValueError('invalid variable')
                    variables.add(t)
                elif t not in ('true','false') and not explicit_in_question(t,question):raise ValueError('literal must come from question: '+t)
            local={t for t in [n.s,n.o] if t.startswith('?')};links.append(local)
            if any(not t.startswith('?') and t not in ('true','false') for t in [n.s,n.o]):connected.update(local)
            if n.o.startswith('?'):
                if n.o in types and types[n.o] not in (n.kind,'entity') and n.kind!='entity':raise ValueError('variable has incompatible output types')
                types[n.o]=n.kind
            if n.scope is not None and not explicit_in_question(n.scope,question):raise ValueError('time scope must come from the question')
        for _ in self.needs:
            for link in links:
                if link&connected:connected.update(link)
        if not variables<=connected:raise ValueError('unanchored variables cannot be acquired from the question')
        for n in self.needs:
            if n.s.startswith('?') and types.get(n.s) in ('number','date','frequency'):
                raise ValueError('scalar output cannot be the subject of an entity relation')
        g=self.goal
        if g.op=='select':
            if g.variable not in variables or g.left or g.right:raise ValueError('select requires one bound answer variable')
            if re.match(r'How many\b',question,re.I) and types.get(g.variable)!='number':raise ValueError('count question must project a number')
            if re.match(r'(?:In )?what year\b',question,re.I) and types.get(g.variable) not in ('number','date'):raise ValueError('year question must project a date/number')
        else:
            if g.variable is not None or g.left not in variables or g.right not in variables or g.left==g.right:
                raise ValueError('comparison requires two distinct bound variables')
        if self.unrepresented:raise ValueError('question conditions unrepresented: '+str(self.unrepresented))
        return self

PLAN_PROMPT='''Translate only the QUESTION into the smallest conjunction of required relations. No answers or remembered facts. First write interpretation: identify the requested value, named anchors, intermediate entities and every restriction in two short sentences. Then needs, goal, choices:{}, unrepresented:[] .
Need: {s:subject,r:relation,o:object,kind:object type,span:exact question phrase}. Use named question entities DIRECTLY. Unknown entities use ?variables; reuse a variable to mean the SAME entity. Either end may be a variable. Do not add "name", "same as", or type-declaration nodes for already named entities. choices is ONLY for explicitly offered alternatives A or B, never for types or unknown values.
Goal {op:"select",variable:"?x"} returns the requested variable after ALL needs hold. Shared school: (A,graduated from,?school) AND (B,graduated from,?school); select ?school. Singer with known birth date: (named band,lead singer,?person) AND (?person,birth date,question date); select ?person. A requested qualification can be one boolean need: (?person,has an independent series with its own logo,true); kind=boolean. Do not invent unknown names for the series/logo. Lists use ONE relation with multiple rows, not three separate category variables. count is ONLY an explicit requested answer count.
Comparison: (named A,attribute,?a), (named B,attribute,?b), goal {op:"greater"|"earlier"|"same",left:"?a",right:"?b"}. Greater/earlier return the subject with the winning value. For choice A or B use choices={"?candidate":["A","B"]} and a single filter on ?candidate, never require it to equal both names.
Types: person,organization,place,work,event,category,entity,number,date,frequency,boolean. A named date/year condition is a literal object; a time restriction on membership or an event is scope. Preserve every requested qualifier; no extra tests. Membership does not mean founded/led. Missing evidence is NOT unrepresented semantics. Quotes in span are verbatim, never ellipses. No facts, evidence or final answer.'''

PLAN_PROMPT+='''
Use proper names, not descriptions, as entity constants. "the actor in [title]" means (?actor,acted in,title), not a person literally named "actor". "X's union" means (X,member of,?union); then (?union,number of members,?count,scope=question year). A person's two occupations describe the SAME person, not a new person connected by an occupation noun. A band's song does not require an unnamed band member. Handshake deals, likenesses and other unnamed events can be expressed as a direct qualified relation between the named participants; do not demand names for them.
Relations must state the attribute being read: species count, publication frequency, founded in, served as. Never use vague "count", "has", "in" alone. Frequency uses kind=frequency. Roles like "sixth governor" are category/boolean, not a numeric quantity. A title excludes external possessives and terminal question punctuation. Include geographical, ordinal, temporal and superlative conditions explicitly. Represent constraints, not presumed answers.'''

def plan_schema(question):
    """The decoder permits question literals and variables, never answer constants."""
    schema=Plan.model_json_schema();spans={question}
    schema['required']=list(dict.fromkeys(['interpretation',*schema.get('required',[])]))
    tokens=list(re.finditer(r'\S+',question))
    for i in range(len(tokens)):
        for j in range(i,min(len(tokens),i+16)):
            text=question[tokens[i].start():tokens[j].end()]
            spans.add(text);spans.add(text.strip('?,.\"'))
    for m in re.finditer(r'"([^"\n]+)"',question):spans.add(m[1])
    # Explicit dates can be represented canonically without adding knowledge.
    from route_planned_rag.indexed.schema import parse_date
    for text in list(spans):
        if parsed:=parse_date(text):spans.add(parsed[0].strftime('%Y' if parsed[1]=='year' else '%Y-%m-%d'))
    literals=sorted(s for s in spans if s)
    schema['$defs']['Need']['properties']['span']={'enum':[s for s in literals if norm(s) in norm(question)]}
    term={'anyOf':[{'enum':literals+['true','false']},{'type':'string','pattern':r'^\?[a-z][a-z0-9_]{0,25}$'}]}
    for field in ['s','o']:schema['$defs']['Need']['properties'][field]=term
    if not re.search(r'\bor\b',question,re.I):schema['properties']['choices']={'type':'object','properties':{},'additionalProperties':False}
    else:schema['properties']['choices']['additionalProperties']={'type':'array','items':{'enum':literals},'maxItems':8}
    return schema
