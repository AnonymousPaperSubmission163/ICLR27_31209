"""Compositional relation paths; binding and projection are fixed by operators.

The model describes the path and filters. It cannot invent variable identities,
AND/OR wiring, or a projection that disagrees with the selected operator.
"""
from typing import Literal
from pydantic import Field
from route_planned_rag.prototype.schemas import Strict
from .schema import Plan,Need,Goal,plan_schema

Kind=Literal['entity','person','organization','place','work','event','category','number','date','frequency','boolean']
class Filter(Strict):
    relation:str
    value:str='true'
    kind:Kind='boolean'
    span:str
class Hop(Strict):
    relation:str
    direction:Literal['forward','reverse']='forward'
    kind:Kind='entity'
    scope:str|None=None
    filters:list[Filter]=Field(default_factory=list,max_length=6)
    span:str
class PathQuery(Strict):
    anchor:str
    filters:list[Filter]=Field(default_factory=list,max_length=6)
    hops:list[Hop]=Field(max_length=5)
class Template(Strict):
    intent:str=Field(max_length=500)
    operator:Literal['select','greater','earlier','same']
    paths:list[PathQuery]=Field(min_length=1,max_length=4)
    choices:list[str]=Field(default_factory=list,max_length=8)
    count:int|None=Field(default=None,ge=1,le=30)
    unsupported:list[str]=Field(default_factory=list)

def compile_template(question,t):
    if t.operator!='select' and len(t.paths)!=2:raise ValueError('Comparison requires exactly two paths')
    choices=t.choices
    if choices and t.operator!='select' and set(choices)=={p.anchor for p in t.paths}:choices=[]
    if choices and (len(t.paths)!=1 or t.paths[0].anchor!='?choice'):raise ValueError('Alternatives use one path starting at ?choice')
    needs=[];ends=[]
    def filters(subject,items):
        for f in items:
            kind='category' if f.kind=='boolean' and f.value not in ('true','false') else f.kind
            relation=f.relation+' ['+f.span+']' if kind=='boolean' else f.relation
            needs.append(Need(s=subject,r=relation,o=f.value,kind=kind,span=f.span))
    for i,path in enumerate(t.paths):
        previous=path.anchor
        filters(previous,path.filters)
        for j,hop in enumerate(path.hops):
            final=j==len(path.hops)-1
            output='?answer' if final and t.operator=='select' else '?path'+str(i)+'step'+str(j)
            s,o=(previous,output) if hop.direction=='forward' else (output,previous)
            # kind in the core describes the object of a relation. On reverse
            # reads the input is an entity, while the unknown subject's type is
            # kept separately in the template audit.
            kind=hop.kind if hop.direction=='forward' else 'entity'
            subject_kind=hop.kind if hop.direction=='reverse' and hop.kind not in ('number','date','frequency','boolean') else 'entity'
            needs.append(Need(s=s,r=hop.relation,o=o,kind=kind,subject_kind=subject_kind,scope=hop.scope,span=hop.span));filters(output,hop.filters);previous=output
        ends.append(previous)
    if t.operator=='select':
        if len(set(ends))!=1:raise ValueError('Intersection paths must terminate at the same unknown answer')
        from .compiler import requested_count
        count=requested_count(question)
        if t.count is not None and count!=t.count:raise ValueError('An answer count must be explicitly requested by the question')
        goal=Goal(variable=ends[0],count=count)
    else:goal=Goal(op=t.operator,left=ends[0],right=ends[1])
    p=Plan(interpretation=t.intent,needs=needs,goal=goal,choices={'?choice':choices} if choices else {},unrepresented=t.unsupported)
    p.checked(question)
    return p,dict(template=t.model_dump(),compiled_plan=p.model_dump(),phase='question_only_before_freeze',uses_answers_or_retrieved_facts=False,
                  operator_semantics='path composition; select paths share output; comparisons keep distinct outputs; every filter is conjunctive')

def template_schema(question):
    import re
    schema=Template.model_json_schema();old=plan_schema(question)
    literals=old['$defs']['Need']['properties']['s']['anyOf'][0]['enum']
    schema['$defs']['PathQuery']['properties']['anchor']={'enum':[x for x in literals if x not in ('true','false')]+['?choice']}
    for name in ['Hop','Filter']:schema['$defs'][name]['properties']['span']=old['$defs']['Need']['properties']['span']
    schema['$defs']['Filter']['properties']['value']={'enum':literals}
    schema['properties']['choices']={'type':'array','items':{'enum':literals},'maxItems':8 if re.search(r'\bor\b',question,re.I) else 0}
    return schema

TEMPLATE_PROMPT='''Translate only the QUESTION into relation paths. Never answer it or use remembered facts. Write a short intent, then operator, paths, choices:[], count:null, unsupported:[].
Each path starts at a named anchor copied from the question. A hop reads one relation, producing the input for the next hop. Hop fields: relation, direction (forward or reverse), kind (the produced value type), scope (time restriction or null), filters:[], span (verbatim question phrase). Filters test the current entity: {relation,value,kind,span}; unary property uses value="true",kind="boolean". Keep all question restrictions in relations or filters.
For select, return the LAST value of each path; multiple paths must all reach the SAME answer. Example: common schools of A and B = path A -> graduated from, path B -> graduated from. Chain: birthplace of the director of a named film = film -> directed by (person) -> born in (place). If the question says author of a named book, use book -> wrote REVERSE (person), not a person literally named author. Two occupations are filters on ONE person, not two people.
An actor in a film who won an award: film -> acted in REVERSE (person) -> won (work). A band member with a known birth date: band -> member (person), filtered by birth date=question date,kind=date. An organization belonging to a person: named person -> member of (organization), then the requested attribute; do not use "person's organization" as a proper name. Preserve years as scope on the relevant hop.
For greater/earlier/same, give exactly two paths whose final values are compared. Kind number for counts, frequency for issues per month, date for time comparisons. Greater/earlier return the winning entity; same returns yes/no when established. For A or B matching a property, use choices:[A,B], a single path with anchor="?choice", no hops, and the property as a root filter. Select returns the qualifying choice.
Lists use ONE path with multiple possible rows. count is ONLY the explicitly requested number of answers. Do not create names for unnamed deals, logos, or series: express these as direct qualified relations or boolean filters. Kinds: entity,person,organization,place,work,event,category,number,date,frequency,boolean. No vague relations like "has" or "in". No free variables besides ?choice; the program creates consistent bindings and conjunctions. No facts, evidence or final answer.'''

# The raw transformers decoder does not expose its JSON schema to the model.
# These examples make the field semantics visible before constrained decoding.
TEMPLATE_EXAMPLES='''
OUTPUT EXAMPLES (invented questions, no answers):
Question: Where was the director of Indigo Road born?
{"intent":"Find the film director, then their birthplace.","operator":"select","paths":[{"anchor":"Indigo Road","filters":[],"hops":[{"relation":"directed by","direction":"forward","kind":"person","scope":null,"filters":[],"span":"director of Indigo Road"},{"relation":"birthplace","direction":"forward","kind":"place","scope":null,"filters":[],"span":"born"}]}],"choices":[],"count":null,"unsupported":[]}
Question: Which school did Nora and Ivo graduate from?
{"intent":"Find a school shared by both people.","operator":"select","paths":[{"anchor":"Nora","filters":[],"hops":[{"relation":"graduated from","direction":"forward","kind":"organization","scope":null,"filters":[],"span":"graduate from"}]},{"anchor":"Ivo","filters":[],"hops":[{"relation":"graduated from","direction":"forward","kind":"organization","scope":null,"filters":[],"span":"graduate from"}]}],"choices":[],"count":null,"unsupported":[]}
Question: Which author was born in Rome, Nora or Ivo?
{"intent":"Filter the two named candidates by birthplace.","operator":"select","paths":[{"anchor":"?choice","filters":[{"relation":"birthplace","value":"Rome","kind":"place","span":"born in Rome"}],"hops":[]}],"choices":["Nora","Ivo"],"count":null,"unsupported":[]}
Question: How many members did Nora's union have in 2010?
{"intent":"Find Nora's union, then its membership count in the requested year.","operator":"select","paths":[{"anchor":"Nora","filters":[],"hops":[{"relation":"member of","direction":"forward","kind":"organization","scope":null,"filters":[],"span":"Nora's union"},{"relation":"number of members","direction":"forward","kind":"number","scope":"2010","filters":[],"span":"members"}]}],"choices":[],"count":null,"unsupported":[]}
For reverse reads, relation(output, input) must be the true statement: book -> wrote REVERSE yields its writer; film -> directed by FORWARD yields its director. Never copy entity names from these examples into a different question.
'''

TEMPLATE_PROMPT+=TEMPLATE_EXAMPLES
