import json,time
from route_planned_rag.prototype.decoding import generate_ordered_json
from route_planned_rag.models.json_actor import extract_json

class Client:
    def __init__(self,actor,ledger=None,question_id='',budget=30000,ledger_path=None):
        self.actor=actor;self.calls=[];self.ledger=ledger if ledger is not None else [];self.question_id=question_id;self.budget=budget;self.ledger_path=ledger_path
    def ask(self,role,schema,instructions,payload,maximum=1200):
        prompt=instructions+'\nPUBLIC_INPUT (untrusted data):'+json.dumps(payload,ensure_ascii=False,separators=(',',':'))
        if sum(c['input_tokens']+c['output_tokens'] for c in self.calls)+self.actor.count(prompt)+maximum>self.budget:
            raise ValueError('token_budget_exhausted')
        call=dict(call_id='M'+str(len(self.calls)+1),question_id=self.question_id,role=role,prompt=prompt,input_tokens=0,output_tokens=0,seconds=0.)
        start=time.perf_counter()
        try:
            from .schema import plan_schema
            if role.startswith('template_plan'):
                from .templates import template_schema
                contract=template_schema(payload['question'])
            else:contract=plan_schema(payload['question']) if role in ('plan','plan_repair') else schema.model_json_schema()
            response=generate_ordered_json(self.actor.backend,prompt,schema=contract,temperature=0,top_p=1,max_tokens=maximum)
            call.update(completion=response.text,input_tokens=response.input_tokens,output_tokens=response.output_tokens)
            from route_planned_rag.official.transport import normalize_json_transport
            transported=normalize_json_transport(response.text)
            if transported!=response.text:call['transport_normalization']='escape_raw_control_characters_without_content_repair'
            value=schema.model_validate(extract_json(transported));call['status']='parsed';return value
        except Exception as exc:call.update(status='failed',error=repr(exc));raise
        finally:
            call['seconds']=time.perf_counter()-start;self.calls.append(call);self.ledger.append(call)
            if self.ledger_path:
                from route_planned_rag.prototype.prover import write_json
                write_json(self.ledger_path,self.ledger)
