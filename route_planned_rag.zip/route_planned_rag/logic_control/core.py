"""Finite relational query execution, explicit conflicts and grounded Prover9 certificates.

The query defines requirements, never facts. Reader proposals need original spans;
semantic acceptance is a separate state and cannot be supplied by the answer model.
"""
import re
from decimal import Decimal
from itertools import product
from pydantic import Field
from route_planned_rag.prototype.schemas import Strict,Atom,Term,RuleSpec
from route_planned_rag.prototype.logic import digest,substitute,unify,opposite,key,ground
from route_planned_rag.indexed.schema import norm,parse_date
from route_planned_rag.indexed.store import value_witness
from .schema import Plan

class Row(Strict):
    node:int=Field(ge=0,le=11)
    s:str
    o:str
    evidence_id:str
    quote:str
    negated:bool=False
    scope:str|None=None

class Reading(Strict):
    rows:list[Row]=Field(default_factory=list,max_length=48)
    complete:list[int]=Field(default_factory=list,max_length=12)
    missing:list[str]=Field(default_factory=list,max_length=12)

def lexical(value):
    return ' '.join(re.findall(r'\w+',value.casefold()))

def align_quote(quote,source):
    """Locate a real continuous span; tolerate whitespace and typographic quotes only."""
    if quote in source:return quote,dict(start=source.index(quote),end=source.index(quote)+len(quote),method='exact')
    def normalized(text):
        chars=[];positions=[]
        for i,c in enumerate(text):
            if c.isspace():
                if chars and chars[-1]!=' ':chars.append(' ');positions.append(i)
            else:chars.append(c.translate(str.maketrans({'“':'"','”':'"','‘':"'",'’':"'"})));positions.append(i)
        # Keep leading whitespace aligned with the original position map.
        return ''.join(chars),positions
    q,_=normalized(quote);q=q.strip();s,offsets=normalized(source)
    if not q or q not in s:return None,None
    start=s.index(q);lo,hi=offsets[start],offsets[start+len(q)-1]+1
    return source[lo:hi],dict(start=lo,end=hi,method='whitespace_typographic_alignment')

def date_bounds(value):
    from datetime import datetime
    parsed=parse_date(value)
    if parsed is None:return None
    date,precision=parsed
    if precision=='year':return date,datetime(date.year,12,31)
    return date,date

def quantity(value,kind='number'):
    """Source surface to exact quantity or explicit interval. Never guess bounds."""
    s=norm(value).replace(',','')
    words={'zero':0,'one':1,'single':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,'eight':8,'nine':9,'ten':10,'eleven':11,'twelve':12}
    if kind=='frequency':
        rates={'daily':365,'weekly':52,'fortnightly':26,'monthly':12,'quarterly':4,'annually':1,'yearly':1,'every two months':6,'twice a month':24}
        if s in rates:return dict(lower=str(rates[s]),upper=str(rates[s]),lower_open=False,upper_open=False,unit='per_year',rule='explicit_frequency_word')
        # bimonthly and biweekly have two conventional senses: keep unknown.
        m=re.fullmatch(r'(\d+) (?:issues|times)(?: (?:per|a|each)) (month|year)',s)
        if m:
            n=Decimal(m[1])*(12 if m[2]=='month' else 1)
            return dict(lower=str(n),upper=str(n),lower_open=False,upper_open=False,unit='per_year',rule='explicit_frequency_unit_conversion')
        return None
    if s=='monotypic':s='1'
    m=re.fullmatch(r'(?:(at least|at most|more than|less than|over|under) )?([+-]?\d+(?:\.\d+)?|'+ '|'.join(words)+r')',s)
    if not m:return None
    modifier,raw=m.groups();n=Decimal(words[raw]) if raw in words else Decimal(raw)
    lower,upper=str(n),str(n)
    if modifier in ('at least','more than','over'):upper=None
    if modifier in ('at most','less than','under'):lower=None
    return dict(lower=lower,upper=upper,lower_open=modifier in ('more than','over'),upper_open=modifier in ('less than','under'),unit='count',rule='explicit_numeric_surface')

def compare_quantities(a,b):
    if not a or not b or a['unit']!=b['unit']:return None
    def greater(x,y):
        if x['lower'] is None or y['upper'] is None:return False
        lo,hi=Decimal(x['lower']),Decimal(y['upper'])
        return lo>hi or (lo==hi and (x['lower_open'] or y['upper_open']))
    return 0 if greater(a,b) else 1 if greater(b,a) else None

class Store:
    def __init__(self,question,plan):
        self.question=question;self.plan=plan.checked(question);self.plan_hash=digest(plan)
        self.evidence={};self.rows={};self.rejected=[];self.reviewed={};self.version=0
        self.aliases={};self.names={};self.lookups=0;self.certificates=[];self.alias_version=0
    def observe(self,evidence):
        for e in evidence:
            eid=e['evidence_id']
            if eid in self.evidence and self.evidence[eid]['original_text']!=e['original_text']:raise ValueError('original evidence changed')
            self.evidence[eid]=e
        definitions={}
        for eid,e in self.evidence.items():
            title=e['source_metadata']['title'];text=e['original_text']
            disambiguated=re.fullmatch(r'(.+) \([^()]+\)',title)
            if disambiguated and re.match(r'^'+re.escape(disambiguated[1])+r'\s+(?:is|was)\b',text):
                for alias in [title,disambiguated[1]]:definitions.setdefault(lexical(alias),[]).append(dict(canonical=lexical(title),display=disambiguated[1],evidence_id=eid,definition=text.split('.')[0]))
            # The title identifies the subject defined by a biographical lead.
            m=re.match(r'^([A-Z][A-Za-z .\'"-]{1,110}?)\s*\((?:born )?[^)]*\b\d{4}\b[^)]*\)\s+(?:is|was)\b',text)
            if m and lexical(title).split()[-1:]==lexical(m[1]).split()[-1:]:
                for alias in [title,m[1]]:definitions.setdefault(lexical(alias),[]).append(dict(canonical=lexical(title),display=m[1],evidence_id=eid,definition=m[0]))
            # Explicit expanded organization name and acronym in its lead.
            m=re.match(r'^(?:The )?([A-Z][^()]{2,100}?)\s*\(([A-Z]{2,10})(?: or [A-Z]{2,10})?\)',text)
            if m:
                variants=[m[1],m[2]]
                if lexical(m[1]).startswith(lexical(title)+' of '):variants.append(title)
                for alias in variants:
                    definitions.setdefault(lexical(alias),[]).append(dict(canonical=lexical(m[1]),display=m[1],evidence_id=eid,definition=m[0]))
        aliases={a:ds[0] for a,ds in definitions.items() if len({d['canonical'] for d in ds})==1}
        if aliases!=self.aliases:
            self.aliases=aliases;self.alias_version+=1;self.version+=1
            for certificate in self.certificates:certificate['valid']=False
    def canonical(self,value,kind='entity'):
        if kind=='date' and (d:=parse_date(value)):
            return d[0].strftime('%Y' if d[1]=='year' else '%Y-%m-%d')
        if kind in ('number','frequency') and (q:=quantity(value,kind)):
            return 'quantity:'+digest({k:v for k,v in q.items() if k!='rule'})
        k=lexical(value);return self.aliases.get(k,{}).get('canonical',k)
    def term(self,value,kind='entity'):
        if value.startswith('?'):return Term(kind='variable',name=value[1:],entity_type='entity')
        c=self.canonical(value,kind);t=Term(kind='constant',name='e'+digest(c),entity_type='entity')
        self.names[t.name]=self.aliases.get(lexical(value),{}).get('display',value)
        return t
    def pattern(self,i):
        n=self.plan.needs[i]
        return Atom(predicate='r'+digest([norm(n.r),n.scope]),arguments=[self.term(n.s),self.term(n.o,n.kind)],negated=False)
    def row_atom(self,row):
        n=self.plan.needs[row['node']]
        return Atom(predicate=self.pattern(row['node']).predicate,arguments=[self.term(row['s']),self.term(row['o'],n.kind)],negated=row['negated'])
    def propose(self,reading,call_id):
        accepted=[]
        for row in reading.rows:
            r=row.model_dump();rid='F'+digest(r);r.update(id=rid,extraction_call=call_id,status='proposed',base_status='proposed',reason=None)
            e=self.evidence.get(row.evidence_id)
            n=self.plan.needs[row.node] if row.node<len(self.plan.needs) else None
            aligned,alignment=align_quote(row.quote,e['original_text']) if e and row.quote else (None,None)
            if n is None:r['reason']='unknown_requirement'
            elif not e or not aligned:r['reason']='quote_not_an_observed_exact_span'
            elif not row.s.strip() or not row.o.strip() or row.s.startswith('?') or row.o.startswith('?'):r['reason']='fact_is_not_ground'
            else:
                r.update(quote=aligned,original_quote=row.quote,quote_alignment=alignment)
                source=e['source_metadata']['title']+' '+aligned
                for field,kind in [('s','entity'),('o',n.kind)]:
                    value=getattr(row,field);witness=lexical(value) in lexical(source)
                    if field=='o' and kind=='boolean' and value in ('true','false'):witness=True
                    if not witness and (alias:=self.aliases.get(lexical(value))):
                        witness=any(d['canonical']==alias['canonical'] and a in lexical(source) for a,d in self.aliases.items())
                    if not witness and kind in ('date','number'):
                        witness=value_witness(value,kind,source) is not None
                    if not witness:r['reason']='argument_has_no_source_witness:'+field
                if row.scope!=n.scope:r['reason']='scope_mismatch'
                if row.scope and row.scope not in e['original_text']:r['reason']='scope_has_no_source_witness'
                if not n.s.startswith('?') and self.canonical(row.s)!=self.canonical(n.s):r['reason']='literal_subject_mismatch'
            if r['reason']:
                r['status']='rejected';self.rejected.append(r);continue
            if n.kind=='boolean' and row.o=='false':
                r.update(original_boolean_value='false',o='true',negated=not row.negated)
            if rid not in self.rows:self.rows[rid]=r;self.version+=1
            accepted.append(rid)
        return accepted
    def set_status(self,ids,status,reason):
        if status not in ('accepted','rejected','conflicted','proposed'):raise ValueError(status)
        for rid in ids:
            if rid not in self.rows:raise ValueError('review references absent fact')
            self.rows[rid].update(status=status,base_status=status,reason=reason);self.version+=1
        self.detect_conflicts()
        for certificate in self.certificates:
            certificate['valid']=self.certificate_valid(certificate)
    def certificate_valid(self,certificate):
        return certificate.get('alias_version')==self.alias_version and all(
            rid.startswith('QD') or self.rows.get(rid,{}).get('status')=='accepted'
            for rid in certificate['input_fact_ids'])
    def detect_conflicts(self):
        active={}
        for rid,r in self.rows.items():
            r['status']=r.get('base_status',r['status'])
            if r['status']=='accepted':active.setdefault(key(self.row_atom(r)),[]).append(rid)
        for rid,r in self.rows.items():
            if r['status']=='accepted' and key(opposite(self.row_atom(r))) in active:r['status']='conflicted'
    def initial(self):
        names=list(self.plan.choices)
        return [{v[1:]:self.term(value) for v,value in zip(names,values)} for values in product(*(self.plan.choices[n] for n in names))]
    def joins(self,statuses=('accepted',),partial=False):
        self.lookups+=1;rows=[dict(binding=b,facts=[],missing=[]) for b in self.initial()]
        for i,_ in enumerate(self.plan.needs):
            pattern=self.pattern(i);next_rows=[]
            for row in rows:
                hits=[]
                for rid,r in self.rows.items():
                    if r['status'] not in statuses:continue
                    a=self.row_atom(r);b=unify(substitute(pattern,row['binding']),a,row['binding'])
                    if b is not None:hits.append(dict(binding=b,facts=sorted(set(row['facts']+[rid])),missing=row['missing']))
                next_rows.extend(hits)
                # Missing-premise planning must be able to bind a shared output
                # from either side. Always keep the hypothetical omission until
                # later constraints decide which consistent partial join is best.
                if partial:next_rows.append(dict(row,missing=row['missing']+[i]))
            rows=next_rows
            if len(rows)>1024:raise ValueError('binding budget exhausted')
        return rows
    def candidates(self,statuses=('accepted',)):
        out=[];g=self.plan.goal
        for row in self.joins(statuses):
            computation=None
            if g.op=='select':term=row['binding'].get(g.variable[1:]);value=self.names.get(term.name) if term else None
            else:
                terms=[row['binding'].get(v[1:]) for v in [g.left,g.right]]
                if any(t is None for t in terms):continue
                values=[self.names[t.name] for t in terms]
                owners=[];kinds=[]
                for v in [g.left,g.right]:
                    ns=[(i,n) for i,n in enumerate(self.plan.needs) if n.o==v]
                    if len(ns)!=1:break
                    i,n=ns[0];owners.append(substitute(self.pattern(i),row['binding']).arguments[0]);kinds.append(n.kind)
                if len(owners)!=2:continue
                if g.op=='greater':
                    amounts=[quantity(v,k) for v,k in zip(values,kinds)];winner=compare_quantities(*amounts)
                    if winner is None:continue
                    value=self.names[owners[winner].name];computation=dict(op='explicit_interval_comparison',inputs=values,quantities=amounts,winner=winner)
                elif g.op=='earlier':
                    dates=[date_bounds(v) for v in values]
                    if any(d is None for d in dates):continue
                    winner=0 if dates[0][1]<dates[1][0] else 1 if dates[1][1]<dates[0][0] else None
                    if winner is None:continue
                    value=self.names[owners[winner].name];computation=dict(op='explicit_date_interval_comparison',inputs=values,intervals=[[d.isoformat() for d in interval] for interval in dates],winner=winner)
                else:
                    if terms[0]!=terms[1]:continue # no arbitrary closed-world inequality
                    value='yes';computation=dict(op='canonical_identity',inputs=values)
                term=self.term(value)
            if value and g.op=='select' and re.search(r'\bwhat year\b|\bwhich year\b',self.question,re.I) and (date:=parse_date(value)):
                original=value;value=date[0].strftime('%Y')
                computation=dict(op='requested_year_projection',source_value=original,output=value,rule='calendar_year_of_source_date');term=self.term(value)
            if value:out.append(dict(value=value,term=term,binding=row['binding'],facts=row['facts'],computation=computation))
        if g.count is not None and len({c['term'].name for c in out})!=g.count:return []
        return out
    def prove(self,candidate,prover):
        facts=[(rid,self.row_atom(self.rows[rid])) for rid in candidate['facts'] if self.rows[rid]['status']=='accepted']
        if len(facts)!=len(candidate['facts']):return None
        body=[self.pattern(i) for i in range(len(self.plan.needs))]
        # Finite domains are question-defined alternatives, not retrieved world
        # facts. Include their membership premises in the certificate explicitly.
        question_fact_ids=set()
        for v,values in self.plan.choices.items():
            pattern=Atom(predicate='question_domain_'+v[1:],arguments=[self.term(v)],negated=False)
            body.append(pattern)
            for value in values:
                fid='QD'+digest([v,value]);question_fact_ids.add(fid)
                facts.append((fid,pattern.model_copy(update={'arguments':[self.term(value)]})))
        if self.plan.goal.op=='select':head=Atom(predicate='answer',arguments=[Term(kind='variable',name=self.plan.goal.variable[1:],entity_type='entity')],negated=False)
        else:head=Atom(predicate='comparison_inputs',arguments=[Term(kind='variable',name=v[1:],entity_type='entity') for v in [self.plan.goal.left,self.plan.goal.right]],negated=False)
        rule=RuleSpec(id='question_conjunction',body=body,head=head,origin='question_definition',source_refs=[],explanation='All fixed question requirements, with explicit shared variables and projection.')
        target=substitute(head,candidate['binding'])
        if not ground(target):return None
        certificate=prover.prove(facts,[(rule.id,rule)],[target],version=self.plan_hash)
        certificate['valid']=all(rid in question_fact_ids or self.rows[rid]['status']=='accepted' for rid in certificate['input_fact_ids'])
        certificate['alias_version']=self.alias_version;self.certificates.append(certificate)
        return certificate if certificate['result']=='proved' and certificate['valid'] and certificate['source_mapping_status']=='complete' else None
    def snapshot(self):
        return dict(plan=self.plan.model_dump(),plan_hash=self.plan_hash,version=self.version,rows=self.rows,rejected=self.rejected,evidence=self.evidence,aliases=self.aliases,alias_version=self.alias_version)
