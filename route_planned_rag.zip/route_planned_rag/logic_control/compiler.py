"""Question-only normalization before the information nodes are frozen.

Equality is a binding constraint, cardinality is a set operator, and an unneeded
existential witness is not a request to invent a proper name. Raw proposals and
every compilation operation are retained for audit.
"""
import re
from collections import Counter
from .schema import Plan
from .core import quantity

def requested_count(question):
    m=re.match(r'^(?:What|Which) (\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b',question,re.I)
    if not m:return None
    q=quantity(m[1].lower())
    return int(q['lower']) if q and q['lower']==q['upper'] else None

def question_operator(question):
    if re.search(r'\bmore\b|\bgreater\b|\blarger\b',question,re.I):return 'greater'
    if re.search(r'\bearlier\b|\bolder\b|\bborn first\b',question,re.I):return 'earlier'
    if re.match(r'^(?:Is|Are|Was|Were|Do|Did)\b',question,re.I) and re.search(r'\bsame\b',question,re.I):return 'same'
    return 'select'

def compile_plan(question,proposal):
    p=proposal.model_copy(deep=True);changes=[];substitutions={};keep=[]
    def resolve(v):
        while v in substitutions:v=substitutions[v]
        return v
    person_vars={n.o for n in p.needs if n.o.startswith('?') and n.kind=='person'}
    for i,n in enumerate(p.needs):
        role=n.r.strip().lower()
        if n.s in person_vars and n.s.startswith('?') and n.o.startswith('?') and n.kind=='person' and re.fullmatch(r'artist|animator|actor|actress|director|writer|author|politician',role) and re.search(r'\band\s+'+role+r'\b',n.span,re.I):
            substitutions[n.o]=resolve(n.s)
            changes.append(dict(operation='person_role_apposition',original_node=i,subject=n.s,role=role,alias=n.o,question_span=n.span))
            n.r='is an '+role;n.o='true';n.kind='boolean';keep.append(n)
            continue
        if re.fullmatch(r'(?:is )?same as|equals',n.r.strip(),re.I) and n.s.startswith('?') and n.o.startswith('?'):
            a,b=resolve(n.s),resolve(n.o)
            if a!=b:
                chosen=a if a in p.choices else b if b in p.choices else a
                substitutions[b if chosen==a else a]=chosen
            changes.append(dict(operation='variable_equality_substitution',original_node=i,left=n.s,right=n.o))
        else:keep.append(n)
    for n in keep:n.s=resolve(n.s);n.o=resolve(n.o)
    for field in ['variable','left','right']:
        value=getattr(p.goal,field)
        if value:setattr(p.goal,field,resolve(value))
    choices={}
    for v,values in p.choices.items():
        v=resolve(v);choices[v]=[x for x in choices[v] if x in values] if v in choices else values
    p.choices=choices;p.needs=keep
    expected_op=question_operator(question)
    if expected_op=='select' and p.goal.op!='select' and p.goal.variable:
        changes.append(dict(operation='question_answer_projection',old=p.goal.model_dump(),new_operator='select'))
        p.goal.op='select';p.goal.left=p.goal.right=None
    count=requested_count(question)
    if count is not None:
        if p.goal.count not in (None,count):raise ValueError('generated answer count contradicts question')
        p.goal.count=count;keep=[]
        for i,n in enumerate(p.needs):
            q=quantity(n.o)
            if n.s==p.goal.variable and re.fullmatch(r'count|number of items',n.r,re.I) and q and q['lower']==q['upper']==str(count):
                changes.append(dict(operation='lift_answer_set_cardinality',original_node=i,variable=n.s,count=count))
            else:keep.append(n)
        p.needs=keep
    occurrences=Counter(t for n in p.needs for t in [n.s,n.o] if t.startswith('?'))
    outputs={v for v in [p.goal.variable,p.goal.left,p.goal.right] if v}|set(p.choices)
    for i,n in enumerate(p.needs):
        if n.kind=='boolean' and not n.o.startswith('?') and n.o not in ('true','false'):
            n.kind='category';changes.append(dict(operation='literal_class_assertion',node=i))
        if n.o.startswith('?') and occurrences[n.o]==1 and n.o not in outputs and n.kind not in ('number','date','frequency','boolean'):
            changes.append(dict(operation='existential_property_guard',node=i,existential_variable=n.o,original_relation=n.r,question_span=n.span))
            n.r=n.r+' ['+n.span+']';n.o='true';n.kind='boolean'
        if n.kind=='number' and re.search(r'\bfrequency\b',n.r,re.I):
            n.kind='frequency';changes.append(dict(operation='frequency_type',node=i))
    p.checked(question)
    return p,dict(raw_proposal=proposal.model_dump(),compiled_plan=p.model_dump(),operations=changes,phase='question_only_before_freeze',uses_answers_or_retrieved_facts=False)
