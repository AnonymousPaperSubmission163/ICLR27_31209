"""Node-keyed extraction slots. Query variables stay inside the logical controller."""
from typing import Literal
import re
from pydantic import Field,create_model
from route_planned_rag.prototype.schemas import Strict
from .core import Reading

class SourceRow(Strict):
    subject:str
    value:str
    evidence_id:str
    sentence_ids:list[str]=Field(min_length=1,max_length=6)
    negated:bool=False
    scope:str|None=None

def original_sentences(evidence):
    """Lossless partition, retaining source offsets; never a summary or deletion."""
    passages=[];lookup={}
    for e in evidence:
        text=e['original_text'];cuts=[0]
        # Some public corpora concatenate sentences without a separating space.
        # Retain exact spans while allowing "...town.She..." boundaries. Avoid
        # decimals, initials and the same common abbreviations as spaced text.
        for m in re.finditer(r'[.!?](?:["”])?(?:\s+(?=[A-Z"“])|(?=[A-Z][a-z]))',text):
            prefix=text[:m.start()+1]
            if re.search(r'\b(?:[A-Za-z]|Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St)\.$',prefix):continue
            cuts.append(m.end())
        cuts.append(len(text))
        sentences=[]
        for start,end in zip(cuts,cuts[1:]):
            if start==end:continue
            sid=e['evidence_id']+'S'+str(len(sentences));sentence=dict(id=sid,text=text[start:end])
            sentences.append(sentence);lookup[sid]=dict(evidence_id=e['evidence_id'],start=start,end=end,text=text[start:end])
        assert ''.join(s['text'] for s in sentences)==text
        passages.append(dict(evidence_id=e['evidence_id'],title=e['source_metadata']['title'],sentences=sentences))
    return passages,lookup

def slot_schema(nodes,evidence):
    _,sentences=original_sentences(evidence)
    Row=create_model('OriginalSourceRow',__base__=SourceRow,evidence_id=(Literal[tuple(e['evidence_id'] for e in evidence)],...),sentence_ids=(list[Literal[tuple(sentences)]],Field(min_length=1,max_length=6)))
    Slot=create_model('RelationSlot',__base__=Strict,check=(str,Field(max_length=280)),rows=(list[Row],Field(max_length=24)))
    return create_model('RelationSlots',__base__=Strict,**{'N'+str(i):(Slot,...) for i in nodes})

def slots_to_reading(value,evidence):
    _,sentences=original_sentences(evidence);sources={e['evidence_id']:e['original_text'] for e in evidence}
    rows=[];missing=[]
    for name,slot in value.model_dump().items():
        node=int(name[1:])
        for row in slot['rows']:
            spans=[sentences[sid] for sid in row['sentence_ids']]
            if any(s['evidence_id']!=row['evidence_id'] for s in spans):raise ValueError('sentence belongs to a different cited source')
            # Keep the entire continuous interval, including intervening original text.
            quote=sources[row['evidence_id']][min(s['start'] for s in spans):max(s['end'] for s in spans)]
            row=dict(row,node=node,s=row['subject'],o=row['value'],quote=quote);del row['subject'];del row['value'];del row['sentence_ids'];rows.append(row)
        if not slot['rows']:missing.append(name+': '+slot['check'])
    return Reading(rows=rows,missing=missing)

SLOT_PROMPT='''Read each listed relation INDEPENDENTLY from the original passages. For each N slot, first write check (one brief sentence describing source support or what is missing), then rows. Row fields: subject, value, evidence_id, sentence_ids (IDs of the original sentences supporting this relation), optional negated and scope. Never copy or summarize a quote; the program keeps the exact original sentences.
subject_filter/value_filter restrict a relation only when non-null. Null means extract all supported actual entities or values. known_subjects/known_values are prior candidates, not an exhaustive list. Return all supported rows even when other slots remain unknown. One person can have multiple schools, companies or awards. The program connects rows and chooses answers; you only read individual relations. Do not fill variables or return a final answer.
Each slot's task names its subject independently. Never inherit a different slot's subject. Ordinary textual entailment is allowed: receiving a degree entails graduation; a storyboard artist is an artist; biography titles and the subject's pronouns refer to the same person.
Use source names and sentences supporting the RELATION; title/pronouns can identify its subject. A listed group property applies to every member explicitly listed, not only the paragraph's title entity. Preserve time/negation. For a boolean property use value="true"; explicit denial also sets negated=true. Dates and numbers should preserve the source's wording/precision, including bounds or frequency words. Do not invent exact counts from vague or disputed quantities. All original text is supplied without shortening. Never turn a different value into a contradiction or require all requested relations to be known before extracting any one of them.'''
