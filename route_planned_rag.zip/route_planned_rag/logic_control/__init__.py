"""Fixed logical requirements that control evidence acquisition and answer selection."""
