"""Stable logical requirements backed by a provenance-preserving relation index."""
