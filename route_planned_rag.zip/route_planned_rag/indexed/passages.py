"""Lossless sentence addressing: citations refer to observed source slices."""
import re
from typing import Literal
from pydantic import model_validator,Field,create_model
from .schema import SpanReading,Reading,Extracted,PassageFact,Strict

def extraction_slots(program):
    """Expose independent predicates; variable joins are exclusively the index's job."""
    return [dict(node=i,subject_filter=None if f.subject.startswith('$') else f.subject,
                 relation=f.relation,value_type=f.value_type,time=f.time,value_filter=f.expected)
            for i,f in enumerate(program.functions)]

def passage_input(evidence):
    return ([dict(evidence_id=e['evidence_id'],title=e['source_metadata'].get('title',''),text=e['original_text']) for e in evidence],
            {e['evidence_id']:dict(evidence=e) for e in evidence})

def passage_schema(lookup,known_entities=()):
    names=set(known_entities)
    stop={'The','A','An','She','He','It','They','In','By','However','Today','Between','No','His','Her','This','There','For'}
    for entry in lookup.values():
        e=entry['evidence'];names.add(e['source_metadata'].get('title',''))
        names.update(m.group() for m in re.finditer(r'\b[A-Z][\w-]*(?:\s+(?:(?:of|the|and|de|van)\s+)?[A-Z][\w-]*)*',e['original_text']) if m.group() not in stop)
    names=sorted(n for n in names if any(c.isalpha() for c in n))
    if not names:raise ValueError('no observed entity spellings')
    Fact=create_model('ObservedPassageFact',__base__=PassageFact,
        subject=(Literal[tuple(names)],...),evidence_id=(Literal[tuple(lookup)],...))
    class GroundedPassages(SpanReading):
        evidence_check: str = Field(max_length=800)
        unsupported_nodes: list[int] = Field(max_length=6)
        facts: list[Fact] = Field(max_length=18)
    return GroundedPassages

def node_decision_schema(lookup,program,known_entities=()):
    # One local verdict controls its own rows. There is no second global list
    # of missing nodes that can contradict otherwise supported facts.
    base=passage_schema(lookup,known_entities)
    observed=base.model_fields['facts'].annotation.__args__[0]
    names=observed.model_fields['subject'].annotation
    ids=Literal[tuple(lookup)]
    fields={}
    for i,f in enumerate(program.functions):
        subject=Literal[f.subject] if not f.subject.startswith('$') else names
        value_field=Field()
        if f.value_type=='number':value_field=Field(pattern=r'^[+-]?\d[\d,]*(?:\.\d+)?$')
        if f.value_type=='date':value_field=Field(pattern=r'^(?:\d{4}(?:-\d{2}-\d{2})?|[A-Za-z]+ \d{1,2},? \d{4}|\d{1,2} [A-Za-z]+ \d{4})$')
        Row=create_model(f'Binding{i}',__base__=Strict,subject=(subject,...),value=(str,value_field),
                         evidence_id=(ids,...),negated=(bool,...))
        Supported=create_model(f'Supported{i}',__base__=Strict,
            evidence_check=(str,Field(max_length=400)),status=(Literal['supported'],...),
            rows=(list[Row],Field(min_length=1,max_length=8)))
        Unknown=create_model(f'Unknown{i}',__base__=Strict,
            evidence_check=(str,Field(max_length=400)),status=(Literal['unknown'],...))
        fields[f'node_{i}']=(Supported|Unknown,...)
    return create_model('NodeDecisions',__base__=Strict,**fields)

def decisions_to_reading(value,lookup,program):
    facts=[];unknown=[];notes=[]
    for i,f in enumerate(program.functions):
        decision=getattr(value,f'node_{i}')
        if decision.status=='unknown':unknown.append(i);notes.append(decision.evidence_check);continue
        for row in decision.rows:
            facts.append(Extracted(node=i,subject=row.subject,value=row.value,time=f.time,negated=row.negated,
                evidence_id=row.evidence_id,quote=lookup[row.evidence_id]['evidence']['original_text']))
    # No generated time field: scope is the requirement being checked. Admission
    # still verifies that the requested time occurs in the observed passage.
    return Reading(unsupported_nodes=unknown,facts=facts,uncertainty=notes,rewrite=None)

def number_sentences(evidence):
    shown=[];lookup={}
    for e in evidence:
        text=e['original_text'];bounds=[0]
        # Every source character remains in exactly one segment, including whitespace.
        bounds += [m.end() for m in re.finditer(r'(?<=[.!?])\s+(?=[A-Z"“])',text)]
        bounds.append(len(text));sentences=[]
        for start,end in zip(bounds,bounds[1:]):
            if end>start:sentences.append(dict(id=len(sentences)+1,text=text[start:end],start=start,end=end))
        lookup[e['evidence_id']]=dict(evidence=e,sentences=sentences)
        shown.append(dict(evidence_id=e['evidence_id'],title=e['source_metadata'].get('title',''),sentences=[dict(id=s['id'],text=s['text']) for s in sentences]))
        assert ''.join(s['text'] for s in sentences)==text
    return shown,lookup

def schema_for(lookup):
    class GroundedSpans(SpanReading):
        evidence_check: str = Field(max_length=800)
        unsupported_nodes: list[int] = Field(max_length=6)
        @model_validator(mode='after')
        def observed_sentences(self):
            for f in self.facts:
                if f.evidence_id not in lookup:raise ValueError('unknown evidence_id '+f.evidence_id)
                if any(not 1<=i<=len(lookup[f.evidence_id]['sentences']) for i in f.sentences):raise ValueError('sentence number absent from cited passage')
            return self
    return GroundedSpans

def to_reading(value,lookup):
    rows=[]
    for f in value.facts:
        e=lookup[f.evidence_id]
        if hasattr(f,'sentences'):
            ss=e['sentences'];start=ss[min(f.sentences)-1]['start'];end=ss[max(f.sentences)-1]['end']
            quote=e['evidence']['original_text'][start:end]
        else:
            # The full observed passage is the citation unit, including scope and
            # antecedents. No guessed sentence ID, source compression, or text repair.
            quote=e['evidence']['original_text']
        rows.append(Extracted(**f.model_dump(exclude={'sentences'}),quote=quote))
    return Reading(unsupported_nodes=value.unsupported_nodes,facts=rows,uncertainty=value.uncertainty,rewrite=value.rewrite)
