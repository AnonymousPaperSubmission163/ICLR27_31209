import math,time
from pathlib import Path
from .schema import *
from .store import RelationIndex,number,date
from .passages import passage_input,node_decision_schema,decisions_to_reading,extraction_slots
from route_planned_rag.prototype.logic import matches,key,ground
from route_planned_rag.prototype.prover import write_json

def reading_width(patterns,required,cap,policy):
    if policy=='fixed' or len(required)<=2:return min(cap,2) if policy=='adaptive' else cap
    # Shared entity terms connect requirements; the scope column is excluded
    # because a shared null/year alone does not connect the subjects or values.
    terms={i:{(t.kind,t.name) for t in patterns[i].arguments[:2]} for i in required}
    unseen=set(required);components=0
    while unseen:
        components+=1;stack=[unseen.pop()]
        while stack:
            i=stack.pop();linked={j for j in unseen if terms[i]&terms[j]}
            unseen-=linked;stack.extend(linked)
    return cap if components>1 else min(2,cap)

class Engine:
    def __init__(self,question,program,client,retriever,prover,directory,mode='proof',max_retrievals=4,reader_top_k=5,reader_budget_policy='fixed',retry_policy='reader'):
        if not 1<=reader_top_k<=5:raise ValueError('reader_top_k must be between 1 and 5')
        if reader_budget_policy not in ['fixed','adaptive']:raise ValueError('invalid reader budget policy')
        self.question=question;self.program=program;self.client=client;self.retriever=retriever;self.prover=prover
        self.patterns=compile_program(program,question);self.directory=Path(directory);self.mode=mode;self.limit=max_retrievals
        if retry_policy not in ['reader','deterministic']:raise ValueError('invalid retry policy')
        self.retry_policy=retry_policy
        self.reader_top_k=reader_top_k;self.reader_budget_policy=reader_budget_policy;self.index=RelationIndex(self.directory/'relations.sqlite',program,self.patterns)
        self.events=[];self.attempts={};self.queries=set();self.rewrites={};self.read_ids=set();self.visited=set();self.nodes={}
        self.cache={};self.proofs=[];self.retrievals=0;self.index_reuses=set();self.query_usage=[];self.step=0;self.started=time.perf_counter()
        self.graph_hash=digest(program)
        self.refresh_nodes();self.event('initialized',graph=program.model_dump(),patterns=[a.model_dump() for a in self.patterns])
    def event(self,kind,**payload):
        e=dict(event_id=len(self.events)+1,kind=kind,payload=payload,retrieval_calls=self.retrievals,proof_calls=self.prover.calls)
        self.events.append(e)
        snapshot=dict(event=e,graph=self.program.model_dump(),graph_hash=self.graph_hash,nodes=self.nodes,index=self.index.snapshot(),proofs=self.proofs)
        write_json(self.directory/'states'/f"E{e['event_id']:04}.json",snapshot)
        write_json(self.directory/'events.json',self.events);write_json(self.directory/'model_calls.json',self.client.calls)
    def refresh_nodes(self):
        assert digest(self.program)==self.graph_hash if hasattr(self,'graph_hash') else True
        for i,pattern in enumerate(self.patterns):
            rows=self.index.match([pattern]);status='supported' if rows else 'unknown'
            self.nodes[str(i)]=dict(id='N'+str(i),function=self.program.functions[i].model_dump(),status=status,
                rows=[dict(bindings={k:v.model_dump() for k,v in r['bindings'].items()},fact_ids=r['fact_ids']) for r in rows])
        valid={fid for fid,_ in self.index.accepted()}
        for p in self.proofs:p['valid']=set(p['fact_ids'])<=valid
    def action(self,i,bindings):
        a=substitute(self.patterns[i],bindings);f=self.program.functions[i];subject=a.arguments[0]
        aid=digest([i,subject.model_dump(),f.time])
        name=self.index.names.get(subject.name) if subject.kind=='constant' else None
        query=' '.join(v for v in [name,f.relation,f.expected,f.time] if v) if name else None
        if self.attempts.get(aid,0):
            fallback=(query+' '+self.question) if query and self.retry_policy=='deterministic' else query
            query=self.rewrites.get(aid,fallback)
        available=self.attempts.get(aid,0)<2 and (query is None or norm(query) not in self.queries)
        return dict(node=i,id=aid,subject=name,query=query,executable=name is not None,available=available,
            attempts=self.attempts.get(aid,0),pattern=a.model_dump())
    def plan(self):
        candidates=[]
        for branch,required in enumerate(supports(self.program)):
            rows=[dict(bindings={},facts=[],missing=[])]
            for i in required:
                next_rows=[]
                for row in rows:
                    hits=self.index.match([self.patterns[i]],row['bindings'])
                    if hits:
                        for hit in hits:
                            action=self.action(i,hit['bindings'])
                            # Topological acquisition control visits every executable slot once.
                            missing=list(row['missing'])
                            if self.mode=='topological' and action['id'] not in self.visited:missing.append(action)
                            elif action['id'] not in self.visited and action['id'] not in self.index_reuses:
                                self.index_reuses.add(action['id']);self.event('index_reuse',node=i,fact_ids=hit['fact_ids'],action_id=action['id'])
                            next_rows.append(dict(bindings=hit['bindings'],facts=sorted(set(row['facts']+hit['fact_ids'])),missing=missing))
                    else:
                        next_rows.append(dict(bindings=row['bindings'],facts=row['facts'],missing=row['missing']+[self.action(i,row['bindings'])]))
                if len(next_rows)>256:raise ValueError('support_binding_budget_exhausted')
                rows=next_rows
            for row in rows:
                unique={a['id']:a for a in row['missing']};missing=list(unique.values())
                missing_nodes={a['node'] for a in missing}
                executable=[a for a in missing if a['executable'] and a['available'] and not ((ancestors(self.program,a['node'])-{a['node']})&missing_nodes)]
                directly_feasible=all(a['available'] for a in missing)
                feasible=(bool(executable) or not missing) if self.retry_policy=='deterministic' else directly_feasible
                candidates.append(dict(branch=branch,required=required,bindings={k:v.model_dump() for k,v in row['bindings'].items()},
                    fact_ids=row['facts'],missing=missing,remaining_cost=len(missing) if feasible else None,
                    executable=executable,feasible=feasible,directly_feasible=directly_feasible))
        executable=[(c,a) for c in candidates if c['feasible'] for a in c['executable']]
        if self.mode=='topological':executable.sort(key=lambda pair:(pair[1]['node'],pair[1]['id']))
        else:executable.sort(key=lambda pair:(pair[0]['remaining_cost'],pair[1]['attempts'],pair[1]['node'],pair[1]['id']))
        return candidates,(dict(executable[0][1],required_nodes=executable[0][0]['required']) if executable else None)
    def verify(self,fact_ids,rule,target):
        facts=[(i,a) for i,a in self.index.accepted() if i in fact_ids]
        signature=digest([[(i,a.model_dump()) for i,a in facts],rule.model_dump(),target.model_dump()])
        if signature not in self.cache:
            proof=self.prover.prove(facts,[(rule.id,rule)],[target]);self.cache[signature]=proof;self.proofs.append(proof)
            self.event('proof',proof_id=proof['proof_id'],result=proof['result'],input_fact_ids=fact_ids,rule=rule.model_dump(),target=target.model_dump())
        proof=self.cache[signature];valid={i for i,_ in self.index.accepted()}
        proof['valid']=set(proof['fact_ids'])<=valid
        return proof if proof['valid'] and proof['result']=='proved' and proof['source_mapping_status']=='complete' else None
    def answer(self,candidates):
        answers=[];kind=self.program.goal.kind
        for c in candidates:
            if c['missing']:continue
            binding={k:Term.model_validate(v) for k,v in c['bindings'].items()}
            body=[self.patterns[i] for i in c['required']];nodes=self.program.goal.nodes;computation=None
            if kind in ['value','intersection']:
                projection=intersection_projection(self.program) if kind=='intersection' else None
                i=projection if projection is not None else nodes[0];term=substitute(self.patterns[i],binding).arguments[1]
            elif kind=='subject':
                i=next(i for i in nodes if i in c['required']);term=substitute(self.patterns[i],binding).arguments[0]
            else:
                pair=[substitute(self.patterns[i],binding) for i in nodes]
                values=[self.index.names.get(a.arguments[1].name,'') for a in pair]
                if kind=='same':
                    if norm(values[0])!=norm(values[1]):continue # aliases mean different strings are not automatically false
                    result='yes';operation='normalized_equality'
                elif kind=='greater':
                    v=[number(s) for s in values]
                    if any(x is None for x in v) or v[0]==v[1]:continue
                    winner=0 if v[0]>v[1] else 1;result=self.index.names[pair[winner].arguments[0].name];operation='exact_numeric_greater'
                else:
                    v=[date(s) for s in values]
                    if any(x is None for x in v) or v[0][1]!=v[1][1] or v[0][0]==v[1][0]:continue
                    winner=0 if v[0][0]<v[1][0] else 1;result=self.index.names[pair[winner].arguments[0].name];operation='explicit_date_earlier'
                term=constant(result);self.index.names[term.name]=result
                computation=dict(operation=operation,values=values,result=result)
            if not ground(atom('answer',[term])):continue
            goal=atom('answer',[term])
            # Comparison uses a proof of all premises, followed by separately recorded computation.
            if computation:
                head=atom('comparison_premises',[a.arguments[1] for a in [self.patterns[i] for i in nodes]])
                target=substitute(head,binding)
            else:
                if kind=='subject':head=atom('answer',[self.patterns[i].arguments[0]])
                else:head=atom('answer',[self.patterns[i].arguments[1]])
                target=goal
            rule=RuleSpec(id='question_support_'+str(c['branch']),body=body,head=head,origin='question_definition',source_refs=[],explanation='All explicitly represented question conditions with consistent bindings; no learned factual axiom.')
            proof=self.verify(c['fact_ids'],rule,target) if self.mode=='proof' else None
            if self.mode=='proof' and not proof:continue
            answers.append(dict(value=self.index.names[term.name],fact_ids=c['fact_ids'],proof_id=proof['proof_id'] if proof else None,
                binding=c['bindings'],rule=rule.model_dump(),computation=computation))
        return answers
    def before_retrieval(self,action):
        pass
    def read_evidence(self,selected,action):
        shown,lookup=passage_input(selected)
        raw=self.client.ask('reader',node_decision_schema(lookup,self.program,self.index.names.values()),SPAN_READ_PROMPT,{'task':'Answer each independent relation request from the passages. The program connects subjects and values across nodes.',
            'relations':extraction_slots(self.program),'current_retrieval_node':action['node'],
            'known_entity_spellings':sorted(set(self.index.names.values())),'passages':shown},max_tokens=2048)
        return decisions_to_reading(raw,lookup,self.program),raw.model_dump()
    def run(self):
        status='unsupported' if self.program.goal.kind=='unsupported' else 'unknown';error=None;answers=[]
        try:
            if status!='unsupported':
                for _ in range(24):
                    self.refresh_nodes();candidates,action=self.plan()
                    answers=self.answer(candidates)
                    if answers:status='proved' if self.mode=='proof' else 'supported_by_join';break
                    if not action:status='unknown_no_available_action';break
                    if self.retrievals>=self.limit:status='retrieval_budget_exhausted';break
                    self.before_retrieval(action)
                    self.event('action_selected',action=action,candidates=candidates)
                    aid=action['id'];self.attempts[aid]=self.attempts.get(aid,0)+1;self.queries.add(norm(action['query']))
                    evidence,usage=self.retriever(action['query'],20);self.retrievals+=1;self.query_usage.append(usage)
                    width=reading_width(self.patterns,action['required_nodes'],self.reader_top_k,self.reader_budget_policy)
                    selected=[e for e in evidence if e['evidence_id'] not in self.read_ids][:width]
                    self.index.observe(selected,self.retrievals)
                    self.event('retrieval',query=action['query'],selected_ids=[e['evidence_id'] for e in selected],encoder_usage=usage,reader_budget=width,reader_budget_policy=self.reader_budget_policy)
                    if not selected:
                        self.attempts[aid]=2;self.event('empty_unseen_retrieval',action_id=aid);continue
                    reading,raw_reading=self.read_evidence(selected,action)
                    self.read_ids.update(e['evidence_id'] for e in selected)
                    added,outcomes=self.index.admit(reading,self.client.calls[-1]['call_id'])
                    bound=Atom.model_validate(action['pattern']);hits=self.index.match([bound])
                    if hits:self.visited.add(aid)
                    elif reading.rewrite and action['subject'] and norm(action['subject']) in norm(reading.rewrite) and norm(reading.rewrite) not in self.queries:
                        self.rewrites[aid]=reading.rewrite
                    elif self.retry_policy=='reader':self.attempts[aid]=2
                    self.refresh_nodes();self.event('facts_processed',action_id=aid,added=added,candidates=outcomes,uncertainty=reading.uncertainty,reader_decisions=raw_reading,unsupported_nodes=reading.unsupported_nodes)
                else:status='step_budget_exhausted'
        except Exception as exc:
            error=repr(exc);status='token_budget_exhausted' if 'token_budget_exhausted' in str(exc) else 'execution_error'
        self.refresh_nodes()
        result=dict(question=self.question,mode=self.mode,status=status,error=error,answers=answers,final_answer='; '.join(sorted({a['value'] for a in answers})),
            retrieval_calls=self.retrievals,reader_calls=len(self.client.calls),proof_calls=self.prover.calls,
            proof_seconds=sum(p['elapsed_seconds'] for p in self.proofs),index_lookups=self.index.lookups,index_hits=self.index.hits,
            reused_actions=len(self.index_reuses),input_tokens=sum(c.get('input_tokens') or 0 for c in self.client.calls),
            output_tokens=sum(c.get('output_tokens') or 0 for c in self.client.calls),seconds=time.perf_counter()-self.started,
            query_embedding_usage=self.query_usage,graph_hash=self.graph_hash,semantic_status='program_checked_premises; human audit pending')
        self.event('finished',result=result)
        write_json(self.directory/'result.json',result);write_json(self.directory/'index.json',self.index.snapshot());write_json(self.directory/'proofs.json',self.proofs)
        used={fid for a in answers for fid in a['fact_ids']};records=self.index.records()
        write_json(self.directory/'audit_packet.json',dict(question=self.question,program=self.program.model_dump(),
            actual_answer_premises=[records[i] for i in sorted(used)],automatic_result=result,human_review='pending',corrections=[]))
        return result
