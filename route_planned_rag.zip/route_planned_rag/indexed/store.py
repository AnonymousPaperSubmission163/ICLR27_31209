"""SQLite relation/provenance index; no model calls and no document summarization."""
import json,re,sqlite3
from decimal import Decimal,InvalidOperation
from datetime import datetime
from pathlib import Path
from .schema import *
from route_planned_rag.prototype.logic import unify,key,opposite,ground

class RelationIndex:
    def __init__(self,path,program,patterns):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(path);self.program=program;self.patterns=patterns;self.lookups=0;self.hits=0;self.version=0;self.admission_guard=None
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS evidence(id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS candidate(id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS fact(id TEXT PRIMARY KEY, predicate TEXT, subject TEXT, value TEXT, scope TEXT, negated INTEGER, status TEXT, data TEXT);
        CREATE INDEX IF NOT EXISTS relation_lookup ON fact(predicate,subject,scope,status);
        CREATE INDEX IF NOT EXISTS reverse_lookup ON fact(predicate,value,scope,status);
        ''')
        self.names={constant(f.subject).name:f.subject for f in program.functions if not f.subject.startswith('$')}
        for f in program.functions:
            if f.expected:self.names[value_constant(f.expected,f.value_type).name]=f.expected
    def observe(self,evidence,call):
        for e in evidence:
            old=self.db.execute('SELECT data FROM evidence WHERE id=?',(e['evidence_id'],)).fetchone()
            if old:
                if json.loads(old[0])['original_text']!=e['original_text']:raise ValueError('immutable evidence text changed')
            else:self.db.execute('INSERT INTO evidence VALUES (?,?)',(e['evidence_id'],json.dumps(dict(e,retrieval_call=call),ensure_ascii=False)))
        self.db.commit()
    def evidence(self,eid):
        row=self.db.execute('SELECT data FROM evidence WHERE id=?',(eid,)).fetchone()
        return json.loads(row[0]) if row else None
    def records(self):return {i:json.loads(d) for i,d in self.db.execute('SELECT id,data FROM fact')}
    def observed_aliases(self):
        """Narrow, source-backed organization title/full-name aliases; no fuzzy matching."""
        groups={};preferred={norm(f.subject):f.subject for f in self.program.functions if not f.subject.startswith('$')}
        preferred.update({norm(f.expected):f.expected for f in self.program.functions if f.expected and f.value_type not in ['date','number']})
        existing={norm(v):v for v in self.names.values() if any(c.isalpha() for c in v)}
        for eid,data in self.db.execute('SELECT id,data FROM evidence'):
            e=json.loads(data);title=e['source_metadata'].get('title','');text=e['original_text']
            # A biographical lead explicitly defines the article subject's full
            # name. This is source identity, not fuzzy matching or name expansion
            # from model memory. Preserve an already used canonical binding.
            lead=re.match(r"^([A-Z][A-Za-z .'-]{2,100}?) \(born ([^;)]+)\) is\b",text)
            if lead and parse_date(lead[2]) and title.split() and lead[1].split()[-1]==title.split()[-1]:
                full=lead[1];options={norm(title):title,norm(full):full}
                anchors=set(options)&set(preferred);seen=set(options)&set(existing)
                if len(anchors)<=1 and len(seen)<=1:
                    canonical=preferred[next(iter(anchors))] if anchors else existing[next(iter(seen))] if seen else full
                    for name in options:groups.setdefault(name,[]).append(dict(value=canonical,evidence_id=eid,definition=text,kind='explicit_biographical_title_lead'))
            # Require the lead to define the title's expanded "... of ..." name.
            # Names merely mentioned elsewhere, nicknames and similar names do not qualify.
            m=re.match(r'(?:The )?('+re.escape(title)+r' of [A-Z][A-Za-z ]{1,60}?)(?=\s*\(|\s+is\b|\s+was\b)',text)
            if not m or len(title.split())<2:continue
            full=m.group(1);options={norm(title):title,norm(full):full,norm(m.group(0)):m.group(0)}
            parenthesis=re.match(r'\s*\(([^)]{1,80})\)',text[m.end():])
            if parenthesis and re.fullmatch(r'(?:[A-Z]{2,10}|or|and|[ /,])+',parenthesis.group(1)):
                options[norm(full+parenthesis.group())]=full+parenthesis.group()
                for abbreviation in re.findall(r'\b[A-Z]{2,10}\b',parenthesis.group(1)):
                    options[norm(abbreviation)]=abbreviation
                    if re.search(r'\bThe '+re.escape(abbreviation)+r'\b',text):options[norm('The '+abbreviation)]='The '+abbreviation
            anchors=set(options)&set(preferred)
            if len(anchors)>1:continue
            seen=set(options)&set(existing)
            if not anchors and len(seen)>1:continue
            canonical=preferred[next(iter(anchors))] if anchors else existing[next(iter(seen))] if seen else title
            for name in options:
                groups.setdefault(name,[]).append(dict(value=canonical,evidence_id=eid,definition=text,kind='explicit_title_lead_name'))
        return {name:records[0] for name,records in groups.items() if len({norm(r['value']) for r in records})==1}
    def accepted(self):return [(i,Atom.model_validate(json.loads(d)['atom'])) for i,d in self.db.execute("SELECT id,data FROM fact WHERE status='accepted' ORDER BY id")]
    def match(self,patterns,initial=None,limit=256):
        self.lookups+=1;rows=[dict(bindings=dict(initial or {}),fact_ids=[])]
        for pattern in patterns:
            next_rows={}
            for row in rows:
                a=substitute(pattern,row['bindings'])
                query="SELECT id,data FROM fact WHERE status='accepted' AND predicate=? AND negated=?";args=[a.predicate,int(a.negated)]
                for column,term in zip(['subject','value','scope'],a.arguments):
                    if term.kind=='constant':query+=' AND '+column+'=?';args.append(term.name)
                for fid,data in self.db.execute(query+' ORDER BY id',args):
                    fact=Atom.model_validate(json.loads(data)['atom']);b=unify(a,fact,row['bindings'])
                    if b is not None:
                        r=dict(bindings=b,fact_ids=sorted(set(row['fact_ids']+[fid])))
                        next_rows[digest([{k:v.model_dump() for k,v in b.items()},r['fact_ids']])]=r
                        if len(next_rows)>limit:raise ValueError('binding_row_budget_exhausted')
            rows=list(next_rows.values())
            if not rows:break
        if rows:self.hits+=1
        return rows
    def admit(self,reading,call_id):
        outcomes=[];added=[];aliases=self.observed_aliases()
        for original in reading.facts:
            row=original.model_copy();normalizations=[]
            for field in ['subject','value']:
                raw=getattr(row,field);entry=aliases.get(norm(raw))
                if entry and norm(raw)!=norm(entry['value']):
                    normalizations.append(dict(field=field,original=raw,**entry));setattr(row,field,entry['value'])
            cid='C'+str(self.db.execute('SELECT COUNT(*) FROM candidate').fetchone()[0]+1)
            record=dict(id=cid,**row.model_dump(),original_extraction=original.model_dump(),normalizations=normalizations,extraction_call=call_id,status='quarantined',reason='',semantic_review='not_independently_verified')
            def reject(reason):record['reason']=reason
            f=self.program.functions[row.node] if row.node<len(self.program.functions) else None
            e=self.evidence(row.evidence_id)
            record['source_value_witness']=value_witness(row.value,f.value_type,e['source_metadata'].get('title','')+' '+row.quote) if f and e else None
            if f and e and not record['source_value_witness'] and any(n['field']=='value' for n in normalizations):
                record['source_value_witness']=value_witness(original.value,f.value_type,e['source_metadata'].get('title','')+' '+row.quote)
            if f is None:reject('unknown_node')
            elif row.node in reading.unsupported_nodes:reject('reader_marked_relation_unsupported')
            elif not e or not row.quote or row.quote not in e['original_text']:reject('citation_not_observed_exact_span')
            elif not any(c.isalnum() for c in row.subject) or not any(c.isalnum() for c in row.value) or norm(row.value) in ['unknown','none','null','n/a']:reject('missing_value')
            elif not f.subject.startswith('$') and norm(row.subject)!=norm(f.subject):reject('question_anchor_identity_mismatch')
            elif norm(row.subject) not in norm(e['source_metadata'].get('title','')+' '+row.quote) and not (any(n['field']=='subject' for n in normalizations) and norm(original.subject) in norm(e['source_metadata'].get('title','')+' '+row.quote)):reject('subject_not_in_quote_or_title')
            elif not record['source_value_witness']:reject('value_not_in_quote_or_title')
            elif row.time!=f.time or (row.time and row.time not in row.quote):reject('time_scope_mismatch')
            elif f.value_type=='number' and number(value_witness(row.value,f.value_type,row.quote) or row.value,row.quote) is None:reject('not_an_exact_number')
            elif f.value_type=='date' and date(row.value) is None:reject('date_not_explicit_comparable')
            elif self.admission_guard and (guard_reason:=self.admission_guard(row,f,e)):reject(guard_reason)
            if not record['reason']:
                a=atom(self.patterns[row.node].predicate,[constant(row.subject),value_constant(row.value,f.value_type),constant(row.time or '__unscoped__')],row.negated)
                fid='F'+digest(a);record.update(status='program_checked',fact_id=fid)
                self.names[a.arguments[0].name]=row.subject;self.names[a.arguments[1].name]=row.value
                old=self.db.execute('SELECT data FROM fact WHERE id=?',(fid,)).fetchone()
                if old:
                    data=json.loads(old[0]);data['candidate_ids'].append(cid)
                    data['evidence_ids']=sorted(set(data['evidence_ids']+[row.evidence_id]))
                    self.db.execute('UPDATE fact SET data=? WHERE id=?',(json.dumps(data,ensure_ascii=False),fid))
                else:
                    data=dict(id=fid,node=row.node,atom=a.model_dump(),candidate_ids=[cid],evidence_ids=sorted({row.evidence_id}|{n['evidence_id'] for n in normalizations}),quote=row.quote,source_value_witness=record['source_value_witness'],
                        status='accepted',scope=row.time,negated=row.negated,subject=row.subject,value=row.value,semantic_review='not_independently_verified')
                    self.db.execute('INSERT INTO fact VALUES (?,?,?,?,?,?,?,?)',(fid,a.predicate,*[t.name for t in a.arguments],int(a.negated),'accepted',json.dumps(data,ensure_ascii=False)))
                    added.append(fid);self.version+=1
                # Explicit opposite atoms remain quarantined together. Re-observation does not resurrect them.
                opp='F'+digest(opposite(a));other=self.db.execute('SELECT data FROM fact WHERE id=? AND status != ?', (opp,'withdrawn')).fetchone()
                if other:
                    for conflict_id in [fid,opp]:self.set_status(conflict_id,'conflicted','explicit_same_scope_opposite')
            self.db.execute('INSERT INTO candidate VALUES (?,?)',(cid,json.dumps(record,ensure_ascii=False)));outcomes.append(record)
        self.db.commit()
        valid={i for i,_ in self.accepted()}
        return [i for i in added if i in valid],outcomes
    def set_status(self,fid,status,reason):
        old=self.db.execute('SELECT data FROM fact WHERE id=?',(fid,)).fetchone()
        if old:
            data=json.loads(old[0]);data.update(status=status,status_reason=reason)
            self.db.execute('UPDATE fact SET status=?,data=? WHERE id=?',(status,json.dumps(data,ensure_ascii=False),fid));self.version+=1;self.db.commit()
    def snapshot(self):
        return dict(version=self.version,facts=self.records(),candidates=[json.loads(d) for d, in self.db.execute('SELECT data FROM candidate')],
            evidence={i:json.loads(d) for i,d in self.db.execute('SELECT id,data FROM evidence')},entity_names=self.names,index_lookups=self.lookups,index_hits=self.hits)

def number(value,quote=''):
    value=value.strip()
    if not re.fullmatch(r'[+-]?\d[\d,]*(?:\.\d+)?',value):return None
    if quote and re.search(r'(?:more than|less than|over|under|about|around|approximately|at least|at most)\s+'+re.escape(value),quote,re.I):return None
    try:return Decimal(value.replace(',',''))
    except InvalidOperation:return None

def date(value):return parse_date(value)

def value_witness(value,kind,text):
    """Return an observed lexical witness; normalize numbers/dates, never entity similarity."""
    if kind not in ['number','date']:
        return value if norm(value) in norm(text) else None
    if kind=='number':
        target=number(value)
        if target is None:return None
        candidates=[m.group() for m in re.finditer(r'(?<!\w)[+-]?\d[\d,]*(?:\.\d+)?(?!\w)',text)]
        return next((s for s in candidates if number(s)==target),None)
    target=parse_date(value)
    if not target:return None
    months='January|February|March|April|May|June|July|August|September|October|November|December'
    patterns=[r'\b\d{4}-\d{2}-\d{2}\b',r'\b(?:'+months+r')\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}\b',
              r'\b\d{1,2}(?:st|nd|rd|th)?\s+(?:'+months+r')\s+\d{4}\b',r'\b\d{4}\b']
    return next((m.group() for pattern in patterns for m in re.finditer(pattern,text,re.I) if parse_date(m.group())==target),None)
