"""Small synthetic real-model gate; no HotpotQA questions or labels are used."""
import json
from pathlib import Path
from .schema import Function,Program,Goal
from .engine import Engine
from route_planned_rag.prototype.model import ModelClient
from route_planned_rag.prototype.prover import Prover,write_json

class ReplayClient:
    """Revalidate real recorded completions only when instructions/schema/input match."""
    def __init__(self,path):self.path=Path(path);self.source=json.loads(self.path.read_text());self.calls=[]
    def ask(self,role,schema,instructions,payload,**kwargs):
        from route_planned_rag.models.json_actor import extract_json
        c=self.source[len(self.calls)];prompt=c['prompt']
        if c['status']!='validated' or c['role']!=role or not prompt.startswith(instructions+'\nReturn one compact JSON object'):
            raise ValueError('replay_instructions_or_role_mismatch')
        observed=json.loads(prompt.split('\nPUBLIC_INPUT:',1)[1])
        old_schema=json.loads(prompt.split('\nJSON_SCHEMA:',1)[1].split('\nPUBLIC_INPUT:',1)[0])
        if observed!=payload or old_schema!=schema.model_json_schema():raise ValueError('replay_schema_or_public_input_mismatch')
        value=schema.model_validate(extract_json(c['completion']))
        self.calls.append(dict(c,input_tokens=0,output_tokens=0,seconds=0,actual_generated=False,
                               replay_source=str(self.path),original_input_tokens=c['input_tokens'],original_output_tokens=c['output_tokens']))
        return value

def run_smoke(actor,small,config,directory,replay_from=None):
    directory=Path(directory)
    def fn(subject,relation,kind='entity',time=None):
        return Function(subject=subject,relation=relation,value_type=kind,time=time,expected=None)
    def program(fs):return Program(functions=fs,goal=Goal(kind='value',nodes=[1]),limitations='')
    chain=program([fn('Copper Moon','directed by'),fn('$0','born in')])
    cases=[
        ('chain','Where was the director of Copper Moon born?',chain,
         [('Copper Moon','Copper Moon was directed by Lena Orin.'),('Lena Orin','Lena Orin was born in Redhaven. She later worked in Blueport.')],{'Redhaven'}),
        ('scope',"How many members did Talia Voss's union have in 2022?",
         program([fn('Talia Voss','affiliated union'),fn('$0','member count','number','2022')]),
         [('Talia Voss','Talia Voss was a labor leader in the Pine Guild.'),('Pine Guild','The Pine Guild had 234 members in 2022 and 310 members in 2024.')],{'234'}),
        ('missing','Where was the director of Copper Moon born?',chain,
         [('Copper Moon','Copper Moon was directed by Lena Orin.'),('Lena Orin','Lena Orin worked in Blueport. Her birthplace is not recorded here.')],set()),
        ('wrong_role','Where was the director of Copper Moon born?',chain,
         [('Copper Moon','Lena Orin composed the score for Copper Moon. The director is not identified.'),('Lena Orin','Lena Orin was born in Redhaven.')],set()),
        ('wrong_year',"How many members did Talia Voss's union have in 2022?",
         program([fn('Talia Voss','affiliated union'),fn('$0','member count','number','2022')]),
         [('Talia Voss','Talia Voss was a labor leader in the Pine Guild.'),('Pine Guild','The Pine Guild had 310 members in 2024. Earlier membership counts are unavailable.')],set()),
        ('unrelated_year',"How many members did Talia Voss's union have in 2022?",
         program([fn('Talia Voss','affiliated union'),fn('$0','member count','number','2022')]),
         [('Talia Voss','Talia Voss was a labor leader in the Pine Guild.'),('Pine Guild','In 2022 the Pine Guild opened a new office. In 2024 it had 310 members. The membership count for 2022 is unknown.')],set()),
        ('other_person','Where was the director of Copper Moon born?',chain,
         [('Copper Moon','Copper Moon was directed by Lena Orin.'),('Lena Orin','Lena Orin worked in Blueport. Ravi Mesa was born in Redhaven. The birthplace of Lena Orin is unknown.')],set()),
        ('and_filter','Which director of Copper Moon was born in Redhaven?',
         Program(functions=[fn('Copper Moon','directed by'),Function(subject='$0',relation='born in',value_type='entity',time=None,expected='Redhaven')],goal=Goal(kind='intersection',nodes=[0,1]),limitations=''),
         [('Copper Moon','Copper Moon was directed by Lena Orin.'),('Lena Orin','Lena Orin was born in Redhaven.')],{'Lena Orin'}),
        ('scope_context',"How many members did Talia Voss's union have in 2022?",
         program([fn('Talia Voss','affiliated union'),fn('$0','member count','number','2022')]),
         [('Talia Voss','Talia Voss was a labor leader in the Pine Guild.'),('Pine Guild','By 2022 the industry had contracted. The Pine Guild was left with 234 members. In 2024 the guild had 310 members.')],{'234'}),
        ('name_and_number',"How many members did Talia Voss's union have in 2022?",
         program([fn('Talia Voss','affiliated union'),fn('$0','member count','number','2022')]),
         [('Talia Voss','Talia Voss was a labor leader in the Pine Guild.'),('Pine Guild','The Pine Guild of Arbor (PGA) is a union. In 2022 it had 23,000 members.')],{'23000'}),
    ]
    results=[]
    for name,question,graph,texts,expected in cases:
        evidence=[dict(evidence_id=f'E{i+1}',source_metadata={'title':title},original_text=text) for i,(title,text) in enumerate(texts)]
        def retrieve(query,k):return evidence,dict(input_tokens=0,seconds=0)
        client=ReplayClient(Path(replay_from)/name/'model_calls.json') if replay_from else ModelClient(actor,small,config);d=directory/name
        engine=Engine(question,graph,client,retrieve,Prover(Path(config['prover_executable']).resolve(),d/'prover'),d,mode='proof',max_retrievals=2,reader_top_k=config.get('reader_top_k',5),reader_budget_policy=config.get('reader_budget_policy','fixed'))
        result=engine.run();observed={a['value'] for a in result['answers']}
        def normalized(values):
            return {v.replace(',','') if v.replace(',','').isdigit() else v for v in values}
        passed=normalized(observed)==normalized(expected) and result['error'] is None
        results.append(dict(case=name,passed=passed,expected=sorted(expected),result=result))
    summary=dict(passed=all(r['passed'] for r in results),cases=results,
        note='Synthetic reader/proof regression gate, not a QA benchmark or evidence of retrieval savings.',
        generation='replayed real completions with matching instructions, schema and public inputs' if replay_from else 'fresh real model calls',
        actual_model_calls=0 if replay_from else sum(r['result']['reader_calls'] for r in results),
        actual_input_tokens=sum(r['result']['input_tokens'] for r in results),
        actual_output_tokens=sum(r['result']['output_tokens'] for r in results))
    write_json(directory/'summary.json',summary)
    return summary
