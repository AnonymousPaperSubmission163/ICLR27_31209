from __future__ import annotations
import re
from datetime import datetime
from typing import Literal
from pydantic import Field,model_validator
from route_planned_rag.prototype.schemas import Strict,Atom,Term,RuleSpec
from route_planned_rag.prototype.logic import digest,substitute

class Function(Strict):
    subject: str # verbatim question entity, or $0 referring to node 0's output
    relation: str
    value_type: Literal['entity','person','organization','place','work','event','category','number','date']
    time: str | None
    expected: str | None # question-explicit value restriction, not a guessed answer

class Goal(Strict):
    kind: Literal['value','subject','intersection','same','greater','earlier','unsupported']
    nodes: list[int]

class Program(Strict):
    question_check: str = Field(default='',max_length=600)
    functions: list[Function] = Field(max_length=6)
    goal: Goal
    limitations: str
    @model_validator(mode='after')
    def check(self):
        if self.goal.kind=='unsupported':
            if self.functions or self.goal.nodes:raise ValueError('unsupported requires empty functions and goal nodes')
            return self
        if not self.functions or not self.goal.nodes:raise ValueError('supported program needs functions and goal indices')
        for i,f in enumerate(self.functions):
            if not f.subject.strip() or not f.relation.strip():raise ValueError('empty subject/relation')
            if f.subject.startswith('$') and (not re.fullmatch(r'\$\d+',f.subject) or not 0<=int(f.subject[1:])<i):raise ValueError('input reference must refer to an earlier node')
            if f.time is not None and not re.fullmatch(r'\d{4}(?:-\d{2}-\d{2})?',f.time):raise ValueError('time must be null, YYYY or YYYY-MM-DD')
        if len(self.goal.nodes)!=len(set(self.goal.nodes)) or any(not 0<=i<len(self.functions) for i in self.goal.nodes):raise ValueError('invalid or repeated goal node')
        if self.goal.kind=='value' and len(self.goal.nodes)!=1:raise ValueError('value returns exactly one node output, which may have multiple rows')
        if self.goal.kind in ['same','greater','earlier'] and len(self.goal.nodes)!=2:raise ValueError('comparison needs two outputs')
        if self.goal.kind=='greater' and any(self.functions[i].value_type!='number' for i in self.goal.nodes):raise ValueError('greater requires numeric outputs')
        if self.goal.kind=='earlier' and any(self.functions[i].value_type!='date' for i in self.goal.nodes):raise ValueError('earlier requires date outputs')
        if self.goal.kind=='intersection' and len(self.goal.nodes)<2:raise ValueError('intersection needs at least two conditions')
        if self.goal.kind=='subject' and any(not self.functions[i].expected for i in self.goal.nodes):raise ValueError('subject selection requires explicit value filters')
        return self

def norm(s):return ' '.join(s.casefold().split())
def scalar(s):return re.sub(r'[^\w]','',norm(s))
def parse_date(s):
    cleaned=re.sub(r'(\d)(?:st|nd|rd|th)\b',r'\1',s.strip(),flags=re.I)
    cleaned=re.sub(r'\bin\b','',cleaned,flags=re.I).replace(',',' ')
    cleaned=' '.join(cleaned.split())
    for fmt,precision in [('%Y-%m-%d','day'),('%B %d %Y','day'),('%d %B %Y','day'),('%Y','year')]:
        try:return datetime.strptime(cleaned,fmt),precision
        except ValueError:pass
    return None

def explicit_in_question(value,question):
    if scalar(value) in scalar(question):return True
    target=parse_date(value)
    if not target:return False
    months='January|February|March|April|May|June|July|August|September|October|November|December'
    for pat in [r'\b(?:'+months+r'),?\s+\d{1,2}(?:st|nd|rd|th)?(?:,|\s)*(?:in\s+)?\d{4}\b',r'\b\d{1,2}(?:st|nd|rd|th)?\s+(?:'+months+r')\s+\d{4}\b']:
        for m in re.finditer(pat,question,re.I):
            if parse_date(m.group())==target:return True
    return False

def value_constant(value,kind):
    if kind=='date' and (parsed:=parse_date(value)):
        value=parsed[0].strftime('%Y' if parsed[1]=='year' else '%Y-%m-%d')
    if kind=='number':
        from decimal import Decimal
        value=format(Decimal(value.replace(',','')),'f')
        if '.' in value:value=value.rstrip('0').rstrip('.')
        if Decimal(value)==0:value='0'
    return constant(value)
def constant(s):return Term(kind='constant',name='e'+digest(norm(s)),entity_type='entity')
def var(i):return Term(kind='variable',name='v'+str(i),entity_type='entity')
def atom(pred,args,neg=False):return Atom(predicate=pred,arguments=args,negated=neg)

def intersection_projection(program):
    """AND filters on one bound entity, versus intersection of independent outputs."""
    nodes=program.goal.nodes
    free=[i for i in nodes if program.functions[i].expected is None]
    if len(free)==1 and all(i==free[0] or free[0] in ancestors(program,i) for i in nodes):
        return free[0]
    return None

def compile_program(program,question):
    patterns=[]
    for i,f in enumerate(program.functions):
        if not f.subject.startswith('$') and norm(f.subject) not in norm(question):raise ValueError('anchor must be copied from the original question: '+f.subject)
        for field,value in [('expected',f.expected),('time',f.time)]:
            if value and not explicit_in_question(value,question):raise ValueError(field+' must be explicitly present in question: '+value)
        subject=patterns[int(f.subject[1:])].arguments[1] if f.subject.startswith('$') else constant(f.subject)
        value=value_constant(f.expected,f.value_type) if f.expected else var(i)
        args=[subject,value,constant(f.time or '__unscoped__')]
        patterns.append(atom('rel_'+digest(norm(f.relation)),args))
    # In intersection, all selected node outputs bind the same candidate.
    if program.goal.kind=='intersection' and intersection_projection(program) is None:
        for i in program.goal.nodes:
            if program.functions[i].expected:raise ValueError('intersection outputs must be variables')
            patterns[i]=patterns[i].model_copy(update={'arguments':[patterns[i].arguments[0],var('candidate'),patterns[i].arguments[2]]})
        if any(f.subject.startswith('$') and int(f.subject[1:]) in program.goal.nodes for f in program.functions):raise ValueError('intersection output dependencies require explicit unsupported status in v1')
    return patterns

def ancestors(program,i):
    seen={i}
    while program.functions[i].subject.startswith('$'):
        i=int(program.functions[i].subject[1:]);seen.add(i)
    return seen

def supports(program):
    if program.goal.kind=='subject':return [sorted(ancestors(program,i)) for i in program.goal.nodes]
    if program.goal.kind=='unsupported':return []
    return [list(range(len(program.functions)))]

PLAN_PROMPT='''Translate the QUESTION into a compact program of information requirements. You are NOT answering the question. Unknown answers and absent evidence are the REASON to create retrieval functions, never a reason to say unsupported. Do not invent factual values.
Each function has subject (verbatim named phrase in QUESTION, or $0/$1/... referring to an earlier output), short precise relation, value_type entity/number/date, time null unless explicitly scoped, expected null unless QUESTION explicitly restricts the value.
Goal value returns one function's output, but EVERY function is a required premise (including filters). Goal subject chooses among explicitly named candidate subjects satisfying their expected filter; each candidate is an alternative branch. Goal intersection returns an output satisfying all listed relations. Goal greater compares two numeric outputs and returns the winning subject. Goal earlier compares two dates and returns the earlier subject. Goal same compares two entity outputs. Use unsupported only for semantics you cannot express, NOT for missing knowledge. Functions remain separate: do not hide multiple hops in a long relation. Preserve all question qualifiers.
EXAMPLE (fictional question, no answers): Where was the director of The Glass Harbor born?
{"functions":[{"subject":"The Glass Harbor","relation":"directed by","value_type":"entity","time":null,"expected":null},{"subject":"$0","relation":"born in","value_type":"entity","time":null,"expected":null}],"goal":{"kind":"value","nodes":[1]},"limitations":""}
EXAMPLE: Which company founded by Ada Example had headquarters in Rome in 2020?
{"functions":[{"subject":"Ada Example","relation":"founded company","value_type":"entity","time":null,"expected":null},{"subject":"$0","relation":"headquartered in","value_type":"entity","time":"2020","expected":"Rome"}],"goal":{"kind":"value","nodes":[0]},"limitations":""}
Only output the program for the actual QUESTION. No answer generation, no statements that data must first be supplied.'''

class Extracted(Strict):
    node: int = Field(ge=0,le=5)
    subject: str
    value: str
    time: str | None
    negated: bool
    evidence_id: str
    quote: str

class Reading(Strict):
    unsupported_nodes: list[int] = Field(default_factory=list,max_length=6)
    facts: list[Extracted] = Field(max_length=18)
    uncertainty: list[str] = Field(max_length=6)
    rewrite: str | None

READ_PROMPT='''Read the ORIGINAL passages and extract concrete facts for the listed function nodes. Do not require a fact to answer the whole question: each supported intermediate relation is useful. Return one row per relation/value, with node index, subject, value, time, negated, evidence_id and an EXACT contiguous quote.
Extract facts for OTHER listed nodes too when passages support them. For a root node copy its subject exactly; for $i nodes use the actual entity from the text, not "$i". Reuse known entity spellings if the text clearly identifies the same entity. Never substitute similarly named people. Do not concatenate different candidates. Values must occur in the quote. The subject must occur in the quote or document title. Include enough text to resolve pronouns. Preserve dates, negation, comparative bounds and restrictions. time denotes the temporal scope of the relationship, not every year mentioned nearby; use null for unqualified relations.
For a numeric output, copy the explicit numeric surface (e.g. 12,000); do not treat "more than 100" or an estimated interval as exact. For expected filters extract what the passage actually says, not what would satisfy the question. An absent fact is unknown, not negated. Never invent facts from model memory. Empty facts with uncertainty is valid.
rewrite is null normally. If the CURRENT request has no supported fact, you may propose ONE short natural-language query retaining its exact subject. No standalone answer or separate binding list: supported values must be in fact rows.'''

class SpanFact(Strict):
    node: int = Field(ge=0,le=5)
    subject: str
    value: str
    time: str | None
    negated: bool
    evidence_id: str
    sentences: list[int] = Field(min_length=1,max_length=8)

class PassageFact(Strict):
    node: int = Field(ge=0,le=5)
    subject: str
    value: str
    time: str | None
    negated: bool
    evidence_id: str

class SpanReading(Strict):
    evidence_check: str = Field(default='',max_length=800)
    unsupported_nodes: list[int] = Field(default_factory=list,max_length=6)
    facts: list[SpanFact] = Field(max_length=18)
    uncertainty: list[str] = Field(max_length=6)
    rewrite: str | None

SPAN_READ_PROMPT='''Using only the original passages, answer EACH relation request independently. subject_filter null means any stated subject; otherwise use the named subject. Match the requested value_type and value_filter: a request for an organization is not answered by a work it commissioned. The program connects different nodes later.
For each node, briefly identify the supporting evidence in evidence_check, then select supported and provide subject/value rows, OR unknown if evidence is missing. Do not require other nodes to be satisfied. A biography can establish both a band's singer and that singer's birth date; ordinary paraphrases and the reverse statement of a relation are valid evidence. Use the whole paragraph to resolve names, pronouns and temporal context. An explicit temporal frame can carry into the following sentence until the context changes; a date belonging to an unrelated event cannot establish the requested scope.
Copy values from the cited passage or its title; do not expand entity names using another passage. Prefer a known document title for an entity when that exact title also occurs in the supporting source. Dates and numbers retain their source expression. Cite the evidence_id actually supporting each row. Use observed entity spellings and the document title for its described entity, not for other people mentioned in it. Keep shared entity spellings consistent. Preserve explicit negation. Do not infer birthplace from workplace, director from composer, or an exact number from a bound or estimate. Missing evidence is unknown. No facts from memory.'''



def question_program_schema(question):
    """Constrain root spellings to question spans; no external entity knowledge or answers."""
    from pydantic import create_model
    candidates=[]
    pattern=r'\b[A-Z][\w.-]*(?:\s+(?:(?:of|the|and|de|van)\s+)?[A-Z][\w.-]*)*'
    stop={'What','Which','Who','Where','When','How','Is','Are','Was','Were','The'}
    for m in re.finditer(pattern,question):
        value=m.group().rstrip('.?')
        if value not in stop:candidates.append(value)
    # Quoted works and titles are also verbatim anchors. If none exist, the whole
    # original question is allowed as a literal anchor; semantic audit still required.
    for m in re.finditer(r'"([^"\n]+)"',question):candidates.append(m.group(1))
    candidates=list(dict.fromkeys(candidates)) or [question]
    subjects=Literal[tuple(candidates+[f'${i}' for i in range(6)])]
    GroundedFunction=create_model('QuestionFunction',__base__=Function,subject=(subjects,...))
    kinds=['value','intersection','unsupported']
    if re.search(r'\bsame\b|\bboth\b',question,re.I):kinds+=['same']
    if re.search(r'\bmore\b|\bgreater\b|\blarger\b',question,re.I):kinds+=['greater']
    if re.search(r'\bearlier\b|\bfirst\b|\bbefore\b',question,re.I):kinds+=['earlier']
    if re.search(r'\bor\b',question,re.I):kinds+=['subject']
    GroundedGoal=create_model('QuestionGoal',__base__=Goal,kind=(Literal[tuple(kinds)],...))
    Base=create_model('BoundedQuestionProgram',__base__=Program,question_check=(str,Field(max_length=600)),functions=(list[GroundedFunction],Field(max_length=6)),goal=(GroundedGoal,...))
    class GroundedProgram(Base):
        @model_validator(mode='after')
        def literal_grounding(self):compile_program(self,question);return self
    return GroundedProgram

PLAN_PROMPT+='''\nUse the permitted subject spellings from the schema exactly. A person\'s organization implies affiliation, not necessarily leadership or ownership. Do not strengthen the question\'s relations. Generic descriptions such as "a European country" or "a college" are output types/requirements, NOT expected entity values. expected is only a concrete named entity, date or number supplied in the question. For a "which ... X or Y" selection with a known filter, use subject, not same. Return value for a named person satisfying a birth-date filter; this is not an equality comparison between two people. Keep any unrepresented condition explicit in limitations.\n'''

PLAN_PROMPT += '''
Before functions, fill question_check with the requested answer type, the intermediate entities, and ONLY the conditions actually requested. Then implement that interpretation. Do not answer the question. Every extra function becomes a required condition, so never add your own selection criteria. A date of creation is a date-valued attribute, not a temporal scope on an unrelated relation. To check multiple properties of an entity from $0, EACH property takes $0 as its subject; do not pass a date/location output as that entity. Lists of named categories are supported: one value function may return multiple rows. A broad descriptive phrase can be a precise relation (for example "largest university in country"), without inventing how size is measured.
'''

PLAN_PROMPT += '''
Use precise output types whenever possible: person, organization (including colleges and unions), place, work, event, category, number or date. Use entity only if no more precise type fits. The type describes the requested VALUE, not the subject. For example a filmmaker's institution is organization, while the filmmaker's movie is work.
'''
