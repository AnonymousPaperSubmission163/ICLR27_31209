from __future__ import annotations

import json
import subprocess
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

from route_planned_rag.accounting import BudgetUsage, GlobalLedger
from route_planned_rag.corpus.chunking import SourceDocument, chunk_document
from route_planned_rag.corpus.retrieval import CachedRetriever, RetrievalCache
from route_planned_rag.data.adapters import (
    BrowseCompPlusAdapter,
    MuSiQueAdapter,
    MultiHopRAGAdapter,
    TwoWikiAdapter,
    iter_raw_json,
)
from route_planned_rag.evaluation.metrics import delivered_support_ids, evaluate_episode
from route_planned_rag.evaluation.official import run_musique_official, run_twowiki_official
from route_planned_rag.models.e5 import E5MistralEncoder
from route_planned_rag.models.json_actor import JsonActor, TransformersGenerationBackend
from route_planned_rag.models.live_retriever import LiveDenseRetriever
from route_planned_rag.models.loaders import load_mistral3_generation
from route_planned_rag.models.pooled_retriever import PooledDenseRetriever, resolve_pooled_index
from route_planned_rag.models.reranker import PointwiseMistralReranker
from route_planned_rag.search.controllers import Pi0Controller
from route_planned_rag.search.engine import EpisodeRunner
from route_planned_rag.storage import RunWriter
from route_planned_rag.types import CompletionStatus, ObservedPassage, PrivateReference, PublicSample


def _row_id(row: dict[str, Any], dataset: str) -> str:
    return str(row["id"] if dataset == "musique" else row["_id"])


def load_fixed_examples(config: dict, dataset: str, role: str, limit: int) -> list[tuple[PublicSample, PrivateReference, dict]]:
    if dataset in {"multihop_rag", "browsecomp_plus"}:
        item = config["data"]["datasets"][dataset]
        adapter = MultiHopRAGAdapter() if dataset == "multihop_rag" else BrowseCompPlusAdapter()
        pairs = list(adapter.load(item["raw_path"], role))
        raw_by_id = {}
        for raw, (public, _) in zip(iter_raw_json(item["raw_path"]), pairs):
            raw_by_id[public.question_id] = raw
        if dataset == "browsecomp_plus":
            extended = json.loads((Path(config["project"]["artifact_root"]) / "extended_data_manifest.json").read_text())
            key = "main_b16_ids" if role == "external_main" else "frozen_curve_200_ids"
            selected = extended["sources"]["browsecomp_queries_private_plaintext"][key][:limit]
        else:
            selected = sorted(
                (public.question_id for public, _ in pairs),
                key=lambda value: __import__("hashlib").sha256(f"{config['data']['seed']}:{value}".encode()).hexdigest(),
            )[:limit]
        pair_by_id = {public.question_id: (public, private) for public, private in pairs}
        return [(pair_by_id[q][0], pair_by_id[q][1], raw_by_id[q]) for q in selected]
    manifest_path = Path(config["project"]["root"]) / "data/manifests/frozen_splits_v1.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    role_key = {
        "initial_train": "initial_train_ids",
        "full_train": "full_train_ids",
        "internal_dev": "internal_dev_ids",
        "e1": "e1_official_dev_ids",
        "e2": "e2_official_dev_ids",
    }[role]
    selected = list(manifest["datasets"][dataset][role_key])[:limit]
    selected_set = set(selected)
    dataset_item = config["data"]["datasets"][dataset]
    source = dataset_item["train_path"] if role in {"initial_train", "full_train", "internal_dev"} else dataset_item["official_dev_path"]
    adapter = MuSiQueAdapter() if dataset == "musique" else TwoWikiAdapter()
    public_private = {
        public.question_id: (public, private)
        for public, private in adapter.load(source, role)
        if public.question_id in selected_set
    }
    raw = {_row_id(row, dataset): row for row in iter_raw_json(source) if _row_id(row, dataset) in selected_set}
    missing = [question_id for question_id in selected if question_id not in public_private or question_id not in raw]
    if missing:
        raise RuntimeError(f"frozen ids missing from {dataset}/{role}: {missing[:5]}")
    return [(public_private[q][0], public_private[q][1], raw[q]) for q in selected]


def _sentence_spans(sentences: list[str]) -> tuple[tuple[int, int, int], ...]:
    spans = []
    cursor = 0
    for index, sentence in enumerate(sentences):
        spans.append((index, cursor, cursor + len(sentence)))
        cursor += len(sentence) + 1
    return tuple(spans)


def public_context_passages(sample: PublicSample, tokenizer, tokenizer_revision: str, *, chunk_tokens: int, overlap_tokens: int) -> list[ObservedPassage]:
    passages: list[ObservedPassage] = []
    for ordinal, item in enumerate(sample.public_context):
        sentences = list(map(str, item.get("sentences", [])))
        document = SourceDocument(
            doc_id=str(item["doc_id"]),
            title=str(item.get("title", ordinal)),
            text=str(item["text"]),
            sentence_char_spans=_sentence_spans(sentences) if sentences else (),
        )
        for chunk in chunk_document(
            document,
            tokenizer,
            tokenizer_revision=tokenizer_revision,
            chunk_tokens=chunk_tokens,
            overlap_tokens=overlap_tokens,
        ):
            passages.append(ObservedPassage(
                chunk_id=chunk.chunk_id,
                doc_id=chunk.doc_id,
                text=chunk.text,
                char_start=chunk.char_start,
                char_end=chunk.char_end,
                token_start=chunk.token_start,
                token_end=chunk.token_end,
                sentence_ids=chunk.sentence_ids,
            ))
    return passages


def make_ledger(config: dict, call_budget: int) -> GlobalLedger:
    budgets = config["budgets"]
    limits = BudgetUsage(
        actor_requests=1024,
        format_repair_requests=256,
        logical_retrieval_calls=call_budget,
        physical_backend_requests=call_budget,
        reasoning_input_tokens=int(budgets["reasoning_input_tokens"]),
        reasoning_output_tokens=int(budgets["reasoning_output_tokens"]),
        unique_evidence_tokens=int(budgets["unique_evidence_tokens"]),
        scorer_forward_tokens=10_000_000,
        dense_forward_tokens=10_000_000,
        reranker_forward_tokens=10_000_000,
        reader_input_tokens=10_000_000,
        reader_output_tokens=10_000_000,
        scorer_gpu_seconds=1_000_000.0,
        dense_gpu_seconds=1_000_000.0,
        reranker_gpu_seconds=1_000_000.0,
        actor_gpu_seconds=1_000_000.0,
    )
    reserve = BudgetUsage(
        reasoning_input_tokens=int(budgets["final_reader_input_reserve"]),
        reasoning_output_tokens=int(budgets["final_reader_output_reserve"]),
        reader_input_tokens=int(budgets["final_reader_input_reserve"]),
        reader_output_tokens=int(budgets["final_reader_output_reserve"]),
    )
    return GlobalLedger(limits, reserve)


class RealVerticalStack:
    def __init__(self, config: dict, *, retrieval_protocol: str = "per-example-public-context-diagnostic"):
        self.config = config
        self.retrieval_protocol = retrieval_protocol
        self.pooled_backends = {}
        root = Path(config["project"]["root"])
        cache = root / "cache/huggingface"
        actor_item = config["models"]["actor"]
        reranker_item = config["models"]["reranker"]
        retriever_item = config["models"]["retriever"]
        self.actor_tokenizer, actor_model = load_mistral3_generation(actor_item, cache_dir=cache)
        self.actor = JsonActor(
            TransformersGenerationBackend(actor_model, self.actor_tokenizer),
            model_revision=actor_item["revision"],
            tokenizer_revision=actor_item["revision"],
            prompt_dir=root / "prompts",
            format_repairs=int(config["generation"]["format_repairs"]),
        )
        self.encoder = E5MistralEncoder(
            retriever_item["repo_id"],
            retriever_item["revision"],
            query_instruction=retriever_item["query_instruction"],
            max_tokens=int(retriever_item["max_tokens"]),
            device="cuda",
            dtype=retriever_item["dtype"],
            cache_dir=str(cache),
        )
        reranker_tokenizer, reranker_model = load_mistral3_generation(reranker_item, cache_dir=cache)
        prompt_template = (root / reranker_item["prompt"]).read_text(encoding="utf-8")
        self.reranker = PointwiseMistralReranker(
            reranker_model,
            reranker_tokenizer,
            prompt_template,
            reranker_item["positive_completion"],
            reranker_item["negative_completion"],
        )

    def runner_for_sample(
        self,
        sample: PublicSample,
        call_budget: int,
        *,
        controller=None,
        ledger: GlobalLedger | None = None,
        cache: RetrievalCache | None = None,
        backend: LiveDenseRetriever | None = None,
    ):
        config = self.config
        if backend is None:
            if self.retrieval_protocol == "pooled-corpus":
                dataset = sample.corpus_id.split(":", 1)[0]
                if dataset not in self.pooled_backends:
                    chunks_path, manifest_path = resolve_pooled_index(config, dataset)
                    self.pooled_backends[dataset] = PooledDenseRetriever(dataset, chunks_path, manifest_path, self.encoder)
                backend = self.pooled_backends[dataset]
                passages = backend.passages
            else:
                passages = public_context_passages(
                    sample,
                    self.actor_tokenizer,
                    self.actor.tokenizer_revision,
                    chunk_tokens=int(config["retrieval"]["chunk_tokens"]),
                    overlap_tokens=int(config["retrieval"]["overlap_tokens"]),
                )
                backend = LiveDenseRetriever(sample.corpus_id, passages, self.encoder)
        else:
            passages = backend.passages
        ledger = ledger or make_ledger(config, call_budget)
        runner = EpisodeRunner(
            self.actor,
            CachedRetriever(backend, ledger, cache),
            controller or Pi0Controller("dependency_first"),
            reranker=self.reranker,
            initial_top_k=int(config["retrieval"]["initial_top_k"]),
            delivered_top_k=int(config["retrieval"]["delivered_top_k"]),
            frontier_cap=int(config["search"]["frontier_cap"]),
            proposals_per_route=int(config["search"]["proposals_per_route"]),
        )
        return runner, backend, len(passages)

    def run_one(self, sample: PublicSample, call_budget: int, *, controller=None):
        runner, backend, passage_count = self.runner_for_sample(sample, call_budget, controller=controller)
        return runner.run(sample), backend.offline_document_usage, passage_count


def _write_jsonl(path: Path, rows: Iterable[dict]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def official_subset_metrics(config: dict, dataset: str, writer: RunWriter, records: list[dict]) -> dict:
    private_dir = writer.run_dir / "private_evaluator_inputs" / dataset
    private_dir.mkdir(parents=True)
    if dataset == "musique":
        gold_path = private_dir / "gold.jsonl"
        pred_path = private_dir / "predictions.jsonl"
        _write_jsonl(gold_path, (record["raw"] for record in records))
        predictions = []
        for record in records:
            episode = record["episode"]
            route = episode.routes.get(episode.selected_route_id) if episode.selected_route_id else None
            support = []
            if route:
                for passage in route.observed_passages:
                    try:
                        support.append(int(passage.doc_id.rsplit(":", 1)[1]))
                    except ValueError:
                        pass
            predictions.append({
                "id": episode.sample.question_id,
                "predicted_answer": episode.answer.answer if episode.answer else "",
                "predicted_support_idxs": sorted(set(support)),
                "predicted_answerable": bool(episode.answer and not episode.answer.abstain),
            })
        _write_jsonl(pred_path, predictions)
        return run_musique_official(
            config["data"]["datasets"][dataset]["official_evaluator"],
            pred_path,
            gold_path,
            config.get("evaluation", {}).get("official_python"),
        )
    if dataset == "browsecomp_plus":
        return {
            "status": "pending_mistral_judge" if not config["models"]["judge"]["enabled"] else "requires_offline_judge_stage",
            "metric_label": "Accuracy (Mistral judge)",
            "judge_model": config["models"]["judge"]["repo_id"],
            "not_official_answer_evaluator": True,
        }
    if dataset == "multihop_rag":
        return {
            "status": "complete",
            "evaluator_kind": "official_deterministic_adaptation",
            "note": "answer metrics are in the isolated internal metric block; upstream overlap metric is not relabeled as exact match",
        }
    gold_path = private_dir / "gold.json"
    pred_path = private_dir / "predictions.json"
    gold_path.write_text(json.dumps([record["raw"] for record in records]), encoding="utf-8")
    answer, support, evidence = {}, {}, {}
    for record in records:
        episode = record["episode"]
        question_id = episode.sample.question_id
        route = episode.routes.get(episode.selected_route_id) if episode.selected_route_id else None
        _, facts = delivered_support_ids(route.observed_passages if route else ())
        answer[question_id] = episode.answer.answer if episode.answer else ""
        support[question_id] = [list(item) for item in sorted(facts)]
        evidence[question_id] = [list(item) for item in (episode.answer.reasoning_triples if episode.answer else ())]
    pred_path.write_text(json.dumps({"answer": answer, "sp": support, "evidence": evidence}), encoding="utf-8")
    return run_twowiki_official(
        config["data"]["datasets"][dataset]["official_evaluator"],
        pred_path,
        gold_path,
        python_executable=config.get("evaluation", {}).get("official_python"),
    )


def run_vertical(
    config: dict,
    writer: RunWriter,
    *,
    datasets: tuple[str, ...],
    role: str,
    limit: int,
    call_budget: int,
    controller_factory=None,
    retrieval_protocol: str = "per-example-public-context-diagnostic",
) -> dict:
    started = time.perf_counter()
    stack = RealVerticalStack(config, retrieval_protocol=retrieval_protocol)
    all_metrics: list[dict] = []
    official = {}
    offline_document_tokens = 0
    offline_document_gpu_seconds = 0.0
    per_dataset_records: dict[str, list[dict]] = {}
    for dataset in datasets:
        records = []
        for sample, reference, raw in load_fixed_examples(config, dataset, role, limit):
            controller = controller_factory() if controller_factory else Pi0Controller("dependency_first")
            if hasattr(controller, "run_on_stack"):
                episode, offline_usage, passage_count = controller.run_on_stack(stack, sample, call_budget)
            else:
                episode, offline_usage, passage_count = stack.run_one(sample, call_budget, controller=controller)
            offline_document_tokens += offline_usage.input_tokens
            offline_document_gpu_seconds += offline_usage.gpu_seconds
            for event in episode.events + episode.ledger.events:
                writer.append_event({
                    "dataset": dataset,
                    "question_id": sample.question_id,
                    "split_role": sample.split_role,
                    "corpus_id": sample.corpus_id,
                    "model_revision": stack.actor.model_revision,
                    "tokenizer_revision": stack.actor.tokenizer_revision,
                    "adapter_id": sample.metadata.get("adapter_id"),
                    "prompt_version": "v2.1-mistral",
                    "controller_id": getattr(controller, "controller_id", type(controller).__name__),
                    "episode_id": episode.episode_id,
                    **event,
                })
            metrics = None
            if episode.completion_status == CompletionStatus.COMPLETE and episode.answer and episode.selected_route_id:
                metrics = evaluate_episode(episode.answer, episode.routes[episode.selected_route_id].observed_passages, reference)
                all_metrics.append(metrics)
            writer.append_prediction({
                "dataset": dataset,
                "question_id": sample.question_id,
                "answer": episode.answer.answer if episode.answer else None,
                "citations": [asdict(value) for value in episode.answer.citations] if episode.answer else [],
                "completion_status": episode.completion_status.value,
                "stop_reason": episode.stop_reason,
                "metrics": metrics,
                "ledger": episode.ledger.used.to_dict(),
                "passage_count": passage_count,
            })
            records.append({"episode": episode, "raw": raw})
        per_dataset_records[dataset] = records
        official[dataset] = official_subset_metrics(config, dataset, writer, records)
    metric_means = {
        key: sum(float(item[key]) for item in all_metrics) / len(all_metrics)
        for key in all_metrics[0]
    } if all_metrics else {}
    gpu = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=name,uuid,driver_version,memory.total,memory.used", "--format=csv,noheader"],
        text=True,
    ).strip().splitlines()
    return {
        "metrics": metric_means,
        "official": official,
        "completed": len(all_metrics),
        "requested": sum(len(value) for value in per_dataset_records.values()),
        "resources": {
            "elapsed_seconds": time.perf_counter() - started,
            "offline_document_embedding_tokens": offline_document_tokens,
            "offline_document_embedding_gpu_seconds": offline_document_gpu_seconds,
            "gpus": gpu,
        },
    }
